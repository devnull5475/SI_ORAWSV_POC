LOG4PLSQL - ReadMe.txt
----------------------


For instalation and user information read : 


Current release  : .\docs\UserGuide.html
    Or 
Last release : http://log4plsql.sourceforge.net/docs/UserGuide.html

And the log4j documentation :
http://jakarta.apache.org/log4j/docs/documentation.html




-- end document --