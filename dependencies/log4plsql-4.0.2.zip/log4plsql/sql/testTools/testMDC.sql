/*
Feature tested

PLOG
       MDC
*/

set linesize 3000
exec PLOG.PURGE;

