/*
Feature tested

PLOG
    getLOG4PLSQVersion
       features        
*/

select PLOG.getLOG4PLSQVersion from DUAL;


/*
SQL> select PLOG.getLOG4PLSQVersion from DUAL;

GETLOG4PLSQVERSION
-------------------------------------------------------------------
3.0.0

SQL> 
*/