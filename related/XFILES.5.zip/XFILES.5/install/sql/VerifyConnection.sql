spool verifyConnection.log
--
var returnCode number
--
begin
  :returnCode := 2;
end;
/
exit :returnCODE
