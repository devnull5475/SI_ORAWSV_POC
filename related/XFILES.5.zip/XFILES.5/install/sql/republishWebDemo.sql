set echo on
--
connect sys/&1  as sysdba
--
def DEMONSTRATION_FOLDER = &2
--
spool republishWebDemo_&DEMONSTRATION_FOLDER..log
--
declare 
  res boolean;
  targetPath varchar2(700) := XDB_CONSTANTS.PUBLIC_FOLDER || '/' || '&DEMONSTRATION_FOLDER';
begin
  if dbms_xdb.existsResource(targetPath) then
    if not dbms_xdb.existsResource(targetPath || '/index.html') then
      dbms_xdb.link('/home/XFILES/src/WebDemo/webDemo.html',targetPath,'index.html',DBMS_XDB.LINK_TYPE_WEAK);
    end if;
  end if;
end;
/
commit
/
quit
