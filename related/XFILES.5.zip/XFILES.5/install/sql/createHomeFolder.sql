set echo on
spool createHomeFolder.log
--
call xdb_utilities.createHomeFolder()
/
--
quit