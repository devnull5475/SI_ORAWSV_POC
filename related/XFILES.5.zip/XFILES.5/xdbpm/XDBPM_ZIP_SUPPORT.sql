--
alter session set current_schema = XDBPM
/
--
DEF SOURCEPATH = /home/XDBPM/java/src 
--
DEF JAVASOURCENAME = ExternalConnectionProvider
DEF JAVACLASSPATH = com/oracle/st/xdb/pm/zip/ExternalConnectionProvider
--
@@XDBPM_COMPILE_JAVA   
--
DEF JAVASOURCENAME = ArchiveManager
DEF JAVACLASSPATH = com/oracle/st/xdb/pm/zip/ArchiveManager
--
@@XDBPM_COMPILE_JAVA   
DEF JAVASOURCENAME = RepositoryImport
DEF JAVACLASSPATH = com/oracle/st/xdb/pm/zip/RepositoryImport
--
@@XDBPM_COMPILE_JAVA 
--
DEF JAVASOURCENAME = RepositoryExport
DEF JAVACLASSPATH = com/oracle/st/xdb/pm/zip/RepositoryExport
--
@@XDBPM_COMPILE_JAVA 
--
DEF JAVASOURCENAME = ZipManager
DEF JAVACLASSPATH = com/oracle/st/xdb/pm/zip/ZipManager
--
@@XDBPM_COMPILE_JAVA 
--
alter session set current_schema = SYS
/
