--
create or replace and resolve java source
named "&JAVASOURCENAME"
using CLOB (select xdburiType('&SOURCEPATH/&JAVACLASSPATH..java').getClob() from dual)
/
show errors
--
declare
  shortname varchar2(128);
begin
	select dbms_java.shortname(NAME)
	  into shortname
	  from ALL_JAVA_CLASSES
	 where OWNER = 'XDBPM'
	   and SOURCE = '&JAVASOURCENAME';
  execute immediate 'grant execute on "' || shortname || '" to public';
end;
/
create or replace public synonym "&JAVASOURCENAME" for "&JAVASOURCENAME"
/
