--
set echo on
--
set serveroutput on
--
begin
  dbms_utility.compile_schema('XDBPM',TRUE);
end;
/
alter package XDB.XDBPM_HELPER compile
/
set pages 100
--
select object_name, object_type, status 
  from all_objects
 where owner= 'XDB' and object_name like 'XDBPM%'
 order by status, object_type, object_name
/
select object_name, object_type, status 
  from all_objects
 where owner= 'XDBPM'
 order by status, object_type, object_name
/
--
set echo off verify off
select case when INVALID_OBJECT_COUNT = 0 
                 then 'XDBPM Installation Successful : See "&XDBPM_LOG_FILE" for details'
                 else 'XDBPM Installation Failed : See "&XDBPM_LOG_FILE" for further details'
            end "Installation Status"
  from (
         select count(*) INVALID_OBJECT_COUNT
           from all_objects
          where OWNER='XDBPM' and status = 'INVALID'
       )
/
set echo on verify on
--
                  