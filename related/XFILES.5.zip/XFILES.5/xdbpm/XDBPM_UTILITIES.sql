--
-- XDBPM_UTILITIES should be created under XDBPM
--
alter session set current_schema = XDBPM
/
create or replace type RESOURCE_ID_TABLE
as table of RAW(16)
/
grant execute on RESOURCE_ID_TABLE to public
/
create or replace public synonym RESOURCE_ID_TABLE for RESOURCE_ID_TABLE
/
create or replace package XDBPM_UTILITIES
authid CURRENT_USER
as
   DEFAULT_FILENAME    constant varchar2(2000) := 'ls.xml';
   DEFAULT_DIRECTORY   constant varchar2(32)   := USER;
   DEFAULT_BATCH_SIZE  constant number(10)     := 1;
   
/*
**
** Deprecated in XDB_UTILITIES. Moved to XDB_ANALYZE_XMLSCHEMA
**
** procedure renameCollectionTable (XMLTABLE varchar2, XPATH varchar2, COLLECTION_TABLE_PREFIX varchar2);
** function printNestedTables(XML_TABLE varchar2) return XMLType;
** function getDefaultTableName(PATH VARCHAR2) return VARCHAR2;
**
*/

   function getBinaryContent(file bfile) return BLOB;
   function getBinaryContent(filename varchar2, directory varchar2 default DEFAULT_DIRECTORY) return BLOB;
   function getBinaryContent(file bfile, tempBLOB IN OUT BLOB) return BLOB;
   function getBinaryContent(filename varchar2, directory varchar2 default DEFAULT_DIRECTORY, tempBLOB IN OUT BLOB) return BLOB;

   function getFileContent(file bfile, charset varchar2 default DBMS_XDB_CONSTANTS.ENCODING_DEFAULT) return CLOB;
   function getFileContent(filename varchar2, directory varchar2 default DEFAULT_DIRECTORY, charset varchar2 default DBMS_XDB_CONSTANTS.ENCODING_DEFAULT) return CLOB;
   function getFileContent(file bfile, charset varchar2 default DBMS_XDB_CONSTANTS.ENCODING_DEFAULT, tempCLOB IN OUT CLOB) return CLOB;
   function getFileContent(filename varchar2, directory varchar2 default DEFAULT_DIRECTORY, charset varchar2 default DBMS_XDB_CONSTANTS.ENCODING_DEFAULT, tempCLOB IN OUT CLOB) return CLOB;
   
   procedure mkdir(folderPath varchar2,force varchar2 default 'FALSE');
   procedure mkdir(folderPath varchar2,force boolean  default FALSE);
   procedure rmdir(folderPath varchar2,force varchar2 default 'FALSE');
   procedure rmdir(folderPath varchar2,force boolean  default FALSE);
   
   procedure uploadFiles(FILELIST varchar2 default DEFAULT_FILENAME, DIRECTORY varchar2 default DEFAULT_DIRECTORY, TARGET_FOLDER varchar2 default XDB_CONSTANTS.FOLDER_USER_HOME , BATCH_SIZE number default DEFAULT_BATCH_SIZE);
   procedure uploadBinaryFiles(FILELIST varchar2 default DEFAULT_FILENAME, DIRECTORY varchar2 default DEFAULT_DIRECTORY, TARGET_FOLDER varchar2 default XDB_CONSTANTS.FOLDER_USER_HOME , BATCH_SIZE number default DEFAULT_BATCH_SIZE);
   procedure uploadTextFiles(FILELIST varchar2 default DEFAULT_FILENAME, DIRECTORY varchar2 default DEFAULT_DIRECTORY, TARGET_FOLDER varchar2 default XDB_CONSTANTS.FOLDER_USER_HOME , BATCH_SIZE number default DEFAULT_BATCH_SIZE);
   procedure uploadXMLFiles(FILELIST varchar2 default DEFAULT_FILENAME, DIRECTORY varchar2 default DEFAULT_DIRECTORY, TARGET_FOLDER varchar2 default XDB_CONSTANTS.FOLDER_USER_HOME , BATCH_SIZE number default DEFAULT_BATCH_SIZE);
   procedure uploadToXMLTable(FILELIST varchar2 default DEFAULT_FILENAME, DIRECTORY varchar2 default DEFAULT_DIRECTORY, TABLE_NAME varchar2, BATCH_SIZE number default DEFAULT_BATCH_SIZE);

   procedure updateXMLContent(path VARCHAR2, content XMLType);
   procedure updateBinaryContent(path VARCHAR2,content BLOB);
   procedure updateCharacterContent(path VARCHAR2,content CLOB,db_charset VARCHAR2);
   
   procedure createHomeFolder;
   procedure createPublicFolder;
   procedure setPublicIndexPageContent;

   function getXMLReference(PATH VARCHAR2) return REF XMLType;
   function getXMLReferenceByResID(RESOID RAW) return REF XMLType;
   function isCheckedOutByRESID(RESOID RAW) return BOOLEAN;
   function getVersionsByPath(path VARCHAR2) return RESOURCE_ID_TABLE pipelined;
   function getVersionsByResid(RESID RAW) return RESOURCE_ID_TABLE pipelined;

   function IS_VERSIONED(P_RESOURCE DBMS_XMLDOM.DOMDocument) return BOOLEAN;
   function IS_VERSIONED(P_RESOURCE XMLTYPE) return BOOLEAN;
   function IS_VERSIONED(P_RESOURCE_PATH VARCHAR2) return BOOLEAN;

   procedure UPDATECONTENT(P_RESOURCE_PATH VARCHAR2, P_CONTENT BLOB);
   procedure UPLOADRESOURCE(P_RESOURCE_PATH VARCHAR2, P_CONTENT BLOB, P_DUPLICATE_POLICY VARCHAR2 DEFAULT XDB_CONSTANTS.RAISE_ERROR);

   procedure printXMLToFile(xmlContent XMLType, targetDirectory varchar2, Filename VARCHAR2);

$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN

   -- Depricated Post 10.2.x : Provided by DBMS_XDB

   procedure changeOwner(resourcePath varchar2, owner varchar2, recursive boolean default false);

$ELSE   -- 11.1.0.1.0 

  function IS_VERSIONED(P_RESOURCE DBMS_XDBRESOURCE.XDBResource) return BOOLEAN;

  function migrateACL(ACL XMLTYPE) return XMLTYPE;
  function migrateACLResource(resourceXML XMLTYPE) return XMLTYPE;
  
  function serializeResource(xdbResource DBMS_XDBRESOURCE.XDBResource) return xmltype;
  function serializeEvent(repositoryEvent DBMS_XEVENT.XDBRepositoryEvent) return xmltype;

$END
--
end XDBPM_UTILITIES;
/
show errors
--
create or replace synonym XDB_UTILITIES for XDBPM_UTILITIES 
/
grant execute on XDBPM_UTILITIES to public
/
create or replace package body XDBPM_UTILITIES
as
   LOAD_ANY_RESOURCE    constant number(2) := 0;
   LOAD_BINARY_RESOURCE constant number(2) := 1;
   LOAD_CLOB_RESOURCE   constant number(2) := 2;
   LOAD_XML_RESOURCE    constant number(2) := 3;
   LOAD_XML_TABLE       constant number(2) := 5;
--
-- When using getBinaryContent() or getFileContent() the application must explicitly free the CLOB/BLOB that the function returns
--
   
   MIGRATE_ACL_10200_TO_11100 xmlType := XMLTYPE(
'<?xml version="1.0"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ACL="http://xmlns.oracle.com/xdb/acl.xsd">
	<xsl:output indent="yes" encoding="utf-8"/>
	<xsl:template match="@*|node()">
		<xsl:choose>
			<xsl:when test="((name()=''ace'') and (namespace-uri()=''http://xmlns.oracle.com/xdb/acl.xsd''))">
				<xsl:element name="ACL:ace">
					<xsl:copy-of select="ACL:grant"/>
					<xsl:copy-of select="ACL:principal"/>
					<xsl:copy-of select="ACL:privilege"/>
				</xsl:element>
			</xsl:when>
			<xsl:otherwise>
				<xsl:copy>
					<xsl:apply-templates select="@*|node()"/>
				</xsl:copy>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:template>
</xsl:stylesheet>');
--
-- Depricated on XDB_UTILITIES
--
procedure renameCollectionTable (XMLTABLE varchar2, XPATH varchar2, COLLECTION_TABLE_PREFIX varchar2)
as
begin
  XDB_ANALYZE_XMLSCHEMA.renameCollectionTable(XMLTABLE,XPATH,COLLECTION_TABLE_PREFIX);
end;
--
function printNestedTables(XML_TABLE varchar2) return XMLType
as
begin
  return XDB_ANALYZE_XMLSCHEMA.printNestedTables(XML_TABLE);
end;
--
function getDefaultTableName(PATH VARCHAR2) return VARCHAR2
as
begin
	return XDB_ANALYZE_XMLSCHEMA.getDefaultTableName(PATH);
end;
--
-- End deprecated methods
--
function getBinaryContent(file bfile,
		          tempBLOB IN OUT BLOB)
return BLOB
is
  targetFile      bfile;

  dest_offset     number :=  1;
  src_offset      number := 1;
  lang_context    number := 0;
  conv_warning    number := 0;
  begin
    targetFile := file;
    if (tempBLOB is null) then
      DBMS_LOB.createTemporary(tempBLOB,true,DBMS_LOB.SESSION);
    else 
      DBMS_LOB.trim(tempBLOB,0);
    end if;
    DBMS_LOB.fileopen(targetFile, DBMS_LOB.file_readonly);
    DBMS_LOB.loadBlobfromFile
    (
       tempBLOB,
       targetFile,
       DBMS_LOB.getLength(targetFile),
       dest_offset,
       src_offset
    );
    DBMS_LOB.fileclose(targetFile);
    return tempBLOB;
end;
--
function getBinaryContent(file bfile)
return BLOB
is
  tempBLOB BLOB := NULL;
begin
  return getBinaryContent(file,tempBLOB);
end;
--
function getBinaryContent(filename varchar2,
                          directory varchar2 default DEFAULT_DIRECTORY,
		          tempBLOB IN OUT BLOB)
return BLOB
is
   file            bfile := bfilename(directory,filename);
begin
  return getBinaryContent(file,tempBLOB);
end;
--
function getBinaryContent(filename varchar2,
                          directory varchar2 default DEFAULT_DIRECTORY)		      
return BLOB
is
   tempBLOB BLOB := NULL;
begin
  return getBinaryContent(filename,directory,tempBLOB);
end;
--
function getFileContent(file bfile,
		        charset varchar2 default DBMS_XDB_CONSTANTS.ENCODING_DEFAULT,
		        tempCLOB IN OUT CLOB)
return CLOB
is
  targetFile      bfile;

  dest_offset     number :=  1;
  src_offset      number := 1;
  lang_context    number := 0;
  conv_warning    number := 0;
  begin
    targetFile := file;
    if (tempCLOB is null) then
      DBMS_LOB.createTemporary(tempCLOB,true,DBMS_LOB.SESSION);
    else 
      DBMS_LOB.trim(tempCLOB,0);
    end if;
    DBMS_LOB.fileopen(targetFile, DBMS_LOB.file_readonly);
    DBMS_LOB.loadClobfromFile
    (
       tempCLOB,
       targetFile,
       DBMS_LOB.getLength(targetFile),
       dest_offset,
       src_offset,
       nls_charset_id(charset),
       lang_context,
       conv_warning
    );
    DBMS_LOB.fileclose(targetFile);
    return tempCLOB;
end;
--
function getFileContent(file bfile,
		        charset varchar2 default DBMS_XDB_CONSTANTS.ENCODING_DEFAULT )
return CLOB
is
  tempCLOB CLOB := NULL;
begin
  return getFileContent(file,charset,tempCLOB);
end;
--
-- When using getFileContent() the application must explicitly free the CLOB that the function returns
--
function getFileContent(filename varchar2,
                        directory varchar2 default DEFAULT_DIRECTORY,
		        charset varchar2 default DBMS_XDB_CONSTANTS.ENCODING_DEFAULT,
		        tempCLOB IN OUT CLOB)
return CLOB
is
   file            bfile := bfilename(directory,filename);
begin
  return getFileContent(file,charset,tempCLOB);
end;
--
function getFileContent(filename varchar2,
                        directory varchar2 default DEFAULT_DIRECTORY,
		        charset varchar2 default DBMS_XDB_CONSTANTS.ENCODING_DEFAULT)		      
return CLOB
is
   tempCLOB CLOB := NULL;
begin
  return getFileContent(filename,directory,charset,tempCLOB);
end;
--
procedure makeFolders(TARGET_FOLDER varchar2,FileList XMLType)
as
  cursor getFolderList(filelist XMLType) is
  select *
    from ( 
            select extractValue(value(f),'/directory/text()') FOLDERPATH
              from table(xmlsequence(extract(filelist,'//directory'))) f
         );
begin
  for f in getFolderList(FileList) loop
    mkdir(TARGET_FOLDER || f.FOLDERPATH, TRUE);
  end loop;
end;
--
procedure uploadFileContent(OPERATION NUMBER, DIRECTORY VARCHAR2, FILELIST VARCHAR2, TARGET VARCHAR2, BATCH_SIZE NUMBER)
as
  file_not_found1 exception;
  PRAGMA EXCEPTION_INIT( file_not_found1 , -22288 );

  file_not_found2 exception;
  PRAGMA EXCEPTION_INIT( file_not_found2 , -22285 );

  cursor getFileList(filelist XMLType) is
  select *
    from ( 
            select extractValue(value(f),'/file/text()')    FILENAME,
                   nvl(extractValue(value(f),'/file/@replace'),'FALSE')  REPLACE,
                   extractValue(value(f),'/file/@encoding') ENCODING,
                   nvl(extractValue(value(f),'/file/@binary'),'FALSE')   BINARY
              from table(xmlsequence(extract(filelist,'//file'))) f
         );
   
  REPLACE_MODE boolean;
  BINARY_MODE  boolean;
  XML_MODE     boolean;
  
  REPLACE_FILE boolean;

  FILELIST_CONTENT XMLTYPE;

  FILE_ENCODING varchar2(32) := DBMS_XDB_CONSTANTS.ENCODING_DEFAULT;
  
  CLOB_CONTENT CLOB;
  BLOB_CONTENT BLOB;
  XML_CONTENT  XMLType;
  
  TARGET_RESOURCE VARCHAR2(2000);
  RES             BOOLEAN;
  STATEMENT       VARCHAR2(2000);
  FILECOUNT       pls_integer := 0;
begin
  FILELIST_CONTENT := XMLType(bfilename(DIRECTORY,FILELIST),nls_charset_id(DBMS_XDB_CONSTANTS.ENCODING_DEFAULT));

  if (OPERATION != LOAD_XML_TABLE) then
    makeFolders(TARGET,FILELIST_CONTENT);
  end if;

  REPLACE_MODE := FILELIST_CONTENT.existsNode('/Upload/files[@replace="true"]') = 1;
  BINARY_MODE := FILELIST_CONTENT.existsNode('/Upload/files[@binary="true"]') = 1;
  XML_MODE := FILELIST_CONTENT.existsNode('/Upload/files[@xml="true"]') = 1;
  
  for f in getFileList(FILELIST_CONTENT) loop
    
    TARGET_RESOURCE := TARGET || F.FILENAME;
      
    if (F.ENCODING is not null) then
      FILE_ENCODING := F.ENCODING;
    else 
      FILE_ENCODING := DBMS_XDB_CONSTANTS.ENCODING_DEFAULT;
    end if;

    begin
          
      if (OPERATION != LOAD_XML_TABLE) then
        REPLACE_FILE    := (REPLACE_MODE and (f.REPLACE <> 'false')) or (f.REPLACE = 'true');
        if (REPLACE_FILE and dbms_xdb.existsResource(TARGET_RESOURCE)) then
          DBMS_XDB.deleteResource(TARGET_RESOURCE);
        end if;
 
        if (OPERATION = LOAD_ANY_RESOURCE or OPERATION = LOAD_BINARY_RESOURCE) then
          res := dbms_xdb.createResource(TARGET_RESOURCE,bfilename(DIRECTORY,F.FILENAME));
        end if;
       
        if (OPERATION = LOAD_CLOB_RESOURCE) then 
           res := dbms_xdb.createResource(TARGET_RESOURCE,bfilename(DIRECTORY,F.FILENAME),NLS_CHARSET_ID(FILE_ENCODING));
        end if;

        if (OPERATION = LOAD_XML_RESOURCE) then
          res := dbms_xdb.createResource(TARGET_RESOURCE,xmltype(bfilename(DIRECTORY,F.FILENAME),nls_charset_id(FILE_ENCODING)));
        end if;
        
      else
        STATEMENT := ' insert into "' || TARGET || '" values ( xmltype ( bfilename(:1,:2), NLS_CHARSET_ID(:3) ) )';
        EXECUTE IMMEDIATE STATEMENT USING DIRECTORY, F.FILENAME, FILE_ENCODING;
      end if;
      
      filecount := filecount + 1;
 
      if (filecount = BATCH_SIZE) then
        filecount := 0;
        commit;
      end if;

    exception    
      when FILE_NOT_FOUND1 then 
        XDB_OUTPUT.createLogFile(TARGET || FILELIST || '.log',FALSE);
        XDB_OUTPUT.writeLogFileEntry('Error opening ' || F.FILENAME);
        XDB_OUTPUT.logException();
        XDB_OUTPUT.flushLogFile();
      when FILE_NOT_FOUND2 then 
        XDB_OUTPUT.createLogFile(TARGET || FILELIST || '.log',FALSE);
        XDB_OUTPUT.writeLogFileEntry('Error opening ' || F.FILENAME);
        XDB_OUTPUT.logException();
        XDB_OUTPUT.flushLogFile();
      when others then
        XDB_OUTPUT.createLogFile(TARGET || FILELIST || '.log',FALSE);
        XDB_OUTPUT.writeLogFileEntry('Error processing ' || F.FILENAME);
        XDB_OUTPUT.logException();
        XDB_OUTPUT.flushLogFile();
    end;
 
  end loop;
  
end;
--
procedure uploadBinaryFiles(FILELIST varchar2 default DEFAULT_FILENAME, DIRECTORY varchar2 default DEFAULT_DIRECTORY, TARGET_FOLDER varchar2 default XDB_CONSTANTS.FOLDER_USER_HOME , BATCH_SIZE number default DEFAULT_BATCH_SIZE)
as
begin
  uploadFileContent(LOAD_BINARY_RESOURCE,DIRECTORY,FILELIST,TARGET_FOLDER,BATCH_SIZE);
end;
--
procedure uploadTextFiles(FILELIST varchar2 default DEFAULT_FILENAME, DIRECTORY varchar2 default DEFAULT_DIRECTORY, TARGET_FOLDER varchar2 default XDB_CONSTANTS.FOLDER_USER_HOME , BATCH_SIZE number default DEFAULT_BATCH_SIZE)
as
begin
  uploadFileContent(LOAD_CLOB_RESOURCE,DIRECTORY,FILELIST,TARGET_FOLDER,BATCH_SIZE);
end;
--
procedure uploadXMLFiles(FILELIST varchar2 default DEFAULT_FILENAME, DIRECTORY varchar2 default DEFAULT_DIRECTORY, TARGET_FOLDER varchar2 default XDB_CONSTANTS.FOLDER_USER_HOME , BATCH_SIZE number default DEFAULT_BATCH_SIZE)
as
begin
  uploadFileContent(LOAD_XML_RESOURCE,DIRECTORY,FILELIST,TARGET_FOLDER,BATCH_SIZE);
end;
--
procedure uploadToXMLTable(FILELIST varchar2 default DEFAULT_FILENAME, DIRECTORY varchar2 default DEFAULT_DIRECTORY, TABLE_NAME varchar2, BATCH_SIZE number default DEFAULT_BATCH_SIZE)
as
begin
  uploadFileContent(LOAD_XML_TABLE,DIRECTORY, FILELIST, TABLE_NAME, BATCH_SIZE);
end;
--
-- Legacy Method.
--
procedure uploadFiles(FILELIST varchar2 default DEFAULT_FILENAME, DIRECTORY varchar2 default DEFAULT_DIRECTORY, TARGET_FOLDER varchar2 default XDB_CONSTANTS.FOLDER_USER_HOME , BATCH_SIZE number default DEFAULT_BATCH_SIZE)
as
begin
  uploadFileContent(LOAD_ANY_RESOURCE,DIRECTORY,FILELIST,TARGET_FOLDER,BATCH_SIZE);
end;
--
procedure createFolderTree(folderPath varchar2)
as
  pathSeperator varchar2(1) := '/';
  parentFolderPath varchar2(256);
  result boolean;
begin
  if (not dbms_xdb.existsResource(folderPath)) then
    if instr(folderPath,pathSeperator,-1) > 1 then
      parentFolderPath := substr(folderPath,1,instr(folderPath,pathSeperator,-1)-1);    
      createFolderTree(parentFolderPath);
    end if;
    result := dbms_xdb.createFolder(folderPath);
  end if;
end;
--
procedure mkdir(folderPath varchar2,force boolean default false)
as
  res boolean;
begin
  if (not dbms_xdb.existsResource(folderPath)) then
    if (force) then
      createFolderTree(folderPath);
    else
      res := dbms_xdb.createFolder(folderPath);
    end if;
  end if;
end;
--
procedure mkdir(folderPath varchar2,force varchar2 default 'FALSE')
as
  f boolean;
begin
  mkdir(folderPath,upper(force) = 'TRUE');
end;
--
procedure deleteFolderTree(folderPath varchar2)
as
  cursor getSubFolders is
  select path, extractValue(res,'/Resource/RefCount') REFCOUNT
    from path_view
   where under_path(res,1,folderPath) = 1;

begin
  delete 
    from path_view
   where under_path(res,1,folderPath) = 1
     and existsNode(res,'/Resource[@Container = "false"]') = 1;
   
   -- At this point only subFolders should remain.
   -- Delete Recursively where REFCOUNT is 1 and remove Link where REFCOUNT > 1
   
   for folder in getSubFolders loop
     if (folder.REFCOUNT = 1 ) then
       deleteFolderTree(folder.path);
     else
       dbms_xdb.deleteResource(folder.path);
     end if;
   end loop;

   dbms_xdb.deleteResource(folderPath);
end;
--
procedure rmdir(folderPath varchar2,force boolean default FALSE)
as
begin
  if (force) then
    deleteFolderTree(folderPath);
  else
    dbms_xdb.deleteResource(folderPath);
  end if;
end;
--
procedure rmdir(folderPath varchar2,force varchar2 default 'FALSE')
as
begin
  rmdir(folderPath,upper(force) = 'TRUE');
end;
--
procedure cloneXMLContent(path varchar2)
as
begin
  update resource_view
     set res = updateXML(res,'/Resource/DisplayName',extract(res,'/Resource/DisplayName'))
   where equals_path(res, path) = 1;
end; 
-- 
procedure updateXMLContent(path varchar2, content xmltype)
as
   defaultTableName varchar2(32);
   sqlStatement varchar2(1000);
begin
   defaultTableName := XDB_ANALYZE_XMLSCHEMA.getDefaultTableName(path);
   cloneXMLContent(path);
   sqlStatement := 'update "' || defaultTableName || '" d set object_value = :1 where ref(d) = xdb_utilities.getXMLReference(:2)';
   execute immediate sqlStatement using content , path;
end;
--
procedure updateBinaryContent(path VARCHAR2,content BLOB)
is 
  xmllob BLOB;
begin
  update RESOURCE_VIEW
     set res = updateXML(res,'/Resource/DisplayName/text()',extractValue(res,'/Resource/DisplayName/text()'))
   where equals_path(res,path) = 1;
  select extractValue(res,'/Resource/XMLLob') 
    into xmllob
    from RESOURCE_VIEW 
   where equals_path(res,path) = 1;
  dbms_lob.open(xmllob,dbms_lob.lob_readwrite);
  dbms_lob.trim(xmllob,0);
  dbms_lob.copy(xmllob,content,dbms_lob.getLength(content),1,1);
  dbms_lob.close(xmllob);
end;
--
procedure updateCharacterContent(path VARCHAR2,content CLOB,db_charset VARCHAR2)
is 
  xmllob        BLOB;
  source_offset integer := 1;
  target_offset integer := 1;
  warning       integer;
  lang_context  integer := 0;
begin
  update RESOURCE_VIEW
     set res = updateXML(res,'/Resource/DisplayName/text()',extractValue(res,'/Resource/DisplayName/text()'))
   where equals_path(res,path) = 1;
  select extractValue(res,'/Resource/XMLLob') 
    into xmllob
    from RESOURCE_VIEW 
   where equals_path(res,path) = 1;
  dbms_lob.open(xmllob,dbms_lob.lob_readwrite);
  dbms_lob.trim(xmllob,0);
  dbms_lob.convertToBlob(xmllob,content,dbms_lob.getLength(content),source_offset,target_offset,nls_charset_id(db_charset),lang_context,warning);
  dbms_lob.close(xmllob);
end;
--
function getXMLReferenceByResID(resoid RAW)
return REF XMLType
as
begin
  return XDB_HELPER.getXMLReferenceByResID(resoid);
end;
--
function getXMLReference(path varchar2)
return REF XMLType
as
begin
  return XDB_HELPER.getXMLReference(path);
end;
--
function isCheckedOutbyRESID(RESOID RAW)
return BOOLEAN
as 
begin
  return XDB_HELPER.isCheckedOutByRESID(RESOID);
end;
--
procedure createHomeFolder
as
begin
  XDB_HELPER.createHomeFolder(XDB_USERNAME.GET_USERNAME());
end;
--
procedure createPublicFolder
as
begin
  XDB_HELPER.createPublicFolder(XDB_USERNAME.GET_USERNAME());
end;
--
function getVersionsByPath(path VARCHAR2)
return RESOURCE_ID_TABLE pipelined
as
  RESOURCE_ID raw(16);
  SOURCE_LIST DBMS_XDB_VERSION.RESID_LIST_TYPE;
begin
  select resid 
    into RESOURCE_ID
    from resource_view
   where equals_path(res,path) = 1;
  pipe row (RESOURCE_ID);
  SOURCE_LIST := DBMS_XDB_VERSION.GETPREDECESSORS(PATH); 
  while SOURCE_LIST.COUNT > 0 loop
    pipe row (SOURCE_LIST(1));
    SOURCE_LIST := DBMS_XDB_VERSION.GETPREDSBYRESID(SOURCE_LIST(1));
  end loop;
  return;
end;
--
function getVersionsByResid(RESID RAW)
return RESOURCE_ID_TABLE pipelined
as
  SOURCE_LIST DBMS_XDB_VERSION.RESID_LIST_TYPE;
begin
  pipe row (RESID);
  SOURCE_LIST := DBMS_XDB_VERSION.GETPREDSBYRESID(RESID); 
  while SOURCE_LIST.COUNT > 0 loop
    pipe row (SOURCE_LIST(1));
    SOURCE_LIST := DBMS_XDB_VERSION.GETPREDSBYRESID(SOURCE_LIST(1));
  end loop;
  return;
end;
--
procedure printXMLToFile(xmlContent XMLType, targetDirectory varchar2, Filename VARCHAR2)
is
   fHandle utl_file.File_Type;
   
   xmlText CLOB := xmlContent.getClobVal();
   xmlTextCopy CLOB;
   xmlTextSize binary_integer := dbms_lob.getLength(xmlText) + 1;

   offset    binary_integer := 1;
   buffer    varchar2(32767);
   linesize  binary_integer := 32767;
   byteCount binary_integer; 
   lob1 clob;
begin
   dbms_lob.createtemporary(xmlTextCopy,TRUE);
   dbms_lob.copy(xmlTextCopy, xmlText, xmlTextSize);
   fhandle  := utl_file.fopen(targetDirectory,Filename,'w',linesize);

   while (offset < xmlTextSize)  loop
     if (xmlTextSize - offset > linesize) then
       byteCount := linesize;
     else
       byteCount := xmlTextSize - offset;
     end if;
     dbms_lob.read(xmlTextCopy, byteCount, offset, buffer);
     offset := offset + byteCount;
     utl_file.put(fHandle, buffer);
     utl_file.fflush(fHandle);
   end loop;
   utl_file.new_line(fhandle);
   utl_file.fclose(fhandle);
   dbms_lob.freeTemporary(xmlTextCopy);
end;
--
procedure setPublicIndexPageContent
as
begin
  XDB_HELPER.setPublicIndexPageContent(XDB_USERNAME.GET_USERNAME());
end;
--
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
--
procedure changeOwner(resourcePath varchar2, owner varchar2, recursive boolean default false)
as
  cursor recursiveOperation is
    select path 
      from path_view 
     where under_path(res,resourcePath) = 1;
begin
  update resource_view
     set res = updateXml(res,'/Resource/Owner/text()',owner)
  where equals_path(res,resourcePath) = 1;
  
  if (recursive) then
    for res in recursiveOperation loop
     update resource_view
        set res = updateXml(res,'/Resource/Owner/text()',owner)
      where equals_path(res,res.path) = 1;
    end loop;
  end if;
end;
--
$ELSE
--
function migrateACL(ACL XMLTYPE)
return XMLTYPE
as
  newACL         XMLTYPE;
begin 
  newACL := ACL;
  if (newACL.isSchemaValid() = 0) then
    newACL := newACL.TRANSFORM(MIGRATE_ACL_10200_TO_11100);
  end if;
  return newACL;
end;
--
function migrateACLResource(resourceXML XMLTYPE)
return XMLTYPE
as
  ACL         XMLTYPE;
  newResource XMLTYPE;
begin
  newResource := resourceXML;
  ACL := RESOURCEXML.extract('/r:Resource/r:Contents/*', XDB_NAMESPACES.RESOURCE_PREFIX_R);
  if (ACL.isSchemaValid() = 0) then
    ACL := ACL.TRANSFORM(MIGRATE_ACL_10200_TO_11100);
    select UPDATEXML
           (
             RESOURCEXML,
             '/r:Resource/r:Contents/*', 
             ACL,
             XDB_NAMESPACES.RESOURCE_PREFIX_R
            )
       into NEWRESOURCE 
       from DUAL;
  end if;
  return NEWRESOURCE;   
end;
--
function addResource(root in out DBMS_XMLDOM.DOMELEMENT, xdbResource dbms_xdbResource.XDBResource)
return DBMS_XMLDOM.DOMELEMENT
as
  doc          dbms_xmldom.DOMDocument;
  elem         dbms_xmldom.DOMElement;
  text         dbms_xmldom.DOMText;
begin
/*
  doc  := dbms_xdbResource.makeDocument(xdbResource);
  elem := dbms_xmldom.getDocumentElement(doc);
  doc  := dbms_xmldom.getOwnerDocument(dbms_xmldom.makeNode(root));
  elem := dbms_xmldom.makeElement(dbms_xmldom.importNode(doc,dbms_xmldom.makeNode(elem),TRUE));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(elem)));
*/  
  doc  := dbms_xmldom.getOwnerDocument(dbms_xmldom.makeNode(root));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'ACL', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getACL(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'Author', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getAuthor(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'CharacterSet', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getCharacterSet(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'Comment', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getComment(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'ContentType', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getContentType(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'CreationDate', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getCreationDate(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'Creator', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getCreator(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'DisplayName', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getDisplayName(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'Language', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getLanguage(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'ModificationDate', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getModificationDate(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'LastModifier', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getLastModifier(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'Owner', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getOwner(xdbResource)))));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'RefCount', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdbResource.getRefCOunt(xdbResource)))));
  
  return root;
end;
--
function serializeResource(xdbResource dbms_xdbResource.XDBResource)
return xmltype
as
  userMetadata XMLType;
  doc          dbms_xmldom.DOMDocument;
  root         dbms_xmldom.DOMElement;
  elem         dbms_xmldom.DOMElement;
  text         dbms_xmldom.DOMText;
begin
  doc  := dbms_xmldom.newDOMDocument();
  root := dbms_xmldom.createElement(doc,'Resource',XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE);
  root := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(doc),dbms_xmldom.makeNode(root)));
  root := addResource(root,xdbResource);
  return dbms_xmldom.getXMLType(doc);
end;
--
function serializeEvent(repositoryEvent dbms_xevent.XDBRepositoryEvent) 
return xmltype
as
  doc          dbms_xmldom.DOMDocument;
  root         dbms_xmldom.DOMElement;
  elem         dbms_xmldom.DOMElement;
  text         dbms_xmldom.DOMText;
  textValue    varchar2(2000);
  xdbEvent     dbms_xevent.XDBEvent;

  resourcePath varchar2(700);
  
begin
  xdbEvent := dbms_xevent.getXDBEvent(repositoryEvent);
  doc  := dbms_xmldom.newDOMDocument();
  root := dbms_xmldom.createElement(doc,'ResourceEvent',XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE);
  root := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(doc),dbms_xmldom.makeNode(root)));
  DBMS_XMLDOM.SETATTRIBUTE(root,'xmlns',XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE);

  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'CurrentUser', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xevent.getCurrentUser(xdbEvent)))));

/*  
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'DAVOwner', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xevent.getDAVOwner(repositoryEvent)))));

  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'DAVToken', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xevent.getDAVToken(repositoryEvent)))));

  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'ExpiryDate', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xevent.getExpiry(repositoryEvent)))));
*/
  
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'EventType', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xevent.getEvent(xdbEvent)))));

  resourcePath := dbms_xevent.getName(dbms_xevent.getPath(repositoryEvent));
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'resourcePath', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,resourcePath))));

  -- Append Resource ID to Payload
  
/*
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'ResourceID', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  text := dbms_xmldom.makeText(dbms_xmldom.appendChild(dbms_xmldom.makeNode(elem),dbms_xmldom.makeNode(dbms_xmldom.createTextNode(doc,dbms_xdb.getResOID(resourcePath)))));
*/
  
  -- Append Old Resource details to Payload
   
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'new', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  elem := addResource(elem, dbms_xevent.getResource(repositoryEvent));

  -- Append New Resource details to Payload
  
/*
  elem := dbms_xmldom.makeElement(dbms_xmldom.appendChild(dbms_xmldom.makeNode(root),dbms_xmldom.makeNode(dbms_xmldom.createElement(doc,'old', XDB_NAMESPACES.RESOURCE_EVENT_NAMESPACE)))); 
  elem := addResource(elem, dbms_xevent.getOldResource(repositoryEvent));
*/
  return dbms_xmldom.getXMLType(doc);

end;
--
$END
--
-- From a DBMS_XMLDOM.DOMDocument object
--
function IS_VERSIONED(P_RESOURCE DBMS_XMLDOM.DOMDocument) 
return BOOLEAN
as
  V_RESOURCE_ELEMENT  DBMS_XMLDOM.DOMElement;
begin
  V_RESOURCE_ELEMENT := DBMS_XMLDOM.getDocumentElement(P_RESOURCE);
  return DBMS_XMLDOM.getAttribute(V_RESOURCE_ELEMENT,'IsVersion') = 'false';
end;
--
-- From an XMLType object
--
function IS_VERSIONED(P_RESOURCE XMLTYPE) 
return BOOLEAN
as
begin
  return IS_VERSIONED(DBMS_XMLDOM.NEWDOMDocument(P_RESOURCE));
end;
--
-- From a Path
--
function IS_VERSIONED(P_RESOURCE_PATH VARCHAR2) 
return BOOLEAN
as
  V_RESOURCE          XMLType; 
begin
--
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
  select RES 
    into V_RESOURCE
    from RESOURCE_VIEW
   where equals_path(res,P_RESOURCE_PATH) = 1;
  return IS_VERSIONED(V_RESOURCE);
$ELSE
  return IS_VERSIONED(DBMS_XDB.getResource(P_RESOURCE_PATH));
$END
--
end;
--
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
$ELSE
--
-- From an XDB.XDB$RESOURCE object (11.1.x and Greater) 
--
function IS_VERSIONED(P_RESOURCE DBMS_XDBRESOURCE.XDBRESOURCE) 
return BOOLEAN
as
begin
  return IS_VERSIONED(DBMS_XDBRESOURCE.makeDocument(P_RESOURCE));
end;
--
$END
--
procedure UPDATECONTENT(P_RESOURCE_PATH VARCHAR2, P_CONTENT BLOB) 
as
  V_LOB_LOCATOR BLOB;
  V_XMLREF      REF XMLTYPE;
begin
  select extractValue(RES,'/Resource/XMLLob'), extractValue(RES,'/Resource/XMLRef') 
    into V_LOB_LOCATOR, V_XMLREF
    from RESOURCE_VIEW
   where equals_path(RES,P_RESOURCE_PATH) = 1
     for update;

  if (V_LOB_LOCATOR is not null) then
    DBMS_LOB.TRIM(V_LOB_LOCATOR,0);
    DBMS_LOB.COPY(V_LOB_LOCATOR,P_CONTENT,DBMS_LOB.getLength(P_CONTENT),1,1);
    return;
  end if;
  
  if (V_XMLREF is not null) then
    update RESOURCE_VIEW
       set RES = updateXML(RES,'/Resource/Contents',xmltype(P_CONTENT,nls_charset_id('AL32UTF8')))
     where equals_path(RES,P_RESOURCE_PATH) = 1;
   return;
 end if;
end;
--
procedure UPLOADRESOURCE(P_RESOURCE_PATH VARCHAR2, P_CONTENT BLOB, P_DUPLICATE_POLICY VARCHAR2 DEFAULT XDB_CONSTANTS.RAISE_ERROR)
as
/*
    Positibilites :

       1. Resource does not exist or Item Exists and duplicate policy is RAISE;

       2. Resource is not versioned
          - Version it
          - Check it out
          - Update it
          - Check it back in

       3. Resource is versioned but is not checked out
          - Check it out
          - Update it
          - Check it back in
   
       4. Resource already checked out
          - Update it. 
*/

  V_RESULT                BOOLEAN;
  V_CURRENTLY_CHECKED_OUT BOOLEAN;
  V_RESID                 RAW(16);
begin

  if ((not DBMS_XDB.existsResource(P_RESOURCE_PATH)) or (P_DUPLICATE_POLICY = XDB_CONSTANTS.RAISE_ERROR)) then
    V_RESULT := DBMS_XDB.createResource(P_RESOURCE_PATH,P_CONTENT);
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
$ELSE
    -- 
    -- Corner case - /dev/null type folder where the resource is deleted by a repository event.
    -- 
    if DBMS_XDB.existsResource(P_RESOURCE_PATH) then
      DBMS_XDB.refreshContentSize(P_RESOURCE_PATH);
    end if;
$END
    return;
  end if;      
    
  if (P_DUPLICATE_POLICY = XDB_CONSTANTS.OVERWRITE) then
    updateContent(P_RESOURCE_PATH,P_CONTENT);
    -- DBMS_XDBRESOURCE.setContent(V_RESOURCE,P_CONTENT);
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
$ELSE
    DBMS_XDB.refreshContentSize(P_RESOURCE_PATH);
$END
  end if;

  if (P_DUPLICATE_POLICY = XDB_CONSTANTS.VERSION) then
    if (not IS_VERSIONED(P_RESOURCE_PATH)) then
      V_RESID := DBMS_XDB_VERSION.makeVersioned(P_RESOURCE_PATH);
    end if;

    V_CURRENTLY_CHECKED_OUT := TRUE;
    if (not DBMS_XDB_VERSION.isCheckedOut(P_RESOURCE_PATH)) then
      V_CURRENTLY_CHECKED_OUT := FALSE;
      DBMS_XDB_VERSION.checkOut(P_RESOURCE_PATH);
    end if;

    -- DBMS_XDBRESOURCE.setContent(V_RESOURCE,P_CONTENT);
    updateContent(P_RESOURCE_PATH,P_CONTENT);

$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
$ELSE
    DBMS_XDB.refreshContentSize(P_RESOURCE_PATH);
$END

    if (not V_CURRENTLY_CHECKED_OUT) then
      V_RESID := DBMS_XDB_VERSION.checkIn(P_RESOURCE_PATH);
    end if;	         

    return;
  end if;
end;
--
end XDBPM_UTILITIES;
/
show errors 
--
alter package XDB.XDBPM_HELPER compile
/
alter session set current_schema = SYS
/
--