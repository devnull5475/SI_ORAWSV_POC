--
-- XDB_MONITOR should be created under XDBPM
--
alter session set current_schema = XDBPM
/
create or replace package XDBPM_MONITOR
authid DEFINER
as
   function getStatistics return XMLType;
   function getLOBUsage(stats XMLTYPE) return XMLType;
   function getTime(stats XMLTYPE) return timestamp;
   procedure initializeTimer;
   function  getElapsedTime return INTERVAL DAY TO SECOND;
end;
/
show errors
--
create or replace synonym XDB_MONITOR for XDBPM_MONITOR
/
grant execute on XDBPM_MONITOR to public
/
create or replace package body XDBPM_MONITOR
as
--
  START_TIME timestamp;
--  
function getStatistics 
return XMLType
as
    time                   timestamp;
    ORA_PID                number;
    ORA_SID                number;
    OS_PID                 number;
    SESSION_PGA_MEMORY     number;
    SESSION_PGA_MEMORY_MAX number;
    SESSION_UGA_MEMORY     number;
    SESSION_UGA_MEMORY_MAX number;
    PGA_USED_MEMORY        number;
    PGA_ALLOC_MEMORY       number;
    PGA_FREEABLE_MEMORY    number;
    PGA_MAX_MEMORY         number;
    CACHE_LOBS             number;
    NO_CACHE_LOBS          number;
    ABSTRACT_LOBS          number;
    TEMP_FILE_USAGE	   number;

    statistics             XMLType;
begin

  select distinct SID 
    into ORA_SID 
    from V$MYSTAT;

  select PID,SPID,
         PGA_USED_MEM,PGA_ALLOC_MEM,PGA_FREEABLE_MEM,PGA_MAX_MEM
    into ORA_PID, OS_PID, 
         PGA_USED_MEMORY, PGA_ALLOC_MEMORY, PGA_FREEABLE_MEMORY, PGA_MAX_MEMORY
    from V$PROCESS p, V$SESSION s
   where p.addr = s.paddr
     and s.sid =  ORA_SID;
 
  select value 
   into SESSION_PGA_MEMORY
   from v$mystat st,v$statname n
  where n.name = 'session pga memory'
    and n.statistic# = st.statistic#;

  select value 
   into SESSION_PGA_MEMORY_MAX
   from v$mystat st,v$statname n
  where n.name = 'session pga memory max'
    and n.statistic# = st.statistic#;

  select value 
   into SESSION_UGA_MEMORY
   from v$mystat st,v$statname n
  where n.name = 'session uga memory'
    and n.statistic# = st.statistic#;

  select value 
   into SESSION_UGA_MEMORY_MAX
   from v$mystat st,v$statname n
  where n.name = 'session uga memory max'
    and n.statistic# = st.statistic#;

  begin
    select l.cache_lobs, l.nocache_lobs, l.abstract_lobs
      into CACHE_LOBS, NO_CACHE_LOBS, ABSTRACT_LOBS
      from v$temporary_lobs l, v$session s
     where s.audsid = SYS_CONTEXT('USERENV', 'SESSIONID')
       and s.sid = l.sid;
  exception
    when others then
      null;
  end;

  select sum(USER_BYTES) 
   into TEMP_FILE_USAGE 
   from SYS.DBA_TEMP_FILES;
     
  select systimestamp
    into TIME
    from dual;

   select xmlElement
          (
	    "statisticsSnapshot",
            xmlForest
            (
	      OS_PID as "operatingSystemPID",
       	      ORA_PID as "databasePID",
       	      ORA_SID as "databaseSID",
              TIME as "snapshotTimestamp",
              TEMP_FILE_USAGE as "tempSpaceUsed"
            ),
            xmlElement
            (
              "PGA",
              xmlForest
              (
                SESSION_PGA_MEMORY as "Current",
                SESSION_PGA_MEMORY_MAX as "Maximum",
                PGA_USED_MEMORY as "Used",
                PGA_ALLOC_MEMORY as "Allocated",
                PGA_FREEABLE_MEMORY as "Freeable",
                PGA_MAX_MEMORY as "Max"
              )
            ),
            xmlElement
            (
              "UGA",
              xmlForest
              (
                SESSION_UGA_MEMORY as "Current",
                SESSION_UGA_MEMORY_MAX as "Maximum"
              ) 
            ),
            xmlElement
            (
              "LOBS",
              xmlForest
              (
                CACHE_LOBS as "Cached",
                NO_CACHE_LOBS as "nonCached",
                ABSTRACT_LOBS as "Abstract"
              ) 
            )
          )
     into statistics
     from dual;

   statistics := statistics.extract('/');
   statistics := xmltype(xmltype.getCLOBVal(statistics));

   return statistics;
end;
--
function getLOBUsage(stats XMLTYPE) return xmltype
as
   val xmltype;
begin
  return stats.extract('/statisticsSnapshot/LOBS');
end;
--
function getTime(stats XMLTYPE) return timestamp
as
begin
   return to_Timestamp
          (
            stats.extract('/statisticsSnapshot/snapshotTimestamp/text()').getStringVal()
          );
end;               
--
procedure initializeTimer
as
begin
  START_TIME := sysTimeStamp;
end;
--
function getElapsedTime return interval DAY TO SECOND
as
  END_TIME timestamp;
  ELAPSED_TIME INTERVAL DAY (2) TO SECOND (6);
begin
  END_TIME := sysTimeStamp;
  ELAPSED_TIME := END_TIME - START_TIME;
  START_TIME := sysTimeStamp;
  return ELAPSED_TIME;
end;
--
end;
/
show errors
--
set pages 50
set long 2048
select XDB_MONITOR.GETSTATISTICS()
from dual
/
alter session set current_schema = SYS
/
