--
-- XDB_ANALYZE_XMLSCHEMA should be created under XDBPM
--
alter session set current_schema = XDBPM
/
create or replace package XDBPM_OPTIMIZE_SQLTYPES
authid CURRENT_USER
as
  function getComplexTypeElementList(P_COMPLEX_TYPE_REF REF XMLTYPE) return XDB.XDB$XMLTYPE_REF_LIST_T;
end XDBPM_OPTIMIZE_SQLTYPES;
/
show errors
--
create or replace synonym XDB_OPTIMIZE_SQLTYPES for XDBPM_OPTIMIZE_SQLTYPES
/
create or replace package body XDBPM_OPTIMIZE_SQLTYPES
as
function appendElementList(V_ELEMENT_LIST IN OUT XDB.XDB$XMLTYPE_REF_LIST_T, V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T) return XDB.XDB$XMLTYPE_REF_LIST_T;
function expandModel(P_MODEL XDB.XDB$MODEL_T) return XDB.XDB$XMLTYPE_REF_LIST_T;
function expandChoiceList(P_CHOICE_LIST XDB.XDB$XMLTYPE_REF_LIST_T) return XDB.XDB$XMLTYPE_REF_LIST_T;
function expandSequenceList(P_SEQUENCE_LIST XDB.XDB$XMLTYPE_REF_LIST_T) return XDB.XDB$XMLTYPE_REF_LIST_T;
function expandGroupList(P_GROUP_LIST XDB.XDB$XMLTYPE_REF_LIST_T) return XDB.XDB$XMLTYPE_REF_LIST_T;
--
function appendElementList(V_ELEMENT_LIST IN OUT XDB.XDB$XMLTYPE_REF_LIST_T, V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T) 
return XDB.XDB$XMLTYPE_REF_LIST_T
as
begin
  SELECT CAST
         ( 
           SET 
           ( 
             CAST(V_ELEMENT_LIST as XDBPM.XMLTYPE_REF_TABLE_T) 
             MULTISET UNION
             CAST(V_CHILD_ELEMENT_LIST as XDBPM.XMLTYPE_REF_TABLE_T) 
           )
           as XDB.XDB$XMLTYPE_REF_LIST_T
         )
    into V_ELEMENT_LIST
    from DUAL;
    return V_ELEMENT_LIST;      
end;
--
function expandModel(P_MODEL XDB.XDB$MODEL_T)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_ELEMENT_LIST       XDB.XDB$XMLTYPE_REF_LIST_T;
  V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T;
begin

  V_ELEMENT_LIST := XDB.XDB$XMLTYPE_REF_LIST_T();
  if P_MODEL.ELEMENTS is not null then
    V_ELEMENT_LIST := P_MODEL.ELEMENTS;
  end if;
  
  if (P_MODEL.CHOICE_KIDS is not NULL) then
    V_CHILD_ELEMENT_LIST := expandChoiceList(P_MODEL.CHOICE_KIDS);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end if;
  
  if (P_MODEL.SEQUENCE_KIDS is not NULL) then
    V_CHILD_ELEMENT_LIST := expandSequenceList(P_MODEL.SEQUENCE_KIDS);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end if;

  -- Process ANYS
  
  if (P_MODEL.GROUPS is not NULL) then
    V_CHILD_ELEMENT_LIST := expandGroupList(P_MODEL.GROUPS);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end if;

  return V_ELEMENT_LIST;
end;
--
function expandChoiceList(P_CHOICE_LIST XDB.XDB$XMLTYPE_REF_LIST_T)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_ELEMENT_LIST       XDB.XDB$XMLTYPE_REF_LIST_T;
  V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T;

  cursor getChoices is
  select c.XMLDATA MODEL
    from XDB.XDB$CHOICE_MODEL c, TABLE(P_CHOICE_LIST) cl
   where ref(c) = value(cl);
begin

  V_ELEMENT_LIST := XDB.XDB$XMLTYPE_REF_LIST_T();

  for c in getChoices loop
    V_CHILD_ELEMENT_LIST := expandModel(c.MODEL);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end loop;

  return V_ELEMENT_LIST;
end;
--
function expandSequenceList(P_SEQUENCE_LIST XDB.XDB$XMLTYPE_REF_LIST_T)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_ELEMENT_LIST       XDB.XDB$XMLTYPE_REF_LIST_T;
  V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T;

  cursor getSequences is
  select s.XMLDATA MODEL
    from XDB.XDB$SEQUENCE_MODEL s, TABLE(P_SEQUENCE_LIST) sl
   where ref(s) = value(sl);
begin

  V_ELEMENT_LIST := XDB.XDB$XMLTYPE_REF_LIST_T();

  for s in getSequences loop
    V_CHILD_ELEMENT_LIST := expandModel(s.MODEL);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end loop;

  return V_ELEMENT_LIST;
end;
--
function expandGroupList(P_GROUP_LIST XDB.XDB$XMLTYPE_REF_LIST_T)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_ELEMENT_LIST       XDB.XDB$XMLTYPE_REF_LIST_T;
  V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T;  V_MODEL  XDB.XDB$MODEL_T;

  cursor getGroups is
  SELECT CASE 
           -- Return The MODEL Definition for the CHOICE, ALL or SEQUENCE
           WHEN gd.XMLDATA.ALL_KID is not NULL
             THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = gd.XMLDATA.ALL_KID)
           WHEN gd.XMLDATA.SEQUENCE_KID is not NULL
             THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = gd.XMLDATA.SEQUENCE_KID)
           WHEN gd.XMLDATA.CHOICE_KID is not NULL
             THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = gd.XMLDATA.CHOICE_KID)
          END MODEL
     FROM XDB.XDB$GROUP_DEF gd, XDB.XDB$GROUP_REF gr, TABLE(P_GROUP_LIST) gl
    WHERE ref(gd) = gr.XMLDATA.GROUPREF_REF
      and ref(gr) = value(gl);
begin
    
  V_ELEMENT_LIST := XDB.XDB$XMLTYPE_REF_LIST_T();

  for g in getGroups loop
    V_CHILD_ELEMENT_LIST := expandModel(g.MODEL);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end loop;

  return V_ELEMENT_LIST;
end;
--
function getComplexTypeElementList(P_COMPLEX_TYPE_REF REF XMLTYPE)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_MODEL        XDB.XDB$MODEL_T;
  V_BASE_TYPE    REF XMLTYPE;
  V_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T := XDB.XDB$XMLTYPE_REF_LIST_T();
begin
  SELECT ct.XMLDATA.BASE_TYPE, 
         CASE 
           -- Return The MODEL Definition for the CHOICE, ALL or SEQUENCE
           WHEN ct.XMLDATA.ALL_KID is not NULL
             THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = ct.XMLDATA.ALL_KID)
           WHEN ct.XMLDATA.SEQUENCE_KID is not NULL
             THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = ct.XMLDATA.SEQUENCE_KID)
           WHEN ct.XMLDATA.CHOICE_KID is not NULL
             THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = ct.XMLDATA.CHOICE_KID)
           WHEN ct.XMLDATA.GROUP_KID is not NULL
             -- COMPLEXTYPE is based on a GROUP. 
             THEN ( 
                     -- RETURN The CHOICE, ALL or SEQUENCE for GROUP
                     SELECT CASE
                              WHEN gd.XMLDATA.ALL_KID is not NULL
                                THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = gd.XMLDATA.ALL_KID)
                              WHEN gd.XMLDATA.SEQUENCE_KID is not NULL
                                THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = gd.XMLDATA.SEQUENCE_KID)
                              WHEN gd.XMLDATA.CHOICE_KID is not NULL
                                THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = gd.XMLDATA.CHOICE_KID)
                              END
                         FROM XDB.XDB$GROUP_DEF gd, xdb.xdb$GROUP_REF gr
                        WHERE ref(gd) = gr.XMLDATA.GROUPREF_REF
                          and ref(gr) = ct.XMLDATA.GROUP_KID
                  )
--           WHEN ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.ALL_KID is not NULL
--             THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.ALL_KID)
--           WHEN ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.SEQUENCE_KID is not NULL
--            THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.SEQUENCE_KID)
--           WHEN ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.CHOICE_KID is not NULL
--             THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.CHOICE_KID)
--           WHEN ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.GROUP_KID is not NULL
--             -- COMPLEXTYPE is based on a GROUP. 
--             THEN ( 
--                     -- RETURN The CHOICE, ALL or SEQUENCE for GROUP
--                     SELECT CASE
--                              WHEN gd.XMLDATA.ALL_KID is not NULL
--                                THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = gd.XMLDATA.ALL_KID)
--                              WHEN gd.XMLDATA.SEQUENCE_KID is not NULL
--                                THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = gd.XMLDATA.SEQUENCE_KID)
--                              WHEN gd.XMLDATA.CHOICE_KID is not NULL
--                                THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = gd.XMLDATA.CHOICE_KID)
--                              END
--                         FROM XDB.XDB$GROUP_DEF gd, xdb.xdb$GROUP_REF gr
--                       WHERE ref(gd) = gr.XMLDATA.GROUPREF_REF
--                          and ref(gr) = ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.GROUP_KID
--                  )
           WHEN ct.XMLDATA.COMPLEXCONTENT.EXTENSION.ALL_KID is not NULL
             THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = ct.XMLDATA.COMPLEXCONTENT.EXTENSION.ALL_KID)
           WHEN ct.XMLDATA.COMPLEXCONTENT.EXTENSION.SEQUENCE_KID is not NULL
             THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = ct.XMLDATA.COMPLEXCONTENT.EXTENSION.SEQUENCE_KID)
           WHEN ct.XMLDATA.COMPLEXCONTENT.EXTENSION.CHOICE_KID is not NULL
             THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = ct.XMLDATA.COMPLEXCONTENT.EXTENSION.CHOICE_KID)
           WHEN ct.XMLDATA.COMPLEXCONTENT.EXTENSION.GROUP_KID is not NULL
             -- COMPLEXTYPE is based on a GROUP. 
             THEN ( 
                     -- RETURN The CHOICE, ALL or SEQUENCE for GROUP
                     SELECT CASE
                              WHEN gd.XMLDATA.ALL_KID is not NULL
                                THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = gd.XMLDATA.ALL_KID)
                              WHEN gd.XMLDATA.SEQUENCE_KID is not NULL
                                THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = gd.XMLDATA.SEQUENCE_KID)
                              WHEN gd.XMLDATA.CHOICE_KID is not NULL
                                THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = gd.XMLDATA.CHOICE_KID)
                              END
                         FROM XDB.XDB$GROUP_DEF gd, xdb.xdb$GROUP_REF gr
                        WHERE ref(gd) = gr.XMLDATA.GROUPREF_REF
                          and ref(gr) = ct.XMLDATA.COMPLEXCONTENT.EXTENSION.GROUP_KID
                  )
          END MODEL
     INTO V_BASE_TYPE, V_MODEL 
     FROM XDB.XDB$COMPLEX_TYPE ct
    WHERE ref(ct) = P_COMPLEX_TYPE_REF;
    
  -- Deal with Base Type and Base on REF...  
  
  return expandModel(V_MODEL);

end;
--             
end XDBPM_OPTIMIZE_SQLTYPES;
/
show errors
--
grant execute on XDBPM_OPTIMIZE_SQLTYPES to public
/