--
-- XDBPM_ADMIN should be created under XDBPM
--
alter session set current_schema = XDBPM
/
create or replace package XDBPM_ADMIN
AUTHID CURRENT_USER
as
    C_BASIC_AUTHENTICATION    constant number := 1;
    C_DIGEST_AUTHENTICATION   constant number := 2;
    C_CUSTOM_AUTHENTICATION   constant number := 4;
    
    FUNCTION BASIC_AUTHENTICATION return number deterministic;
    FUNCTION DIGEST_AUTHENTICATION return number deterministic;
    FUNCTION CUSTOM_AUTHENTICATION return number deterministic;
    
    PROCEDURE RESET_AUTHENTICATION(P_AUTHENTICATION NUMBER DEFAULT C_DIGEST_AUTHENTICATION);
end;
/
show errors
--
create or replace synonym XDB_ADMIN for XDBPM_ADMIN
/
grant execute on XDBPM_ADMIN to XDBADMIN
/
create or replace package body XDBPM_ADMIN
as
FUNCTION BASIC_AUTHENTICATION 
return number deterministic
as
begin
  return C_BASIC_AUTHENTICATION;
end;
--
FUNCTION DIGEST_AUTHENTICATION 
return number deterministic
as
begin
  return C_DIGEST_AUTHENTICATION;
end;
--
FUNCTION CUSTOM_AUTHENTICATION 
return number deterministic
as
begin
  return C_CUSTOM_AUTHENTICATION;
end;
--
PROCEDURE RESET_AUTHENTICATION(P_AUTHENTICATION NUMBER DEFAULT C_DIGEST_AUTHENTICATION)
as
  V_CONFIG  XMLTYPE := dbms_xdb.cfg_get();
  V_SNIPPET XMLTYPE;
begin

  select deletexml(
           V_CONFIG,
           '/cfg:xdbconfig/cfg:sysconfig/cfg:protocolconfig/cfg:httpconfig/cfg:authentication/cfg:allow-mechanism',
           'xmlns:cfg="http://xmlns.oracle.com/xdb/xdbconfig.xsd"'
         )
    into V_CONFIG
    from DUAL;
    
                
  if (P_AUTHENTICATION = C_BASIC_AUTHENTICATION) then
    V_SNIPPET := XMLTYPE('<allow-mechanism xmlns="http://xmlns.oracle.com/xdb/xdbconfig.xsd">basic</allow-mechanism>');
    select insertChildXML(
             V_CONFIG, 
             '/cfg:xdbconfig/cfg:sysconfig/cfg:protocolconfig/cfg:httpconfig/cfg:authentication',
             'allow-mechanism',
             V_SNIPPET,
             'xmlns:cfg="http://xmlns.oracle.com/xdb/xdbconfig.xsd"'
           )
      into V_CONFIG
      from dual;
  end if;

  if (P_AUTHENTICATION = C_DIGEST_AUTHENTICATION) then
    V_SNIPPET := XMLTYPE('<allow-mechanism xmlns="http://xmlns.oracle.com/xdb/xdbconfig.xsd">digest</allow-mechanism>');
    select insertChildXML(
             V_CONFIG, 
             '/cfg:xdbconfig/cfg:sysconfig/cfg:protocolconfig/cfg:httpconfig/cfg:authentication',
             'allow-mechanism',
             V_SNIPPET,
           'xmlns:cfg="http://xmlns.oracle.com/xdb/xdbconfig.xsd"'
           )
      into V_CONFIG
      from dual;
  end if;

  if (P_AUTHENTICATION = C_BASIC_AUTHENTICATION + C_DIGEST_AUTHENTICATION) then
    V_SNIPPET := XMLTYPE('<allow-mechanism xmlns="http://xmlns.oracle.com/xdb/xdbconfig.xsd">digest</allow-mechanism>');
    select insertChildXML(
             V_CONFIG, 
             '/cfg:xdbconfig/cfg:sysconfig/cfg:protocolconfig/cfg:httpconfig/cfg:authentication',
             'allow-mechanism',
             V_SNIPPET,
             'xmlns:cfg="http://xmlns.oracle.com/xdb/xdbconfig.xsd"'
           )
      into V_CONFIG
      from dual;
    V_SNIPPET := XMLTYPE('<allow-mechanism xmlns="http://xmlns.oracle.com/xdb/xdbconfig.xsd">basic</allow-mechanism>');
    select insertChildXML(
             V_CONFIG, 
             '/cfg:xdbconfig/cfg:sysconfig/cfg:protocolconfig/cfg:httpconfig/cfg:authentication',
             'allow-mechanism',
             V_SNIPPET,
             'xmlns:cfg="http://xmlns.oracle.com/xdb/xdbconfig.xsd"'
           )
      into V_CONFIG
      from dual;

  end if;

  dbms_xdb.cfg_update(V_CONFIG);

end;
--
end;
/
show errors
--
alter session set current_schema = SYS
/