
-- All public synonyms should be created under XDBPM
--
alter session set current_schema = XDBPM
/
create or replace synonym XDB_PATH_HELPER                 for XDBPM_PATH_HELPER
/
create or replace public synonym XDB_USERNAME             for XDBPM_USERNAME
/
create or replace public synonym XDB_CONSTANTS            for XDBPM_CONSTANTS
/
create or replace public synonym XDB_NAMESPACES           for XDBPM_NAMESPACES
/
create or replace public synonym XDB_OUTPUT               for XDBPM.XDBPM_OUTPUT
/
create or replace public synonym XDB_DEBUG                for XDBPM.XDBPM_DEBUG
/
create or replace public synonym XDB_EDIT_XMLSCHEMA       for XDBPM.XDBPM_EDIT_XMLSCHEMA
/
create or replace public synonym XDB_ANNOTATE_XMLSCHEMA   for XDBPM.XDBPM_ANNOTATE_XMLSCHEMA
/
create or replace public synonym XDB_ANNOTATE_SCHEMA      for XDBPM.XDBPM_ANNOTATE_XMLSCHEMA
/
create or replace public synonym XDB_ANALYZE_XMLSCHEMA    for XDBPM.XDB_ANALYZE_XMLSCHEMA
/
create or replace public synonym XDB_ANALYZE_SCHEMA       for XDBPM.XDB_ANALYZE_XMLSCHEMA
/
create or replace public synonym XDB_UTILITIES 					  for XDBPM_UTILITIES
/
create or replace public synonym XDB_MONITOR  					  for XDBPM_MONITOR
/
create or replace public synonym XDB_DOM_UTILITIES  			for XDBPM_DOM_UTILITIES
/
create or replace public synonym XDB_XMLINDEX_SEARCH  	  for XDBPM_XMLINDEX_SEARCH
/
create or replace public synonym XDB_XMLSCHEMA_SEARCH			for XDBPM_XMLSCHEMA_SEARCH
/
create or replace public synonym XDB_REPOSITORY_SEARCH	  for XDBPM_REPOSITORY_SEARCH
/
create or replace public synonym XDB_RESCONFIG_MANAGER	  for XDBPM_RESCONFIG_MANAGER
/
create or replace public synonym XDB_TABLE_UPLOAD   			for XDBPM_TABLE_UPLOAD
/
create or replace public synonym XDB_ZIP_UTILITY 		for XDBPM_ZIP_UTILITY
/
create or replace public synonym XDB_IMPORT_UTILITIES 		for XDBPM_IMPORT_UTILITIES
/
create or replace public synonym XDB_CONFIGURATION     		for XDBPM_CONFIGURATION
/
alter session set current_schema = SYS
/
create or replace public synonym XDB_IMPORT_HELPER        for XDBPM_IMPORT_HELPER
/