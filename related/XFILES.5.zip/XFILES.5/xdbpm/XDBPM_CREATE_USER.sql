--
-- Create the XDBPM Account as a locked account.
--
drop user XDBPM cascade
/
create user XDBPM identified by XDBPM account lock
/
grant unlimited tablespace to XDBPM
/
--

