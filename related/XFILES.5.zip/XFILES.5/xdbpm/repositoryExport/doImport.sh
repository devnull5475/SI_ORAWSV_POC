. ./config.sh
ORACLE_HOME=C:\\ORACLE\\PRODUCT\\10.2.0\\DB_1
#JAVA_HOME=$ORACLE_HOME\\jre\\1.4.2
#PATH=$JAVA_HOME\\bin;$PATH
java -Xmx256M -classpath "`pwd`\\SaxLoader.jar;$ORACLE_HOME\\lib\\xmlparserv2.jar;$ORACLE_HOME\\jdbc\\lib\\ojdbc14.jar;$ORACLE_HOME\\jdbc\\lib\\ojdbc14dms.jar;$ORACLE_HOME\\rdbms\\jlib\\xdb.jar" -Dcom.oracle.st.xmldb.pm.ConnectionParameters=$1 com.oracle.st.xmldb.pm.saxLoader.SaxProcessor
