export CLASSPATH=./xdbpm.jar:$ORACLE_HOME/lib/xmlparserv2.jar:$ORACLE_HOME/jdbc/lib/ojdbc5.jar:$ORACLE_HOME/jdbc/lib/ojdbc5dms.jar:$ORACLE_HOME/rdbms/jlib/xdb.jar
java -Xmx256M com.oracle.st.xdb.pm.zip.RepositoryExport -D $1
