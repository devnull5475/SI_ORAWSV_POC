create or replace VIEW XDBPM_ALL_TYPES
as 
select OWNER,                      
       TYPE_NAME,                  
       TYPE_OID,                   
       TYPECODE,                   
       ATTRIBUTES,                 
       METHODS,                    
       PREDEFINED,                 
       INCOMPLETE,                 
       FINAL,                      
       INSTANTIABLE,               
       SUPERTYPE_OWNER,            
       SUPERTYPE_NAME,             
       LOCAL_ATTRIBUTES,           
       LOCAL_METHODS,              
       TYPEID   
  from ALL_TYPES
/
show errors
--
grant all on XDBPM.XDBPM_ALL_TYPES to public
/
create or replace VIEW XDBPM_ALL_TYPE_ATTRS
as 
select OWNER,
       TYPE_NAME,
       ATTR_NAME,
       ATTR_TYPE_MOD,
       ATTR_TYPE_OWNER,
       ATTR_TYPE_NAME,
       LENGTH,
       PRECISION,
       SCALE,
       CHARACTER_SET_NAME,
       ATTR_NO,
       INHERITED,
       CHAR_USED
  from ALL_TYPE_ATTRS
/
show errors
--
grant all on XDBPM.XDBPM_ALL_TYPE_ATTRS to public
/
create or replace view XDBPM_ALL_COLL_TYPES
as
select OWNER,
       TYPE_NAME,
       COLL_TYPE,
       UPPER_BOUND,
       ELEM_TYPE_MOD,
       ELEM_TYPE_OWNER,
       ELEM_TYPE_NAME,
       LENGTH,
       PRECISION,
       SCALE,
       CHARACTER_SET_NAME,
       ELEM_STORAGE,
       NULLS_STORED,
       CHAR_USED
  from ALL_COLL_TYPES
/
show errors
--
grant all on XDBPM.XDBPM_ALL_COLL_TYPES to public
/
