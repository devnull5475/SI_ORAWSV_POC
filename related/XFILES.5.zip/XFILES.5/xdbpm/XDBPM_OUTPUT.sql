--
-- XDBPM_OUTPUT should be created under XDBPM
--
alter session set current_schema = XDBPM
/
create or replace package XDBPM_OUTPUT
authid CURRENT_USER
as

  procedure writeOutputFileEntry(P_CONTENT VARCHAR2);
  procedure writeOutputFileEntry(P_CONTENT CLOB);
  procedure writeOutputFileEntry(P_CONTENT XMLTYPE, P_PRETTY_PRINT BOOLEAN DEFAULT TRUE);
  procedure createOutputFile(P_FILE_PATH VARCHAR2 DEFAULT NULL, P_OVERWRITE BOOLEAN DEFAULT FALSE);
  procedure flushOutputFile;

  procedure writeLogFileEntry(P_CONTENT VARCHAR2);
  procedure writeLogFileEntry(P_CONTENT CLOB);
  procedure writeLogFileEntry(P_CONTENT XMLTYPE, P_PRETTY_PRINT BOOLEAN DEFAULT TRUE);
  procedure logException;
  procedure createLogFile(P_TRACE_FILE_PATH VARCHAR2 DEFAULT NULL, P_OVERWRITE BOOLEAN DEFAULT FALSE);
  procedure flushLogFile;
  
  procedure createFile(P_RESOURCE_PATH VARCHAR2 DEFAULT NULL,P_OVERWRITE BOOLEAN DEFAULT FALSE);
  procedure writeToFile(P_RESOURCE_PATH VARCHAR2, P_CONTENT IN OUT CLOB);
end;
/
create or replace synonym XDB_OUTPUT for XDBPM_OUTPUT
/
grant execute on XDBPM_OUTPUT to public
/
show errors
--
create or replace package body XDBPM_OUTPUT
as
  G_OUTPUT_FILE_PATH   VARCHAR2(700) := NULL;
  G_OUTPUT_FILE_BUFFER CLOB;
  G_LOG_FILE_PATH   VARCHAR2(700) := NULL;
  G_LOG_FILE_BUFFER CLOB;

procedure writeOutputFileEntry(P_CONTENT VARCHAR2) 
as
  V_BUFFER            VARCHAR2(32000);    
begin
	if (G_OUTPUT_FILE_BUFFER IS NULL) THEN
	  DBMS_LOB.CREATETEMPORARY(G_OUTPUT_FILE_BUFFER,TRUE);
	else
    DBMS_LOB.WRITEAPPEND(G_OUTPUT_FILE_BUFFER,2, CHR(13) || CHR(10));
	end if;
	DBMS_LOB.WRITEAPPEND(G_OUTPUT_FILE_BUFFER,LENGTH(P_CONTENT),P_CONTENT);
end;
--
procedure writeOutputFileEntry(P_CONTENT CLOB) 
as
  V_BUFFER            VARCHAR2(32000);    
begin
	if (G_OUTPUT_FILE_BUFFER IS NULL) THEN
	  DBMS_LOB.CREATETEMPORARY(G_OUTPUT_FILE_BUFFER,TRUE);
	else
    DBMS_LOB.WRITEAPPEND(G_OUTPUT_FILE_BUFFER,2, CHR(13) || CHR(10));
	end if;
  DBMS_LOB.APPEND(G_OUTPUT_FILE_BUFFER,P_CONTENT);
end;
--
procedure writeOutputFileEntry(P_CONTENT XMLTYPE, P_PRETTY_PRINT BOOLEAN DEFAULT TRUE) 
as
  V_BUFFER            VARCHAR2(32000);    
  V_SERIALIZED_XML    CLOB;
begin
	if (G_OUTPUT_FILE_BUFFER IS NULL) THEN
	  DBMS_LOB.CREATETEMPORARY(G_OUTPUT_FILE_BUFFER,TRUE);
	else
    DBMS_LOB.WRITEAPPEND(G_OUTPUT_FILE_BUFFER,2,CHR(13) || CHR(10));
	end if;
  if (P_PRETTY_PRINT) then
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
    select P_CONTENT.getClobVal()
      into V_SERIALIZED_XML
      from DUAL;
$ELSE
    select XMLSERIALIZE(DOCUMENT P_CONTENT AS CLOB INDENT SIZE = 2)
      into V_SERIALIZED_XML
      from DUAL;
$END
  else
    select XMLSERIALIZE(DOCUMENT P_CONTENT AS CLOB)
      into V_SERIALIZED_XML
      from DUAL;
  end if;
  
  DBMS_LOB.APPEND(G_OUTPUT_FILE_BUFFER,V_SERIALIZED_XML);
end;
--
--
procedure writeLogFileEntry(P_CONTENT VARCHAR2) 
as
  V_BUFFER            VARCHAR2(32000);    
begin
	if (G_LOG_FILE_BUFFER IS NULL) THEN
	  DBMS_LOB.CREATETEMPORARY(G_LOG_FILE_BUFFER,TRUE);
	else
    DBMS_LOB.WRITEAPPEND(G_LOG_FILE_BUFFER,2,CHR(13) || CHR(10));
	end if;
	
  V_BUFFER := to_char(systimestamp,'YYYY-MM-DD"T"HH24:MI:SS.FF') || ' : ' || P_CONTENT;
  DBMS_LOB.WRITEAPPEND(G_LOG_FILE_BUFFER,LENGTH(V_BUFFER),V_BUFFER);
end;
--
procedure writeLogFileEntry(P_CONTENT CLOB) 
as
  V_BUFFER            VARCHAR2(32000);    
begin
	if (G_LOG_FILE_BUFFER IS NULL) THEN
	  DBMS_LOB.CREATETEMPORARY(G_LOG_FILE_BUFFER,TRUE);
	else
    DBMS_LOB.WRITEAPPEND(G_LOG_FILE_BUFFER,2,CHR(13) || CHR(10));
	end if;

  V_BUFFER := to_char(systimestamp,'YYYY-MM-DD"T"HH24:MI:SS.FF') || ' : CLOB Content';
  DBMS_LOB.APPEND(G_LOG_FILE_BUFFER,P_CONTENT);
end;
--
procedure writeLogFileEntry(P_CONTENT XMLTYPE, P_PRETTY_PRINT BOOLEAN DEFAULT TRUE) 
as
  V_BUFFER            VARCHAR2(32000);    
  V_SERIALIZED_XML    CLOB;
begin
	if (G_LOG_FILE_BUFFER IS NULL) THEN
	  DBMS_LOB.CREATETEMPORARY(G_LOG_FILE_BUFFER,TRUE);
	else
    DBMS_LOB.WRITEAPPEND(G_LOG_FILE_BUFFER,2,CHR(13) || CHR(10));
	end if;
	
  V_BUFFER := to_char(systimestamp,'YYYY-MM-DD"T"HH24:MI:SS.FF') || ' : XML Content'  || CHR(13) || CHR(10);
  DBMS_LOB.WRITEAPPEND(G_LOG_FILE_BUFFER,LENGTH(V_BUFFER),V_BUFFER);
  
  if (P_PRETTY_PRINT) then
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
    select P_CONTENT.getClobVal()
      into V_SERIALIZED_XML
      from DUAL;
$ELSE
    select XMLSERIALIZE(DOCUMENT P_CONTENT AS CLOB INDENT SIZE = 2)
      into V_SERIALIZED_XML
      from DUAL;
$END 
  else
    select XMLSERIALIZE(DOCUMENT P_CONTENT AS CLOB)
      into V_SERIALIZED_XML
      from DUAL;
  end if;
  
  DBMS_LOB.APPEND(G_LOG_FILE_BUFFER,V_SERIALIZED_XML);
end;
--
procedure logException 
as
  V_BUFFER            VARCHAR2(32000);
  V_SERIALIZED_XML    CLOB;
  
begin
	if (G_LOG_FILE_BUFFER IS NULL) THEN
	  DBMS_LOB.CREATETEMPORARY(G_LOG_FILE_BUFFER,TRUE);
	else
    DBMS_LOB.WRITEAPPEND(G_LOG_FILE_BUFFER,2,CHR(13) || CHR(10));
	end if;

  V_BUFFER := to_char(systimestamp,'YYYY-MM-DD"T"HH24:MI:SS.FF') || ' : Exception Details' || CHR(13) || CHR(10);
  DBMS_LOB.WRITEAPPEND(G_LOG_FILE_BUFFER,LENGTH(V_BUFFER),V_BUFFER);

  V_BUFFER := DBMS_UTILITY.FORMAT_ERROR_STACK() || CHR(13) || CHR(10);
  DBMS_LOB.WRITEAPPEND(G_LOG_FILE_BUFFER,LENGTH(V_BUFFER),V_BUFFER);

  V_BUFFER := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() || CHR(13) || CHR(10);
  DBMS_LOB.WRITEAPPEND(G_LOG_FILE_BUFFER,LENGTH(V_BUFFER),V_BUFFER);

end;
--
procedure createFile(P_RESOURCE_PATH VARCHAR2 DEFAULT NULL,P_OVERWRITE BOOLEAN DEFAULT FALSE)
as
  pragma autonomous_transaction;
  V_RESULT BOOLEAN;
begin
  if (DBMS_XDB.EXISTSRESOURCE(P_RESOURCE_PATH)) then
    if (P_OVERWRITE) then
      DBMS_XDB.DELETERESOURCE(P_RESOURCE_PATH,DBMS_XDB.DELETE_FORCE);
      V_RESULT := DBMS_XDB.CREATERESOURCE(P_RESOURCE_PATH,'');
    end if;
  else
      V_RESULT := DBMS_XDB.CREATERESOURCE(P_RESOURCE_PATH,'');
  end if;
  commit;
end;
--
procedure createOutputFile(P_FILE_PATH VARCHAR2 DEFAULT NULL,P_OVERWRITE BOOLEAN DEFAULT FALSE)
as
  pragma autonomous_transaction;
  V_RESULT BOOLEAN;
begin
	G_OUTPUT_FILE_PATH := P_FILE_PATH;
  createFile(G_OUTPUT_FILE_PATH,P_OVERWRITE);
end;
--
procedure createLogFile(P_TRACE_FILE_PATH VARCHAR2 DEFAULT NULL,P_OVERWRITE BOOLEAN DEFAULT FALSE)
as
  V_RESULT BOOLEAN;
begin
	G_LOG_FILE_PATH := P_TRACE_FILE_PATH;
	if (G_LOG_FILE_PATH is NULL) then
	  G_LOG_FILE_PATH := '/public/' || USER || '_' || to_char(systimestamp,'YYYY-MM-DD"T"HH24.MI.SS.FF') || '.log';
  end if;
  createFile(G_LOG_FILE_PATH,P_OVERWRITE);
end;
--
procedure writeToFile(P_RESOURCE_PATH VARCHAR2, P_CONTENT IN OUT CLOB)
as
  pragma autonomous_transaction;
    
  V_BINARY_CONTENT   BLOB;
  V_EXISTING_CONTENT BLOB;

  V_SOURCE_OFFSET    integer := 1;
  V_TARGET_OFFSET    integer := 1;
  V_WARNING          integer;
  V_LANG_CONTEXT     integer := 0;

begin	
  dbms_lob.createTemporary(V_BINARY_CONTENT,true);
  dbms_lob.convertToBlob(V_BINARY_CONTENT,P_CONTENT,dbms_lob.getLength(P_CONTENT),V_SOURCE_OFFSET,V_TARGET_OFFSET,nls_charset_id('AL32UTF8'),V_LANG_CONTEXT,V_WARNING);

  DBMS_XDB.touchResource(P_RESOURCE_PATH);
   
  select extractValue(res,'/Resource/XMLLob') 
    into V_EXISTING_CONTENT
    from RESOURCE_VIEW 
   where equals_path(res,P_RESOURCE_PATH) = 1
     for update;
  
  dbms_lob.open(V_EXISTING_CONTENT,dbms_lob.lob_readwrite);
  dbms_lob.append(V_EXISTING_CONTENT,V_BINARY_CONTENT);
  dbms_lob.close(V_EXISTING_CONTENT);
  commit;

  dbms_lob.freeTemporary(V_BINARY_CONTENT);
  dbms_lob.freeTemporary(P_CONTENT);
  P_CONTENT := NULL;
end;
--
procedure flushLogFile
as
begin
	DBMS_LOB.WRITEAPPEND(G_LOG_FILE_BUFFER, 2, CHR(13) || CHR(10));
	writeToFile(G_LOG_FILE_PATH,G_LOG_FILE_BUFFER);
end;
--
procedure flushOutputFile
as
begin
	DBMS_LOB.WRITEAPPEND(G_OUTPUT_FILE_BUFFER, 2, CHR(13) || CHR(10));
	writeToFile(G_OUTPUT_FILE_PATH,G_OUTPUT_FILE_BUFFER);
end;
--
end;
/
show errors
--
grant execute on XDBPM_OUTPUT to public
/
alter session set current_schema = SYS
/
