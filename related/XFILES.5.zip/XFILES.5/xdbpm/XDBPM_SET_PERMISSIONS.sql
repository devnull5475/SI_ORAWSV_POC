--
grant XDBADMIN to XDBPM
/
grant resource to XDBPM
/
grant create any directory to XDBPM
/
--
-- Grant access to V$ views to XDBPM
--
alter session set current_schema = SYS
/
grant select on V_$SESSION          to XDBPM
/
grant select on V_$MYSTAT           to XDBPM
/
grant select on V_$STATNAME         to XDBPM
/
grant select on V_$PROCESS          to XDBPM
/
grant select on V_$PARAMETER        to XDBPM
/
grant select on V_$INSTANCE         to XDBPM
/
grant select on V_$SYSTEM_PARAMETER to XDBPM
/
grant select on V_$DATABASE         to XDBPM
/
grant all on XDB.XDB$RESOURCE       to XDBPM
/
grant all on XDB.XDB$NLOCKS         to XDBPM
/
grant all on XDB.XDB$CHECKOUTS      to XDBPM
/
grant all on XDB.XDB$ROOT_INFO      to XDBPM
/
grant all on XDB.XDB$SCHEMA         to XDBPM
/
grant all on XDB.XDB$COMPLEX_TYPE   to XDBPM
/
grant all on XDB.XDB$ELEMENT        to XDBPM
/
grant all on XDB.XDB$ANY            to XDBPM
/
grant all on XDB.XDB$ATTRIBUTE      to XDBPM
/
grant all on XDB.XDB$ANYATTR        to XDBPM
/
grant select on SYS.DBA_TEMP_FILES  to XDBPM
/
grant execute on SYS.DBMS_SYSTEM    to XDBPM
/
alter session set current_schema = XDBPM
/
