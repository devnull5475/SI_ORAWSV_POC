--
-- XDB_ANALYZE_XMLSCHEMA should be created under XDBPM
--
alter session set current_schema = XDBPM
/
--
set define on
--
@@&SQLTYPE_VIEWS_SCRIPT
--
create or replace TYPE XMLTYPE_REF_TABLE_T 
                    IS TABLE of REF XMLTYPE
/
show errors
--
grant execute on XMLTYPE_REF_TABLE_T to public
/
create global temporary table STORAGE_MODEL_CACHE
(
  TYPE_NAME           VARCHAR2(128),
  TYPE_OWNER          VARCHAR2(32),
  EXTENDED_DEFINITION VARCHAR2(3),
  STORAGE_MODEL       XMLType
)
ON COMMIT PRESERVE ROWS
/
grant all on STORAGE_MODEL_CACHE to public
/
create  global temporary table TYPE_SUMMARY
(
  TYPE_NAME     VARCHAR2(30),
  OWNER         VARCHAR2(30),
  COLUMN_COUNT  NUMBER,
  PRIMARY KEY (OWNER, TYPE_NAME)
)
ON COMMIT PRESERVE ROWS
/
grant all on TYPE_SUMMARY to public
/
create GLOBAL TEMPORARY TABLE REVISED_TYPE_SUMMARY
(
  TYPE_NAME     VARCHAR2(30),
  OWNER         VARCHAR2(30),
  COLUMN_COUNT  NUMBER,
  PRIMARY KEY (OWNER, TYPE_NAME)
)
ON COMMIT PRESERVE ROWS
/
grant all on REVISED_TYPE_SUMMARY to public
/
create global temporary table REVISED_TYPES
(
  OWNER                      VARCHAR2(30),
  TYPE_NAME                  VARCHAR2(30),
  TYPE_OID                   RAW(16),
  TYPECODE                   VARCHAR2(30),
  ATTRIBUTES                 NUMBER,
  METHODS                    NUMBER,
  PREDEFINED                 VARCHAR2(3),
  INCOMPLETE                 VARCHAR2(3),
  FINAL                      VARCHAR2(3),
  INSTANTIABLE               VARCHAR2(3),
  SUPERTYPE_OWNER            VARCHAR2(30),
  SUPERTYPE_NAME             VARCHAR2(30),
  LOCAL_ATTRIBUTES           NUMBER,
  LOCAL_METHODS              NUMBER,
  TYPEID                     RAW(16),
  PRIMARY KEY(OWNER,TYPE_NAME)
)
ON COMMIT PRESERVE ROWS      
/
grant all on REVISED_TYPES to public
/
create global temporary table REVISED_COLL_TYPES
(
  OWNER                      VARCHAR2(30) NOT NULL ,
  TYPE_NAME                  VARCHAR2(30) NOT NULL ,
  COLL_TYPE                  VARCHAR2(30) NOT NULL ,
  UPPER_BOUND                NUMBER,
  ELEM_TYPE_MOD              VARCHAR2(7),
  ELEM_TYPE_OWNER            VARCHAR2(30),
  ELEM_TYPE_NAME             VARCHAR2(30),
  LENGTH                     NUMBER,
  PRECISION                  NUMBER,
  SCALE                      NUMBER,
  CHARACTER_SET_NAME         VARCHAR2(44),
  ELEM_STORAGE               VARCHAR2(7),
  NULLS_STORED               VARCHAR2(3),
  CHAR_USED                  VARCHAR2(1),
  PRIMARY KEY (OWNER,TYPE_NAME)
)
ON COMMIT PRESERVE ROWS      
/
grant all on REVISED_COLL_TYPES to public
/
create GLOBAL TEMPORARY TABLE REVISED_TYPE_ATTRS
(
  OWNER                VARCHAR2(30),
  TYPE_NAME            VARCHAR2(30),
  ATTR_NAME            VARCHAR2(30),
  ATTR_TYPE_MOD        VARCHAR2(7),
  ATTR_TYPE_OWNER      VARCHAR2(30),
  ATTR_TYPE_NAME       VARCHAR2(30),
  LENGTH               NUMBER,
  PRECISION            NUMBER,
  SCALE                NUMBER,
  CHARACTER_SET_NAME   VARCHAR2(44),
  ATTR_NO              NUMBER,
  INHERITED            VARCHAR2(3),
  CHAR_USED            VARCHAR2(1),
  PRIMARY KEY (OWNER, TYPE_NAME, ATTR_NAME)
)
ON COMMIT PRESERVE ROWS
/
grant all on REVISED_TYPE_ATTRS to public
/
create index XDBPM_ATTR_TYPE_INDEX 
    on REVISED_TYPE_ATTRS (ATTR_TYPE_OWNER, ATTR_TYPE_NAME)
/
create GLOBAL TEMPORARY TABLE REVISED_CHOICE_MODEL
(
  CHOICE_REFERENCE REF XMLTYPE,
  SQLTYPE          VARCHAR2(30),
  COLUMN_COUNT     NUMBER,
  PRIMARY KEY      (SQLTYPE)
)
/
grant all on REVISED_TYPE_ATTRS to public
/
create table XDBPM_INDEX_DDL_CACHE
(
  TABLE_NAME           VARCHAR2(128),
  OWNER                VARCHAR2(32),
  INDEX_DDL            XMLType
)
/
grant all on XDBPM_INDEX_DDL_CACHE to public
/
create or replace view MISSING_TYPES
as
select * 
  from XDBPM.XDBPM_ALL_TYPES at
 where not exists
       (
          select 1 
            from TYPE_SUMMARY ts
           where nvl(ts.OWNER,'SYS') = nvl(at.OWNER,'SYS')
             and ts.TYPE_NAME = at.TYPE_NAME
       )   
/
grant all on MISSING_TYPES to public
/
create or replace view MISSING_TYPE_ATTRS
as
select ata.*
  from MISSING_TYPES mt, XDBPM.XDBPM_ALL_TYPE_ATTRS ata
 where mt.TYPE_NAME = ata.TYPE_NAME
   and mt.OWNER = ata.OWNER
   and not exists
       (
          select 1 
            from TYPE_SUMMARY ts
           where nvl(ts.OWNER,'SYS') = nvl(ata.ATTR_TYPE_OWNER,'SYS')
             and ts.TYPE_NAME = ata.ATTR_TYPE_NAME
       )   
/
grant all on MISSING_TYPE_ATTRS to public
/
create or replace view MISSING_TYPE_HIERARCHY
as
select level TYPE_LEVEL, ata.TYPE_NAME, ata.OWNER, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER
  from XDBPM.XDBPM_ALL_TYPES at, XDBPM.XDBPM_ALL_TYPE_ATTRS ata
 where at.TYPE_NAME = ata.TYPE_NAME
   and INHERITED = 'NO'
   and at.OWNER     = ata.OWNER
   and not exists
       (
          select 1 
            from TYPE_SUMMARY ts
           where nvl(ts.OWNER,'SYS') = nvl(ata.ATTR_TYPE_OWNER,'SYS')
             and ts.TYPE_NAME = ata.ATTR_TYPE_NAME
       )   
       and not exists
       ( 
         select syn.SYNONYM_NAME, syn.OWNER
           from ALL_SYNONYMS syn, XDBPM.XDBPM_ALL_TYPES at
          where syn.TABLE_NAME  = at.TYPE_NAME
            and syn.TABLE_OWNER = at.OWNER
            and syn.SYNONYM_NAME = ata.ATTR_TYPE_NAME
            and syn.OWNER        = ata.ATTR_TYPE_OWNER
       )
       connect by SUPERTYPE_NAME = prior at.TYPE_NAME
              and SUPERTYPE_OWNER = prior at.OWNER
/
grant all on MISSING_TYPE_HIERARCHY to public
/
create or replace view BASE_TYPE_SUMMARY 
as
select ata.TYPE_NAME, ata.OWNER, ata.ATTR_NAME, ata.ATTR_TYPE_NAME, ata.ATTR_TYPE_OWNER,
       case when ts.OWNER = 'XDB' and (ts.TYPE_NAME = 'XDB$RAW_LIST_T' or ts.TYPE_NAME = 'XDB$ENUM_T')
            then ts.COLUMN_COUNT
            else case when exists (
                                    select 1 from XDBPM.XDBPM_ALL_TYPES at
                                     where at.TYPE_NAME = ts.TYPE_NAME
                                       and at.OWNER = ts.OWNER
                                       and at.FINAL = 'YES'
                                       and at.TYPECODE = 'OBJECT'
                                  )
                      then ts.COLUMN_COUNT + 2
                      else ts.COLUMN_COUNT
                 end       
       end COLUMN_COUNT
  from XDBPM.XDBPM_ALL_TYPE_ATTRS ata, TYPE_SUMMARY ts
 where ata.ATTR_TYPE_NAME = ts.TYPE_NAME
	 and nvl(ata.ATTR_TYPE_OWNER,'SYS') = nvl(ts.OWNER,'SYS')
/
grant all on BASE_TYPE_SUMMARY to public
/
create or replace view EXPANDED_TYPE_SUMMARY
as
select bts.TYPE_NAME, bts.OWNER, bts.ATTR_NAME, bts.ATTR_TYPE_NAME, bts.ATTR_TYPE_OWNER, bts.COLUMN_COUNT
  from BASE_TYPE_SUMMARY bts
union all
select at.SUPERTYPE_NAME TYPE_NAME, at.SUPERTYPE_OWNER OWNER, 'SYS$EXTENSION' ATTR_TYPE_NAME, at.TYPE_NAME ATTR_TYPE_NAME, at.OWNER ATTR_TYPE_OWNER, 
       ts.COLUMN_COUNT -
	     (
	       select sum(COLUMN_COUNT)
		       from BASE_TYPE_SUMMARY bts
		      where bts.TYPE_NAME = at.SUPERTYPE_NAME
		        and bts.OWNER = at.SUPERTYPE_OWNER
 	     )
  from XDBPM.XDBPM_ALL_TYPES at, TYPE_SUMMARY ts
 where at.TYPE_NAME = ts.TYPE_NAME
	and at.OWNER = ts.OWNER
/
grant all on EXPANDED_TYPE_SUMMARY to public
/
create or replace package XDBPM_ANALYZE_XMLSCHEMA
authid CURRENT_USER
as
  procedure scopeXMLReferences;
  procedure indexXMLReferences(INDEX_NAME VARCHAR2);
  procedure prepareBulkLoad(P_TABLE_NAME VARCHAR2, P_OWNER VARCHAR2 DEFAULT USER);
  procedure completeBulkLoad(P_TABLE_NAME VARCHAR2, P_OWNER VARCHAR2 DEFAULT USER);
  procedure renameCollectionTable (XMLTABLE VARCHAR2, XPATH VARCHAR2, COLLECTION_TABLE_PREFIX VARCHAR2);
  
  function analyzeTypeHierarchy(P_GLOBAL_OBJECT_NAME VARCHAR2) return XMLTYPE;
  function analyzeTypeHierarchy(P_GLOBAL_OBJECT_NAME VARCHAR2, P_SCHEMA_URL VARCHAR2) return XMLTYPE;

  function analyzeComplexType(P_COMPLEX_TYPE_NAME VARCHAR2) return XMLTYPE;  function analyzeComplexType(P_COMPLEX_TYPE_NAME VARCHAR2, P_SCHEMA_URL VARCHAR2) return XMLTYPE;
  function analyzeGlobalElement(P_GLOBAL_ELEMENT_NAME VARCHAR2) return XMLTYPE;
  function analyzeGlobalElement(P_GLOBAL_ELEMENT_NAME VARCHAR2, P_SCHEMA_URL VARCHAR2) return XMLTYPE;

  function printNestedTables(XML_TABLE VARCHAR2) return XMLType;
  function getDefaultTableName(P_RESOURCE_PATH VARCHAR2) return VARCHAR2;
  
  function showSQLTypes(schemaFolder VARCHAR2) return XMLType;
  function getComplexTypeElementList(P_SQLTYPE VARCHAR2, P_SQLSCHEMA VARCHAR2) return XDB.XDB$XMLTYPE_REF_LIST_T;
  
  function generateSchemaFromTable(P_TABLE_NAME VARCHAR2, P_OWNER VARCHAR2 default USER) return XMLTYPE;  
  function generateCreateTableStatement(XML_TABLE_NAME VARCHAR2, NEW_TABLE_NAME VARCHAR2) return CLOB;

  procedure cleanupSchema(P_OWNER VARCHAR2);
  
  procedure disableTableReferencedElements(P_XML_SCHEMA IN OUT XMLTYPE);
  procedure disableTableSubgroupMembers(P_XML_SCHEMA IN OUT XMLTYPE);
  procedure disableTableNonRootElements(P_XML_SCHEMA IN OUT XMLTYPE);

  procedure generateTypeSummary; 
  procedure generateCycleReport(P_RESOURCE_PATH VARCHAR2 DEFAULT '/public/cycleReport.log');

  procedure describeAnnotations(P_RESOURCE_PATH VARCHAR2, P_SCHEMA_LOCATION_HINT VARCHAR2,P_OWNER VARCHAR2 DEFAULT USER);
  
  function  XMLSCHEMA_WIZARD_UPLOAD(P_SCHEMA_CONTAINER VARCHAR2) return XMLType;
  function  XMLSCHEMA_WIZARD_ORDER_SCHEMAS(P_ROOT_XMLSCHEMA VARCHAR2, P_XMLSCHEMA_FOLDER VARCHAR2, P_SCHEMA_LOCATION_PREFIX VARCHAR2) return XMLType;
  function  XMLSCHEMA_WIZARD_TYPE_ANALYSIS(P_CONFIGURATION IN OUT XMLTYPE, P_LOGFILE_PATH VARCHAR2, P_SCHEMA_LOCATION_HINT VARCHAR2, P_OWNER VARCHAR2 DEFAULT USER)  return VARCHAR2;
  
  procedure setRegistrationScriptOptions(
              P_ADD_XDB_NAMESPACE      BOOLEAN        DEFAULT TRUE,  
              P_DISABLE_DOM_FIDELITY   BOOLEAN        DEFAULT FALSE, 
              P_DISABLE_DEFAULT_TABLES BOOLEAN        DEFAULT FALSE,
              P_REMOVE_APPINFO         BOOLEAN        DEFAULT FALSE,
              P_CALL_ANNOTATION_SCRIPT BOOLEAN        DEFAULT FALSE
            );
            
  procedure addXDBNamespace;
  procedure disableDOMFidelity;
  procedure disableDefaultTables;
  procedure removeAppInfo;
  procedure annotationScript;
            
  procedure setSchemaRegistrationOptions(
              P_LOCAL                BOOLEAN        DEFAULT TRUE,  
              P_GENTYPES             BOOLEAN        DEFAULT TRUE,  
              P_GENTABLES            BOOLEAN        DEFAULT TRUE, 
              P_FORCE                BOOLEAN        DEFAULT FALSE, 
              P_OWNER                VARCHAR2       DEFAULT NULL, 
              P_ENABLE_HIERARCHY     BINARY_INTEGER DEFAULT DBMS_XMLSCHEMA.ENABLE_HIERARCHY_NONE,
              P_OPTIONS              BINARY_INTEGER DEFAULT NULL
            );
           
  procedure schemaOrderingScript(P_OUTPUT_FOLDER VARCHAR2, P_XMLSCHEMA_FOLDER VARCHAR2, P_SCHEMA_LOCATION_PREFIX VARCHAR2, P_XMLSCHEMA_PATH VARCHAR2 DEFAULT NULL);
  procedure setEvent(P_EVENT VARCHAR2, P_LEVEL VARCHAR2);
  procedure schemaRegistrationScript(P_OUTPUT_FOLDER VARCHAR2, P_XMLSCHEMA_FOLDER VARCHAR2, P_CONFIGURATION XMLType, P_SCHEMA_LOCATION_HINT VARCHAR2 DEFAULT NULL, P_OWNER VARCHAR2 DEFAULT USER, P_LIMIT NUMBER DEFAULT 3);
  procedure tableCreationScript(P_OUTPUT_FOLDER VARCHAR2, P_TARGET_NAMESPACE VARCHAR2);
  procedure deleteOrphanTypes(P_REGISTRATION_DATE TIMESTAMP);
  
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
--
-- Depricated in 11.1.x : ALL_XML_SCHEMAS now contains column SCHEMA_ID which can be used to get this value.
--
  function getXMLSchemaRef(P_SCHEMA_LOCATION_HINT VARCHAR2,P_OWNER VARCHAR2) return REF XMLTYPE;
--
$END
--
end XDBPM_ANALYZE_XMLSCHEMA;
/
show errors
--
create or replace synonym XDB_ANALYZE_XMLSCHEMA for XDBPM_ANALYZE_XMLSCHEMA
/
create or replace synonym XDB_ANALYZE_SCHEMA for XDBPM_ANALYZE_XMLSCHEMA
/
create or replace package body XDBPM_ANALYZE_XMLSCHEMA
as
--
  C_NEW_LINE   constant VARCHAR2(2) := CHR(10);
  C_BLANK_LINE constant VARCHAR2(4) := C_NEW_LINE || C_NEW_LINE;
  -- Track the names of tables used.
  TYPE TABLE_LIST_ENTRY_T 
  is RECORD 
  (
    PARENT_SCHEMA          REF XMLTYPE,
    ELEMENT_NAME           VARCHAR2(2000),
    SQLTYPE                VARCHAR2(30),
    TABLE_NAME             VARCHAR2(30)
  );
  --
  TYPE TABLE_LIST_T 
    is TABLE of  TABLE_LIST_ENTRY_T;
  --
  TYPE SCHEMA_LOCATION_LIST_T 
    is TABLE of VARCHAR2(700); 
  --  
  TYPE SCHEMA_DEPENDENCY_REC 
  IS RECORD 
  ( 
     SCHEMA_PATH              VARCHAR2(700),
     DEPENDENCY_LIST          SCHEMA_LOCATION_LIST_T,
     EXTENDED_DEPENDENCY_LIST SCHEMA_LOCATION_LIST_T,
     RECURSIVE_PATH_COUNT     NUMBER
  );
  --
  TYPE SCHEMA_DEPENDENCY_LIST_T 
    IS TABLE of SCHEMA_DEPENDENCY_REC;
  --
  TYPE SCHEMA_ANNOTATION_T 
  IS RECORD 
  (
    SCHEMA_LOCATION_HINT      VARCHAR2(700),
    OWNER                     VARCHAR2(30),
    SCHEMA_ANNOTATIONS        CLOB,
    HAS_ANNOTATIONS           BOOLEAN,
    HAS_OUT_OF_LINE_HEADER    BOOLEAN
  );
  --
  TYPE SCHEMA_ANNOTATION_LIST_T 
    IS TABLE OF SCHEMA_ANNOTATION_T;
  --
  TYPE TYPE_DEFINITION_T 
  is RECORD
  (
    TYPE_NAME VARCHAR2(30),
    OWNER     VARCHAR2(30)
  );
  --
  TYPE TYPE_LIST_T 
    is TABLE of TYPE_DEFINITION_T;
  --
  TYPE CYCLE_LIST_ENTRY_T 
  is RECORD
  (
    TYPE            TYPE_DEFINITION_T,
    SUPER_TYPE_LIST TYPE_LIST_T
  );
  TYPE CYCLE_LIST_T
    is TABLE of CYCLE_LIST_ENTRY_T;
  --  
  TYPE EVENT_T
  is RECORD
  (
     EVENT         VARCHAR2(32),
     LEVEL         VARCHAR2(32)
  );
  --
  TYPE EVENT_LIST_T
    is TABLE of EVENT_T;
  
  G_DEPTH_COUNT NUMBER(2) := 0;
  --
  G_KNOWN_CYCLE_LIST TYPE_LIST_T;
  --
  G_PROCESSED_TYPE_LIST TYPE_LIST_T;
  --
  G_TABLE_LIST TABLE_LIST_T;
  --
  G_LOCAL                    BOOLEAN := TRUE;
  G_GENTYPES                 BOOLEAN := TRUE;
  G_GENTABLES                BOOLEAN := TRUE;
  G_FORCE                    BOOLEAN := FALSE;
  G_OWNER                    VARCHAR2(32) := NULL;
  G_ENABLE_HIERARCHY         BINARY_INTEGER := NULL;
  G_OPTIONS                  BINARY_INTEGER :=NULL;
  G_ADD_XDB_NAMESPACE        BOOLEAN := TRUE;
  G_DISABLE_DOM_FIDELITY     BOOLEAN := FALSE;
  G_DISABLE_DEFAULT_TABLES   BOOLEAN := FALSE;
  G_REMOVE_APPINFO           BOOLEAN := FALSE;
  G_CALL_ANNOTATION_SCRIPT   BOOLEAN := TRUE;
  --
  G_SCHEMA_ANNOTATION_CACHE  SCHEMA_ANNOTATION_LIST_T;
  --
  G_SCHEMA_REFERENCE_LIST    XDB.XDB$XMLTYPE_REF_LIST_T;
  --
  G_EVENT_LIST               EVENT_LIST_T;
--
procedure scopeXMLReferences
as
begin
  XDB.DBMS_XMLSTORAGE_MANAGE.scopeXMLReferences;
end;
--
procedure indexXMLReferences(INDEX_NAME VARCHAR2)
as
  cursor getTables
  is
  select distinct TABLE_NAME
    from USER_REFS
   where IS_SCOPED = 'NO';
   
begin
  for t in getTables loop
    XDB.DBMS_XMLSTORAGE_MANAGE.indexXMLReferences(USER,t.TABLE_NAME,null,INDEX_NAME);
  end loop;
end;
--  
procedure renameCollectionTable (XMLTABLE VARCHAR2, XPATH VARCHAR2, COLLECTION_TABLE_PREFIX VARCHAR2)
as
begin
  XDB.DBMS_XMLSTORAGE_MANAGE.renameCollectionTable(USER,XMLTABLE,NULL,XPATH,COLLECTION_TABLE_PREFIX || 'TABLE');
end;
--
procedure prepareBulkLoad(P_TABLE_NAME VARCHAR2, P_OWNER VARCHAR2 DEFAULT USER)
as
begin
  XDB.DBMS_XMLSTORAGE_MANAGE.enableIndexesAndConstraints(P_TABLE_NAME, P_OWNER);
end;
--
procedure completeBulkLoad(P_TABLE_NAME VARCHAR2, P_OWNER VARCHAR2 DEFAULT USER)
as
begin
  XDB.DBMS_XMLSTORAGE_MANAGE.enableIndexesAndConstraints(P_TABLE_NAME, P_OWNER);
end;
--
function findStorageModel(P_TYPE_NAME VARCHAR2, P_TYPE_OWNER VARCHAR2,  P_INCLUDE_SUBTYPES VARCHAR2 DEFAULT 'YES') return XMLType;
--
procedure cleanupSchema(P_OWNER VARCHAR2)
as
  V_OBJECT_COUNT number;
begin

  select count(*) 
    into V_OBJECT_COUNT
    from ALL_USERS
   where USERNAME = P_OWNER;
   
  if (V_OBJECT_COUNT > 0) then
    RAISE_APPLICATION_ERROR( -20000, 'User "' || P_OWNER || '" exists. XML Schema clean up only valid for dropped users.');
  end if;

  select count(*) 
    into V_OBJECT_COUNT
    from XDB.XDB$SCHEMA x
   where x.XMLDATA.SCHEMA_OWNER = P_OWNER;
  
  if (V_OBJECT_COUNT > 0) then
    delete 
      from XDB.XDB$SCHEMA x
     where x.XMLDATA.SCHEMA_OWNER = P_OWNER;
     commit;
  end if;
    
  select count(*) 
    into V_OBJECT_COUNT
    from XDB.XDB$COMPLEX_TYPE x
   where x.XMLDATA.SQLSCHEMA = P_OWNER;
  
  if (V_OBJECT_COUNT > 0) then
    delete 
      from XDB.XDB$COMPLEX_TYPE x
     where x.XMLDATA.SQLSCHEMA = P_OWNER;
     commit;
  end if;

  select count(*) 
    into V_OBJECT_COUNT
    from XDB.XDB$ELEMENT x
   where x.XMLDATA.PROPERTY.SQLSCHEMA = P_OWNER;
  
  if (V_OBJECT_COUNT > 0) then
    delete 
      from XDB.XDB$ELEMENT x
     where x.XMLDATA.PROPERTY.SQLSCHEMA = P_OWNER;
     commit;
  end if;

  select count(*) 
    into V_OBJECT_COUNT
    from XDB.XDB$ATTRIBUTE x
   where x.XMLDATA.SQLSCHEMA = P_OWNER;
  
  if (V_OBJECT_COUNT > 0) then
    delete 
      from XDB.XDB$ATTRIBUTE x
     where x.XMLDATA.SQLSCHEMA = P_OWNER;
     commit;
  end if;

  select count(*) 
    into V_OBJECT_COUNT
    from XDB.XDB$ANYATTR x
   where x.XMLDATA.PROPERTY.SQLSCHEMA = P_OWNER;
  
  if (V_OBJECT_COUNT > 0) then
    delete 
      from XDB.XDB$ANYATTR x
     where x.XMLDATA.PROPERTY.SQLSCHEMA = P_OWNER;
     commit;
  end if;

  select count(*) 
    into V_OBJECT_COUNT
    from XDB.XDB$ANY x
   where x.XMLDATA.PROPERTY.SQLSCHEMA = P_OWNER;
  
  if (V_OBJECT_COUNT > 0) then
    delete 
      from XDB.XDB$ANY x
     where x.XMLDATA.PROPERTY.SQLSCHEMA = P_OWNER;
     commit;
  end if;

end;
--
function getLocalAttributes(P_TYPE_NAME VARCHAR2, P_TYPE_OWNER VARCHAR2) return XMLType;
--
function makeElement(P_NAME VARCHAR2) 
return XMLType
as
  V_NAME VARCHAR2(4000) := P_NAME;
begin
  if (P_NAME LIKE '%$') then
    V_NAME := SUBSTR(V_NAME,1,LENGTH(V_NAME) - 1);
  end if;
  
  if (P_NAME LIKE '%$%') then
    V_NAME := REPLACE(V_NAME,'$','_0x22_');
  end if;

  return XMLTYPE( '<' || V_NAME || '/>');
end;
--
function getPathToRoot(SUBTYPE VARCHAR2, SUBTYPE_OWNER VARCHAR2)
return VARCHAR2
as
  TYPE_HIERARCHY VARCHAR2(4000);
begin
          
   SELECT sys_connect_by_path( OWNER || '.' || TYPE_NAME , '/')
     INTO TYPE_HIERARCHY
     FROM XDBPM.XDBPM_ALL_TYPES
    WHERE TYPE_NAME = SUBTYPE
      AND OWNER = SUBTYPE_OWNER
          CONNECT BY SUPERTYPE_NAME = PRIOR TYPE_NAME
                 AND SUPERTYPE_OWNER = PRIOR OWNER
          START WITH SUPERTYPE_NAME IS NULL
                 AND SUPERTYPE_OWNER IS NULL;
                     
   return TYPE_HIERARCHY;
                 
end;
--
function expandSQLType(ATTR_NAME VARCHAR2, SUBTYPE VARCHAR2, SUBTYPE_OWNER VARCHAR2)
return XMLType 
as 

  STORAGE_MODEL       XMLTYPE;
  ATTRIBUTES          XMLTYPE;
  EXTENDED_TYPE       XMLTYPE;
  ATTR_COUNT          NUMBER := 0;

  CURSOR FIND_EXTENDED_TYPES 
  is 
  select TYPE_NAME, OWNER 
    from XDBPM.XDBPM_ALL_TYPES
   where SUPERTYPE_NAME  = SUBTYPE
     and SUPERTYPE_OWNER = SUBTYPE_OWNER;

begin

  -- --# XDB_OUTPUT.writeOutputFileEntry('Processing SQLType  : "' || SUBTYPE_OWNER || '.' || SUBTYPE || '".' );
    
  STORAGE_MODEL := makeElement(ATTR_NAME);

  select insertChildXML(STORAGE_MODEL,'/' || STORAGE_MODEL.getRootElement(),'@type',SUBTYPE) 
    into STORAGE_MODEL
    from dual;

  select insertChildXML(STORAGE_MODEL,'/' || STORAGE_MODEL.getRootElement(),'@typeOwner',SUBTYPE_OWNER) 
    into STORAGE_MODEL
    from dual;

  ATTRIBUTES := getLocalAttributes(SUBTYPE, SUBTYPE_OWNER);          
  ATTR_COUNT := ATTR_COUNT + ATTRIBUTES.extract('/' || ATTRIBUTES.getRootElement() || '/@columns').getNumberVal();

  select appendChildXML(STORAGE_MODEL,'/' || STORAGE_MODEL.getRootElement(),ATTRIBUTES)
    into STORAGE_MODEL         
    from DUAL;
  
  for t in FIND_EXTENDED_TYPES loop
     EXTENDED_TYPE := expandSQLType('ExtendedType',T.TYPE_NAME,T.OWNER);
     ATTR_COUNT := ATTR_COUNT + EXTENDED_TYPE.extract('/' || EXTENDED_TYPE.getRootElement() || '/@columns').getNumberVal();
     
     select appendChildXML(STORAGE_MODEL,'/' || STORAGE_MODEL.getRootElement(),EXTENDED_TYPE)
       into STORAGE_MODEL
       from DUAL;    
  end loop;

  select insertChildXML(STORAGE_MODEL,'/' || STORAGE_MODEL.getRootElement(),'@columns',ATTR_COUNT) 
    into STORAGE_MODEL
    from dual;

  return STORAGE_MODEL;
end;
--
function getLocalAttributes(P_TYPE_NAME VARCHAR2, P_TYPE_OWNER VARCHAR2)
return XMLType
as
  V_ATTRIBUTE_COUNT     NUMBER := 0;
  V_TOTAL_ATTRIBUTES    NUMBER := 0;
  V_TEMP_RESULT         NUMBER;
  
  V_COLLECTION_TYPE     VARCHAR2(32);
  V_COLLECTION_OWNER    VARCHAR2(32);

  CURSOR FIND_CHILD_ATTRS 
  is
  select ATTR_NAME, ATTR_TYPE_OWNER, ATTR_TYPE_NAME, INHERITED
    from XDBPM.XDBPM_ALL_TYPE_ATTRS
   where TYPE_NAME = P_TYPE_NAME
     and OWNER = P_TYPE_OWNER
     and INHERITED = 'NO'
   order by ATTR_NO;        

  V_ATTR                    DBMS_XMLDOM.DOMATTR;

  V_ATTRIBUTE_LIST      XMLTYPE;
  V_ATTRIBUTE_LIST_DOCUMENT DBMS_XMLDOM.DOMDOCUMENT;
  V_ATTRIBUTE_LIST_ROOT     DBMS_XMLDOM.DOMELEMENT;

  V_ATTRIBUTE           XMLTYPE;
  V_ATTRIBUTE_DOCUMENT                DBMS_XMLDOM.DOMDOCUMENT;
  V_ATTRIBUTE_ROOT                    DBMS_XMLDOM.DOMELEMENT;

  V_TYPE_DEFINITION     XMLTYPE;
  V_TYPE_DEFINITION_DOCUMENT  DBMS_XMLDOM.DOMDOCUMENT;
  V_TYPE_DEFINITION_ROOT      DBMS_XMLDOM.DOMELEMENT;
begin     

  -- --# XDB_OUTPUT.writeOutputFileEntry('getLocalAttributes() : Processing Attributes of "' || P_TYPE_OWNER || '"."' || P_TYPE_NAME || '"');

  V_ATTRIBUTE_LIST          := makeElement('Attributes');
  V_ATTRIBUTE_LIST_DOCUMENT := DBMS_XMLDOM.NEWDOMDOCUMENT(V_ATTRIBUTE_LIST);
  V_ATTRIBUTE_LIST_ROOT     := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_ATTRIBUTE_LIST_DOCUMENT);
   
  for ATTR in FIND_CHILD_ATTRS loop

    -- --# XDB_OUTPUT.writeOutputFileEntry('getLocalAttributes() : Processing Attribute "' || ATTR.ATTR_NAME || '".  TYPE = "' || ATTR.ATTR_TYPE_OWNER || '"."' || ATTR.ATTR_TYPE_NAME || '"');
  
    -- Finding Element / Attribute Name could be tricky. Use SQLName
  
    V_ATTRIBUTE          := makeElement(ATTR.ATTR_NAME);
    V_ATTRIBUTE_DOCUMENT := DBMS_XMLDOM.NEWDOMDOCUMENT(V_ATTRIBUTE);
    V_ATTRIBUTE_ROOT     := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_ATTRIBUTE_DOCUMENT);
   
    begin

      -- Check for Attributes based on collection types, With Nested Table storage each Collection will cost 2 columns.
      
      select ELEM_TYPE_NAME, ELEM_TYPE_OWNER
        into V_COLLECTION_TYPE, V_COLLECTION_OWNER 
        from XDBPM.XDBPM_ALL_COLL_TYPES
       where TYPE_NAME = ATTR.ATTR_TYPE_NAME
         and OWNER = ATTR.ATTR_TYPE_OWNER;

      -- --# XDB_OUTPUT.writeOutputFileEntry('Adding "' || ATTR.ATTR_NAME || '". Collection of "' || ATTR.ATTR_TYPE_OWNER || '"."' || ATTR.ATTR_TYPE_NAME || '".');

      -- Attribute is a Collection Type. 
      -- Assume Collection will be managed as a NESTED TABLE
      -- Each Collection costs 2 columns.
      -- May want to count the number of columns in the NESTED_TABLE at a later date.

      V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'SQLCollType');
                     DBMS_XMLDOM.SETVALUE(V_ATTR,ATTR.ATTR_TYPE_NAME);
      V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);
             
      V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'SQLCollTypeOwner');
                     DBMS_XMLDOM.SETVALUE(V_ATTR,ATTR.ATTR_TYPE_OWNER);
      V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);

      V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'SQLType');
                     DBMS_XMLDOM.SETVALUE(V_ATTR,V_COLLECTION_TYPE);
      V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);

      V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'SQLTypeOwner');
                     DBMS_XMLDOM.SETVALUE(V_ATTR,V_COLLECTION_OWNER);
      V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);

      if ((ATTR.ATTR_NAME = 'SYS_XDBPD$') and (ATTR.ATTR_TYPE_NAME = 'XDB$RAW_LIST_T') and (ATTR.ATTR_TYPE_OWNER='XDB')  and (V_COLLECTION_TYPE='RAW')) then      
        V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'columns');
                       DBMS_XMLDOM.SETVALUE(V_ATTR,1);
        V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);
      else
        V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'columns');
                       DBMS_XMLDOM.SETVALUE(V_ATTR,2);
        V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);
      end if;
      
    exception
      when no_data_found then
        
        -- Attribute is not a collection type.
      
        begin
          
          -- Check for Attributes based on non-scalar types. 
          
          select 1
            into V_TEMP_RESULT
            from XDBPM.XDBPM_ALL_TYPES
           where not (TYPE_NAME = 'XMLTYPE' and OWNER = 'SYS')
             and not (TYPE_NAME = 'XDB$ENUM_T' and OWNER = 'XDB')
             and TYPE_NAME = ATTR.ATTR_TYPE_NAME
             and OWNER = ATTR.ATTR_TYPE_OWNER;
          
          -- Attribute is based on a non-scalar type. Find the Storage Model for this type.
          
          V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'SQLType');
                         DBMS_XMLDOM.SETVALUE(V_ATTR,ATTR.ATTR_TYPE_NAME);
          V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);

          V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'SQLTypeOwner');
                         DBMS_XMLDOM.SETVALUE(V_ATTR,ATTR.ATTR_TYPE_OWNER);
          V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);

          V_TYPE_DEFINITION            := findStorageModel(ATTR.ATTR_TYPE_NAME, ATTR.ATTR_TYPE_OWNER, 'YES');    
          
          V_TYPE_DEFINITION_DOCUMENT   := DBMS_XMLDOM.NEWDOMDOCUMENT(V_TYPE_DEFINITION);
          V_TYPE_DEFINITION_ROOT       := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_TYPE_DEFINITION_DOCUMENT);
          V_ATTRIBUTE_COUNT            := DBMS_XMLDOM.GETATTRIBUTE(V_TYPE_DEFINITION_ROOT,'columns');

          V_TYPE_DEFINITION_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.IMPORTNODE(V_ATTRIBUTE_DOCUMENT,DBMS_XMLDOM.MAKENODE(V_TYPE_DEFINITION_ROOT),TRUE));
          V_TYPE_DEFINITION_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.APPENDCHILD(DBMS_XMLDOM.MAKENODE(V_ATTRIBUTE_ROOT),DBMS_XMLDOM.MAKENODE(V_TYPE_DEFINITION_ROOT)));
                                  
          DBMS_XMLDOM.FREEDOCUMENT(V_TYPE_DEFINITION_DOCUMENT);
                                  
          if (ATTR.ATTR_TYPE_NAME = 'XDB$ENUM_T' and ATTR.ATTR_TYPE_OWNER = 'XDB') then
            -- The cost of a XDB$ENUM_T is 2 columns
            V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'columns');
                           DBMS_XMLDOM.SETVALUE(V_ATTR,2);
            V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);
          else
            -- The cost of a non scalar Type is the number of attributes plus one for Type and one for the TYPEID.
           
            V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'columns');
                           DBMS_XMLDOM.SETVALUE(V_ATTR,V_ATTRIBUTE_COUNT + 2);
            V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);
          end if;
        
        exception
          when no_data_found then
           
             -- Attribute is based on a scalar type
          
             V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'SQLType');
                            DBMS_XMLDOM.SETVALUE(V_ATTR,ATTR.ATTR_TYPE_NAME);
             V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);
              
             V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_DOCUMENT,'columns');
                            DBMS_XMLDOM.SETVALUE(V_ATTR,1);
             V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_ROOT,V_ATTR);
          when others then
            raise;
        end;
      when others then
        raise;
    end;

    V_TOTAL_ATTRIBUTES     := V_TOTAL_ATTRIBUTES + DBMS_XMLDOM.GETATTRIBUTE(V_ATTRIBUTE_ROOT,'columns');
    
    V_ATTRIBUTE_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.IMPORTNODE(V_ATTRIBUTE_LIST_DOCUMENT,DBMS_XMLDOM.MAKENODE(V_ATTRIBUTE_ROOT),TRUE));
    V_ATTRIBUTE_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.APPENDCHILD(DBMS_XMLDOM.MAKENODE(V_ATTRIBUTE_LIST_ROOT),DBMS_XMLDOM.MAKENODE(V_ATTRIBUTE_ROOT)));
    
    DBMS_XMLDOM.FREEDOCUMENT(V_ATTRIBUTE_DOCUMENT);

    if (V_TOTAL_ATTRIBUTES > 25000) then
      exit;
    end if;

  end loop; 

  V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_ATTRIBUTE_LIST_DOCUMENT,'columns');
                 DBMS_XMLDOM.SETVALUE(V_ATTR,V_TOTAL_ATTRIBUTES);
  V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ATTRIBUTE_LIST_ROOT,V_ATTR);

  -- --# XDB_OUTPUT.writeOutputFileEntry('getLocalAttributes() : Local Attributes Processed.');

  return V_ATTRIBUTE_LIST;

end;
--
function getSubTypes(P_TYPE_NAME VARCHAR2, P_TYPE_OWNER VARCHAR2) 
return XMLType
as
  CURSOR FIND_SUBTYPES
  is 
  select TYPE_NAME, OWNER 
    from XDBPM.XDBPM_ALL_TYPES
   where SUPERTYPE_NAME  = P_TYPE_NAME
     and SUPERTYPE_OWNER = P_TYPE_OWNER;  

  CURSOR FIND_SUBTYPE_HEIRARCHY
  is 
  select LEVEL, TYPE_NAME, OWNER 
    from XDBPM.XDBPM_ALL_TYPES
   where TYPE_NAME <> P_TYPE_NAME
     and OWNER <> P_TYPE_OWNER
         connect by SUPERTYPE_NAME = PRIOR TYPE_NAME
                and SUPERTYPE_OWNER = PRIOR OWNER
         start with TYPE_NAME = P_TYPE_NAME
                and OWNER = P_TYPE_OWNER;

  V_SUBTYPE_LIST                 XMLType;
  V_SUBTYPE_LIST_DOCUMENT        DBMS_XMLDOM.DOMDOCUMENT;
  V_SUBTYPE_LIST_ROOT            DBMS_XMLDOM.DOMELEMENT;

  V_TYPE_DEFINITION              XMLType;
  V_TYPE_DEFINITION_DOCUMENT     DBMS_XMLDOM.DOMDOCUMENT;
  V_TYPE_DEFINITION_ROOT         DBMS_XMLDOM.DOMELEMENT;

  V_SUBTYPE_DEFINITIONS          XMLType;
  V_SUBTYPE_DEFINITIONS_DOCUMENT DBMS_XMLDOM.DOMDOCUMENT;
  V_SUBTYPE_DEFINITIONS_ROOT     DBMS_XMLDOM.DOMELEMENT;

  V_ATTRIBUTE_LIST               XMLType;
  V_ATTRIBUTE_LIST_DOCUMENT      DBMS_XMLDOM.DOMDOCUMENT;
  V_ATTRIBUTE_LIST_ROOT          DBMS_XMLDOM.DOMELEMENT;
  
  V_SUBTYPES_EXIST               BOOLEAN := FALSE;
  V_TOTAL_columns                number;
  V_ATTRIBUTE_COUNT              number;
  
  V_ATTR                         DBMS_XMLDOM.DOMATTR;
  V_COMPLEX_TYPE                 VARCHAR2(2000);
  
begin

  --# XDB_OUTPUT.writeOutputFileEntry('getSubTypes() : Processing Subtypes of "' || P_TYPE_OWNER || '"."' || P_TYPE_NAME || '"');

  V_SUBTYPE_LIST          := makeElement('SubTypeDefinitions');
  V_SUBTYPE_LIST_DOCUMENT := DBMS_XMLDOM.NEWDOMDOCUMENT(V_SUBTYPE_LIST);
  V_SUBTYPE_LIST_ROOT     := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_SUBTYPE_LIST_DOCUMENT);

  V_TOTAL_columns := 0;
  
  for t in FIND_SUBTYPES() loop

    V_SUBTYPES_EXIST  := TRUE;

    --# XDB_OUTPUT.writeOutputFileEntry('getSubTypes() : Processing Subtype : "' || t.OWNER || '"."' || t.TYPE_NAME || '"');
        
    V_TYPE_DEFINITION            := makeElement(t.TYPE_NAME);
    V_TYPE_DEFINITION_DOCUMENT   := DBMS_XMLDOM.NEWDOMDOCUMENT(V_TYPE_DEFINITION);
    V_TYPE_DEFINITION_ROOT       := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_TYPE_DEFINITION_DOCUMENT);
    
    V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_TYPE_DEFINITION_DOCUMENT,'SQLTypeOwner');
                   DBMS_XMLDOM.SETVALUE(V_ATTR,t.OWNER);
    V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_TYPE_DEFINITION_ROOT,V_ATTR);

    begin
      select x.XMLDATA.NAME 
        into V_COMPLEX_TYPE 
        from XDB.XDB$COMPLEX_TYPE x
       where x.XMLDATA.SQLTYPE = t.TYPE_NAME
         and x.XMLDATA.SQLSCHEMA = t.OWNER;
   
      V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_TYPE_DEFINITION_DOCUMENT,'type');
                     DBMS_XMLDOM.SETVALUE(V_ATTR,V_COMPLEX_TYPE);
      V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_TYPE_DEFINITION_ROOT,V_ATTR);

      -- Consider adding Schema URL Attribute
    
    exception
      when no_data_found then
        null;
      when others then
        raise;
    end;
             
    V_ATTRIBUTE_LIST            := getLocalAttributes(t.TYPE_NAME, t.OWNER);   
    V_ATTRIBUTE_LIST_DOCUMENT   := DBMS_XMLDOM.NEWDOMDOCUMENT(V_ATTRIBUTE_LIST);
    V_ATTRIBUTE_LIST_ROOT       := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_ATTRIBUTE_LIST_DOCUMENT);
    V_ATTRIBUTE_COUNT           := DBMS_XMLDOM.GETATTRIBUTE(V_ATTRIBUTE_LIST_ROOT,'columns');
  
    V_ATTRIBUTE_LIST_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.IMPORTNODE(V_TYPE_DEFINITION_DOCUMENT,DBMS_XMLDOM.MAKENODE(V_ATTRIBUTE_LIST_ROOT),TRUE));
    V_ATTRIBUTE_LIST_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.APPENDCHILD(DBMS_XMLDOM.MAKENODE(V_TYPE_DEFINITION_ROOT),DBMS_XMLDOM.MAKENODE(V_ATTRIBUTE_LIST_ROOT)));

    DBMS_XMLDOM.FREEDOCUMENT(V_ATTRIBUTE_LIST_DOCUMENT);

    V_SUBTYPE_DEFINITIONS       := getSubTypes(t.TYPE_NAME,t.OWNER);

    if (V_SUBTYPE_DEFINITIONS is not NULL) then
      V_SUBTYPE_DEFINITIONS_DOCUMENT   := DBMS_XMLDOM.NEWDOMDOCUMENT(V_SUBTYPE_DEFINITIONS);
      V_SUBTYPE_DEFINITIONS_ROOT       := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_SUBTYPE_DEFINITIONS_DOCUMENT);
      V_ATTRIBUTE_COUNT                := V_ATTRIBUTE_COUNT + DBMS_XMLDOM.GETATTRIBUTE(V_SUBTYPE_DEFINITIONS_ROOT,'columns');
  
      V_SUBTYPE_DEFINITIONS_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.IMPORTNODE(V_TYPE_DEFINITION_DOCUMENT,DBMS_XMLDOM.MAKENODE(V_SUBTYPE_DEFINITIONS_ROOT),TRUE));
      V_SUBTYPE_DEFINITIONS_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.APPENDCHILD(DBMS_XMLDOM.MAKENODE(V_TYPE_DEFINITION_ROOT),DBMS_XMLDOM.MAKENODE(V_SUBTYPE_DEFINITIONS_ROOT)));
    end if;

    V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_TYPE_DEFINITION_DOCUMENT,'columns');
                   DBMS_XMLDOM.SETVALUE(V_ATTR,V_ATTRIBUTE_COUNT);
    V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_TYPE_DEFINITION_ROOT,V_ATTR);
    
    V_TYPE_DEFINITION_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.IMPORTNODE(V_SUBTYPE_LIST_DOCUMENT,DBMS_XMLDOM.MAKENODE(V_TYPE_DEFINITION_ROOT),TRUE));
    V_TYPE_DEFINITION_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.APPENDCHILD(DBMS_XMLDOM.MAKENODE(V_SUBTYPE_LIST_ROOT),DBMS_XMLDOM.MAKENODE(V_TYPE_DEFINITION_ROOT)));

    V_TOTAL_columns := V_TOTAL_columns + V_ATTRIBUTE_COUNT;
        
  end loop;
  
  if (V_SUBTYPES_EXIST) then
    V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_SUBTYPE_LIST_DOCUMENT,'columns');
                   DBMS_XMLDOM.SETVALUE(V_ATTR,V_TOTAL_columns);
    V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_SUBTYPE_LIST_ROOT,V_ATTR);

    --# XDB_OUTPUT.writeOutputFileEntry('getLocalAttributes() : SubType Processing complete.');
    return V_SUBTYPE_LIST;
  else
    --# XDB_OUTPUT.writeOutputFileEntry('getLocalAttributes() : No SubTypes found.');
    return NULL;
  end if;

end;
--
function findSuperTypeModel(P_TYPE_NAME VARCHAR2, P_TYPE_OWNER VARCHAR2)
return XMLType
as
begin
  --# XDB_OUTPUT.writeOutputFileEntry('Processing Super Type : "' || P_TYPE_OWNER || '"."' || P_TYPE_NAME || '"');
  return findStorageModel(P_TYPE_NAME, P_TYPE_OWNER,'NO');
end;
--
function getStorageModel(P_TYPE_NAME VARCHAR2, P_TYPE_OWNER VARCHAR2, P_INCLUDE_SUBTYPES VARCHAR2 DEFAULT 'YES') 
return XMLType
as
  V_TYPE_DEFINITION      XMLTYPE;
  V_ATTRIBUTE_COUNT      NUMBER := 0;
  SUBTYPE_STORAGE_MODEL  XMLTYPE;

  V_SUPERTYPE_DEFINITION XMLTYPE;
  V_SUPERTYPE_DOCUMENT   DBMS_XMLDOM.DOMDOCUMENT;
  V_SUPERTYPE_ROOT       DBMS_XMLDOM.DOMELEMENT;

  V_SUBTYPE_DEFINITION XMLTYPE;
  V_SUBTYPE_DOCUMENT   DBMS_XMLDOM.DOMDOCUMENT;
  V_SUBTYPE_ROOT       DBMS_XMLDOM.DOMELEMENT;

  V_ATTRIBUTE_LIST          XMLTYPE;
  V_ATTRIBUTE_LIST_DOCUMENT DBMS_XMLDOM.DOMDOCUMENT;
  V_ATTRIBUTE_LIST_ROOT     DBMS_XMLDOM.DOMELEMENT;

  cursor FIND_SUPERTYPE_HEIRARCHY 
  is
  select TYPE_NAME, OWNER
    from XDBPM.XDBPM_ALL_TYPES 
   where TYPE_NAME <> P_TYPE_NAME
     and OWNER <> P_TYPE_OWNER
         connect by TYPE_NAME = PRIOR SUPERTYPE_NAME
                and OWNER = PRIOR SUPERTYPE_OWNER
         start with TYPE_NAME = P_TYPE_NAME
                and OWNER = P_TYPE_OWNER
   order by LEVEL;

  V_COMPLEX_TYPE        VARCHAR2(2000);
  V_SUPERTYPE_NAME      VARCHAR2(30);
  v_SUPERTYPE_OWNER     VARCHAR2(30);
  
  V_DOCUMENT            DBMS_XMLDOM.DOMDOCUMENT;
  V_ROOT                DBMS_XMLDOM.DOMELEMENT;
  V_ATTR                DBMS_XMLDOM.DOMATTR;
  
begin

  --# XDB_OUTPUT.writeOutputFileEntry('getStorageModel() : Processing "' || P_TYPE_OWNER || '"."' || P_TYPE_NAME || '"');
  
  V_TYPE_DEFINITION := makeElement(P_TYPE_NAME);

  V_DOCUMENT  := DBMS_XMLDOM.NEWDOMDOCUMENT(V_TYPE_DEFINITION);
  V_ROOT      := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_DOCUMENT);

  V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_DOCUMENT,'SQLTypeOwner');
                 DBMS_XMLDOM.SETVALUE(V_ATTR,P_TYPE_OWNER);
  V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ROOT,V_ATTR);

  begin
    select x.XMLDATA.NAME 
      into V_COMPLEX_TYPE 
      from XDB.XDB$COMPLEX_TYPE x
     where x.XMLDATA.SQLTYPE = P_TYPE_NAME
       and x.XMLDATA.SQLSCHEMA = P_TYPE_OWNER;
   
    V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_DOCUMENT,'type');
                   DBMS_XMLDOM.SETVALUE(V_ATTR,V_COMPLEX_TYPE);
    V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ROOT,V_ATTR);

    -- Consider adding Schema URL Attribute
    
  exception
    when no_data_found then
      null;
    when others then
      raise;
  end;
             
  select SUPERTYPE_NAME, SUPERTYPE_OWNER
    into V_SUPERTYPE_NAME, V_SUPERTYPE_OWNER
    from XDBPM.XDBPM_ALL_TYPES
   where TYPE_NAME = P_TYPE_NAME
     and OWNER = P_TYPE_OWNER;
    
  -- Process SuperType.  
    
  if (V_SUPERTYPE_NAME is not null) then

    --# XDB_OUTPUT.writeOutputFileEntry('getStorageModel() : Processing Supertypes of "' || P_TYPE_OWNER || '"."' || P_TYPE_NAME || '"');

    V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_DOCUMENT,'SQLParentType');
                   DBMS_XMLDOM.SETVALUE(V_ATTR,V_SUPERTYPE_NAME);
    V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ROOT,V_ATTR);
             
    V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_DOCUMENT,'SQLParentTypeOwner');
                   DBMS_XMLDOM.SETVALUE(V_ATTR,V_SUPERTYPE_OWNER);
    V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ROOT,V_ATTR);
    
    -- Find the Definition for the super type. Do not include the definition of it's subtypes.
    
    V_SUPERTYPE_DEFINITION := findSuperTypeModel(V_SUPERTYPE_NAME, V_SUPERTYPE_OWNER);
    
    -- --# XDB_OUTPUT.writeOutputFileEntry(dbms_lob.substr(V_SUPERTYPE_DEFINITION.getClobVal(),1000,1));
    
    V_SUPERTYPE_DOCUMENT   := DBMS_XMLDOM.NEWDOMDOCUMENT(V_SUPERTYPE_DEFINITION);
    V_SUPERTYPE_ROOT       := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_SUPERTYPE_DOCUMENT);
    V_ATTRIBUTE_COUNT      := V_ATTRIBUTE_COUNT + DBMS_XMLDOM.GETATTRIBUTE(V_SUPERTYPE_ROOT,'columns');
  
    V_SUPERTYPE_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.IMPORTNODE(V_DOCUMENT,DBMS_XMLDOM.MAKENODE(V_SUPERTYPE_ROOT),TRUE));
    V_SUPERTYPE_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.APPENDCHILD(DBMS_XMLDOM.MAKENODE(V_ROOT),DBMS_XMLDOM.MAKENODE(V_SUPERTYPE_ROOT)));
    
    DBMS_XMLDOM.FREEDOCUMENT(V_SUPERTYPE_DOCUMENT);

    --# XDB_OUTPUT.writeOutputFileEntry('getStorageModel() : Supertype Processing Complete.');
    
  end if;
  
  -- Process Attributes defined directly by the Type.

  V_ATTRIBUTE_LIST            := getLocalAttributes(P_TYPE_NAME, P_TYPE_OWNER);   
  V_ATTRIBUTE_LIST_DOCUMENT   := DBMS_XMLDOM.NEWDOMDOCUMENT(V_ATTRIBUTE_LIST);
  V_ATTRIBUTE_LIST_ROOT       := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_ATTRIBUTE_LIST_DOCUMENT);
  V_ATTRIBUTE_COUNT           := V_ATTRIBUTE_COUNT + DBMS_XMLDOM.GETATTRIBUTE(V_ATTRIBUTE_LIST_ROOT,'columns');
  
  V_ATTRIBUTE_LIST_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.IMPORTNODE(V_DOCUMENT,DBMS_XMLDOM.MAKENODE(V_ATTRIBUTE_LIST_ROOT),TRUE));
  V_ATTRIBUTE_LIST_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.APPENDCHILD(DBMS_XMLDOM.MAKENODE(V_ROOT),DBMS_XMLDOM.MAKENODE(V_ATTRIBUTE_LIST_ROOT)));

  DBMS_XMLDOM.FREEDOCUMENT(V_ATTRIBUTE_LIST_DOCUMENT);

  if (P_INCLUDE_SUBTYPES = 'YES') then
  
    -- Process any Sub-Types...

    V_SUBTYPE_DEFINITION := getSubTypes(P_TYPE_NAME, P_TYPE_OWNER);
    if (V_SUBTYPE_DEFINITION is not null) then
      V_SUBTYPE_DOCUMENT   := DBMS_XMLDOM.NEWDOMDOCUMENT(V_SUBTYPE_DEFINITION);
      V_SUBTYPE_ROOT       := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_SUBTYPE_DOCUMENT);
      V_ATTRIBUTE_COUNT    := V_ATTRIBUTE_COUNT + DBMS_XMLDOM.GETATTRIBUTE(V_SUBTYPE_ROOT,'columns');
  
      V_SUBTYPE_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.IMPORTNODE(V_DOCUMENT,DBMS_XMLDOM.MAKENODE(V_SUBTYPE_ROOT),TRUE));
      V_SUBTYPE_ROOT       := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.APPENDCHILD(DBMS_XMLDOM.MAKENODE(V_ROOT),DBMS_XMLDOM.MAKENODE(V_SUBTYPE_ROOT)));    

      DBMS_XMLDOM.FREEDOCUMENT(V_SUBTYPE_DOCUMENT);

    end if;
  
  end if;

  V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_DOCUMENT,'columns');
                 DBMS_XMLDOM.SETVALUE(V_ATTR,V_ATTRIBUTE_COUNT);
  V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ROOT,V_ATTR);

  -- Cache the type definition.
  -- --# XDB_OUTPUT.writeOutputFileEntry('Cached Storage Model for "' || P_TYPE_OWNER || '.' || P_TYPE_NAME || '".');
  insert into XDBPM.STORAGE_MODEL_CACHE (TYPE_NAME, TYPE_OWNER, EXTENDED_DEFINITION, STORAGE_MODEL) VALUES (P_TYPE_NAME, P_TYPE_OWNER, P_INCLUDE_SUBTYPES, V_TYPE_DEFINITION);
    
  return V_TYPE_DEFINITION;
end;
--    
function findStorageModel(P_TYPE_NAME VARCHAR2, P_TYPE_OWNER VARCHAR2, P_INCLUDE_SUBTYPES VARCHAR2 DEFAULT 'YES')
--
-- Find the Storage Model for the Base Type.
--
-- If the type is derived from another type we need the storage model of the Base Type
-- 
-- As storage models are calculated they are cached in the global temporary table STORAGE_MODEL_CACHE. This makes
-- the process much more efficient. A global temporary table is used to minimize memory usage.
--
return XMLType 
as
  V_STORAGE_MODEL          XMLType;
  V_STORAGE_MODEL_DOCUMENT DBMS_XMLDOM.DOMDOCUMENT;
  V_STORAGE_MODEL_ROOT     DBMS_XMLDOM.DOMELEMENT;
  V_ATTRIBUTE_COUNT        VARCHAR2(10);
begin

  --# XDB_OUTPUT.writeOutputFileEntry('findStorageModel() [' || G_DEPTH_COUNT || '] : Processing "' || P_TYPE_OWNER || '"."' || P_TYPE_NAME || '".' );
                
  begin
    SELECT STORAGE_MODEL 
      into V_STORAGE_MODEL
      from XDBPM.STORAGE_MODEL_CACHE
     where TYPE_NAME = P_TYPE_NAME
       and TYPE_OWNER = P_TYPE_OWNER
       and EXTENDED_DEFINITION = P_INCLUDE_SUBTYPES;

     --# XDB_OUTPUT.writeOutputFileEntry('Resolved Storage Model from cache.');
       
  exception
    when no_data_found then
      G_DEPTH_COUNT := G_DEPTH_COUNT + 1;
      V_STORAGE_MODEL := getStorageModel(P_TYPE_NAME,P_TYPE_OWNER, P_INCLUDE_SUBTYPES);
      G_DEPTH_COUNT := G_DEPTH_COUNT - 1;  
    when others then
      raise;
  end;

  V_STORAGE_MODEL_DOCUMENT := DBMS_XMLDOM.NEWDOMDOCUMENT(V_STORAGE_MODEL);
  V_STORAGE_MODEL_ROOT     := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_STORAGE_MODEL_DOCUMENT);
  V_ATTRIBUTE_COUNT        := DBMS_XMLDOM.GETATTRIBUTE(V_STORAGE_MODEL_ROOT,'columns');
  
  --# XDB_OUTPUT.writeOutputFileEntry('findStorageModel : Attribute Count for "' || P_TYPE_OWNER || '"."' || P_TYPE_NAME || '" = ' || V_ATTRIBUTE_COUNT || '.' );
  return V_STORAGE_MODEL;
  
  
end;
--
function analyzeTypeHierarchy(P_GLOBAL_OBJECT_NAME VARCHAR2, P_TYPE_NAME VARCHAR2, P_TYPE_OWNER VARCHAR2)
--
-- Generates a map showing the number of columns required to persist an instance a global complex type or global elemnent, 
-- including those introduced by of all of its subtypes.
--
return XMLType 
as 
  V_STORAGE_MODEL       XMLTYPE;
  V_COUNT               NUMBER := 0;

  V_DOCUMENT            DBMS_XMLDOM.DOMDOCUMENT;
  V_ROOT                DBMS_XMLDOM.DOMELEMENT;
  V_ATTR                DBMS_XMLDOM.DOMATTR;
  V_MODEL               DBMS_XMLDOM.DOMELEMENT;
  V_TYPE_DEFINITION     DBMS_XMLDOM.DOMELEMENT;
begin
 	 --# XDB_OUTPUT.writeOutputFileEntry('"' || P_GLOBAL_OBJECT_NAME || '" mapped to "' || P_TYPE_OWNER || '"."' || P_TYPE_NAME || '".');

  V_STORAGE_MODEL := makeElement(P_GLOBAL_OBJECT_NAME);

  V_DOCUMENT  := DBMS_XMLDOM.NEWDOMDOCUMENT(V_STORAGE_MODEL);
  V_ROOT      := DBMS_XMLDOM.GETDOCUMENTELEMENT(V_DOCUMENT);

  V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_DOCUMENT,'SQLType');
                 DBMS_XMLDOM.SETVALUE(V_ATTR,P_TYPE_NAME);
  V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ROOT,V_ATTR);
             
  V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_DOCUMENT,'SQLTypeOwner');
                 DBMS_XMLDOM.SETVALUE(V_ATTR,P_TYPE_OWNER);
  V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ROOT,V_ATTR);
 
  V_TYPE_DEFINITION   := DBMS_XMLDOM.GETDOCUMENTELEMENT(DBMS_XMLDOM.NEWDOMDOCUMENT(findStorageModel(P_TYPE_NAME, P_TYPE_OWNER, 'YES')));
  V_TYPE_DEFINITION   := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.IMPORTNODE(V_DOCUMENT,DBMS_XMLDOM.MAKENODE(V_TYPE_DEFINITION),TRUE));
  V_TYPE_DEFINITION   := DBMS_XMLDOM.MAKEELEMENT(DBMS_XMLDOM.APPENDCHILD(DBMS_XMLDOM.MAKENODE(V_ROOT),DBMS_XMLDOM.MAKENODE(V_TYPE_DEFINITION)));

  V_ATTR      := DBMS_XMLDOM.CREATEATTRIBUTE(V_DOCUMENT,'columns');
                 DBMS_XMLDOM.SETVALUE(V_ATTR,DBMS_XMLDOM.GETATTRIBUTE(V_TYPE_DEFINITION,'columns')+2);
  V_ATTR      := DBMS_XMLDOM.SETATTRIBUTENODE(V_ROOT,V_ATTR);

  return  V_STORAGE_MODEL;

end;
--
function analyzeTypeHierarchy(P_GLOBAL_OBJECT_NAME VARCHAR2) 
return XMLTYPE
--
-- Generates a map showing the number of columns required to persist an instance a global complex type or global elemnent, 
-- including those introduced by of all of its subtypes.
--
as
  pragma autonomous_transaction;
  
  V_SQLTYPE           VARCHAR2(128);
  V_SQLSCHEMA         VARCHAR2(32);
  V_RESULT            XMLType;
begin

 G_DEPTH_COUNT := 0;
 	
  --# XDB_OUTPUT.createLogFile('/public/analyzeTypeHierarchy.log',TRUE);
  --# XDB_OUTPUT.writeOutputFileEntry('Processing "' || P_GLOBAL_OBJECT_NAME || '".');

  begin 
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN 
  select ct.XMLDATA.SQLTYPE, ct.XMLDATA.SQLSCHEMA
    into V_SQLTYPE, V_SQLSCHEMA
    from XDB.XDB$COMPLEX_TYPE ct, XDB.XDB$SCHEMA s
   where ct.XMLDATA.NAME = P_GLOBAL_OBJECT_NAME
     and ref(s) = ct.XMLDATA.PARENT_SCHEMA
     and s.XMLDATA.SCHEMA_OWNER = USER;
  exception
    when no_data_found then
		 select e.XMLDATA.PROPERTY.SQLTYPE, e.XMLDATA.PROPERTY.SQLSCHEMA
    	 into V_SQLTYPE, V_SQLSCHEMA
    	 from XDB.XDB$ELEMENT e, XDB.XDB$SCHEMA s
   where e.XMLDATA.PROPERTY.NAME = P_GLOBAL_OBJECT_NAME
     and e.XMLDATA.PROPERTY.GLOBAL = HEXTORAW('01')
     and ref(s) = e.XMLDATA.PROPERTY.PARENT_SCHEMA
     and s.XMLDATA.SCHEMA_OWNER = USER;
$ELSE      	 
   select SQLTYPE, SQLSCHEMA
     into V_SQLTYPE, V_SQLSCHEMA
     from USER_XML_SCHEMAS,
          xmlTable
          (
             xmlnamespaces
             (
               'http://www.w3.org/2001/XMLSchema' as "xsd",
               'http://xmlns.oracle.com/xdb' as "xdb"
             ),
             '$SCH/xsd:schema/xsd:complexType[@name=$OBJ]'
             passing SCHEMA as "SCH", P_GLOBAL_OBJECT_NAME as "OBJ"
             columns
             SQLTYPE       VARCHAR2(128)  path '@xdb:SQLType',
             SQLSCHEMA     VARCHAR2(32)   path '@xdb:SQLSchema'
          )
    where existsNode(SCHEMA,'/xsd:schema/xsd:complexType[@name="' || P_GLOBAL_OBJECT_NAME || '"]',XDB_NAMESPACES.XMLSCHEMA_PREFIX_XSD) = 1;
  exception
    when no_data_found then
      select SQLTYPE, SQLSCHEMA
        into V_SQLTYPE, V_SQLSCHEMA
        from USER_XML_SCHEMAS,
             xmlTable
             (
                xmlnamespaces
                (
                  'http://www.w3.org/2001/XMLSchema' as "xsd",
                  'http://xmlns.oracle.com/xdb' as "xdb"
                ),
                '$SCH/xsd:schema/xsd:element[@name=$OBJ]'
                passing SCHEMA as "SCH", P_GLOBAL_OBJECT_NAME as "OBJ"
                columns
                SQLTYPE       VARCHAR2(128)  path '@xdb:SQLType',
                SQLSCHEMA     VARCHAR2(32)   path '@xdb:SQLSchema'
             )
       where existsNode(SCHEMA,'/xsd:schema/xsd:element[@name="' || P_GLOBAL_OBJECT_NAME || '"]',XDB_NAMESPACES.XMLSCHEMA_PREFIX_XSD) = 1;
$END                   
    when others then
      raise;
  end;

  delete from XDBPM.STORAGE_MODEL_CACHE;
  V_RESULT := analyzeTypeHierarchy(P_GLOBAL_OBJECT_NAME,V_SQLTYPE,V_SQLSCHEMA);
  COMMIT;

  --# XDB_OUTPUT.writeOutputFileEntry('Processing Complete "' || P_GLOBAL_OBJECT_NAME || '".');
  --# XDB_OUTPUT.fliushLogFile
  return V_RESULT;
exception
  when no_data_found then
    --# XDB_OUTPUT.writeOutputFileEntry('Unable to find SQLType mapping for complexType : "' || USER || '"."' || P_GLOBAL_OBJECT_NAME || '".' );
    --# XDB_OUTPUT.fliushLogFile
    rollback;
    return null; 
  when others then
    --# XDB_OUTPUT.logException();
    --# XDB_OUTPUT.fliushLogFile
    rollback;
    raise;
end;
--
function analyzeTypeHierarchy(P_GLOBAL_OBJECT_NAME VARCHAR2, P_SCHEMA_URL VARCHAR2) 
return XMLTYPE
--
-- Generate a map showing the number of columns required to persist an instance of the complex type.
--
as
  pragma autonomous_transaction;
  
  V_SQLTYPE           VARCHAR2(128);
  V_SQLSCHEMA         VARCHAR2(32);
  V_RESULT            XMLType;
begin

 G_DEPTH_COUNT := 0;

 begin 
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN 
  select ct.XMLDATA.SQLTYPE, ct.XMLDATA.SQLSCHEMA
    into V_SQLTYPE, V_SQLSCHEMA
    from XDB.XDB$COMPLEX_TYPE ct, XDB.XDB$SCHEMA s
   where ct.XMLDATA.NAME = P_GLOBAL_OBJECT_NAME
     and ref(s) = ct.XMLDATA.PARENT_SCHEMA
     and s.XMLDATA.SCHEMA_OWNER = USER
     and s.XMLDATA.SCHEMA_URL = P_SCHEMA_URL;
  exception
    when no_data_found then
		 select e.XMLDATA.PROPERTY.SQLTYPE, e.XMLDATA.PROPERTY.SQLSCHEMA
    	 into V_SQLTYPE, V_SQLSCHEMA
    	 from XDB.XDB$ELEMENT e, XDB.XDB$SCHEMA s
   where e.XMLDATA.PROPERTY.NAME = P_GLOBAL_OBJECT_NAME
     and e.XMLDATA.PROPERTY.GLOBAL = HEXTORAW('01')
     and ref(s) = e.XMLDATA.PROPERTY.PARENT_SCHEMA
     and s.XMLDATA.SCHEMA_OWNER = USER
     and s.XMLDATA.SCHEMA_URL = P_SCHEMA_URL;
$ELSE      	 
   select SQLTYPE, SQLSCHEMA
     into V_SQLTYPE, V_SQLSCHEMA
     from USER_XML_SCHEMAS,
          xmlTable
          (
             xmlnamespaces
             (
               'http://www.w3.org/2001/XMLSchema' as "xsd",
               'http://xmlns.oracle.com/xdb' as "xdb"
             ),
             '$SCH/xsd:schema/xsd:complexType[@name=$OBJ]'
             passing SCHEMA as "SCH", P_GLOBAL_OBJECT_NAME as "OBJ"
             columns
             SQLTYPE       VARCHAR2(128)  path '@xdb:SQLType',
             SQLSCHEMA     VARCHAR2(32)   path '@xdb:SQLSchema'
          )
    where existsNode(SCHEMA,'/xsd:schema/xsd:complexType[@name="' || P_GLOBAL_OBJECT_NAME || '"]',XDB_NAMESPACES.XMLSCHEMA_PREFIX_XSD) = 1
      and SCHEMA_URL = P_SCHEMA_URL;
  exception
    when no_data_found then
      select SQLTYPE, SQLSCHEMA
        into V_SQLTYPE, V_SQLSCHEMA
        from USER_XML_SCHEMAS,
             xmlTable
             (
                xmlnamespaces
                (
                  'http://www.w3.org/2001/XMLSchema' as "xsd",
                  'http://xmlns.oracle.com/xdb' as "xdb"
                ),
                '$SCH/xsd:schema/xsd:element[@name=$OBJ]'
                passing SCHEMA as "SCH", P_GLOBAL_OBJECT_NAME as "OBJ"
                columns
                SQLTYPE       VARCHAR2(128)  path '@xdb:SQLType',
                SQLSCHEMA     VARCHAR2(32)   path '@xdb:SQLSchema'
             )
       where existsNode(SCHEMA,'/xsd:schema/xsd:element[@name="' || P_GLOBAL_OBJECT_NAME || '"]',XDB_NAMESPACES.XMLSCHEMA_PREFIX_XSD) = 1
         and SCHEMA_URL = P_SCHEMA_URL;
$END
    when others then
      raise;
  end;
     
  delete from XDBPM.STORAGE_MODEL_CACHE;
  V_RESULT := analyzeTypeHierarchy(P_GLOBAL_OBJECT_NAME,V_SQLTYPE,V_SQLSCHEMA);
  COMMIT;

  --# XDB_OUTPUT.writeOutputFileEntry('Processing Complete "' || P_GLOBAL_OBJECT_NAME || '".');
  --# XDB_OUTPUT.fliushLogFile
  return V_RESULT;
exception
  when no_data_found then
    --# XDB_OUTPUT.writeOutputFileEntry('Unable to find SQLType mapping for complexType : "' || USER || '"."' || P_GLOBAL_OBJECT_NAME || '".' );
    --# XDB_OUTPUT.fliushLogFile
    rollback;
    return null; 
  when others then
    --# XDB_OUTPUT.logException();
    --# XDB_OUTPUT.fliushLogFile
    rollback;
    raise;
end;
--
function analyzeSQLType(ATTR_NAME VARCHAR2, TARGET_TYPE_NAME VARCHAR2, TARGET_TYPE_OWNER VARCHAR2)
return XMLType 
as 
   ROOT_NODE_NAME   VARCHAR2(128);
   ATTR_DETAIL      XMLTYPE;
   XPATH_EXPRESSION VARCHAR2(129);
   
   CURSOR FIND_CHILD_ATTRS is
     select ATTR_NAME, ATTR_TYPE_OWNER, ATTR_TYPE_NAME, INHERITED
       from XDBPM.XDBPM_ALL_TYPE_ATTRS
      where OWNER = TARGET_TYPE_OWNER
        and TYPE_NAME = TARGET_TYPE_NAME
      order by ATTR_NO;        
   
   CHILD_ATTR  XMLTYPE;
   ATTR_COUNT NUMBER := 0;
   TEMP number;
   
   COLLECTION_TYPE_NAME  VARCHAR2(30);
   COLLECTION_TYPE_OWNER VARCHAR2(30);
   
begin

  -- --# XDB_OUTPUT.writeOutputFileEntry('Processing Attribute ' || ATTR_NAME || ' of ' || TARGET_TYPE_OWNER || '.' || TARGET_TYPE_NAME );
  
  ATTR_DETAIL := makeElement(ATTR_NAME);
  XPATH_EXPRESSION := '/' || ATTR_DETAIL.GETROOTELEMENT();

  for ATTR in FIND_CHILD_ATTRS loop
   
    begin
      select ELEM_TYPE_NAME, ELEM_TYPE_OWNER
        into COLLECTION_TYPE_NAME, COLLECTION_TYPE_OWNER 
        from XDBPM.XDBPM_ALL_COLL_TYPES
       where TYPE_NAME = ATTR.ATTR_TYPE_NAME
         and OWNER = ATTR.ATTR_TYPE_OWNER;
            
      CHILD_ATTR := analyzeSQLType(ATTR.ATTR_NAME, COLLECTION_TYPE_NAME, COLLECTION_TYPE_OWNER );
      ATTR_COUNT := ATTR_COUNT + CHILD_ATTR.extract('/' || CHILD_ATTR.GETROOTELEMENT()  || '/@sqlAttrs').getNumberVal();

      select appendChildXML(ATTR_DETAIL,XPATH_EXPRESSION,CHILD_ATTR)
        into ATTR_DETAIL
        from DUAL;
    exception
      when no_data_found then
        begin
          select 1 
            into TEMP
            from XDBPM.XDBPM_ALL_TYPES
           where TYPE_NAME = ATTR.ATTR_TYPE_NAME
            and OWNER = ATTR.ATTR_TYPE_OWNER;
          
          CHILD_ATTR := analyzeSQLType(ATTR.ATTR_NAME, ATTR.ATTR_TYPE_NAME, ATTR.ATTR_TYPE_OWNER );
          ATTR_COUNT := ATTR_COUNT + CHILD_ATTR.extract('/' || CHILD_ATTR.GETROOTELEMENT() || '/@sqlAttrs').getNumberVal();

          select appendChildXML(ATTR_DETAIL,XPATH_EXPRESSION,CHILD_ATTR)
            into ATTR_DETAIL
            from DUAL;
        exception
         when no_data_found then
           ATTR_COUNT := ATTR_COUNT + 1; 
         when others then
           raise;
        end;
    when others then
      raise;
    end;
  end loop; 
   
  select insertChildXML(ATTR_DETAIL,XPATH_EXPRESSION,'@sqlAttrs',ATTR_COUNT) 
    into ATTR_DETAIL
    from dual;
 
  return ATTR_DETAIL;
end;
--
function analyzeComplexType(P_COMPLEX_TYPE_NAME VARCHAR2)
return XMLType
as
  V_RESULT       XMLType;
  V_SQLTYPE      VARCHAR2(128);
  V_SQLSCHEMA    VARCHAR2(32);
begin
  select SQLTYPE, SQLSCHEMA
    into V_SQLTYPE, V_SQLSCHEMA
    from USER_XML_SCHEMAS,
         xmlTable
         (
            xmlnamespaces
            (
              'http://www.w3.org/2001/XMLSchema' as "xsd",
              'http://xmlns.oracle.com/xdb' as "xdb"
            ),
            '/xsd:schema/xsd:complexType'
            passing Schema
            columns
            COMPLEX_TYPE_NAME VARCHAR2(4000) path '@name',
            SQLTYPE           VARCHAR2(128)  path '@xdb:SQLType',
            SQLSCHEMA         VARCHAR2(32)   path '@xdb:SQLSchema'
         )
   where COMPLEX_TYPE_NAME = P_COMPLEX_TYPE_NAME;
      
  V_RESULT := analyzeSQLType(P_COMPLEX_TYPE_NAME,V_SQLTYPE,V_SQLSCHEMA);
 
  select insertChildXML(V_RESULT,'/' || P_COMPLEX_TYPE_NAME,'@SQLType',V_SQLTYPE) 
    into V_RESULT
    from dual;
    
  return V_RESULT;
end;
--
function analyzeComplexType(P_COMPLEX_TYPE_NAME VARCHAR2, P_SCHEMA_URL VARCHAR2)
return XMLType
as
  V_RESULT       XMLType;
  V_SQLTYPE      VARCHAR2(128);
  V_SQLSCHEMA    VARCHAR2(32);
begin
  select SQLTYPE, SQLSCHEMA
    into V_SQLTYPE, V_SQLSCHEMA
    from USER_XML_SCHEMAS,
         xmlTable
         (
            xmlnamespaces
            (
              'http://www.w3.org/2001/XMLSchema' as "xsd",
              'http://xmlns.oracle.com/xdb' as "xdb"
            ),
            '/xsd:schema/xsd:complexType'
            passing Schema
            columns
            COMPLEX_TYPE_NAME VARCHAR2(4000) path '@name',
            SQLTYPE           VARCHAR2(128)  path '@xdb:SQLType',
            SQLSCHEMA         VARCHAR2(32)   path '@xdb:SQLSchema'
         )
   where COMPLEX_TYPE_NAME = P_COMPLEX_TYPE_NAME
     and SCHEMA_URL = P_SCHEMA_URL;
      
      
      
  V_RESULT := analyzeSQLType(P_COMPLEX_TYPE_NAME,V_SQLTYPE,V_SQLSCHEMA);
 
  select insertChildXML(V_RESULT,'/' || P_COMPLEX_TYPE_NAME,'@SQLType',V_SQLTYPE) 
    into V_RESULT
    from dual;
    
  return V_RESULT;
end;
--
function analyzeGlobalElement(P_GLOBAL_ELEMENT_NAME VARCHAR2)
return XMLType
as
  V_RESULT       XMLType;
  V_SQLTYPE      VARCHAR2(128);
  V_SQLSCHEMA    VARCHAR2(32);
begin
  select SQLTYPE, SQLSCHEMA
    into V_SQLTYPE, V_SQLSCHEMA
    from USER_XML_SCHEMAS,
         xmlTable
         (
            xmlnamespaces
            (
              'http://www.w3.org/2001/XMLSchema' as "xsd",
              'http://xmlns.oracle.com/xdb' as "xdb"
            ),
            '/xsd:schema/xsd:element'
            passing Schema
            columns
            GLOBAL_ELEMENT_NAME VARCHAR2(4000) path '@name',
            SQLTYPE             VARCHAR2(128)  path '@xdb:SQLType',
            SQLSCHEMA           VARCHAR2(32)   path '@xdb:SQLSchema'
         )
   where GLOBAL_ELEMENT_NAME = P_GLOBAL_ELEMENT_NAME;
      
  V_RESULT := analyzeSQLType(P_GLOBAL_ELEMENT_NAME,V_SQLTYPE,V_SQLSCHEMA);
 
  select insertChildXML(V_RESULT,'/' || P_GLOBAL_ELEMENT_NAME,'@SQLType',V_SQLTYPE) 
    into V_RESULT
    from dual;
    
  return V_RESULT;
end;
--
function analyzeGlobalElement(P_GLOBAL_ELEMENT_NAME VARCHAR2, P_SCHEMA_URL VARCHAR2)
return XMLType
as
  V_RESULT       XMLType;
  V_SQLTYPE      VARCHAR2(128);
  V_SQLSCHEMA    VARCHAR2(32);
begin
  select SQLTYPE, SQLSCHEMA
    into V_SQLTYPE, V_SQLSCHEMA
    from USER_XML_SCHEMAS,
         xmlTable
         (
            xmlnamespaces
            (
              'http://www.w3.org/2001/XMLSchema' as "xsd",
              'http://xmlns.oracle.com/xdb' as "xdb"
            ),
            '/xsd:schema/xsd:element'
            passing Schema
            columns
            GLOBAL_ELEMENT_NAME VARCHAR2(4000) path '@name',
            SQLTYPE             VARCHAR2(128)  path '@xdb:SQLType',
            SQLSCHEMA           VARCHAR2(32)   path '@xdb:SQLSchema'
         )
   where GLOBAL_ELEMENT_NAME = P_GLOBAL_ELEMENT_NAME
     and SCHEMA_URL = P_SCHEMA_URL;
         
  V_RESULT := analyzeSQLType(P_GLOBAL_ELEMENT_NAME,V_SQLTYPE,V_SQLSCHEMA);
 
  select insertChildXML(V_RESULT,'/' || P_GLOBAL_ELEMENT_NAME,'@SQLType',V_SQLTYPE) 
    into V_RESULT
    from dual;
    
  return V_RESULT;
end;
--
function showSQLTypes(schemaFolder VARCHAR2) return XMLType
is
  xmlSchema XMLTYPE;
begin
  select xmlElement                                  
         (                                           
           "TypeList",                               
           xmlAgg                                    
           (                                         
              xmlElement                              
              (                                       
                "Schema",                             
                xmlElement
                (
                  "ResourceName",
                  extractValue(res,'/Resource/DisplayName')
                ),
                xmlElement                          
                (                                   
                  "complexTypes",                   
                  (                                 
                    select xmlAgg                                
                           (                                     
                             xmlElement               
                             (                        
                               "complexType",         
                               xmlElement            
                               (                      
                                 "name",              
                                 extractValue(value(XML),'/xsd:complexType/@name',XDB_NAMESPACES.XDBSCHEMA_PREFIXES)                           
                               ),                     
                               xmlElement             
                               (                      
                                 "SQLType",           
                                 extractValue(value(XML),'/xsd:complexType/@xdb:SQLType',XDB_NAMESPACES.XDBSCHEMA_PREFIXES)                             
                               )                      
                             )
                           )
                      from table                    
                           (                        
                             xmlsequence            
                             (                      
                               extract              
                               (                    
                                 xdburitype(p.path).getXML(),
                                 '/xsd:schema/xsd:complexType',
                                 XDB_NAMESPACES.XDBSCHEMA_PREFIXES
                               )                    
                             )                      
                           ) xml
                      -- order by extractValue(value(XML),'/xsd:complexType/@name',XDB_NAMESPACES.XDBSCHEMA_PREFIXES)
                  )                                   
                )
              )
            )                                     
          ).extract('/*')                             
     into xmlSchema
     from path_view p                                 
    where under_path(res,schemaFolder) = 1       
    order by extractValue(res,'/Resource/DisplayName');
    
  return xmlSchema;
    
end;
--
function processNestedTable(currentLevel in out number, currentNode in out XMLType, query SYS_REFCURSOR)
return XMLType
is 
  thisLevel  number;
  thisNode   xmlType;
  result xmlType;
begin
  thisLevel := currentLevel;
  thisNode := currentNode;
  fetch query into currentLevel, currentNode;
  if (query%NOTFOUND) then 
    currentLevel := -1;
  end if;
  while (currentLevel >= thisLevel) loop
    -- Next Node is a decendant of sibling of this Node.
    if (currentLevel > thisLevel) then
      -- Next Node is a decendant of this Node. 
      result := processNestedTable(currentLevel, currentNode, query);
      select xmlElement
             (
                "Collection",
                extract(thisNode,'/Collection/*'),
                xmlElement
                (
                  "NestedCollections",
                  result
                )
              )
         into thisNode
         from dual;
    else
      -- Next node is a sibling of this Node. 
      result := processNestedTable(currentLevel, currentNode, query);
      select xmlconcat(thisNode,result) into thisNode from dual;
    end if;
  end loop;

  -- Next Node is a sibling of some ancestor of this node.

  return thisNode;
  
end;
--
function printNestedTables(XML_TABLE VARCHAR2)
return XMLType
is
   query SYS_REFCURSOR;
   result XMLType;
   rootLevel number := 0;
   rootNode xmlType; 
begin
   open query for 
        select level, xmlElement
                      (
                        "Collection",
                        xmlElement
                        (
                          "CollectionId",
                          PARENT_TABLE_COLUMN
                        )
                      ) as XML
          from USER_NESTED_TABLES
       connect by PRIOR TABLE_NAME = PARENT_TABLE_NAME
               start with PARENT_TABLE_NAME = XML_TABLE;
    fetch query into rootLevel, rootNode;
    result := processNestedTable(rootLevel, rootNode, query);
    select xmlElement
           (
              "NestedTableStructure",
              result
           )
      into result 
      from dual;
    return result;
end;
--
function getDefaultTableName(P_RESOURCE_PATH VARCHAR2)
return VARCHAR2
as 
  V_TARGET_URL          VARCHAR2(4096);
  V_SCHEMA_URL          VARCHAR2(1024);
  V_ELEMENT_NAME        VARCHAR2(2000);
  V_DEFAULT_TABLE_NAME  VARCHAR2(32);
begin
  select extractValue(res,'/Resource/SchemaElement')
    into V_TARGET_URL
    from RESOURCE_VIEW
   where equals_path(res,P_RESOURCE_PATH) = 1;

  V_SCHEMA_URL := substr(V_TARGET_URL,1,instr(V_TARGET_URL,'#')-1);
  V_ELEMENT_NAME := substr(V_TARGET_URL,instr(V_TARGET_URL,'#')+1);

  select extractValue
         (
            SCHEMA,
            '/xsd:schema/xsd:element[@name="' || V_ELEMENT_NAME || '"]/@xdb:defaultTable',
            xdb_namespaces.XMLSCHEMA_PREFIX_XSD || ' ' || xdb_namespaces.XDBSCHEMA_PREFIX_XDB
         )
    into V_DEFAULT_TABLE_NAME
    from USER_XML_SCHEMAS
   where SCHEMA_URL = V_SCHEMA_URL;
     
  return V_DEFAULT_TABLE_NAME;
end;
--
function generateSchemaFromTable(P_TABLE_NAME VARCHAR2, P_OWNER VARCHAR2 default USER)
return XMLTYPE
as
  xmlSchema XMLTYPE;
begin
  select xmlElement
         (
           "xsd:schema",
           xmlAttributes
           (
             'http://www.w3.org/2001/XMLSchema' as "xmlns:xsd",
             'http://xmlns.oracle.com/xdb' as "xmlns:xdb"
           ),
           xmlElement
           (
             "xsd:element",
             xmlAttributes
             (
               'ROWSET' as "name",
               'rowset' as "type"
             )
           ),
           xmlElement 
           (
             "xsd:complexType",
             xmlAttributes
             (
               'rowset' as "name"
             ),
             xmlElement
             (
               "xsd:sequence",
               xmlElement
               (
                  "xsd:element",
                  xmlAttributes
                  (
                    'ROW' as "name",
                    table_name || '_T' as "type",
                    'unbounded' as "maxOccurs"
                  )
                )
              )
           ),
           xmlElement
           (
             "xsd:complexType",
             xmlAttributes
             (
               table_name || '_T' as "name"
             ),
             xmlElement
             (
               "xsd:sequence",
               (
                 xmlAgg(ELEMENT order by INTERNAL_COLUMN_ID)
               )
             )
           )
         )
    into xmlSchema
    from (select TABLE_NAME, INTERNAL_COLUMN_ID,
                 case 
                   when DATA_TYPE in ('VARCHAR2','CHAR') then
                     xmlElement
                     (
                       "xsd:element",
                       xmlattributes
                       (
                         column_name as "name", 
                         decode(NULLABLE, 'Y', 0, 1) as "minOccurs",
                         column_name as "xdb:SQLName", 
                         DATA_TYPE as "xdb:SQLType"
                       ),
                       xmlElement
                       (
                         "xsd:simpleType",
                         xmlElement
                         (
                           "xsd:restriction",
                           xmlAttributes
                           (
                             'xsd:string' as "base"
                           ),
                           xmlElement
                           (
                             "xsd:maxLength",
                             xmlAttributes
                             (
                               DATA_LENGTH  as "value"
                             )
                           )
                         )
                       )
                     )
                   when DATA_TYPE = 'NUMBER' then
                     xmlElement
                     (
                       "xsd:element",
                       xmlattributes
                       (
                         column_name as "name", 
                         decode(NULLABLE, 'Y', 0, 1) as "minOccurs",
                         column_name as "xdb:SQLName", 
                         DATA_TYPE as "xdb:SQLType"
                       ),
                       xmlElement
                       (
                         "xsd:simpleType",
                         xmlElement
                         (
                           "xsd:restriction",
                           xmlAttributes
                           (
                              decode(DATA_SCALE, 0, 'xsd:integer', 'xsd:double') as "base"
                           ),
                           xmlElement
                           (
                             "xsd:totalDigits",
                             xmlAttributes
                             (
                               DATA_PRECISION  as "value"
                             )
                           )
                         )
                       )
                     )
                   when DATA_TYPE = 'DATE' then
                     xmlElement
                     (
                       "xsd:element",
                       xmlattributes
                       (
                         column_name as "name", 
                         decode(NULLABLE, 'Y', 0, 1) as "minOccurs",
                         'xsd:date' as "type",
                         column_name as "xdb:SQLName", 
                         DATA_TYPE as "xdb:SQLType"
                       )
                     )
                   when DATA_TYPE like 'TIMESTAMP%WITH TIME ZONE' then
                     xmlElement
                     (
                       "xsd:element",
                       xmlattributes
                       (
                         column_name as "name", 
                         decode(NULLABLE, 'Y', 0, 1) as "minOccurs",
                         'xsd:dateTime' as "type",
                         column_name as "xdb:SQLName", 
                         DATA_TYPE as "xdb:SQLType"
                       )
                     )
                   else
                     xmlElement
                     (
                       "xsd:element",
                       xmlattributes
                       (
                         column_name as "name", 
                         decode(NULLABLE, 'Y', 0, 1) as "minOccurs",
                         'xsd:anySimpleType' as "type",
                         column_name as "xdb:SQLName", 
                         DATA_TYPE as "xdb:SQLType"
                       )
                     )
                 end ELEMENT
            from all_tab_cols c 
           where c.TABLE_NAME = P_TABLE_NAME
             and c.OWNER = P_OWNER
          )
    group by TABLE_NAME;
  return xmlSchema;
end;
--
function appendElementList(V_ELEMENT_LIST IN OUT XDB.XDB$XMLTYPE_REF_LIST_T, V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T) return XDB.XDB$XMLTYPE_REF_LIST_T;
function expandModel(P_MODEL XDB.XDB$MODEL_T) return XDB.XDB$XMLTYPE_REF_LIST_T;
function expandChoiceList(P_CHOICE_LIST XDB.XDB$XMLTYPE_REF_LIST_T) return XDB.XDB$XMLTYPE_REF_LIST_T;
function expandSequenceList(P_SEQUENCE_LIST XDB.XDB$XMLTYPE_REF_LIST_T) return XDB.XDB$XMLTYPE_REF_LIST_T;
function expandGroupList(P_GROUP_LIST XDB.XDB$XMLTYPE_REF_LIST_T) return XDB.XDB$XMLTYPE_REF_LIST_T;
--
function appendElementList(V_ELEMENT_LIST IN OUT XDB.XDB$XMLTYPE_REF_LIST_T, V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T) 
return XDB.XDB$XMLTYPE_REF_LIST_T
as
begin
  SELECT CAST
         ( 
           SET 
           ( 
             CAST(V_ELEMENT_LIST as XDBPM.XMLTYPE_REF_TABLE_T) 
             MULTISET UNION
             CAST(V_CHILD_ELEMENT_LIST as XDBPM.XMLTYPE_REF_TABLE_T) 
           )
           as XDB.XDB$XMLTYPE_REF_LIST_T
         )
    into V_ELEMENT_LIST
    from DUAL;
    return V_ELEMENT_LIST;      
end;
--
function expandModel(P_MODEL XDB.XDB$MODEL_T)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_ELEMENT_LIST       XDB.XDB$XMLTYPE_REF_LIST_T;
  V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T;
begin

  V_ELEMENT_LIST := XDB.XDB$XMLTYPE_REF_LIST_T();
  if P_MODEL.ELEMENTS is not null then
    V_ELEMENT_LIST := P_MODEL.ELEMENTS;
  end if;
  
  if (P_MODEL.CHOICE_KIDS is not NULL) then
    V_CHILD_ELEMENT_LIST := expandChoiceList(P_MODEL.CHOICE_KIDS);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end if;
  
  if (P_MODEL.SEQUENCE_KIDS is not NULL) then
    V_CHILD_ELEMENT_LIST := expandSequenceList(P_MODEL.SEQUENCE_KIDS);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end if;

  -- Process ANYS
  
  if (P_MODEL.GROUPS is not NULL) then
    V_CHILD_ELEMENT_LIST := expandGroupList(P_MODEL.GROUPS);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end if;

  return V_ELEMENT_LIST;
end;
--
function expandChoiceList(P_CHOICE_LIST XDB.XDB$XMLTYPE_REF_LIST_T)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_ELEMENT_LIST       XDB.XDB$XMLTYPE_REF_LIST_T;
  V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T;

  cursor getChoices is
  select c.XMLDATA MODEL
    from XDB.XDB$CHOICE_MODEL c, TABLE(P_CHOICE_LIST) cl
   where ref(c) = value(cl);
begin

  V_ELEMENT_LIST := XDB.XDB$XMLTYPE_REF_LIST_T();

  for c in getChoices loop
    V_CHILD_ELEMENT_LIST := expandModel(c.MODEL);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end loop;

  return V_ELEMENT_LIST;
end;
--
function expandSequenceList(P_SEQUENCE_LIST XDB.XDB$XMLTYPE_REF_LIST_T)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_ELEMENT_LIST       XDB.XDB$XMLTYPE_REF_LIST_T;
  V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T;

  cursor getSequences is
  select s.XMLDATA MODEL
    from XDB.XDB$SEQUENCE_MODEL s, TABLE(P_SEQUENCE_LIST) sl
   where ref(s) = value(sl);
begin

  V_ELEMENT_LIST := XDB.XDB$XMLTYPE_REF_LIST_T();

  for s in getSequences loop
    V_CHILD_ELEMENT_LIST := expandModel(s.MODEL);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end loop;

  return V_ELEMENT_LIST;
end;
--
function expandGroupList(P_GROUP_LIST XDB.XDB$XMLTYPE_REF_LIST_T)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_ELEMENT_LIST       XDB.XDB$XMLTYPE_REF_LIST_T;
  V_CHILD_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T;  V_MODEL  XDB.XDB$MODEL_T;

  cursor getGroups is
  SELECT CASE 
           -- Return The MODEL Definition for the CHOICE, ALL or SEQUENCE
           WHEN gd.XMLDATA.ALL_KID is not NULL
             THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = gd.XMLDATA.ALL_KID)
           WHEN gd.XMLDATA.SEQUENCE_KID is not NULL
             THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = gd.XMLDATA.SEQUENCE_KID)
           WHEN gd.XMLDATA.CHOICE_KID is not NULL
             THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = gd.XMLDATA.CHOICE_KID)
          END MODEL
     FROM XDB.XDB$GROUP_DEF gd, XDB.XDB$GROUP_REF gr, TABLE(P_GROUP_LIST) gl
    WHERE ref(gd) = gr.XMLDATA.GROUPREF_REF
      and ref(gr) = value(gl);
begin
    
  V_ELEMENT_LIST := XDB.XDB$XMLTYPE_REF_LIST_T();

  for g in getGroups loop
    V_CHILD_ELEMENT_LIST := expandModel(g.MODEL);
    V_ELEMENT_LIST := appendElementList(V_ELEMENT_LIST,V_CHILD_ELEMENT_LIST);
  end loop;

  return V_ELEMENT_LIST;
end;
--
function getComplexTypeElementList(P_COMPLEX_TYPE_REF REF XMLTYPE)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_MODEL        XDB.XDB$MODEL_T;
  V_BASE_TYPE    REF XMLTYPE;
  V_ELEMENT_LIST XDB.XDB$XMLTYPE_REF_LIST_T := XDB.XDB$XMLTYPE_REF_LIST_T();
begin
  SELECT ct.XMLDATA.BASE_TYPE, 
         CASE 
           -- Return The MODEL Definition for the CHOICE, ALL or SEQUENCE
           WHEN ct.XMLDATA.ALL_KID is not NULL
             THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = ct.XMLDATA.ALL_KID)
           WHEN ct.XMLDATA.SEQUENCE_KID is not NULL
             THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = ct.XMLDATA.SEQUENCE_KID)
           WHEN ct.XMLDATA.CHOICE_KID is not NULL
             THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = ct.XMLDATA.CHOICE_KID)
           WHEN ct.XMLDATA.GROUP_KID is not NULL
             -- COMPLEXTYPE is based on a GROUP. 
             THEN ( 
                     -- RETURN The CHOICE, ALL or SEQUENCE for GROUP
                     SELECT CASE
                              WHEN gd.XMLDATA.ALL_KID is not NULL
                                THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = gd.XMLDATA.ALL_KID)
                              WHEN gd.XMLDATA.SEQUENCE_KID is not NULL
                                THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = gd.XMLDATA.SEQUENCE_KID)
                              WHEN gd.XMLDATA.CHOICE_KID is not NULL
                                THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = gd.XMLDATA.CHOICE_KID)
                              END
                         FROM XDB.XDB$GROUP_DEF gd, xdb.xdb$GROUP_REF gr
                        WHERE ref(gd) = gr.XMLDATA.GROUPREF_REF
                          and ref(gr) = ct.XMLDATA.GROUP_KID
                  )
--           WHEN ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.ALL_KID is not NULL
--             THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.ALL_KID)
--           WHEN ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.SEQUENCE_KID is not NULL
--            THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.SEQUENCE_KID)
--           WHEN ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.CHOICE_KID is not NULL
--             THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.CHOICE_KID)
--           WHEN ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.GROUP_KID is not NULL
--             -- COMPLEXTYPE is based on a GROUP. 
--             THEN ( 
--                     -- RETURN The CHOICE, ALL or SEQUENCE for GROUP
--                     SELECT CASE
--                              WHEN gd.XMLDATA.ALL_KID is not NULL
--                                THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = gd.XMLDATA.ALL_KID)
--                              WHEN gd.XMLDATA.SEQUENCE_KID is not NULL
--                                THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = gd.XMLDATA.SEQUENCE_KID)
--                              WHEN gd.XMLDATA.CHOICE_KID is not NULL
--                                THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = gd.XMLDATA.CHOICE_KID)
--                              END
--                         FROM XDB.XDB$GROUP_DEF gd, xdb.xdb$GROUP_REF gr
--                       WHERE ref(gd) = gr.XMLDATA.GROUPREF_REF
--                          and ref(gr) = ct.XMLDATA.COMPLEXCONTENT.RESTRICTION.GROUP_KID
--                  )
           WHEN ct.XMLDATA.COMPLEXCONTENT.EXTENSION.ALL_KID is not NULL
             THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = ct.XMLDATA.COMPLEXCONTENT.EXTENSION.ALL_KID)
           WHEN ct.XMLDATA.COMPLEXCONTENT.EXTENSION.SEQUENCE_KID is not NULL
             THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = ct.XMLDATA.COMPLEXCONTENT.EXTENSION.SEQUENCE_KID)
           WHEN ct.XMLDATA.COMPLEXCONTENT.EXTENSION.CHOICE_KID is not NULL
             THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = ct.XMLDATA.COMPLEXCONTENT.EXTENSION.CHOICE_KID)
           WHEN ct.XMLDATA.COMPLEXCONTENT.EXTENSION.GROUP_KID is not NULL
             -- COMPLEXTYPE is based on a GROUP. 
             THEN ( 
                     -- RETURN The CHOICE, ALL or SEQUENCE for GROUP
                     SELECT CASE
                              WHEN gd.XMLDATA.ALL_KID is not NULL
                                THEN ( SELECT a.XMLDATA  from XDB.XDB$ALL_MODEL a where ref(a) = gd.XMLDATA.ALL_KID)
                              WHEN gd.XMLDATA.SEQUENCE_KID is not NULL
                                THEN ( SELECT s.XMLDATA  from XDB.XDB$SEQUENCE_MODEL s where ref(s) = gd.XMLDATA.SEQUENCE_KID)
                              WHEN gd.XMLDATA.CHOICE_KID is not NULL
                                THEN ( SELECT c.XMLDATA  from XDB.XDB$CHOICE_MODEL c where ref(c) = gd.XMLDATA.CHOICE_KID)
                              END
                         FROM XDB.XDB$GROUP_DEF gd, xdb.xdb$GROUP_REF gr
                        WHERE ref(gd) = gr.XMLDATA.GROUPREF_REF
                          and ref(gr) = ct.XMLDATA.COMPLEXCONTENT.EXTENSION.GROUP_KID
                  )
          END MODEL
     INTO V_BASE_TYPE, V_MODEL 
     FROM XDB.XDB$COMPLEX_TYPE ct
    WHERE ref(ct) = P_COMPLEX_TYPE_REF;
    
  -- Deal with Base Type and Base on REF...  
  
  if (V_BASE_TYPE is not null) then
    V_ELEMENT_LIST := getComplexTypeElementList(V_BASE_TYPE);
    return appendElementList(V_ELEMENT_LIST,expandModel(V_MODEL));
  else
    return expandModel(V_MODEL);
  end if;
end;
--
function getComplexTypeElementList(P_SQLTYPE VARCHAR2, P_SQLSCHEMA VARCHAR2)
return XDB.XDB$XMLTYPE_REF_LIST_T
as
  V_COMPLEX_TYPE_REF REF XMLTYPE;
begin
  select ref(ct)
    into V_COMPLEX_TYPE_REF
    from XDB.XDB$COMPLEX_TYPE ct
   where ct.XMLDATA.SQLTYPE = P_SQLTYPE
     and ct.XMLDATA.SQLSCHEMA = P_SQLSCHEMA;
       
  return getComplexTypeElementList(V_COMPLEX_TYPE_REF);
end;
--
function generateCreateTableStatement(XML_TABLE_NAME VARCHAR2, NEW_TABLE_NAME VARCHAR2)
return CLOB
is
  DDL_STATEMENT CLOB;
  cursor getStructure (XML_TABLE_NAME VARCHAR2) is
  select level, PARENT_TABLE_NAME, PARENT_TABLE_COLUMN, TABLE_TYPE_NAME, TABLE_NAME
    from USER_NESTED_TABLES
         connect by PRIOR TABLE_NAME = PARENT_TABLE_NAME
                 start with PARENT_TABLE_NAME = XML_TABLE_NAME;
  current_level pls_integer := 0;
  clause VARCHAR2(4000);
  indent VARCHAR2(4000); 
  table_number pls_integer := 0;
  
  XMLSCHEMA VARCHAR2(700);
  ELEMENT   VARCHAR2(2000);
  
begin
  dbms_lob.createTemporary(DDL_STATEMENT,FALSE,DBMS_LOB.SESSION);
  current_level := 0;

  select XMLSCHEMA, ELEMENT_NAME 
    into XMLSCHEMA, ELEMENT
    from USER_XML_TABLES
   where TABLE_NAME = XML_TABLE_NAME;

  clause := 'create table "' || NEW_TABLE_NAME ||'" of XMLType' || chr(10) ||
            'XMLSCHEMA "' || XMLSCHEMA || '" ELEMENT "' || ELEMENT || '"' || CHR(10);
  dbms_lob.writeAppend(DDL_STATEMENT,length(clause),clause);            
  for nt in getStructure(XML_TABLE_NAME) loop
     clause := null;
     if nt.level <= current_level then
       while current_level  >= nt.level loop
         indent := lpad(' ',current_level * 2,' ');
         clause := clause || indent || ')' || chr(10);
         current_level := current_level - 1;
       end loop;
     end if;
     current_level := nt.level;
     table_number := table_number + 1;
     indent := lpad(' ',nt.level * 2,' ');
     clause := clause ||
               indent || 'varray ' || nt.PARENT_TABLE_COLUMN || chr(10) || 
               indent || 'store as table "' || NEW_TABLE_NAME || '_NT' || lpad(table_number,4,'0') || '"' || chr(10) ||
               indent || '(' || chr(10) ||
               indent || '  ( constraint "' || NEW_TABLE_NAME || '_NT' || lpad(table_number,4,'0') || '_PKEY" primary key (NESTED_TABLE_ID, SYS_NC_ARRAY_INDEX$))' || chr(10);
     dbms_lob.writeAppend(DDL_STATEMENT,length(clause),clause);
  end loop;
  clause := null;
  while current_level  > 0 loop
    indent := lpad(' ',current_level * 2,' ');
    clause := clause || indent || ')' || chr(10);
    current_level := current_level - 1;
  end loop;
  if clause is not null then
    dbms_lob.writeAppend(DDL_STATEMENT,length(clause),clause);
  end if;
  return DDL_STATEMENT;
end;
--
function normalizePath(P_TARGET_PATH VARCHAR2, P_RELATIVE_PATH VARCHAR2, P_LOCATION_PREFIX VARCHAR2)
return VARCHAR2
as
  V_BASE_FOLDER   VARCHAR2(700);
  V_TARGET_FOLDER  VARCHAR2(700);
  V_RELATIVE_PATH VARCHAR2(700);
begin

  V_BASE_FOLDER := NULL;
  
  if instr(P_TARGET_PATH,'/',-1) > 1 then
    --
    -- The base URL for any relative locations in import or include elements is everything to the left of the last '/' 
    --
    V_BASE_FOLDER := substr(P_TARGET_PATH,1,instr(P_TARGET_PATH,'/',-1)-1);
  end if;

  V_RELATIVE_PATH := P_RELATIVE_PATH;
  V_TARGET_FOLDER := V_BASE_FOLDER;

  -- The following are treated as relative URLs
  -- URLs with no '/' character
  -- URLs which do not start with '/' and which do not contain '://'
  -- URLS which start with ./

  if ( ( (instr(V_RELATIVE_PATH,'://') = 0) and (instr(V_RELATIVE_PATH,'/') <> 1) )  or (instr(V_RELATIVE_PATH,'./') = 1)) then
  
    if (instr(V_RELATIVE_PATH,'..')  = 1 ) then
      while instr(V_RELATIVE_PATH,'..') = 1 loop
        V_RELATIVE_PATH := substr(V_RELATIVE_PATH,4);
        if (V_TARGET_FOLDER is not NULL) then
          V_TARGET_FOLDER := substr(V_TARGET_FOLDER,1,instr(V_TARGET_FOLDER,'/',-1)-1);
        end if;
      end loop;
    else    
      if (instr(V_RELATIVE_PATH,'./') = 1) then
        V_RELATIVE_PATH := substr(V_RELATIVE_PATH,3);
      end if;
    end if; 

    if (V_TARGET_FOLDER is not NULL) then
      V_RELATIVE_PATH := V_TARGET_FOLDER || '/' || V_RELATIVE_PATH;
    end if;

  end if;     
  
  if (P_LOCATION_PREFIX is not null) THEN
    if (INSTR(P_RELATIVE_PATH,P_LOCATION_PREFIX)=1) THEN
      V_RELATIVE_PATH := V_TARGET_FOLDER || SUBSTR(V_RELATIVE_PATH,LENGTH(P_LOCATION_PREFIX)+1);
    end if;
  end if;
  
  return V_RELATIVE_PATH;

end;
--
procedure disableTableReferencedElements(P_XML_SCHEMA IN OUT XMLTYPE)
as
	cursor getElementReferences
	is
	select REF
    from XMLTABLE
         (
            xmlNamespaces
            (
              'http://www.w3.org/2001/XMLSchema' as "xsd"
            ),
            '/xsd:schema//xsd:element[@ref]'
            passing P_XML_SCHEMA
            columns REF VARCHAR2(4000) path '@ref'
        );
begin 
  for ge in getElementReferences loop
    DBMS_XMLSCHEMA_ANNOTATE.disableDefaultTableCreation(P_XML_SCHEMA,ge.REF); 
  end loop;
end;
--
procedure disableTableSubgroupMembers(P_XML_SCHEMA IN OUT XMLTYPE)
as
	cursor getSubstitutionMembers
	is
	select NAME
    from XMLTABLE
         (
            xmlNamespaces
            (
              'http://www.w3.org/2001/XMLSchema' as "xsd"
            ),
            '/xsd:schema/xsd:element[@substitutionGroup]/@name'
            passing P_XML_SCHEMA
            columns NAME VARCHAR2(4000) path '@name'
        );
        
begin 
  for ge in getSubstitutionMembers loop
    DBMS_XMLSCHEMA_ANNOTATE.disableDefaultTableCreation(P_XML_SCHEMA,ge.NAME); 
  end loop;
end;
--
procedure disableTableNonRootElements(P_XML_SCHEMA IN OUT XMLTYPE)
as
begin
	 XDB_ANALYZE_XMLSCHEMA.disableTableSubgroupMembers(P_XML_SCHEMA);
	 XDB_ANALYZE_XMLSCHEMA.disableTableReferencedElements(P_XML_SCHEMA);
end;
--
procedure appendSchemaAnnotations(P_SCHEMA_REFERENCE REF XMLTYPE, P_CONTENT IN OUT CLOB)
as
begin
	for i in G_SCHEMA_REFERENCE_LIST.first .. G_SCHEMA_REFERENCE_LIST.last loop
	  if G_SCHEMA_REFERENCE_LIST(i) = P_SCHEMA_REFERENCE then
      DBMS_LOB.append(G_SCHEMA_ANNOTATION_CACHE(i).SCHEMA_ANNOTATIONS,P_CONTENT);
      G_SCHEMA_ANNOTATION_CACHE(i).HAS_ANNOTATIONS := TRUE;
      DBMS_LOB.freeTemporary(P_CONTENT);
      P_CONTENT := NULL;
      exit;
    end if;
  end loop;
end;
--
procedure enforceDomFidelity
--
--  Enforce DOM Fidelity for the following use-cases
--  
--  #1. ComplexType contains an element that is the head of a substitution group
-- 
--  #2. ComplexType contains an element that is defined as Mixed Text
--
--  #3. ComplexType contains an element that contains a repeating choice.
--
--  #4. ComplexType contains a choice ... - This is need until the bug about printing in Schema Defined order is fixed. 
--
as
--
  cursor getComplexTypes
  is
  select  distinct SCHEMA_ID, NAME, XPATH, PREFIX
    from (  
           select MAKE_REF(XDB.XDB$SCHEMA,SCHEMA_ID) SCHEMA_ID, NAME, SUBSTR(XPATH,11) XPATH, PREFIX
             from XMLTABLE
                  (
                     'declare namespace functx = "http://www.functx.com"; 
         						 declare namespace xdbpm = "http://xmlns.oracle.com/xdb/xdbpm"; 
         						 
                     declare function functx:index-of-node ( $nodes as node()* , $nodeToFind as node() )  
                             as xs:integer* 
                     {
                       for $seq in (1 to count($nodes))
                       return $seq[$nodes[$seq] is $nodeToFind]
                     };
                     
                     declare function functx:path-to-node-with-pos ( $node as node()? ) 
                             as xs:string 
                     {     
                       string-join
                       (
                         for $ancestor in $node/ancestor-or-self::*
                           let $sibsOfSameName := $ancestor/../*[name() = name($ancestor)]
                           return concat
                                  (
                                    name($ancestor),
                
                                    if (count($sibsOfSameName) <= 1) then 
                                      ''''
                                    else 
                                      concat
                                      (
                                        ''['',
                                        functx:index-of-node($sibsOfSameName,$ancestor),
                                        '']''
                                      )
                                  ),
                         ''/''
                       )
                     };
                                          
                     declare function xdbpm:substitutable-elements ( $schemaList as  node() * ) 
                          as xs:string*
                     {           
                       let $subGroupHeadList := for $e in $schemaList/SCHEMA/xs:schema/xs:element[@substitutionGroup]
                                                  return xdbpm:qname-to-string($e/@substitutionGroup,$e)
                       let $subGroupHeadList := fn:distinct-values($subGroupHeadList)
                       return $subGroupHeadList
                     }; 
                     
                     declare function xdbpm:qname-to-string ( $qname as xs:string, $context as node() ) 
                             as xs:string
                     { 
                       let $qn := fn:resolve-QName( $qname, $context)
                       return concat(fn:namespace-uri-from-QName($qn),":",fn:local-name-from-QName($qn))
                     }; 
                                          
         						 declare function xdbpm:getComplexType ( $schemaList as node()* , $targetNamespace as xs:string, $typename as xs:string ) 
         						         as node()
                     {  
                       let $ct := if (fn:empty($targetNamespace)  or ($targetNamespace="")) then
                                    $schemaList/SCHEMA/xs:schema[not(@targetNamespace)]/xs:complexType[@name=$typename]
                                  else
                                    $schemaList/SCHEMA/xs:schema[@targetNamespace=$targetNamespace]/xs:complexType[@name=$typename] 
                       return $ct
                     };                         
                                            
                     declare function xdbpm:getParentType($schemaList as node()*, $extension as node()) 
                             as node()
                     {
                       let $qn := fn:resolve-QName( $extension/@base, $extension)
                       return xdbpm:getComplexType($schemaList,fn:namespace-uri-from-QName($qn),fn:local-name-from-QName($qn))
                     };

                     declare function xdbpm:processComplexType($schemaList as node()*, $complexType as node()) 
                             as node()
                     {                               
                       if ($complexType[not(xs:complexContent/xs:extension[not(@base="xs:anyType")])]) then
                         if ($complexType/@name) then
                           <Result>
                             <SCHEMA_ID>{fn:root($complexType)/ROW/SCHEMA_ID/text()}</SCHEMA_ID>
                             <NAME>{fn:data($complexType/@name)}</NAME>
           								 </Result> 
                         else
                           <Result>
                             <SCHEMA_ID>{fn:root($complexType)/ROW/SCHEMA_ID/text()}</SCHEMA_ID>
                             <XPATH>{functx:path-to-node-with-pos($complexType)}</XPATH>
                             <PREFIX>{fn:prefix-from-QName(fn:node-name(fn:root($complexType)/ROW/SCHEMA/xs:schema))}</PREFIX>
             		      	   </Result> 
                       else
                         <Result>
    								     { 
     								       xdbpm:processComplexType ( $schemaList, xdbpm:getParentType($schemaList,$complexType/xs:complexContent/xs:extension))/*
     								     }
                         </Result>                       
                     };

                     let $schemaList := fn:collection("oradb:/PUBLIC/ALL_XML_SCHEMAS")/ROW
                     let $subGroupHeaders := xdbpm:substitutable-elements ( $schemaList)
                     
                     for $schema in $schemaList
                       for $ct in $schema/SCHEMA/xs:schema//xs:complexType
                         return if ($ct[@mixed="true"]) then
                                  xdbpm:processComplexType($schemaList,$ct)
                                else
                                  if ($ct[descendant::xs:choice[@maxOccurs="unbounded" or @maxOccurs > 1]]) then
                                    xdbpm:processComplexType($schemaList,$ct)
                                  else
(:                                    
                                    if ($ct[descendant::xs:choice]) then
                                      xdbpm:processComplexType($schemaList,$ct)
                                    else 
:)                                
                                      for $e in $ct//xs:element[@ref]
                                      where xdbpm:qname-to-string($e/@ref,$e) = $subGroupHeaders
                                      return xdbpm:processComplexType($schemaList,$ct)'
                     COLUMNS
                     SCHEMA_ID        RAW(16),
                     NAME       VARCHAR2(256),
                     XPATH      VARCHAR2(700),
                     PREFIX     VARCHAR2(32)
                  )
         ) sg,
   TABLE (G_SCHEMA_REFERENCE_LIST) sl
   where sg.SCHEMA_ID = sl.COLUMN_VALUE
   order by sg.SCHEMA_ID;

  V_PREV_SCHEMA REF XMLTYPE;
  V_BUFFER      VARCHAR2(4000);
  V_CONTENT     CLOB;   
begin
  DBMS_LOB.createTemporary(V_CONTENT,TRUE);
  V_BUFFER := '  -- DOM Fidelity enabled due to presence of mixed text, substitution group heads, or repeating choice structures in complex type defintion :-'  || C_BLANK_LINE;
  DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);

  V_PREV_SCHEMA := NULL;
  for p in getComplexTypes loop
    if (V_PREV_SCHEMA is not NULL and V_PREV_SCHEMA <> p.SCHEMA_ID) then
       DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
       appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
       DBMS_LOB.createTemporary(V_CONTENT,TRUE);
       V_BUFFER := '  -- DOM Fidelity enabled due to presence of mixed text, substitution group heads, or repeating choice structures in complex type defintion :-'  || C_BLANK_LINE;
       DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);	    
	   end if;
	   if (p.NAME is not NULL) then
  	   V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.enableMaintainDOM(V_XML_SCHEMA,''' || p.NAME || ''',TRUE);' || C_BLANK_LINE;
  	 else
  	   -- 
  	   -- Normalize XML Schema prefix to 'xsd:'
  	   --
  	   if (p.PREFIX is not null) then
  	     V_BUFFER := '  XDB_EDIT_XMLSCHEMA.setMaintainDOM(V_XML_SCHEMA,''' || replace(p.XPATH,'/' || p.PREFIX || ':','/xsd:') || ''',''true'');' || C_BLANK_LINE;
  	   else
  	     V_BUFFER := '  XDB_EDIT_XMLSCHEMA.setMaintainDOM(V_XML_SCHEMA,''' || replace(p.XPATH,'/','/xsd:') || ''',''true'');' || C_BLANK_LINE;
  	   end if;
  	 end if;
     DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
     V_PREV_SCHEMA := p.SCHEMA_ID;
  end loop;

  if (V_PREV_SCHEMA is not null) then
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
  end if;

  if (V_CONTENT is not NULL) then
    DBMS_LOB.freeTemporary(V_CONTENT);
  end if;
       
end;
--
procedure calculateChoiceSummary
as
  cursor findChoiceSize 
  is
  select ct.XMLDATA.SQLTYPE COMPLEX_TYPE_T, ELEMENT_NAME, ce.TYPE_NAME, ce.OWNER
    from XDB.XDB$COMPLEX_TYPE ct, XDBPM.XDBPM_ALL_TYPES t,
         (
            select ref(cm) P_CHOICE_REFERENCE, 
                   case when e.XMLDATA.PROPERTY.NAME is not null 
                        then e.XMLDATA.PROPERTY.NAME
                        else e.XMLDATA.PROPERTY.PROPREF_NAME.NAME
                   end ELEMENT_NAME, 
                   e.XMLDATA.PROPERTY.SQLTYPE TYPE_NAME,  
                   e.XMLDATA.PROPERTY.SQLSCHEMA OWNER, 
                   cm.XMLDATA.PARENT_SCHEMA P_CHOICE_SCHEMA
              from XDB.XDB$CHOICE_MODEL cm, XDB.XDB$ELEMENT e,
                   TABLE(cm.XMLDATA.ELEMENTS) el
             where ref(e) = el.COLUMN_VALUE
               and (cm.XMLDATA.MAX_OCCURS is null or cm.XMLDATA.MAX_OCCURS = '1')
               and cm.XMLDATA.CHOICE_KIDS is null
               and cm.XMLDATA.SEQUENCE_KIDS is null
               and cm.XMLDATA.ANYS is null
               and cm.XMLDATA.GROUPS is null
         ) ce
   where (
           ct.XMLDATA.CHOICE_KID = P_CHOICE_REFERENCE
           or 
           ct.XMLDATA.COMPLEXCONTENT.EXTENSION.CHOICE_KID = P_CHOICE_REFERENCE
         )
     and ct.XMLDATA.PARENT_SCHEMA = P_CHOICE_SCHEMA
     and ct.XMLDATA.SQLSCHEMA = USER
     and t.TYPE_NAME = ce.TYPE_NAME
     and t.OWNER = ce.OWNER
   order by COMPLEX_TYPE_T;
begin
  null;
end;
--
function initializeTypeSummary
return number
as
  V_NEW_TYPE_COUNT NUMBER := 0;
begin

  execute immediate 'DELETE FROM XDBPM.REVISED_TYPE_SUMMARY';
  commit;  

  -- Cost of all native types is 1

  insert into XDBPM.REVISED_TYPE_SUMMARY 
  select DISTINCT ATTR_TYPE_NAME, nvl(ATTR_TYPE_OWNER,'SYS'), 1
    from XDBPM.REVISED_TYPE_ATTRS ata
   where not exists
         (
           select TYPE_NAME, OWNER
                  from XDBPM.REVISED_TYPES at
            where ata.ATTR_TYPE_NAME = at.TYPE_NAME
              and ata.ATTR_TYPE_OWNER = at.OWNER
          )
      and not exists
         ( 
           select syn.SYNONYM_NAME, syn.OWNER
             from ALL_SYNONYMS syn, XDBPM.REVISED_TYPES at
            where syn.TABLE_NAME  = at.TYPE_NAME
              and syn.TABLE_OWNER = at.OWNER
              and syn.SYNONYM_NAME = ata.ATTR_TYPE_NAME
              and syn.OWNER        = ata.ATTR_TYPE_OWNER
         );

  commit;

  insert into XDBPM.REVISED_TYPE_SUMMARY 
  select distinct TYPE_NAME, nvl(OWNER,'SYS'), 1
    from XDBPM.REVISED_TYPES at
   where not exists
         (
           select TYPE_NAME, OWNER
                  from XDBPM.REVISED_TYPE_ATTRS ata
            where ata.TYPE_NAME = at.TYPE_NAME
              and ata.OWNER = at.OWNER
          )
     and not exists
        (
          select COLL_TYPE, OWNER
            from XDBPM.REVISED_COLL_TYPES act
           where act.TYPE_NAME = at.TYPE_NAME
             and nvl(act.OWNER,'SYS') = nvl(at.OWNER,'SYS')
        );

  -- All collection types cost 2 COLUMN_COUNT except for the PD, XMLEXTRA and XMLNAMESPACES

  insert into XDBPM.REVISED_TYPE_SUMMARY values ('XDB$RAW_LIST_T','XDB',1);
  insert into XDBPM.REVISED_TYPE_SUMMARY values ('XDB$ENUM_T','XDB',1);

  commit;

  insert into XDBPM.REVISED_TYPE_SUMMARY
  select TYPE_NAME, nvl(OWNER,'SYS'), 2
    from XDBPM.REVISED_COLL_TYPES
   where not (OWNER = 'XDB' and TYPE_NAME = 'XDB$RAW_LIST_T');
  
  commit;
 
  select count(*) 
    into V_NEW_TYPE_COUNT 
    from XDBPM.REVISED_TYPE_SUMMARY;
 
  return V_NEW_TYPE_COUNT;

end;
-- 
function updateTypeSummary 
return number
as
  V_NEW_TYPE_COUNT NUMBER := 0;
begin

  insert into XDBPM.REVISED_TYPE_SUMMARY
  select t1.TYPE_NAME, 
         t1.OWNER, 
         sum(COLUMN_COUNT) +
         ( 
           select count(*) * 2
             from XDBPM.REVISED_TYPE_ATTRS ata, XDBPM.REVISED_TYPES at
            where ata.TYPE_NAME = t1.TYPE_NAME 
              and ata.OWNER = t1.OWNER
              and at.TYPE_NAME = ata.ATTR_TYPE_NAME
              and at.OWNER = ata.ATTR_TYPE_OWNER
              and at.FINAL = 'NO'
         ) COLUMN_COUNT
    from XDBPM.REVISED_TYPE_ATTRS ata, XDBPM.REVISED_TYPE_SUMMARY ts,
         (
           select distinct TYPE_NAME, OWNER
             from XDBPM.REVISED_TYPES at1
            where not exists
                  (
                     -- Types where all the attributes are already known..
                        select 1
                          from XDBPM.REVISED_TYPE_ATTRS ata
                         where not exists
                                   ( 
                                     select 1
                                       from XDBPM.REVISED_TYPE_SUMMARY ts
                                      where ts.TYPE_NAME = ata.ATTR_TYPE_NAME
                                        and nvl(ts.OWNER,'SYS') = nvl(ata.ATTR_TYPE_OWNER,'SYS')
                                   )
                           and ata.TYPE_NAME = at1.TYPE_NAME
                           and ata.OWNER = at1.OWNER
                  )
              and not exists
                  (
                    select 1 
                      from XDBPM.REVISED_TYPE_SUMMARY ts
                     where at1.TYPE_NAME = ts.TYPE_NAME
                       and at1.OWNER = ts.OWNER
                  )
              and not exists
                  (
                    select 1
                      from XDBPM.REVISED_TYPES at
                     where at.SUPERTYPE_NAME = at1.TYPE_NAME
                       and at.SUPERTYPE_OWNER = at1.OWNER
                  )
         ) t1
   where ata.TYPE_NAME = t1.TYPE_NAME
     and ata.OWNER = t1.OWNER
     and ts.TYPE_NAME = ata.ATTR_TYPE_NAME
     and nvl(ts.OWNER,'SYS') = nvl(ata.ATTR_TYPE_OWNER,'SYS')
   group by t1.TYPE_NAME, t1.OWNER;

  commit;  

  select count(*) 
    into V_NEW_TYPE_COUNT 
    from XDBPM.REVISED_TYPE_SUMMARY;
 
  return V_NEW_TYPE_COUNT;

end;
--
procedure calculateTypeSummary
--
-- Calculate the REVISED_TYPE_SUMMARY from the REVISED_TYPE_ATTS
--
as
	
  V_OLD_TYPE_COUNT NUMBER := 0;
  V_NEW_TYPE_COUNT NUMBER := 0;
  
  cursor getTypeAttributes
  is
  select t1.TYPE_NAME, 
         t1.OWNER, 
         sum(COLUMN_COUNT) +
         ( 
           select count(*) * 2
             from XDBPM.REVISED_TYPE_ATTRS ata, XDBPM.REVISED_TYPES at
            where ata.TYPE_NAME = t1.TYPE_NAME 
              and ata.OWNER = t1.OWNER
              and at.TYPE_NAME = ata.ATTR_TYPE_NAME
              and at.OWNER = ata.ATTR_TYPE_OWNER
              and at.FINAL = 'NO'
              and at.TYPECODE = 'OBJECT'
         ) COLUMN_COUNT
    from XDBPM.REVISED_TYPE_ATTRS ata, XDBPM.REVISED_TYPE_SUMMARY ts,
         (
           select distinct TYPE_NAME, OWNER
             from XDBPM.REVISED_TYPES at1
            where not exists
                  (
                     -- Types where all the attributes are already known..
                        select 1
                          from XDBPM.REVISED_TYPE_ATTRS ata
                         where not exists
                                   ( 
                                     select 1
                                       from XDBPM.REVISED_TYPE_SUMMARY ts
                                      where ts.TYPE_NAME = ata.ATTR_TYPE_NAME
                                        and nvl(ts.OWNER,'SYS') = nvl(ata.ATTR_TYPE_OWNER,'SYS')
                                   )
                           and ata.TYPE_NAME = at1.TYPE_NAME
                           and ata.OWNER = at1.OWNER
                  )
              and not exists
                  (
                    select 1 
                      from XDBPM.REVISED_TYPE_SUMMARY ts
                     where at1.TYPE_NAME = ts.TYPE_NAME
                       and at1.OWNER = ts.OWNER
                  )
         ) t1
   where ata.TYPE_NAME = t1.TYPE_NAME
     and ata.OWNER = t1.OWNER
     and ts.TYPE_NAME = ata.ATTR_TYPE_NAME
     and nvl(ts.OWNER,'SYS') = nvl(ata.ATTR_TYPE_OWNER,'SYS')
   group by t1.TYPE_NAME, t1.OWNER;

   cursor getTypeSubtypes(C_TYPE_NAME VARCHAR2, C_OWNER VARCHAR2)
   is
   select TYPE_NAME, OWNER
     from XDBPM.REVISED_TYPES at1
    where SUPERTYPE_NAME = C_TYPE_NAME
      and SUPERTYPE_OWNER = C_OWNER;
      
  V_COLUMN_COUNT NUMBER;
  V_SUBTYPES_RESOLVED BOOLEAN;         
  
  V_ROWCOUNT NUMBER;   

begin

  V_OLD_TYPE_COUNT := 0;
  V_NEW_TYPE_COUNT := initializeTypeSummary();

  WHILE (V_OLD_TYPE_COUNT <> V_NEW_TYPE_COUNT) loop
    V_OLD_TYPE_COUNT := V_NEW_TYPE_COUNT;
    V_NEW_TYPE_COUNT := updateTypeSummary();   
  end loop;
 
  V_OLD_TYPE_COUNT := 0;

  WHILE (V_OLD_TYPE_COUNT <> V_NEW_TYPE_COUNT) loop
    V_OLD_TYPE_COUNT := V_NEW_TYPE_COUNT;

    for t in getTypeAttributes loop
      V_COLUMN_COUNT :=  t.COLUMN_COUNT;
      V_SUBTYPES_RESOLVED := TRUE;
      for st in getTypeSubtypes(T.TYPE_NAME,T.OWNER) loop
        begin
          select V_COLUMN_COUNT + (COLUMN_COUNT - t.COLUMN_COUNT) 
            into V_COLUMN_COUNT
            from XDBPM.REVISED_TYPE_SUMMARY
           where TYPE_NAME = st.TYPE_NAME
             and OWNER = st.OWNER;
        exception
          when no_data_found then
            V_SUBTYPES_RESOLVED := FALSE;
          when others then
            RAISE;
         end;
      end loop;
      if (V_SUBTYPES_RESOLVED) then
        insert into XDBPM.REVISED_TYPE_SUMMARY values (t.TYPE_NAME, nvl(t.OWNER,'SYS'), V_COLUMN_COUNT);
      end if;
    end loop;

    commit;
  
    V_NEW_TYPE_COUNT := updateTypeSummary();   
    commit;

    select count(*) 
      into V_NEW_TYPE_COUNT 
      from XDBPM.REVISED_TYPE_SUMMARY;

  end loop;

end;
--
procedure createOutputFile(P_RESOURCE_PATH VARCHAR2 DEFAULT '/public/annotateSchema.sql')
as
begin
  XDB_OUTPUT.createFile(P_RESOURCE_PATH,TRUE);
end;
--
function initializeSchemaAnnotations(P_SCHEMA_LOCATION_HINT VARCHAR2)
return CLOB
as
  V_BUFFER  VARCHAR2(4000);
  V_CONTENT CLOB;
begin
	  
	return V_CONTENT;
end;
--
procedure printSchemaList(P_RESOURCE_PATH VARCHAR2, P_SCHEMA_LOCATION_LIST XDB.XDB$STRING_LIST_T, P_TARGET_NAME VARCHAR2, P_SCHEMA_LOCATION_HINT VARCHAR2)
as
  V_BUFFER  VARCHAR2(4000);
  V_CONTENT CLOB;
begin
  DBMS_LOB.createTemporary(V_CONTENT,TRUE);
  DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);

  if (P_SCHEMA_LOCATION_HINT is NULL) then
    V_BUFFER := '-- Initiating Object-Relational storage model optimization for XML Schemas in "' || P_TARGET_NAME || '"'  || C_BLANK_LINE;
  else
    V_BUFFER := '-- Initiating Object-Relational storage model optimization for XML Schema "' || P_TARGET_NAME || '"'  || C_BLANK_LINE;
  end if;

  DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);

  if ((P_SCHEMA_LOCATION_LIST is NULL) or (P_SCHEMA_LOCATION_LIST.count() = 0)) then

    if (P_SCHEMA_LOCATION_HINT is NULL) then
      V_BUFFER := '-- Unable to locate any XML Schemas in "' || P_TARGET_NAME || '" '  || C_BLANK_LINE;
    else
      V_BUFFER := '-- Unable to locate XML Schema "' || P_TARGET_NAME || '"'  || C_BLANK_LINE;
    end if;

    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
    
  else
    
    if P_SCHEMA_LOCATION_LIST.count() > 1 then
      V_BUFFER := '-- Processing Object Types derived from the following XML Schemas :- ' || C_NEW_LINE;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
      for i in P_SCHEMA_LOCATION_LIST.first + 1 .. P_SCHEMA_LOCATION_LIST.last loop
          V_BUFFER := '--    ' || P_SCHEMA_LOCATION_LIST(i)  || C_NEW_LINE;
          DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
      end loop;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);

    end if;
     	
  end if;

  XDB_OUTPUT.writeToFile(P_RESOURCE_PATH,V_CONTENT);
   
end;
--
procedure printScriptFile(P_RESOURCE_PATH VARCHAR2)
as
  V_CONTENT CLOB;
  V_BUFFER  VARCHAR2(4000);
  V_SCHEMA_LOCATION_HINT VARCHAR2(700);
  
begin
	for i in G_SCHEMA_ANNOTATION_CACHE.first .. G_SCHEMA_ANNOTATION_CACHE.last loop
    if G_SCHEMA_ANNOTATION_CACHE(i).HAS_ANNOTATIONS then
      DBMS_LOB.createTemporary(V_CONTENT,TRUE);
      V_SCHEMA_LOCATION_HINT := G_SCHEMA_ANNOTATION_CACHE(i).SCHEMA_LOCATION_HINT;
      
      V_BUFFER := ' -- Annotations for "' || V_SCHEMA_LOCATION_HINT || '" --' ||  C_BLANK_LINE;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
      V_BUFFER := '  if (V_SCHEMA_LOCATION_HINT = ''' || V_SCHEMA_LOCATION_HINT || ''') THEN ' || C_BLANK_LINE;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
      DBMS_LOB.append(V_CONTENT,G_SCHEMA_ANNOTATION_CACHE(i).SCHEMA_ANNOTATIONS);
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
      V_BUFFER :=  '  end if;' || C_BLANK_LINE;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
      
      XDB_OUTPUT.writeToFile(P_RESOURCE_PATH,V_CONTENT);
    end if;
  end loop;
  
  DBMS_LOB.createTemporary(V_CONTENT,TRUE);
  V_BUFFER :=  '-- End of Script --' || C_BLANK_LINE;
  DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
  XDB_OUTPUT.writeToFile(P_RESOURCE_PATH,V_CONTENT);
  
end;
--
procedure addGlobalTypeNames(P_REUSE_GENERATED_NAMES BOOLEAN DEFAULT FALSE)
--
-- Capture existing Type Mapping for the Global Elements and ComplexTypes
--
as
  V_LIMIT                 NUMBER;
  V_CONTENT               CLOB;
  V_BUFFER                VARCHAR2(1024);
  V_PREV_SYSTEM_GENERATED NUMBER;
  V_PREV_SCHEMA REF       XMLType;
  
  cursor complexTypeMappings
  is
  select COMPLEX_TYPE_NAME, SQL_TYPE, PARENT_SCHEMA, SYSTEM_GENERATED
    from (
           select case when regexp_like(ct.XMLDATA.SQLTYPE,'[0-9]{3}_T$')
                       then 1
                       else 0
                  end                      SYSTEM_GENERATED,
                  ct.XMLDATA.NAME          COMPLEX_TYPE_NAME, 
                  ct.XMLDATA.SQLTYPE       SQL_TYPE, 
                  ct.XMLDATA.PARENT_SCHEMA PARENT_SCHEMA
             from XDB.XDB$COMPLEX_TYPE ct
                 ,TABLE(G_SCHEMA_REFERENCE_LIST) sl
            where ct.XMLDATA.PARENT_SCHEMA  = sl.COLUMN_VALUE
              and ct.XMLDATA.NAME is not NULL
         )
   where SYSTEM_GENERATED < V_LIMIT
   order by PARENT_SCHEMA, SYSTEM_GENERATED, COMPLEX_TYPE_NAME;
  
  cursor globalElementMappings
  is
  select ELEMENT_NAME, SQL_TYPE, PARENT_SCHEMA, SYSTEM_GENERATED
    from (
           select case when regexp_like(e.XMLDATA.PROPERTY.SQLTYPE,'[0-9]{3}_T$')
                       then 1
                       else 0
                  end                              SYSTEM_GENERATED,
                  e.XMLDATA.PROPERTY.NAME          ELEMENT_NAME, 
                  e.XMLDATA.PROPERTY.SQLTYPE       SQL_TYPE, 
                  e.XMLDATA.PROPERTY.PARENT_SCHEMA PARENT_SCHEMA
             from XDB.XDB$ELEMENT e
                 ,TABLE(G_SCHEMA_REFERENCE_LIST) sl
            where e.XMLDATA.PROPERTY.PARENT_SCHEMA = sl.COLUMN_VALUE
              and e.XMLDATA.PROPERTY.TYPENAME is NULL
              and e.XMLDATA.PROPERTY.SQLTYPE <> 'VARCHAR2' -- Default mapping for Elements with no specific type attribute.
              and e.XMLDATA.PROPERTY.GLOBAL = HEXTORAW('01')
          )
   where SYSTEM_GENERATED < V_LIMIT
   order by PARENT_SCHEMA, SYSTEM_GENERATED, ELEMENT_NAME;

begin
  
  if P_REUSE_GENERATED_NAMES then
    -- Include System Generated Names in the list
    V_LIMIT := 2;  
  else
    -- Exclude System Generated Names in the list
    V_LIMIT := 1;
  end if;
  
  DBMS_LOB.createTemporary(V_CONTENT,TRUE);
  V_BUFFER := '  -- SQLType names for global complex types :-'  || C_NEW_LINE;
  DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
  
  V_PREV_SCHEMA := NULL;
  V_PREV_SYSTEM_GENERATED := -1;
	for ct in complexTypeMappings loop
	  if (V_PREV_SCHEMA is not NULL and V_PREV_SCHEMA <> ct.PARENT_SCHEMA) then
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
	    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
      DBMS_LOB.createTemporary(V_CONTENT,TRUE);
      V_BUFFER := '  -- SQLType names for global complex types :-'  || C_NEW_LINE;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);	    
      V_PREV_SYSTEM_GENERATED := -1;
	  end if;
	  if (V_PREV_SYSTEM_GENERATED <> ct.SYSTEM_GENERATED) then
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
	    V_PREV_SYSTEM_GENERATED := ct.SYSTEM_GENERATED;
	  end if;
	  V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.setSQLType(V_XML_SCHEMA,''' || ct.COMPLEX_TYPE_NAME || ''',';
	  V_BUFFER := RPAD(V_BUFFER,120,' ');
	  V_BUFFER := V_BUFFER || '''' || ct.SQL_TYPE || ''');' || C_NEW_LINE;
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
    V_PREV_SCHEMA := ct.PARENT_SCHEMA;
  end loop;
  
  if (V_PREV_SCHEMA is not null) then
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
  end if;
  
  DBMS_LOB.createTemporary(V_CONTENT,TRUE);
  V_BUFFER := '  -- SQLType names for global elements based on local complex types :-'  || C_NEW_LINE;
  DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);

  V_PREV_SCHEMA := NULL;
  V_PREV_SYSTEM_GENERATED := -1;
	for ge in globalElementMappings loop
	  if (V_PREV_SCHEMA is not NULL and V_PREV_SCHEMA <> ge.PARENT_SCHEMA) then
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
	    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
      DBMS_LOB.createTemporary(V_CONTENT,TRUE);
      V_BUFFER := '      -- SQLType names for global elements based on local complex types :-'  || C_NEW_LINE;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);	    
      V_PREV_SYSTEM_GENERATED := -1;
	  end if;
	  if (V_PREV_SYSTEM_GENERATED <> ge.SYSTEM_GENERATED) then
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
	    V_PREV_SYSTEM_GENERATED := ge.SYSTEM_GENERATED;
	  end if;
	  V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.setSQLType(V_XML_SCHEMA,''' ||  ge.ELEMENT_NAME || ''',';
	  V_BUFFER := RPAD(V_BUFFER,120,' ');
	  V_BUFFER := V_BUFFER || '''' || ge.SQL_TYPE || ''');' || C_NEW_LINE;
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
    V_PREV_SCHEMA := ge.PARENT_SCHEMA;
  end loop;
  
  if (V_PREV_SCHEMA is not null) then
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
  end if;
  
  if (V_CONTENT is not NULL) then
    DBMS_LOB.freeTemporary(V_CONTENT);
  end if;
    
end;
--
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
--
function getXMLSchemaREF(P_SCHEMA_LOCATION_HINT VARCHAR2,P_OWNER VARCHAR2) 
return REF XMLTYPE
as
  V_SCHEMA_REF REF XMLTYPE;
begin
	select ref(s)
	  into V_SCHEMA_REF
	  from XDB.XDB$SCHEMA s
	 where s.XMLDATA.SCHEMA_URL = P_SCHEMA_LOCATION_HINT
	   and s.XMLDATA.SCHEMA_OWNER = P_OWNER;
	 return V_SCHEMA_REF;
end;
--
$END
-- 
procedure addOutOfLineStorage(P_PARENT_SCHEMA REF XMLTYPE DEFAULT NULL)
--
-- Capture existing Out of Line Mappings 
--
as
  V_CONTENT     CLOB;
  V_BUFFER      VARCHAR2(1024);
  V_PREV_SCHEMA REF XMLType;
 
  cursor complexTypeMappings
  is
  select XSD_TYPE_NAME, 
         case 
            WHEN XSD_ELEMENT_NAME is NULL
            THEN XSD_ELEMENT_REF
            ELSE XSD_ELEMENT_NAME
         end XSD_ELEMENT_NAME,
         XDB_DEFAULT_TABLE,
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
				 P_PARENT_SCHEMA PARENT_SCHEMA
$ELSE         
         MAKE_REF(XDB.XDB$SCHEMA,SCHEMA_ID) PARENT_SCHEMA
$END
    from ALL_XML_SCHEMAS sc
        ,XMLTABLE
         (
           xmlNamespaces
           (
             'http://www.w3.org/2001/XMLSchema' as "xsd",
             'http://xmlns.oracle.com/xdb' as "xdb"
           ),
           '/xsd:schema/xsd:complexType[descendant::xsd:element[@xdb:defaultTable]]'
           passing SCHEMA
           columns
           XSD_TYPE_NAME VARCHAR2(2000) path '@name',
           ELEMENT_LIST  XMLTYPE        path 'descendant::xsd:element[@xdb:defaultTable]'
         )
        ,XMLTable
         (
           xmlNamespaces
           (
             'http://www.w3.org/2001/XMLSchema' as "xsd",
             'http://xmlns.oracle.com/xdb' as "xdb"
           ),
           '/xsd:element'
           passing ELEMENT_LIST
           columns
           XSD_ELEMENT_NAME  VARCHAR2(2000) path '@name',
           XSD_ELEMENT_REF   VARCHAR2(2000) path '@ref',
           XDB_DEFAULT_TABLE VARCHAR2(30)  path '@xdb:defaultTable'
         )
        ,TABLE(G_SCHEMA_REFERENCE_LIST) sl
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
	where P_PARENT_SCHEMA = sl.COLUMN_VALUE
$ELSE         
   where MAKE_REF(XDB.XDB$SCHEMA,SCHEMA_ID) = sl.COLUMN_VALUE
$END
   order by PARENT_SCHEMA, XDB_DEFAULT_TABLE, XSD_TYPE_NAME;
   
  cursor globalElementMappings
  is
  select XSD_GLOBAL_ELEMENT_NAME, 
         case 
            WHEN XSD_ELEMENT_NAME is NULL
            THEN XSD_ELEMENT_REF
            ELSE XSD_ELEMENT_NAME
         end XSD_ELEMENT_NAME,
         XDB_DEFAULT_TABLE,
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
				 P_PARENT_XMLSCHEMA PARENT_SCHEMA
$ELSE         
         MAKE_REF(XDB.XDB$SCHEMA,SCHEMA_ID) PARENT_SCHEMA
$END
    from ALL_XML_SCHEMAS sc
        ,XMLTABLE
         (
           xmlNamespaces
           (
             'http://www.w3.org/2001/XMLSchema' as "xsd",
             'http://xmlns.oracle.com/xdb' as "xdb"
           ),
           '/xsd:schema/xsd:element[descendant::xsd:element[@xdb:defaultTable]]'
           passing SCHEMA
           columns
           XSD_GLOBAL_ELEMENT_NAME VARCHAR2(2000) path '@name',
           ELEMENT_LIST            XMLTYPE       path 'descendant::xsd:element[@xdb:defaultTable]'
         )
        ,XMLTable
         (
           xmlNamespaces
           (
             'http://www.w3.org/2001/XMLSchema' as "xsd",
             'http://xmlns.oracle.com/xdb' as "xdb"
           ),
           '/xsd:element'
           passing ELEMENT_LIST
           columns
           XSD_ELEMENT_NAME  VARCHAR2(2000) path '@name',
           XSD_ELEMENT_REF   VARCHAR2(2000) path '@ref',
           XDB_DEFAULT_TABLE VARCHAR2(30)  path '@xdb:defaultTable'
         )
        ,TABLE(G_SCHEMA_REFERENCE_LIST) sl
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
	where P_PARENT_SCHEMA = sl.COLUMN_VALUE
$ELSE         
   where MAKE_REF(XDB.XDB$SCHEMA,SCHEMA_ID) = sl.COLUMN_VALUE
$END
   order by PARENT_SCHEMA, XDB_DEFAULT_TABLE, XSD_ELEMENT_NAME;

  cursor groupMappings
  is
  select XSD_GROUP_NAME, 
         case 
            WHEN XSD_ELEMENT_NAME is NULL
            THEN XSD_ELEMENT_REF
            ELSE XSD_ELEMENT_NAME
         end XSD_ELEMENT_NAME,
         XDB_DEFAULT_TABLE,
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
				 P_PARENT_SCHEMA = PARENT_SCHEMA
$ELSE         
         MAKE_REF(XDB.XDB$SCHEMA,SCHEMA_ID) PARENT_SCHEMA
$END
    from ALL_XML_SCHEMAS sc
        ,XMLTABLE
         (
           xmlNamespaces
           (
             'http://www.w3.org/2001/XMLSchema' as "xsd",
             'http://xmlns.oracle.com/xdb' as "xdb"
           ),
           '/xsd:schema/xsd:group[descendant::xsd:element[@xdb:defaultTable]]'
           passing SCHEMA
           columns
           XSD_GROUP_NAME VARCHAR2(2000) path '@name',
           ELEMENT_LIST   XMLTYPE       path 'descendant::xsd:element[@xdb:defaultTable]'
         )
        ,XMLTable
         (
           xmlNamespaces
           (
             'http://www.w3.org/2001/XMLSchema' as "xsd",
             'http://xmlns.oracle.com/xdb' as "xdb"
           ),
           '/xsd:element'
           passing ELEMENT_LIST
           columns
           XSD_ELEMENT_NAME  VARCHAR2(2000) path '@name',
           XSD_ELEMENT_REF   VARCHAR2(2000) path '@ref',
           XDB_DEFAULT_TABLE VARCHAR2(30)  path '@xdb:defaultTable'
         )
        ,TABLE(G_SCHEMA_REFERENCE_LIST) sl
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
	where P_PARENT_SCHEMA = sl.COLUMN_VALUE
$ELSE         
   where MAKE_REF(XDB.XDB$SCHEMA,SCHEMA_ID) = sl.COLUMN_VALUE
$END
   order by PARENT_SCHEMA, XDB_DEFAULT_TABLE, XSD_GROUP_NAME;

begin
  
  DBMS_LOB.createTemporary(V_CONTENT,TRUE);
  V_BUFFER := '  -- Out-of-Line mappings for global complex types :-'  || C_BLANK_LINE;
  DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);

  V_PREV_SCHEMA := NULL;
	for ct in complexTypeMappings loop
	  if (V_PREV_SCHEMA is not NULL and V_PREV_SCHEMA <> ct.PARENT_SCHEMA) then
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
	    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
      DBMS_LOB.createTemporary(V_CONTENT,TRUE);
      V_BUFFER := '  -- Out-of-Line mappings for global complex types :-'  || C_BLANK_LINE;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);	    
	  end if;
	  V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.setOutOfLine(V_XML_SCHEMA,DBMS_XDB_CONSTANTS.XSD_COMPLEX_TYPE,''' || ct.XSD_TYPE_NAME || ''',';
	  V_BUFFER := RPAD(V_BUFFER,160,' ');
	  V_BUFFER := V_BUFFER || '''' || ct.XSD_ELEMENT_NAME || ''',';
	  V_BUFFER := RPAD(V_BUFFER,210,' ');
	  V_BUFFER := V_BUFFER || '''' || ct.XDB_DEFAULT_TABLE || ''');' || C_NEW_LINE;
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
    V_PREV_SCHEMA := ct.PARENT_SCHEMA;
  end loop;

  if (V_PREV_SCHEMA is not null) then
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
  end if;
  
  DBMS_LOB.createTemporary(V_CONTENT,TRUE);
  V_BUFFER := '  -- Out-of-Line mappings for global elements :-'  || C_BLANK_LINE;
  DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);

  V_PREV_SCHEMA := NULL;
	for ge in globalElementMappings loop
	  if (V_PREV_SCHEMA is not NULL and V_PREV_SCHEMA <> ge.PARENT_SCHEMA) then
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
	    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
      DBMS_LOB.createTemporary(V_CONTENT,TRUE);
      V_BUFFER := '  -- Out-of-Line mappings for global elements :-'  || C_BLANK_LINE;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);	    
	  end if;
	  V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.setOutOfLine(V_XML_SCHEMA,DBMS_XDB_CONSTANTS.XSD_ELEMENT,''' || ge.XSD_GLOBAL_ELEMENT_NAME || ''',';
	  V_BUFFER := RPAD(V_BUFFER,160,' ');
	  V_BUFFER := V_BUFFER || '''' || ge.XSD_ELEMENT_NAME || ''',';
	  V_BUFFER := RPAD(V_BUFFER,210,' ');
	  V_BUFFER := V_BUFFER || '''' || ge.XDB_DEFAULT_TABLE || ''');' || C_NEW_LINE;
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
    V_PREV_SCHEMA := ge.PARENT_SCHEMA;
  end loop;

  if (V_PREV_SCHEMA is not null) then
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
  end if;

  DBMS_LOB.createTemporary(V_CONTENT,TRUE);
  V_BUFFER := '  -- Out-of-Line mappings for global groups :-'  || C_BLANK_LINE;
  DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);

  V_PREV_SCHEMA := NULL;
	for g in groupMappings loop
	  if (V_PREV_SCHEMA is not NULL and V_PREV_SCHEMA <> g.PARENT_SCHEMA) then
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
	    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
      DBMS_LOB.createTemporary(V_CONTENT,TRUE);
      V_BUFFER := '  -- Out-of-Line mappings for global groups :-'  || C_BLANK_LINE;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);	    
	  end if;
	  V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.setOutOfLine(V_XML_SCHEMA,DBMS_XDB_CONSTANTS.XSD_GROUP,''' || g.XSD_GROUP_NAME || ''',';
	  V_BUFFER := RPAD(V_BUFFER,160,' ');
	  V_BUFFER := V_BUFFER || '''' || g.XSD_ELEMENT_NAME || ''',';
	  V_BUFFER := RPAD(V_BUFFER,210,' ');
	  V_BUFFER := V_BUFFER || '''' || g.XDB_DEFAULT_TABLE || ''');' || C_NEW_LINE;
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
    V_PREV_SCHEMA := g.PARENT_SCHEMA;
  end loop;

  if (V_PREV_SCHEMA is not null) then
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
    appendSchemaAnnotations(V_PREV_SCHEMA,V_CONTENT);
  end if;

  if (V_CONTENT is not NULL) then
    DBMS_LOB.freeTemporary(V_CONTENT);
  end if;
    
end;
--
function findLocalElementName(P_ATTR_NAME VARCHAR2, P_ATTR_TYPE_NAME VARCHAR2, P_ATTR_TYPE_OWNER VARCHAR2)
return VARCHAR2
as
  V_LOCAL_ELEMENT_NAME VARCHAR2(256);
begin
	
  -- Find the Element Name or Reference for the first element which matches the selected SQLNAME, SQLTYPE and OWNER.

  select case when e.XMLDATA.PROPERTY.PROPREF_REF is null
              then e.XMLDATA.PROPERTY.NAME
              else e.XMLDATA.PROPERTY.PROPREF_NAME.NAME
         end LOCAL_ELEMENT_NAME
    into V_LOCAL_ELEMENT_NAME
    from xdb.xdb$element e
   where e.XMLDATA.PROPERTY.SQLNAME     = P_ATTR_NAME
     and e.XMLDATA.PROPERTY.SQLTYPE     = P_ATTR_TYPE_NAME
     and e.XMLDATA.PROPERTY.SQLSCHEMA   = P_ATTR_TYPE_OWNER
     and e.XMLDATA.PROPERTY.GLOBAL      = HEXTORAW('00')
     and e.XMLDATA.PROPERTY.SQLCOLLTYPE is null
     and rownum < 2;
     
  return V_LOCAL_ELEMENT_NAME;
end;
--      
function findCandidate(P_TYPE_NAME IN VARCHAR2, P_OWNER IN VARCHAR2, P_ATTR_NAME OUT VARCHAR2, P_ATTR_TYPE_NAME OUT VARCHAR2, P_ATTR_TYPE_OWNER OUT VARCHAR2, P_BUFFER IN OUT CLOB)
return NUMBER
--
--  Find Attribute which contributes the largest number of columns to the type hierarchy. 
--
--
-- Todo : This logic can be improved by looking for non repeating choices containing elements based on complexTypes and 
-- moving all the members of the non repeating choice out of line before working on the largest element. 
-- This is because each instance document will only contain one of the members in the choice.
-- In effect the choice contributes the sum of it's members.
-- This can probably be calculated by finding the COMPLEXTYPE for the P_TYPE_NAME (There should be only 1) and then looking for CHOICES in that type.
-- Once the choices are found calculate the same of the attributes for that choice and determine whether or not it is worth moving each member of 
-- the choice out of line. 
--
-- Todo : Consider choosing optional elements before mandatory elements.
--
-- Todo : For memory otpimization (4030 errors), as distinct from column count optimization the logic needs to be extended to consider the number of columns in the 
-- types behind collection types.
--
as
  V_COLUMN_COUNT       NUMBER; 
  V_TYPE_NAME          VARCHAR2(30);
  V_OWNER              VARCHAR2(30);
    
  -- 
  --  Fix for Phantom Types generated by Schema Registration : Add condition that the type name must map to xdb.xdb$complex_type.
  --  
    
  cursor getCandidate 
  is
  select TYPE_NAME, OWNER, ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER, COLUMN_COUNT
    from (
           select rt.TYPE_NAME, rt.OWNER, rta.ATTR_NAME, rta.ATTR_TYPE_NAME, rta.ATTR_TYPE_OWNER, rts.COLUMN_COUNT, MAX(COLUMN_COUNT) over () MAX_COLUMN_COUNT
             from XDBPM.REVISED_TYPES rt, XDBPM.REVISED_TYPE_ATTRS rta, XDBPM.REVISED_TYPE_SUMMARY rts, XDB.XDB$COMPLEX_TYPE ct
            where rta.type_name = rt.type_name
              and rta.owner = rt.owner
              and rts.type_name = rta.attr_type_name
              and rts.owner = nvl(rta.attr_type_owner,'SYS')
              and rt.TYPE_NAME = ct.XMLDATA.SQLTYPE
                  connect by rt.supertype_name = prior rt.type_name
                         and rt.supertype_owner = prior rt.owner
                  start with rt.type_name = P_TYPE_NAME
                         and rt.owner = P_OWNER
         )
   where COLUMN_COUNT = MAX_COLUMN_COUNT
     and ROWNUM < 2;
    
   V_BUFFER VARCHAR2(4000);
   
begin

  -- V_BUFFER := '#DEBUG -- Find Candidate : Type Name "' || P_TYPE_NAME || '"; Owner "' || P_OWNER || '"' || C_NEW_LINE;
  -- DBMS_LOB.writeAppend(P_BUFFER,LENGTH(V_BUFFER),V_BUFFER);

  for c in getCandidate loop
      P_ATTR_NAME       := c.ATTR_NAME;
      V_TYPE_NAME       := c.TYPE_NAME;
      V_OWNER           := c.OWNER;
      P_ATTR_TYPE_NAME  := c.ATTR_TYPE_NAME;
      P_ATTR_TYPE_OWNER := c.ATTR_TYPE_OWNER;
      V_COLUMN_COUNT    := c.COLUMN_COUNT;
      V_BUFFER := '--   Processing "' || P_ATTR_NAME || '" of type "' || P_ATTR_TYPE_OWNER || '"."'|| P_ATTR_TYPE_NAME || '" in type "' || V_OWNER || '"."' || V_TYPE_NAME || '". Columns = ' || V_COLUMN_COUNT || '.' || C_NEW_LINE;
      DBMS_LOB.writeAppend(P_BUFFER,LENGTH(V_BUFFER),V_BUFFER);
  end loop;

  
  if (V_COLUMN_COUNT > 1000) then
    V_COLUMN_COUNT := findCandidate(P_ATTR_TYPE_NAME, P_ATTR_TYPE_OWNER, P_ATTR_NAME, P_ATTR_TYPE_NAME, P_ATTR_TYPE_OWNER, P_BUFFER);
  end if;
  
  return V_COLUMN_COUNT;

end;
--
function getTableName(P_PARENT_SCHEMA REF XMLType, P_ELEMENT_NAME VARCHAR2, P_SQLTYPE VARCHAR2, P_OWNER VARCHAR2)
return VARCHAR2
as
--
-- Create a Unique name for this Table.
--
-- Rules are as follows
-- Name derived from element name. Name must be unqiue within the XML Schema for the ComplexType and XML Schema
--

  V_COUNTER      NUMBER(2) := 0;
  V_TABLE_NAME   VARCHAR2(30);
  V_TABLE_EXISTS NUMBER;
begin
		
	if (G_TABLE_LIST.count() > 0) then
   	for i in G_TABLE_LIST.first .. G_TABLE_LIST.last loop
   	  if ((G_TABLE_LIST(i).PARENT_SCHEMA = P_PARENT_SCHEMA) and (G_TABLE_LIST(i).ELEMENT_NAME = P_ELEMENT_NAME) and (G_TABLE_LIST(i).SQLTYPE = P_SQLTYPE)) then
   	    return G_TABLE_LIST(i).TABLE_NAME;
   	  end if;
    end loop;
  end if;
	
  G_TABLE_LIST.extend();
  G_TABLE_LIST(G_TABLE_LIST.last).PARENT_SCHEMA := P_PARENT_SCHEMA;
  G_TABLE_LIST(G_TABLE_LIST.last).ELEMENT_NAME  := P_ELEMENT_NAME;
  G_TABLE_LIST(G_TABLE_LIST.last).SQLTYPE       := P_SQLTYPE;

	V_TABLE_NAME := SUBSTR(UPPER(P_ELEMENT_NAME),1,26) || '_XML';
	
	loop
    select count(*)
      into V_TABLE_EXISTS
      from ALL_XML_TABLES
     where TABLE_NAME = V_TABLE_NAME
       and OWNER = P_OWNER;
     
    exit when V_TABLE_EXISTS = 0;

    V_COUNTER := V_COUNTER + 1;
    V_TABLE_NAME := SUBSTR(UPPER(P_ELEMENT_NAME),1,23) || '_' || LPAD(V_COUNTER,2,'0') || '_XML';
  end loop;     
     
	for i in G_TABLE_LIST.first .. G_TABLE_LIST.last loop
	  if G_TABLE_LIST(i).TABLE_NAME = V_TABLE_NAME then
	    V_COUNTER := V_COUNTER + 1;
	    V_TABLE_NAME := SUBSTR(UPPER(P_ELEMENT_NAME),1,23) || '_' || LPAD(V_COUNTER,2,'0') || '_XML';
	  end if;
  end loop;

  G_TABLE_LIST(G_TABLE_LIST.last).TABLE_NAME := V_TABLE_NAME;
  return V_TABLE_NAME;
end;
--
procedure markOutOfLine(P_PARENT_SCHEMA REF XMLTYPE, P_PROP_NUMBER NUMBER, P_ATTR_NAME VARCHAR2, P_LOCAL_ELEMENT_NAME VARCHAR2, P_TABLE_NAME VARCHAR2)
as
  V_BUFFER        VARCHAR2(2000);
  V_PARENT_SCHEMA REF XMLType;
  cursor checkGlobalComplexTypes
  is
  --
  -- Element identified by property number is part of a global complex type.
  --
  select ct.XMLDATA.NAME COMPLEX_TYPE_NAME, ct.XMLDATA.PARENT_SCHEMA PARENT_SCHEMA
    from xdb.xdb$complex_type ct
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
   where existsNode(ct.OBJECT_VALUE,'/xsd:complexType/descendant::xsd:element[@xdb:propNumber="' || P_PROP_NUMBER || '"]',DBMS_XDB_CONSTANTS.XDBSCHEMA_PREFIXES) = 1
$ELSE
   where xmlExists
  	     (
  	       'declare namespace xdb = "http://xmlns.oracle.com/xdb"; (: :)
   	        $CT/xs:complexType/descendant::xs:element[@xdb:propNumber=$PROP]'
  	        passing ct.OBJECT_VALUE as "CT", P_PROP_NUMBER as "PROP"
  	     )
$END
  	 and ct.XMLDATA.PARENT_SCHEMA = P_PARENT_SCHEMA
  	 and ct.XMLDATA.NAME is not NULL;
     
  cursor checkGlobalElements
  is
  --
  -- Element identified by property number is part of a global element
  --
  select ge.XMLDATA.PROPERTY.NAME GLOBAL_ELEMENT_NAME, ge.XMLDATA.PROPERTY.PARENT_SCHEMA PARENT_SCHEMA
    from xdb.xdb$element ge
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
   where existsNode(ge.OBJECT_VALUE,'/xsd:element/descendant::xsd:element[@xdb:propNumber="' || P_PROP_NUMBER || '"]',DBMS_XDB_CONSTANTS.XDBSCHEMA_PREFIXES) = 1
$ELSE
   where xmlExists
  	     (
  	       'declare namespace xdb = "http://xmlns.oracle.com/xdb"; (: :)
   	        $ELMNT/xs:element/descendant::xs:element[@xdb:propNumber=$PROP]'
  	        passing ge.OBJECT_VALUE as "ELMNT",  P_PROP_NUMBER as "PROP"
  	     )
$END
  	 and ge.XMLDATA.PROPERTY.PARENT_SCHEMA   = P_PARENT_SCHEMA
     and ge.XMLDATA.PROPERTY.GLOBAL = HEXTORAW('01');
     
  cursor checkGlobalGroups
  is
  --
  -- Element identified by property number is part of a global group
  --
	select gd.XMLDATA.NAME GLOBAL_GROUP_NAME, gd.XMLDATA.PARENT_SCHEMA PARENT_SCHEMA
	  from xdb.xdb$GROUP_DEF gd
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
   where existsNode(gd.OBJECT_VALUE,'/xsd:group/descendant::xsd:element[@xdb:propNumber="' || P_PROP_NUMBER || '"]',DBMS_XDB_CONSTANTS.XDBSCHEMA_PREFIXES) = 1
$ELSE
   where xmlExists
  	     (
  	       'declare namespace xdb = "http://xmlns.oracle.com/xdb"; (: :)
   	        $GRP/xs:group/descendant::xs:element[@xdb:propNumber=$PROP]'
  	        passing gd.OBJECT_VALUE as "GRP",  P_PROP_NUMBER as "PROP"
  	     )
$END
	   and gd.XMLDATA.PARENT_SCHEMA = P_PARENT_SCHEMA;
	       
	 V_GLOBAL_OBJECT_FOUND BOOLEAN := FALSE;
begin

  if (not V_GLOBAL_OBJECT_FOUND) then
    for e in checkGlobalComplexTypes loop
    	V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.setOutOfLine(V_XML_SCHEMA,DBMS_XDB_CONSTANTS.XSD_COMPLEX_TYPE,''' || e.COMPLEX_TYPE_NAME || ''',';
    	V_PARENT_SCHEMA := e.PARENT_SCHEMA;
    	V_GLOBAL_OBJECT_FOUND := TRUE;
    end loop;
  end if;

  if (not V_GLOBAL_OBJECT_FOUND) then
    for e in checkGlobalElements loop
    	V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.setOutOfLine(V_XML_SCHEMA,DBMS_XDB_CONSTANTS.XSD_ELEMENT,''' || e.GLOBAL_ELEMENT_NAME || ''',';
    	V_PARENT_SCHEMA := e.PARENT_SCHEMA;
    	V_GLOBAL_OBJECT_FOUND := TRUE;
    end loop;
  end if;

  if (not V_GLOBAL_OBJECT_FOUND) then
    for e in checkGlobalGroups loop
    	V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.setOutOfLine(V_XML_SCHEMA,DBMS_XDB_CONSTANTS.XSD_GROUP,''' || e.GLOBAL_GROUP_NAME || ''',';
    	V_PARENT_SCHEMA := e.PARENT_SCHEMA;
    	V_GLOBAL_OBJECT_FOUND := TRUE;
    end loop;
  end if;

  if (V_GLOBAL_OBJECT_FOUND) then
  	V_BUFFER := RPAD(V_BUFFER,160,' ') || '''' || P_LOCAL_ELEMENT_NAME || ''',';
    V_BUFFER := RPAD(V_BUFFER,210,' ') || '''' || P_TABLE_NAME || ''');'; 
    V_BUFFER := V_BUFFER || C_NEW_LINE;
	  for i in G_SCHEMA_REFERENCE_LIST.first .. G_SCHEMA_REFERENCE_LIST.last loop
  	  if G_SCHEMA_REFERENCE_LIST(i) = V_PARENT_SCHEMA then
  	    if not (G_SCHEMA_ANNOTATION_CACHE(i).HAS_OUT_OF_LINE_HEADER) then
          V_BUFFER := '      -- Out-of-Line mappings for 1000 Column optimization :-'  || C_BLANK_LINE || V_BUFFER;
          G_SCHEMA_ANNOTATION_CACHE(i).HAS_ANNOTATIONS := TRUE;
  	      G_SCHEMA_ANNOTATION_CACHE(i).HAS_OUT_OF_LINE_HEADER := TRUE;
  	    end if;
        DBMS_LOB.writeAppend(G_SCHEMA_ANNOTATION_CACHE(i).SCHEMA_ANNOTATIONS,LENGTH(V_BUFFER),V_BUFFER);
        exit;
      end if;
    end loop;
  end if;
end;
--
procedure makeOutOfLine(P_LOCAL_ELEMENT_NAME VARCHAR2, P_TYPE_NAME VARCHAR2, P_OWNER VARCHAR2)
as
--
-- Find all local elements of the specified name and type.
--
  V_TABLE_NAME VARCHAR2(30);  

  cursor getLocalElements
  is
  select e.XMLDATA.PROPERTY.PROP_NUMBER  PROP_NUMBER,
         e.XMLDATA.PROPERTY.PARENT_SCHEMA PARENT_SCHEMA,
         e.XMLDATA.PROPERTY.SQLNAME SQLNAME,
	       case when e.XMLDATA.PROPERTY.PROPREF_REF is null     
   		     then e.XMLDATA.PROPERTY.NAME                          
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
		       else extractValue(OBJECT_VALUE,'/xsd:element/@ref',DBMS_XDB_CONSTANTS.XDBSCHEMA_PREFIXES)
$ELSE
		       else XMLCast                                          
			          (                                                      
			            XMLQuery                                             
			            (                                                    
			              '$EL/xs:element/@ref'                              
			               passing e.OBJECT_VALUE as "EL"                     
			               returning CONTENT                                  
			            )                                                   
			            as VARCHAR2(2000)                                   
			          )              
$END			                                                 
	       end LOCAL_ELEMENT_NAME
    from xdb.xdb$element e
   where e.XMLDATA.PROPERTY.SQLTYPE     = P_TYPE_NAME
     and e.XMLDATA.PROPERTY.SQLSCHEMA   = P_OWNER
     and e.XMLDATA.PROPERTY.GLOBAL      = HEXTORAW('00')
     and e.XMLDATA.PROPERTY.SQLCOLLTYPE is null
     and (( e.XMLDATA.PROPERTY.NAME = P_LOCAL_ELEMENT_NAME) or (e.XMLDATA.PROPERTY.PROPREF_NAME.NAME = P_LOCAL_ELEMENT_NAME));

begin

	for e in getLocalElements loop
    --
    -- Get the Table Name. 
    -- Table name is generated from the local element name.
    -- The table can be shared by all local elements with the same name and type within the XML Schema.
    -- The table cannot (11.2.0.1.0 and earlier) be shared accross schemas.
    -- Use The SQL Type name rather than complex type name, since this avoids a join back to the Global Element to find the name of the complexType (which might be anonymous)
    --
    V_TABLE_NAME := getTableName(e.PARENT_SCHEMA, P_LOCAL_ELEMENT_NAME, P_TYPE_NAME, P_OWNER);
    markOutOfLine(e.PARENT_SCHEMA, e.PROP_NUMBER, e.SQLNAME, e.LOCAL_ELEMENT_NAME, V_TABLE_NAME);
    update XDBPM.REVISED_TYPE_ATTRS rta
       set ATTR_TYPE_NAME = 'XMLTYPE',
           ATTR_TYPE_OWNER = 'SYS'
     where ATTR_TYPE_NAME = P_TYPE_NAME
       and ATTR_TYPE_OWNER = P_OWNER
       and ATTR_NAME = e.SQLNAME;
  end loop;

end;
--
procedure initializeTypeModel
as
begin
	execute immediate 'DELETE FROM XDBPM.REVISED_TYPES';
  execute immediate 'insert into XDBPM.REVISED_TYPES select * from XDBPM.XDBPM_ALL_TYPES';
  execute immediate 'DELETE FROM XDBPM.REVISED_COLL_TYPES';
  execute immediate 'insert into XDBPM.REVISED_COLL_TYPES select * from XDBPM.XDBPM_ALL_COLL_TYPES';
  execute immediate 'DELETE FROM XDBPM.REVISED_TYPE_ATTRS';
  execute immediate 'insert into XDBPM.REVISED_TYPE_ATTRS select * from XDBPM.XDBPM_ALL_TYPE_ATTRS';
  calculateTypeSummary();
  execute immediate 'DELETE FROM XDBPM.TYPE_SUMMARY';
  execute immediate 'insert into XDBPM.TYPE_SUMMARY select * from XDBPM.REVISED_TYPE_SUMMARY';
  commit;
 end;
--
procedure generateTypeSummary
as
begin
  initializeTypeModel();
end;
--
function optimizeTypeModel(P_TYPE_ANALYSIS_PATH VARCHAR2, P_LIMIT NUMBER DEFAULT 2)
return BOOLEAN
as
  V_TYPE_NAME               VARCHAR2(30);
  V_OWNER                   VARCHAR2(30);
  V_COLUMN_COUNT            NUMBER(4);  
  V_ATTR_NAME               VARCHAR2(30);
  V_LOCAL_ELEMENT_NAME      VARCHAR2(256);

  V_OPTIMIZATION_COMPLETE   BOOLEAN := FALSE;
  V_OPTIMIZATION_SUCCESSFUL BOOLEAN := TRUE;
  
  -- Find Type that requires More than 975 columns to persist. (This allows for extra hidden columns 
  -- 5 For XMLType Namespaces and Extras, PD etc
  -- 2 For Hierarchically Enabled Tables.
  -- 1 or 2 based on Final Type / Non Final Type
  
  cursor findLargeType
  is
  select TYPE_NAME, OWNER, COLUMN_COUNT
    from (
            SELECT rts.TYPE_NAME, rts.OWNER, COLUMN_COUNT, MAX(COLUMN_COUNT) over ( ) MAX_COLUMN_COUNT
              FROM XDBPM.REVISED_TYPE_SUMMARY rts
                  ,XDB.XDB$COMPLEX_TYPE ct
                  ,TABLE(G_SCHEMA_REFERENCE_LIST) sl           
             where rts.OWNER = ct.XMLDATA.SQLSCHEMA
               and rts.TYPE_NAME = ct.XMLDATA.SQLTYPE
               and ct.XMLDATA.PARENT_SCHEMA = sl.COLUMN_VALUE
               and rts.COLUMN_COUNT > 975
         )  
   WHERE COLUMN_COUNT = MAX_COLUMN_COUNT
     and ROWNUM < 2;

  V_CONTENT CLOB;                              
  V_BUFFER  VARCHAR2(4000);
begin 
	
  initializeTypeModel();

  while (not V_OPTIMIZATION_COMPLETE) loop
    V_OPTIMIZATION_COMPLETE := TRUE;
    for t in findLargeType loop
      DBMS_LOB.createTemporary(V_CONTENT,TRUE); 
      V_BUFFER := '-- Type "' || t.OWNER || '"."' || t.TYPE_NAME || '" requires ' || t.COLUMN_COUNT || ' columns : Commencing Type Structure optimization -' || C_NEW_LINE;
      DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
      V_OPTIMIZATION_COMPLETE := FALSE;
      V_COLUMN_COUNT := findCandidate(t.TYPE_NAME, t.OWNER, V_ATTR_NAME, V_TYPE_NAME, V_OWNER, V_CONTENT);   
      if (V_COLUMN_COUNT > P_LIMIT) then
        -- V_BUFFER := '#DEBUG - Find Local Element Name : Attr Name "' || V_ATTR_NAME || '"; Type Name "' || V_TYPE_NAME || '; Type Owner "' || V_OWNER || '".' || C_NEW_LINE;
        -- DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
        V_LOCAL_ELEMENT_NAME := findLocalElementName(V_ATTR_NAME, V_TYPE_NAME, V_OWNER);
        DBMS_LOB.writeAppend(V_CONTENT,LENGTH(C_NEW_LINE),C_NEW_LINE);
        XDB_OUTPUT.writeToFile(P_TYPE_ANALYSIS_PATH,V_CONTENT);
        makeOutOfLine(V_LOCAL_ELEMENT_NAME, V_TYPE_NAME, V_OWNER); 
        calculateTypeSummary();    
      else
        V_OPTIMIZATION_COMPLETE := TRUE;
        V_OPTIMIZATION_SUCCESSFUL := FALSE;
        V_BUFFER := '  -- Unable to optimize type model.' || C_NEW_LINE;
        DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
        XDB_OUTPUT.writeToFile(P_TYPE_ANALYSIS_PATH,V_CONTENT);
      end if;
    end loop;
  end loop;  

  DBMS_LOB.createTemporary(V_CONTENT,TRUE); 
  V_BUFFER := '  -- Optimization Complete. --' || C_BLANK_LINE;
  DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
  XDB_OUTPUT.writeToFile(P_TYPE_ANALYSIS_PATH,V_CONTENT);
          
  return V_OPTIMIZATION_SUCCESSFUL;
  
exception
  when OTHERS then
    if (V_CONTENT is NULL) then
      DBMS_LOB.createTemporary(V_CONTENT,TRUE); 
    end if;    
    V_BUFFER := '  -- Error Detected During Optimization. --' || C_BLANK_LINE;
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
    V_BUFFER := DBMS_UTILITY.FORMAT_ERROR_STACK() || C_BLANK_LINE;
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
    V_BUFFER := DBMS_UTILITY.FORMAT_ERROR_BACKTRACE() || C_BLANK_LINE;
    DBMS_LOB.writeAppend(V_CONTENT,LENGTH(V_BUFFER),V_BUFFER);
    XDB_OUTPUT.writeToFile(P_TYPE_ANALYSIS_PATH,V_CONTENT);
    RAISE;
  
end;
--
function loadSchemaAnnotationCache(V_SCHEMA_LOCATION_LIST XDB.XDB$STRING_LIST_T)
return SCHEMA_ANNOTATION_LIST_T
as
  V_SCHEMA_ANNOTATION_CACHE SCHEMA_ANNOTATION_LIST_T := SCHEMA_ANNOTATION_LIST_T();
  V_CONTENT CLOB;
  
  cursor getSchemas 
  is
  SELECT SCHEMA_URL, OWNER, 
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
				 XDBPM_ANALYZE_XMLSCHEMA.getXMLSchemaRef(SCHEMA_URL,OWNER) SCHEMA_REFERENCE
$ELSE				 
         MAKE_REF(XDB.XDB$SCHEMA,SCHEMA_ID) SCHEMA_REFERENCE
$END         
    from ALL_XML_SCHEMAS
        ,TABLE(V_SCHEMA_LOCATION_LIST) sl
   where SCHEMA_URL = sl.COLUMN_VALUE;
begin
  G_SCHEMA_REFERENCE_LIST := XDB.XDB$XMLTYPE_REF_LIST_T();
	for s in getSchemas loop
    G_SCHEMA_REFERENCE_LIST.extend();
    G_SCHEMA_REFERENCE_LIST(G_SCHEMA_REFERENCE_LIST.last) := s.SCHEMA_REFERENCE;

    V_SCHEMA_ANNOTATION_CACHE.extend();
    DBMS_LOB.createTemporary(V_CONTENT,TRUE);

    V_SCHEMA_ANNOTATION_CACHE(V_SCHEMA_ANNOTATION_CACHE.last).SCHEMA_LOCATION_HINT   := s.SCHEMA_URL;
    V_SCHEMA_ANNOTATION_CACHE(V_SCHEMA_ANNOTATION_CACHE.last).OWNER                  := s.OWNER;
    
    V_SCHEMA_ANNOTATION_CACHE(V_SCHEMA_ANNOTATION_CACHE.last).SCHEMA_ANNOTATIONS     := V_CONTENT;
    V_SCHEMA_ANNOTATION_CACHE(V_SCHEMA_ANNOTATION_CACHE.last).HAS_ANNOTATIONS        := FALSE;
    V_SCHEMA_ANNOTATION_CACHE(V_SCHEMA_ANNOTATION_CACHE.last).HAS_OUT_OF_LINE_HEADER := FALSE;
  end loop;
  
  return V_SCHEMA_ANNOTATION_CACHE;
  
end;
--
procedure getDependentSchemas(P_SCHEMA_LOCATION_HINT VARCHAR2, P_OWNER VARCHAR2 DEFAULT USER, P_SCHEMA_LOCATION_LIST IN OUT XDB.XDB$STRING_LIST_T)
as
  V_SCHEMA_COUNT NUMBER;
  cursor getSchemaLocations
  is
  select distinct L.SCHEMA_LOCATION
    from xdb.xdb$schema sc, table(sc.XMLDATA.INCLUDES) l
   where sc.XMLDATA.SCHEMA_URL = P_SCHEMA_LOCATION_HINT
     and not exists
         ( 
           select 1
             from TABLE(P_SCHEMA_LOCATION_LIST) k
            where l.SCHEMA_LOCATION = k.COLUMN_VALUE
         )
  union all
  select distinct L.SCHEMA_LOCATION
    from xdb.xdb$schema sc, table(sc.XMLDATA.IMPORTS) l
   where sc.XMLDATA.SCHEMA_URL = P_SCHEMA_LOCATION_HINT
     and not exists
         ( 
           select 1
             from TABLE(P_SCHEMA_LOCATION_LIST) k
            where l.SCHEMA_LOCATION = k.COLUMN_VALUE
         );

begin
	V_SCHEMA_COUNT := P_SCHEMA_LOCATION_LIST.last;
  for sc in getSchemaLocations loop
    P_SCHEMA_LOCATION_LIST.extend();
    P_SCHEMA_LOCATION_LIST(P_SCHEMA_LOCATION_LIST.last) := sc.SCHEMA_LOCATION;
  end loop;

  if (P_SCHEMA_LOCATION_LIST.last > V_SCHEMA_COUNT) then
    for i in V_SCHEMA_COUNT + 1 .. P_SCHEMA_LOCATION_LIST.last loop
      getDependentSchemas(P_SCHEMA_LOCATION_LIST(i), P_OWNER, P_SCHEMA_LOCATION_LIST);
    end loop;
  end if;
end;
--	
function getSchemaLocationList(P_SCHEMA_LOCATION_HINT VARCHAR2,P_OWNER VARCHAR2 DEFAULT USER)
return XDB.XDB$STRING_LIST_T
as
  V_SCHEMA_EXISTS NUMBER;
  V_SCHEMA_LOCATION_LIST XDB.XDB$STRING_LIST_T := XDB.XDB$STRING_LIST_T();
begin
	select count(*) 
	  into V_SCHEMA_EXISTS
    from ALL_XML_SCHEMAS
   where SCHEMA_URL = P_SCHEMA_LOCATION_HINT
     and OWNER = P_OWNER;
   
	if (V_SCHEMA_EXISTS = 1) then
    V_SCHEMA_LOCATION_LIST.extend();
    V_SCHEMA_LOCATION_LIST(V_SCHEMA_LOCATION_LIST.last) := P_SCHEMA_LOCATION_HINT;
    getDependentSchemas(P_SCHEMA_LOCATION_HINT, P_OWNER, V_SCHEMA_LOCATION_LIST);
  end if;
 
  return V_SCHEMA_LOCATION_LIST;
end;
--
function getSchemaLocationList(P_CONFIGURATION XMLTYPE)
return XDB.XDB$STRING_LIST_T
as
  --
  -- There may be corner cases where we need XML Schemas other than those in the configuration document...
  -- These schemas were already registered (possibly as system defined schemas) 
  -- 
  V_SCHEMA_EXISTS NUMBER;
  V_SCHEMA_LOCATION_LIST XDB.XDB$STRING_LIST_T := XDB.XDB$STRING_LIST_T();
  
  cursor getSchemaLocationList 
  is
  select *
    from XMLTABLE
         (
           xmlNamespaces
           (
              default 'http://xmlns.oracle.com/xdb/pm/registrationConfiguration'
           ),
           '/RegistrationList/Schema'
           passing P_CONFIGURATION
           columns
           SCHEMA_LOCATION_HINT VARCHAR2(700) path 'SchemaLocationHint'
         );
   
  V_UNKNOWN_SCHEMA BOOLEAN := FALSE;
            
begin
  for x in getSchemaLocationList loop
    V_UNKNOWN_SCHEMA := TRUE;
    if V_SCHEMA_LOCATION_LIST.count() > 0 then
      for i in V_SCHEMA_LOCATION_LIST.first .. V_SCHEMA_LOCATION_LIST.last loop
        if (V_SCHEMA_LOCATION_LIST(i) = x.SCHEMA_LOCATION_HINT) then
          V_UNKNOWN_SCHEMA := FALSE;
          exit;
        end if;
      end loop;
    end if;
    if (V_UNKNOWN_SCHEMA) then
      V_SCHEMA_LOCATION_LIST.extend();
      V_SCHEMA_LOCATION_LIST(V_SCHEMA_LOCATION_LIST.last) := x.SCHEMA_LOCATION_HINT;
      getDependentSchemas(x.SCHEMA_LOCATION_HINT, USER, V_SCHEMA_LOCATION_LIST);
    end if;
  end loop;
  
  return V_SCHEMA_LOCATION_LIST;
end;
function getDefaultTableList
return TABLE_LIST_T
as
  V_TABLE_LIST TABLE_LIST_T := TABLE_LIST_T(); 
  
  cursor getDefaultTables 
  is
  select e.XMLDATA.DEFAULT_TABLE TABLE_NAME, 
         e.XMLDATA.PROPERTY.PARENT_SCHEMA PARENT_SCHEMA, 
         e.XMLDATA.PROPERTY.NAME ELEMENT_NAME, 
         e.XMLDATA.PROPERTY.SQLTYPE SQLTYPE
	  from XDB.XDB$ELEMENT e
        ,TABLE(G_SCHEMA_REFERENCE_LIST) sl
   where e.XMLDATA.PROPERTY.PARENT_SCHEMA = sl.COLUMN_VALUE
     and e.XMLDATA.PROPERTY.GLOBAL        = HEXTORAW('00')
     and e.XMLDATA.DEFAULT_TABLE is not NULL;
 
begin
	for t in getDefaultTables loop
    V_TABLE_LIST.extend();
    V_TABLE_LIST(V_TABLE_LIST.last).PARENT_SCHEMA := t.PARENT_SCHEMA;
    V_TABLE_LIST(V_TABLE_LIST.last).ELEMENT_NAME  := t.ELEMENT_NAME;
    V_TABLE_LIST(V_TABLE_LIST.last).SQLTYPE       := t.SQLTYPE;
    V_TABLE_LIST(V_TABLE_LIST.last).TABLE_NAME    := t.TABLE_NAME;
  end loop;
  
  return V_TABLE_LIST;
end;
--
procedure describeAnnotations(P_RESOURCE_PATH VARCHAR2, P_SCHEMA_LOCATION_HINT VARCHAR2,P_OWNER VARCHAR2 DEFAULT USER)
as
  V_REUSE_GENERATED_NAMES BOOLEAN := TRUE;
  V_SCHEMA_LOCATION_LIST XDB.XDB$STRING_LIST_T;
  V_PARENT_XMLSCHEMA REF XMLTYPE := NULL;
begin

$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
	V_PARENT_XMLSCHEMA := XDBPM_ANALYZE_XMLSCHEMA.getXMLSchemaRef(P_SCHEMA_LOCATION_HINT,P_OWNER) PARENT_SCHEMA
$END

	V_SCHEMA_LOCATION_LIST    := getSchemaLocationList(P_SCHEMA_LOCATION_HINT,P_OWNER);

  createOutputFile(P_RESOURCE_PATH);  
	printSchemaList(P_RESOURCE_PATH, V_SCHEMA_LOCATION_LIST, P_SCHEMA_LOCATION_HINT, P_SCHEMA_LOCATION_HINT);
	    
  if (V_SCHEMA_LOCATION_LIST is not null) then G_TABLE_LIST              := 
    getDefaultTableList(); 
    G_SCHEMA_ANNOTATION_CACHE := loadSchemaAnnotationCache(V_SCHEMA_LOCATION_LIST); 
    addGlobalTypeNames(TRUE); 
    addOutOfLineStorage(V_PARENT_XMLSCHEMA); 
    printScriptFile(P_RESOURCE_PATH); 
  end if;

end;	
--
function isCyclicReference(P_TYPE_NAME VARCHAR2, P_OWNER VARCHAR2, P_ATTR_NAME VARCHAR2, P_ATTR_TYPE_NAME VARCHAR2, P_ATTR_TYPE_OWNER VARCHAR2, P_LEVEL NUMBER,  P_CYCLE_LIST CYCLE_LIST_T)
return BOOLEAN
as
begin	
	if (P_LEVEL > 50) then
	  XDB_OUTPUT.WRITEOUTPUTFILEENTRY('Level limit excceeded.');
	  XDB_OUTPUT.FLUSHOUTPUTFILE();
	  return true;
	end if;
	if P_CYCLE_LIST.count() > 0 then
	  for i in P_CYCLE_LIST.first .. P_CYCLE_LIST.last loop
	    if P_CYCLE_LIST(i).TYPE.TYPE_NAME = P_ATTR_TYPE_NAME and P_CYCLE_LIST(i).TYPE.OWNER = P_ATTR_TYPE_OWNER then
     	  XDB_OUTPUT.WRITEOUTPUTFILEENTRY('isCyclicReference [' || P_LEVEL || '] : "' || P_OWNER || '"."' || P_TYPE_NAME || '"."' || P_ATTR_NAME || '"  of type "' || P_ATTR_TYPE_OWNER || '"."' || P_ATTR_TYPE_NAME || '". Cycle Detected.');
	      XDB_OUTPUT.FLUSHOUTPUTFILE();
	      G_KNOWN_CYCLE_LIST.extend();
	      G_KNOWN_CYCLE_LIST(G_KNOWN_CYCLE_LIST.last).TYPE_NAME := P_TYPE_NAME;
	      G_KNOWN_CYCLE_LIST(G_KNOWN_CYCLE_LIST.last).OWNER := P_OWNER;
        return true;
      end if;
      if P_CYCLE_LIST(i).SUPER_TYPE_LIST.count() > 0 then
        for j in P_CYCLE_LIST(i).SUPER_TYPE_LIST.first .. P_CYCLE_LIST(i).SUPER_TYPE_LIST.last loop
    	    if P_CYCLE_LIST(i).SUPER_TYPE_LIST(j).TYPE_NAME = P_ATTR_TYPE_NAME and P_CYCLE_LIST(i).SUPER_TYPE_LIST(j).OWNER = P_ATTR_TYPE_OWNER then
        	  XDB_OUTPUT.WRITEOUTPUTFILEENTRY('isCyclicReference [' || P_LEVEL || '] : "' || P_OWNER || '"."' || P_TYPE_NAME || '"."' || P_ATTR_NAME || '"  of type "' || P_ATTR_TYPE_OWNER || '"."' || P_ATTR_TYPE_NAME || '". Cycle by Supertype Detected.');
	          XDB_OUTPUT.FLUSHOUTPUTFILE();
     	      G_KNOWN_CYCLE_LIST.extend();
	          G_KNOWN_CYCLE_LIST(G_KNOWN_CYCLE_LIST.last).TYPE_NAME := P_TYPE_NAME;
	          G_KNOWN_CYCLE_LIST(G_KNOWN_CYCLE_LIST.last).OWNER := P_OWNER;
            return true;
          end if;
        end loop;
      end if;
    end loop;
  end if;    
	return false;
end;
--
procedure processType(P_TYPE_NAME VARCHAR2, P_OWNER VARCHAR2,P_LEVEL NUMBER,  P_CYCLE_LIST CYCLE_LIST_T)
as
  V_CYCLE_LIST CYCLE_LIST_T := P_CYCLE_LIST;
  V_LEVEL NUMBER := P_LEVEL + 1;
  cursor findChildren 
  is
  select ATTR_NAME, ATTR_TYPE_NAME, ATTR_TYPE_OWNER
    from XDBPM.MISSING_TYPE_ATTRS
   where TYPE_NAME = P_TYPE_NAME
     and P_OWNER = P_OWNER;
     
  cursor findSubTypes
  is
  select TYPE_NAME, OWNER
    from XDBPM.MISSING_TYPES
   where SUPERTYPE_NAME = P_TYPE_NAME
    and SUPERTYPE_OWNER = P_OWNER;
    
  cursor findSuperTypes 
  is
  select SUPERTYPE_NAME, SUPERTYPE_OWNER
    FROM XDBPM.XDBPM_ALL_TYPES
         CONNECT BY prior SUPERTYPE_NAME = TYPE_NAME
                      and SUPERTYPE_OWNER = OWNER
         START WITH TYPE_NAME = P_TYPE_NAME
                and OWNER = P_OWNER;
                   
  V_CYCLE_DETECTED BOOLEAN := FALSE;
  
begin
	
	if G_KNOWN_CYCLE_LIST.count() > 0 then
	  for i in G_KNOWN_CYCLE_LIST.first .. G_KNOWN_CYCLE_LIST.last loop
	    if G_KNOWN_CYCLE_LIST(i).TYPE_NAME = P_TYPE_NAME and G_KNOWN_CYCLE_LIST(i).OWNER = P_OWNER then
        XDB_OUTPUT.WRITEOUTPUTFILEENTRY('Skipping known cyclic type : "' || P_OWNER || '"."' || P_TYPE_NAME || '".');
        XDB_OUTPUT.FLUSHOUTPUTFILE();
	      return;
	    end if;
	  end loop;
  end if;
	    
	if G_PROCESSED_TYPE_LIST.count() > 0 then
	  for i in G_PROCESSED_TYPE_LIST.first .. G_PROCESSED_TYPE_LIST.last loop
	    if G_PROCESSED_TYPE_LIST(i).TYPE_NAME = P_TYPE_NAME and G_PROCESSED_TYPE_LIST(i).OWNER = P_OWNER then
        XDB_OUTPUT.WRITEOUTPUTFILEENTRY('Skipping known non-cyclic type : "' || P_OWNER || '"."' || P_TYPE_NAME || '".');
        XDB_OUTPUT.FLUSHOUTPUTFILE();
	      return;
	    end if;
	  end loop;
  end if;
  
	V_CYCLE_LIST.extend();
	V_CYCLE_LIST(V_CYCLE_LIST.last).TYPE.TYPE_NAME := P_TYPE_NAME;
	V_CYCLE_LIST(V_CYCLE_LIST.last).TYPE.OWNER := P_OWNER;
	V_CYCLE_LIST(V_CYCLE_LIST.last).SUPER_TYPE_LIST := TYPE_LIST_T();
	for s in findSupertypes loop
	  V_CYCLE_LIST(V_CYCLE_LIST.last).SUPER_TYPE_LIST.extend();
	  V_CYCLE_LIST(V_CYCLE_LIST.last).SUPER_TYPE_LIST(V_CYCLE_LIST(V_CYCLE_LIST.last).SUPER_TYPE_LIST.last).TYPE_NAME := s.SUPERTYPE_NAME;
	  V_CYCLE_LIST(V_CYCLE_LIST.last).SUPER_TYPE_LIST(V_CYCLE_LIST(V_CYCLE_LIST.last).SUPER_TYPE_LIST.last).OWNER := s.SUPERTYPE_OWNER;
  end loop;
	  
  XDB_OUTPUT.WRITEOUTPUTFILEENTRY('processType [' || P_LEVEL || '] : Checking "' || P_OWNER || '"."' || P_TYPE_NAME || '".');
  XDB_OUTPUT.FLUSHOUTPUTFILE();
	for c in findChildren() loop 
   	XDB_OUTPUT.WRITEOUTPUTFILEENTRY('Child : "' || c.ATTR_TYPE_OWNER || '"."' || c.ATTR_TYPE_NAME || '"."' || c.ATTR_NAME || '".');
    XDB_OUTPUT.FLUSHOUTPUTFILE();
	  V_CYCLE_DETECTED := isCyclicReference(P_TYPE_NAME, P_OWNER, c.ATTR_NAME, c.ATTR_TYPE_NAME, c.ATTR_TYPE_OWNER, V_LEVEL,V_CYCLE_LIST);
	  if ( not V_CYCLE_DETECTED) then
   	  processType(c.ATTR_TYPE_NAME,C.ATTR_TYPE_OWNER,V_LEVEL,V_CYCLE_LIST);
	  end if;
	end loop;
	
  for st in findSubTypes() loop
    XDB_OUTPUT.WRITEOUTPUTFILEENTRY('SubType : "' || st.OWNER || '"."' || st.TYPE_NAME || '".');
    XDB_OUTPUT.FLUSHOUTPUTFILE();
 	  processType(st.TYPE_NAME,st.OWNER,V_LEVEL,V_CYCLE_LIST);
	end loop;

  G_KNOWN_CYCLE_LIST.extend();
  G_KNOWN_CYCLE_LIST(G_KNOWN_CYCLE_LIST.last).TYPE_NAME := P_TYPE_NAME;
  G_KNOWN_CYCLE_LIST(G_KNOWN_CYCLE_LIST.last).OWNER := P_OWNER;
	  	    
end;
--
procedure generateCycleReport(P_RESOURCE_PATH VARCHAR2 DEFAULT '/public/cycleReport.log')
as
  cursor findUnresolvedElements
  is
  select ge.XMLDATA.PROPERTY.SQLTYPE  TYPE_NAME,
         ge.XMLDATA.PROPERTY.SQLSCHEMA OWNER
    from xdb.xdb$ELEMENT ge, XDBPM.MISSING_TYPES mt
   where ge.XMLDATA.PROPERTY.SQLTYPE = mt.TYPE_NAME
     and ge.XMLDATA.PROPERTY.SQLSCHEMA = mt.OWNER
     and ge.XMLDATA.PROPERTY.GLOBAL = hexToRaw('01')
     and ge.XMLDATA.HEAD_ELEM_REF is null
     and not exists
         (
           select 1 
             from XDB.XDB$ELEMENT le
            where le.XMLDATA.PROPERTY.PROPREF_REF = ref(ge)
              and le.XMLDATA.PROPERTY.GLOBAL = hexToRaw('00')
         )
   order by ge.XMLDATA.PROPERTY.SQLTYPE;

  V_CYCLE_LIST CYCLE_LIST_T;
  V_TYPE_SUMMARY_SIZE NUMBER :=0;
  
begin
	select count(*) 
	  into V_TYPE_SUMMARY_SIZE
	  from XDBPM.TYPE_SUMMARY;
	  
	if (V_TYPE_SUMMARY_SIZE = 0) then
	  XDB_ANALYZE_XMLSCHEMA.generateTypeSummary();
	end if;

	XDB_OUTPUT.createOutputFile(P_RESOURCE_PATH,TRUE);
	G_KNOWN_CYCLE_LIST := TYPE_LIST_T();
	G_PROCESSED_TYPE_LIST := TYPE_LIST_T();
  for ge in findUnresolvedElements() loop
    V_CYCLE_LIST := CYCLE_LIST_T();
    processType(ge.TYPE_NAME,ge.OWNER,1,V_CYCLE_LIST);
  end loop;
end;
--
function XMLSCHEMA_WIZARD_UPLOAD(P_SCHEMA_CONTAINER VARCHAR2) 
return XMLType
--
--  Support the XML Schema container upload portion of the XFILES Application
--
as 
  V_FOLDER_PATH        VARCHAR2(700) := substr(P_SCHEMA_CONTAINER,1,instr(P_SCHEMA_CONTAINER,'/',-1)-1);
  V_CONTAINER_FILE     VARCHAR2(700) := substr(P_SCHEMA_CONTAINER,instr(P_SCHEMA_CONTAINER,'/',-1)+1);
  V_CONTAINER_NAME     VARCHAR2(700) := substr(V_CONTAINER_FILE,1,instr(V_CONTAINER_FILE,'.',-1)-1);
  V_SCHEMA_FOLDER_PATH VARCHAR2(700) := V_FOLDER_PATH || '/' || V_CONTAINER_NAME;
  V_UNZIP_LOGFILE      VARCHAR2(700) := V_SCHEMA_FOLDER_PATH || '.log';
  V_RESULT             BOOLEAN;
  V_LOCAL_PATH_OFFSET  NUMBER(3);
  V_SCHEMA_LIST        XMLTYPE;
begin
	if (DBMS_XDB.existsResource(V_SCHEMA_FOLDER_PATH)) then
	  DBMS_XDB.deleteResource(V_SCHEMA_FOLDER_PATH,DBMS_XDB.DELETE_RECURSIVE);
	end if;
	
	if (DBMS_XDB.existsResource(V_UNZIP_LOGFILE)) then
	  DBMS_XDB.deleteResource(V_UNZIP_LOGFILE);
	end if;
	

	V_RESULT := DBMS_XDB.createFolder(V_SCHEMA_FOLDER_PATH);
  commit;
  
	XDB_IMPORT_UTILITIES.unZip(P_SCHEMA_CONTAINER,V_SCHEMA_FOLDER_PATH,V_UNZIP_LOGFILE,XDB_CONSTANTS.RAISE_ERROR);
  commit;

  V_LOCAL_PATH_OFFSET := length(V_SCHEMA_FOLDER_PATH) + 1;
  select xmlElement
         (
            "ROWSET",
            xmlAgg
            (
              xmlElement
              (
                "ROW",
                xmlElement
                (
                  "relativePath",
                  substr(ANY_PATH,V_LOCAL_PATH_OFFSET)
                )
              )
            )     
	        )
	   into V_SCHEMA_LIST
	   from RESOURCE_VIEW
	  where under_path(res,V_SCHEMA_FOLDER_PATH) = 1
	    and XMLExists('declare default element namespace "http://xmlns.oracle.com/xdb/XDBResource.xsd"; (: :) $R/Resource[ends-with(DisplayName,".xsd")]' passing RES as "R");
	
	return V_SCHEMA_LIST;
end;
--
function getDependentList(P_TARGET_SCHEMA VARCHAR2, P_LOCATION_PREFIX VARCHAR2)
return SCHEMA_LOCATION_LIST_T
as
  V_XML_SCHEMA           XMLType;
  V_SCHEMA_LOCATION_LIST SCHEMA_LOCATION_LIST_T;
  
  cursor getSchemaLocationList(C_XML_SCHEMA XMLType)
  is
  select distinct SCHEMA_LOCATION
    from (
           select SCHEMA_LOCATION
             from XMLTable
                  (
                    xmlNamespaces
                    (
                      'http://xmlns.oracle.com/xdb/XDBResource.xsd' as "res",
                      'http://www.w3.org/2001/XMLSchema' as "xsd"
                    ),
                    '/xsd:schema/xsd:import'
                    passing C_XML_SCHEMA
                    columns
                    NAMESPACE       VARCHAR2(700) path '@namespace',
                    SCHEMA_LOCATION VARCHAR2(700) path '@schemaLocation'
                  )
            where NAMESPACE <> 'http://www.w3.org/XML/1998/namespace'
           union all  
           select SCHEMA_LOCATION
             from XMLTable
                  (
                    xmlNamespaces
                    (
                      'http://xmlns.oracle.com/xdb/XDBResource.xsd' as "res",
                      'http://www.w3.org/2001/XMLSchema' as "xsd"
                    ),
                    '/xsd:schema/xsd:include'
                    passing C_XML_SCHEMA
                    columns
                    SCHEMA_LOCATION VARCHAR2(700) path '@schemaLocation'
                 )
         )
   where SCHEMA_LOCATION is not NULL
     and not exists
         ( 
           select 1
             from ALL_XML_SCHEMAS alx
            where alx.SCHEMA_URL = SCHEMA_LOCATION
         );

begin
	DBMS_OUTPUT.PUT_LINE(P_TARGET_SCHEMA);
	V_XML_SCHEMA := xdburitype(P_TARGET_SCHEMA).getXML();
	V_SCHEMA_LOCATION_LIST := SCHEMA_LOCATION_LIST_T();
	for i in getSchemaLocationList(V_XML_SCHEMA)loop
	  V_SCHEMA_LOCATION_LIST.extend();
	  V_SCHEMA_LOCATION_LIST(V_SCHEMA_LOCATION_LIST.LAST) := NORMALIZEPATH(P_TARGET_SCHEMA,i.SCHEMA_LOCATION,P_LOCATION_PREFIX);
  end loop;
  return V_SCHEMA_LOCATION_LIST;
end;
--
procedure buildDependencyGraph(P_TARGET_SCHEMA VARCHAR2, P_LOCATION_PREFIX VARCHAR2, P_SCHEMA_DEPENDENCY_LIST IN OUT SCHEMA_DEPENDENCY_LIST_T) 
as
  V_SCHEMA_DEPENDENCY_REC  SCHEMA_DEPENDENCY_REC;
  V_TARGET_SCHEMA          VARCHAR2(700);
  
  cursor schemaRegistered
  is
  select 1 
    from ALL_XML_SCHEMAS
   where SCHEMA_URL = P_TARGET_SCHEMA;
   
begin
  --#ORDERING#-- XDB_OUTPUT.writeOutputFileEntry('  Processing XML Schema : "' || P_TARGET_SCHEMA|| '".');

  -- Check if this schema has already been processed.. 
  
  for s in schemaRegistered loop
    --#ORDERING#--  XDB_OUTPUT.writeOutputFileEntry('Schema already Registered.');
    return;
  end loop;
  

  for i in 1..P_SCHEMA_DEPENDENCY_LIST.count() loop
    if (P_SCHEMA_DEPENDENCY_LIST(i).SCHEMA_PATH = P_TARGET_SCHEMA) then
      --#ORDERING#--  XDB_OUTPUT.writeOutputFileEntry('Schema already Processed.');
      return;
    end if;
  end loop;
  
  V_SCHEMA_DEPENDENCY_REC.SCHEMA_PATH := P_TARGET_SCHEMA;
  V_SCHEMA_DEPENDENCY_REC.DEPENDENCY_LIST := getDependentList(P_TARGET_SCHEMA,P_LOCATION_PREFIX);

  --#ORDERING#--  XDB_OUTPUT.writeOutputFileEntry('Checking Dependencies.');
  
  P_SCHEMA_DEPENDENCY_LIST.extend();
  P_SCHEMA_DEPENDENCY_LIST(P_SCHEMA_DEPENDENCY_LIST.LAST) := V_SCHEMA_DEPENDENCY_REC;
  
  --#ORDERING#--  XDB_OUTPUT.writeOutputFileEntry('Dependency count  = ' || V_SCHEMA_DEPENDENCY_REC.DEPENDENCY_LIST.count());
  if (V_SCHEMA_DEPENDENCY_REC.DEPENDENCY_LIST.count() > 0) then
    for i in V_SCHEMA_DEPENDENCY_REC.DEPENDENCY_LIST.FIRST..V_SCHEMA_DEPENDENCY_REC.DEPENDENCY_LIST.LAST loop
      --ORDERING#--  XDB_OUTPUT.writeOutputFileEntry('Dependency [' || i || '] : = "' || V_SCHEMA_DEPENDENCY_REC.DEPENDENCY_LIST(i) || '".');
      V_TARGET_SCHEMA := V_SCHEMA_DEPENDENCY_REC.DEPENDENCY_LIST(i);
      buildDependencyGraph(V_TARGET_SCHEMA, P_LOCATION_PREFIX, P_SCHEMA_DEPENDENCY_LIST);
    end loop;
  end if;
  
end;
--
procedure dumpDependencyGraph(P_SCHEMA_DEPENDENCY_LIST SCHEMA_DEPENDENCY_LIST_T)
as
begin
	for i in P_SCHEMA_DEPENDENCY_LIST.FIRST..P_SCHEMA_DEPENDENCY_LIST.LAST LOOP
    if (P_SCHEMA_DEPENDENCY_LIST.exists(i)) THEN
      XDB_OUTPUT.writeOutputFileEntry('Schema "' || P_SCHEMA_DEPENDENCY_LIST(i).SCHEMA_PATH  || '".');
  	  if (P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.count() > 0) THEN
      	for j in P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.FIRST..P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.LAST  LOOP
          if (P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.exists(j)) THEN
            XDB_OUTPUT.writeOutputFileEntry('>> "' || P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST(j) || '".');
  	      end if;
  	    end loop;
  	  end if;
  	end if;
  end loop;
end;
--
procedure dumpExtendedGraph(P_SCHEMA_DEPENDENCY_LIST SCHEMA_DEPENDENCY_LIST_T)
as
begin
	for i in P_SCHEMA_DEPENDENCY_LIST.FIRST..P_SCHEMA_DEPENDENCY_LIST.LAST LOOP
    if (P_SCHEMA_DEPENDENCY_LIST.exists(i)) THEN
      XDB_OUTPUT.writeOutputFileEntry('Schema "' || P_SCHEMA_DEPENDENCY_LIST(i).SCHEMA_PATH  || '". Recursive Path count = ' || P_SCHEMA_DEPENDENCY_LIST(i).RECURSIVE_PATH_COUNT || '. Extended Path Count = ' || P_SCHEMA_DEPENDENCY_LIST(i).EXTENDED_DEPENDENCY_LIST.count() || '.' );
  	  if (P_SCHEMA_DEPENDENCY_LIST(i).EXTENDED_DEPENDENCY_LIST.count() > 0) THEN
      	for j in P_SCHEMA_DEPENDENCY_LIST(i).EXTENDED_DEPENDENCY_LIST.FIRST..P_SCHEMA_DEPENDENCY_LIST(i).EXTENDED_DEPENDENCY_LIST.LAST  LOOP
          if (P_SCHEMA_DEPENDENCY_LIST(i).EXTENDED_DEPENDENCY_LIST.exists(j)) THEN
            XDB_OUTPUT.writeOutputFileEntry('>> "' || P_SCHEMA_DEPENDENCY_LIST(i).EXTENDED_DEPENDENCY_LIST(j) || '".');
            NULL;
  	      end if;
  	    end loop;
  	  end if;
  	end if;
  end loop;
end;
--
procedure addDependancies(P_CURRENT_SCHEMA VARCHAR2, P_DEPENDENCY_LOCATION VARCHAR2,P_SCHEMA_LOCATION_LIST IN OUT SCHEMA_LOCATION_LIST_T, P_SCHEMA_DEPENDENCY_LIST SCHEMA_DEPENDENCY_LIST_T,P_RECURSIVE_PATH_COUNT IN OUT NUMBER)
as
begin
	--
	-- Do not reprocess the current schema
	--
	--# ORDERING#--  XDB_OUTPUT.writeOutputFileEntry('"' || P_CURRENT_SCHEMA || '" : Checking Dependency "' || P_DEPENDENCY_LOCATION || '".');

  if (P_CURRENT_SCHEMA = P_DEPENDENCY_LOCATION) then
   	--#ORDERING#--  XDB_OUTPUT.writeOutputFileEntry('"' || P_CURRENT_SCHEMA || '" : Skipping recursive dependency.');
   	P_RECURSIVE_PATH_COUNT := P_RECURSIVE_PATH_COUNT + 1;
    return;
  end if;
  
	--
	-- If the current schema is already in the extended dependency list do not process it again.
	--
	if P_SCHEMA_LOCATION_LIST.count() > 0 then
	  for i in P_SCHEMA_LOCATION_LIST.FIRST .. P_SCHEMA_LOCATION_LIST.LAST loop
	    if (P_SCHEMA_LOCATION_LIST.exists(i)) then
  	    if (P_SCHEMA_LOCATION_LIST(i) = P_DEPENDENCY_LOCATION) then 
        	--#ORDERING#--  XDB_OUTPUT.writeOutputFileEntry('"' || P_CURRENT_SCHEMA || '" : Skipping known dependency.');
	        return;
	      end if;
	    end if;
    end loop;
  end if;
  
 	--#ORDERING#--  XDB_OUTPUT.writeOutputFileEntry('"' || P_CURRENT_SCHEMA || '" : Adding dependancy on "' || P_DEPENDENCY_LOCATION || '".');
  P_SCHEMA_LOCATION_LIST.extend();
  P_SCHEMA_LOCATION_LIST(P_SCHEMA_LOCATION_LIST.LAST) := P_DEPENDENCY_LOCATION;
  
  --
  -- Find the Dependency List for the current schema.
  --   
  for i in P_SCHEMA_DEPENDENCY_LIST.FIRST..P_SCHEMA_DEPENDENCY_LIST.LAST loop
    if (P_SCHEMA_DEPENDENCY_LIST.exists(i)) THEN
      if (P_SCHEMA_DEPENDENCY_LIST(i).SCHEMA_PATH = P_DEPENDENCY_LOCATION) then 
        --
        -- Add each dependent schema to the extended dependancies list
        --
        for j in P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.FIRST .. P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.LAST loop
          if (P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.exists(j)) then
            addDependancies(P_CURRENT_SCHEMA,P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST(j),P_SCHEMA_LOCATION_LIST,P_SCHEMA_DEPENDENCY_LIST,P_RECURSIVE_PATH_COUNT);
          end if;
        end loop;
      end if;
    end if;	
  end loop;
        
end;
--
procedure extendDependencyGraph(P_SCHEMA_DEPENDENCY_LIST  IN OUT SCHEMA_DEPENDENCY_LIST_T)
as
  V_SCHEMA_LOCATION_LIST SCHEMA_LOCATION_LIST_T;
  V_RECURSIVE_PATH_COUNT NUMBER := 0;
begin
  for i in P_SCHEMA_DEPENDENCY_LIST.FIRST..P_SCHEMA_DEPENDENCY_LIST.LAST loop
    if (P_SCHEMA_DEPENDENCY_LIST.exists(i)) THEN
      V_SCHEMA_LOCATION_LIST := SCHEMA_LOCATION_LIST_T();
      V_RECURSIVE_PATH_COUNT := 0;
      for j in P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.FIRST .. P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.LAST loop
        if (P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.exists(j)) then
          addDependancies(P_SCHEMA_DEPENDENCY_LIST(i).SCHEMA_PATH,P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST(j),V_SCHEMA_LOCATION_LIST,P_SCHEMA_DEPENDENCY_LIST,V_RECURSIVE_PATH_COUNT);
          P_SCHEMA_DEPENDENCY_LIST(i).EXTENDED_DEPENDENCY_LIST := V_SCHEMA_LOCATION_LIST;
          P_SCHEMA_DEPENDENCY_LIST(i).RECURSIVE_PATH_COUNT := V_RECURSIVE_PATH_COUNT;
        end if;
      end loop;
    end if;	
  end loop;
end;
--
function processSchema(P_CURRENT_SCHEMA VARCHAR2, P_SCHEMA_FOLDER VARCHAR2, P_LOCATION_HINT_PREFIX VARCHAR2, P_SCHEMA_DEPENDENCY_LIST IN OUT SCHEMA_DEPENDENCY_LIST_T, P_FORCE BOOLEAN)
return XMLType
as
  V_BUFFER               VARCHAR2(32000);
  V_SCHEMA_LOCATION_HINT VARCHAR2(700);
  V_NEXT_SCHEMA          XMLType;
  V_FORCE_OPTION         VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_FORCE);
begin
	
	V_SCHEMA_LOCATION_HINT := P_LOCATION_HINT_PREFIX || SUBSTR(P_CURRENT_SCHEMA,LENGTH(P_SCHEMA_FOLDER)+1);
	
	-- Remove leading '/' if the only '/' is the leading '/'
	
	if ((INSTR(V_SCHEMA_LOCATION_HINT,'/') = 1) and (INSTR(V_SCHEMA_LOCATION_HINT,'/',-1) = 1)) then
	  V_SCHEMA_LOCATION_HINT := SUBSTR(V_SCHEMA_LOCATION_HINT,2);
	end if;

  select xmlElement
         (
           "Schema",
 					 xmlAttributes('http://xmlns.oracle.com/xdb/pm/registrationConfiguration' as "xmlns"),
           xmlElement
           (
             "SchemaLocationHint",
             xmlAttributes('http://xmlns.oracle.com/xdb/pm/registrationConfiguration' as "xmlns"),
             V_SCHEMA_LOCATION_HINT
           ),           
           xmlElement
           (
             "RepositoryPath",
             xmlAttributes('http://xmlns.oracle.com/xdb/pm/registrationConfiguration' as "xmlns"),
             P_CURRENT_SCHEMA
           ),
           xmlElement
           (
             "Force",
             xmlAttributes('http://xmlns.oracle.com/xdb/pm/registrationConfiguration' as "xmlns"),
             V_FORCE_OPTION
           )
         )
    into V_NEXT_SCHEMA
    from dual;

  for i in P_SCHEMA_DEPENDENCY_LIST.FIRST..P_SCHEMA_DEPENDENCY_LIST.LAST loop
    if (P_SCHEMA_DEPENDENCY_LIST.exists(i)) THEN
      if (P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.count() > 0) then
        for j in P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.FIRST..P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.LAST loop
          if (P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.exists(j)) THEN
	          if (P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST(j) = P_CURRENT_SCHEMA) THEN
	             P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.delete(j);
	             EXIT;
	          end if;
	        end if;
  	    end loop;
  	  end if;
	  end if;
  end loop;
  
  return V_NEXT_SCHEMA;
end;
--
function processExtendedDependencyList(P_SCHEMA_ORDERING IN OUT XMLType, P_LOCATION_HINT_PREFIX VARCHAR2, P_SCHEMA_FOLDER VARCHAR2, P_SCHEMA_LOCATION_LIST SCHEMA_LOCATION_LIST_T,P_SCHEMA_DEPENDENCY_LIST IN OUT SCHEMA_DEPENDENCY_LIST_T)
return XMLType
as
  V_NEXT_SCHEMA       XMLType;
begin
  for i in P_SCHEMA_LOCATION_LIST.FIRST..P_SCHEMA_LOCATION_LIST.LAST  LOOP
    for j in P_SCHEMA_DEPENDENCY_LIST.FIRST..P_SCHEMA_DEPENDENCY_LIST.LAST  LOOP
      if (P_SCHEMA_DEPENDENCY_LIST.exists(j)) THEN
        if (P_SCHEMA_LOCATION_LIST(i) = P_SCHEMA_DEPENDENCY_LIST(j).SCHEMA_PATH) THEN
          if j < P_SCHEMA_DEPENDENCY_LIST.LAST then
            V_NEXT_SCHEMA := processSchema(P_SCHEMA_DEPENDENCY_LIST(j).SCHEMA_PATH,P_SCHEMA_FOLDER,P_LOCATION_HINT_PREFIX,P_SCHEMA_DEPENDENCY_LIST,TRUE);
            select appendChildXML
                   (
                     P_SCHEMA_ORDERING,
                     '/RegistrationList',
										 V_NEXT_SCHEMA,
										 'xmlns="http://xmlns.oracle.com/xdb/pm/registrationConfiguration"'                     
                   )
              into P_SCHEMA_ORDERING
              from DUAL;
          else
            V_NEXT_SCHEMA := processSchema(P_SCHEMA_DEPENDENCY_LIST(j).SCHEMA_PATH,P_SCHEMA_FOLDER,P_LOCATION_HINT_PREFIX,P_SCHEMA_DEPENDENCY_LIST,FALSE);
            select appendChildXML
                   (
                     P_SCHEMA_ORDERING,
                     '/RegistrationList',
										 V_NEXT_SCHEMA,
										 'xmlns="http://xmlns.oracle.com/xdb/pm/registrationConfiguration"'                                         
                   )
              into P_SCHEMA_ORDERING
              from DUAL;
          end if;
          P_SCHEMA_DEPENDENCY_LIST.delete(j);
        end if;
      end if;
    end loop;
  end loop;
  return P_SCHEMA_ORDERING;
end;
--
function  processDependencyGraph(P_SCHEMA_DEPENDENCY_LIST IN OUT SCHEMA_DEPENDENCY_LIST_T,P_SCHEMA_FOLDER VARCHAR2, P_LOCATION_HINT_PREFIX VARCHAR2)
return XMLType
as
  V_SCHEMA_PROCESSED  BOOLEAN := TRUE;
  V_INDEX             BINARY_INTEGER;
  V_SCHEMA_ORDERING   XMLType;
  V_NEXT_SCHEMA       XMLType;
begin

	select XMLElement("RegistrationList", xmlAttributes('http://xmlns.oracle.com/xdb/pm/registrationConfiguration' as "xmlns")) 
	  into V_SCHEMA_ORDERING
	  from DUAL;
	
	WHILE (P_SCHEMA_DEPENDENCY_LIST.count() > 0) loop
  	WHILE (V_SCHEMA_PROCESSED) LOOP
	    V_SCHEMA_PROCESSED := FALSE;
      if (P_SCHEMA_DEPENDENCY_LIST.count() > 0) then
  	    for i in P_SCHEMA_DEPENDENCY_LIST.FIRST..P_SCHEMA_DEPENDENCY_LIST.LAST  LOOP
          if (P_SCHEMA_DEPENDENCY_LIST.exists(i)) THEN
            if (P_SCHEMA_DEPENDENCY_LIST(i).DEPENDENCY_LIST.count() = 0) THEN
              V_NEXT_SCHEMA := processSchema(P_SCHEMA_DEPENDENCY_LIST(i).SCHEMA_PATH,P_SCHEMA_FOLDER,P_LOCATION_HINT_PREFIX,P_SCHEMA_DEPENDENCY_LIST,FALSE);
              select appendChildXML
                     (
                       V_SCHEMA_ORDERING,
                       '/RegistrationList',
                       V_NEXT_SCHEMA,
										   'xmlns="http://xmlns.oracle.com/xdb/pm/registrationConfiguration"'                     
                     )
                into V_SCHEMA_ORDERING
                from DUAL;
  	          P_SCHEMA_DEPENDENCY_LIST.delete(i);
	            V_SCHEMA_PROCESSED := TRUE;
	            exit;
	          end if;
	        end if;
  	    end LOOP;
  	  end if;
    end LOOP;
   
    if (P_SCHEMA_DEPENDENCY_LIST.count() > 0) THEN
      --
      -- Calculate the complete dependancy list for all remaining schemas.
      --
  	  extendDependencyGraph(P_SCHEMA_DEPENDENCY_LIST);
  	  --
  	  -- Pick the first schema in the list and register it and all but the last dependent schemas with FORCE = TRUE;
  	  -- Register the last dependent schema with FORCE = FALSE, since all cycles should be resolvable.
  	  --
  	  V_INDEX := P_SCHEMA_DEPENDENCY_LIST.FIRST;
  	  V_NEXT_SCHEMA := processSchema(P_SCHEMA_DEPENDENCY_LIST(V_INDEX).SCHEMA_PATH,P_SCHEMA_FOLDER,P_LOCATION_HINT_PREFIX,P_SCHEMA_DEPENDENCY_LIST,TRUE);
      select appendChildXML
             (
               V_SCHEMA_ORDERING,
               '/RegistrationList',
               V_NEXT_SCHEMA,
						   'xmlns="http://xmlns.oracle.com/xdb/pm/registrationConfiguration"'                     
             )
        into V_SCHEMA_ORDERING
        from DUAL;
  	  V_SCHEMA_ORDERING := processExtendedDependencyList(V_SCHEMA_ORDERING, P_LOCATION_HINT_PREFIX, P_SCHEMA_FOLDER, P_SCHEMA_DEPENDENCY_LIST(V_INDEX).EXTENDED_DEPENDENCY_LIST,P_SCHEMA_DEPENDENCY_LIST);
      P_SCHEMA_DEPENDENCY_LIST.delete(V_INDEX);
      V_SCHEMA_PROCESSED := TRUE;
    end if; 	  
  end loop;
  return V_SCHEMA_ORDERING;
end;
--
function orderSchemas(P_XMLSCHEMA_FOLDER VARCHAR2, P_XMLSCHEMA_PATH VARCHAR2, P_SCHEMA_LOCATION_PREFIX VARCHAR2) 
return XMLType
as
  V_SCHEMA_DEPENDENCY_LIST SCHEMA_DEPENDENCY_LIST_T   := SCHEMA_DEPENDENCY_LIST_T();
  V_SCHEMA_ORDERING        XMLTYPE;
begin  	

  -- #ORDERING#-- XDB_OUTPUT.writeOutputFileEntry('Processing XML Schema "' || P_XMLSCHEMA_FOLDER || '/' || P_XMLSCHEMA_PATH || '".');

  buildDependencyGraph(P_XMLSCHEMA_FOLDER || '/' || P_XMLSCHEMA_PATH, P_SCHEMA_LOCATION_PREFIX, V_SCHEMA_DEPENDENCY_LIST);  

  -- #ORDERING#-- dumpDependencyGraph(V_SCHEMA_DEPENDENCY_LIST);
  -- #ORDERING#-- XDB_OUTPUT.flushOutputFile();

  V_SCHEMA_ORDERING := processDependencyGraph(V_SCHEMA_DEPENDENCY_LIST, P_XMLSCHEMA_FOLDER, P_SCHEMA_LOCATION_PREFIX);
  return V_SCHEMA_ORDERING;
end;
--
function orderSchemas(P_XMLSCHEMA_FOLDER VARCHAR2, P_SCHEMA_LOCATION_PREFIX VARCHAR2) 
return XMLType
as
  V_SCHEMA_DEPENDENCY_LIST SCHEMA_DEPENDENCY_LIST_T   := SCHEMA_DEPENDENCY_LIST_T();
  V_SCHEMA_ORDERING        XMLTYPE;
  
  cursor getXMLSchemas
  is
  select ANY_PATH
	  from RESOURCE_VIEW
	 where under_path(res,P_XMLSCHEMA_FOLDER) = 1
	   and XMLExists('declare default element namespace "http://xmlns.oracle.com/xdb/XDBResource.xsd"; (: :) $R/Resource[ends-with(DisplayName,".xsd")]' passing RES as "R");

begin
  -- #ORDERING#-- XDB_OUTPUT.writeOutputFileEntry('Processing XML Schemas for folder "' || P_XMLSCHEMA_FOLDER || '".');
  
	for x in getXMLSchemas() loop
	  buildDependencyGraph(x.ANY_PATH, P_SCHEMA_LOCATION_PREFIX, V_SCHEMA_DEPENDENCY_LIST);  
	end loop;

  -- #ORDERING#-- dumpDependencyGraph(V_SCHEMA_DEPENDENCY_LIST);
  -- #ORDERING#-- XDB_OUTPUT.flushOutputFile();
  
  V_SCHEMA_ORDERING := processDependencyGraph(V_SCHEMA_DEPENDENCY_LIST, P_XMLSCHEMA_FOLDER, P_SCHEMA_LOCATION_PREFIX);
  return V_SCHEMA_ORDERING;
end;
--
procedure addAnnotations(P_CONFIGURATION IN OUT XMLTYPE)
as
  V_ANNOTATIONS   XMLType;
  V_BUFFER        VARCHAR2(4000);
  V_NAMESPACE_URI VARCHAR2(1024);
begin
	select XMLCast(XMLQuery('for $i in fn:namespace-uri($XML) return $i' passing P_CONFIGURATION as "XML" returning content) as VARCHAR2(1024))
	  into V_NAMESPACE_URI
	  from DUAL;
	  
	for i in G_SCHEMA_ANNOTATION_CACHE.first .. G_SCHEMA_ANNOTATION_CACHE.last loop
    if G_SCHEMA_ANNOTATION_CACHE(i).HAS_ANNOTATIONS then

  		select  XMLElement
               (
                 "rc:Annotations",
                 xmlattributes(V_NAMESPACE_URI as "xmlns:rc"),
                 G_SCHEMA_ANNOTATION_CACHE(i).SCHEMA_ANNOTATIONS
               )
        into V_ANNOTATIONS 
        from dual;
        
      select insertChildXML
             (
               P_CONFIGURATION,
               '/rc:RegistrationList/rc:Schema[rc:SchemaLocationHint="' || G_SCHEMA_ANNOTATION_CACHE(i).SCHEMA_LOCATION_HINT || '"]',
               'rc:Annotations',
               V_ANNOTATIONS,
               'xmlns:rc="' || V_NAMESPACE_URI || '"'
             )
        into P_CONFIGURATION
        from DUAL;
    end if;
  end loop;  
end;
--
function doTypeAnalysis(P_OUTPUT_FILE VARCHAR2, P_TARGET_NAME VARCHAR2, P_CONFIGURATION IN OUT XMLTYPE, P_SCHEMA_LOCATION_HINT VARCHAR2 DEFAULT NULL, P_OWNER VARCHAR2 DEFAULT USER, P_LIMIT NUMBER DEFAULT 3)
return VARCHAR2
as
  V_OPTIMIZATION_SUCCESSFUL BOOLEAN := FALSE;     
  V_SCHEMA_LOCATION_LIST    XDB.XDB$STRING_LIST_T;
  V_PARENT_XMLSCHEMA REF XMLTYPE := NULL;
begin

$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
	V_PARENT_XMLSCHEMA := XDBPM_ANALYZE_XMLSCHEMA.getXMLSchemaRef(P_SCHEMA_LOCATION_HINT,P_OWNER) PARENT_SCHEMA
$END

  createOutputFile(P_OUTPUT_FILE);  

  if (P_SCHEMA_LOCATION_HINT is NULL) then
	  V_SCHEMA_LOCATION_LIST    := getSchemaLocationList(P_CONFIGURATION);
	else
  	V_SCHEMA_LOCATION_LIST    := getSchemaLocationList(P_SCHEMA_LOCATION_HINT,P_OWNER);
  end if;

	printSchemaList(P_OUTPUT_FILE, V_SCHEMA_LOCATION_LIST, P_TARGET_NAME, P_SCHEMA_LOCATION_HINT);  

  if (V_SCHEMA_LOCATION_LIST is not null) then
	  G_TABLE_LIST              := getDefaultTableList();
  	G_SCHEMA_ANNOTATION_CACHE := loadSchemaAnnotationCache(V_SCHEMA_LOCATION_LIST);
    enforceDomFidelity();
    addGlobalTypeNames(TRUE);
    addOutOfLineStorage(V_PARENT_XMLSCHEMA);
    V_OPTIMIZATION_SUCCESSFUL := optimizeTypeModel(P_OUTPUT_FILE,P_LIMIT);
    if (V_OPTIMIZATION_SUCCESSFUL) then
      addAnnotations(P_CONFIGURATION);
    end if;
  end if;

 
  return XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(V_OPTIMIZATION_SUCCESSFUL);
end;	
--
procedure setRegistrationScriptOptions(
           P_ADD_XDB_NAMESPACE      BOOLEAN        DEFAULT TRUE,  
           P_DISABLE_DOM_FIDELITY   BOOLEAN        DEFAULT FALSE, 
           P_DISABLE_DEFAULT_TABLES BOOLEAN        DEFAULT FALSE,
           P_REMOVE_APPINFO         BOOLEAN        DEFAULT FALSE,
           P_CALL_ANNOTATION_SCRIPT BOOLEAN        DEFAULT FALSE
        )
as
begin
	G_ADD_XDB_NAMESPACE      := P_ADD_XDB_NAMESPACE;
	G_DISABLE_DOM_FIDELITY   := P_DISABLE_DOM_FIDELITY;
	G_DISABLE_DEFAULT_TABLES := P_DISABLE_DEFAULT_TABLES;
	G_REMOVE_APPINFO         := P_REMOVE_APPINFO;
	G_CALL_ANNOTATION_SCRIPT := P_CALL_ANNOTATION_SCRIPT; 
end;
--
procedure addXDBNamespace
as
begin
	G_ADD_XDB_NAMESPACE      := TRUE;
end;
--
procedure disableDOMFidelity
as
begin
	G_DISABLE_DOM_FIDELITY   := TRUE;
end;
--
procedure disableDefaultTables
as
begin
	G_DISABLE_DEFAULT_TABLES := TRUE;
end;
--
procedure removeAppInfo
as
begin
	G_REMOVE_APPINFO := TRUE;
end;
--

procedure annotationScript
as
begin
	G_CALL_ANNOTATION_SCRIPT := TRUE; 
end;
--
procedure setSchemaRegistrationOptions(
           P_LOCAL                BOOLEAN        DEFAULT TRUE,  
           P_GENTYPES             BOOLEAN        DEFAULT TRUE,  
           P_GENTABLES            BOOLEAN        DEFAULT TRUE, 
           P_FORCE                BOOLEAN        DEFAULT FALSE, 
           P_OWNER                VARCHAR2       DEFAULT NULL, 
           P_ENABLE_HIERARCHY     BINARY_INTEGER DEFAULT DBMS_XMLSCHEMA.ENABLE_HIERARCHY_NONE,
           P_OPTIONS              BINARY_INTEGER DEFAULT NULL
        )
as
begin
	G_LOCAL            := P_LOCAL;
	G_GENTYPES         := P_GENTYPES;
	G_GENTABLES        := P_GENTABLES;
	G_FORCE            := P_FORCE;
	G_OWNER            := P_OWNER;
	G_ENABLE_HIERARCHY := P_ENABLE_HIERARCHY;
	G_OPTIONS          := P_OPTIONS;
end;
--
procedure declareExceptions(P_SCRIPT IN OUT CLOB)
as
  V_BUFFER     VARCHAR2(32000);
begin
    V_BUFFER := '  GENERIC_ERROR exception;' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '  PRAGMA EXCEPTION_INIT( GENERIC_ERROR , -31061 ); ' || C_BLANK_LINE;
    DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '  NO_MATCHING_NODES exception;' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '  PRAGMA EXCEPTION_INIT( NO_MATCHING_NODES , -64405 ); ' || C_BLANK_LINE;
    DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
end;
--
procedure addExceptionBlock(P_SCRIPT IN OUT CLOB,P_STATEMENT VARCHAR2)
as
  V_BUFFER     VARCHAR2(32000);
begin

  V_BUFFER := '  begin ' || C_NEW_LINE;
  DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

  DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(P_STATEMENT),P_STATEMENT);
     
  V_BUFFER := '  exception ' || C_NEW_LINE;
  DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  V_BUFFER := '    when GENERIC_ERROR or NO_MATCHING_NODES then' || C_NEW_LINE;
  DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  V_BUFFER := '      NULL;' || C_NEW_LINE;
  DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  V_BUFFER := '    when OTHERS then ' || C_NEW_LINE;
  DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  V_BUFFER := '      RAISE;' || C_NEW_LINE;
  DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  V_BUFFER := '  end;' || C_BLANK_LINE;
  DBMS_LOB.WRITEAPPEND(P_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

end;
--
procedure createDeleteSchemaScript(P_SCRIPT_FILE VARCHAR2, P_COMMENT VARCHAR2, P_SCHEMA_ORDERING XMLTYPE) 
as
  pragma       autonomous_transaction;
  V_BUFFER     VARCHAR2(32000);
  V_SCRIPT     CLOB;
  V_RESULT     BOOLEAN;
   
  cursor getSchemas 
  is
  select * 
    from XMLTable
         (
           xmlNamespaces
           (
              default 'http://xmlns.oracle.com/xdb/pm/registrationConfiguration'
           ),
           '/RegistrationList/Schema'
           passing P_SCHEMA_ORDERING
           columns
           SCHEMA_INDEX         FOR ORDINALITY,
           SCHEMA_LOCATION_HINT VARCHAR2(700) PATH 'SchemaLocationHint',
           REPOSITORY_PATH      VARCHAR2(700) PATH 'RepositoryPath',
           FORCE_OPTION         VARCHAR2(5)   PATH 'Force',
           ANNOTATIONS          CLOB          PATH 'Annotations'
         )
   ORDER BY SCHEMA_INDEX DESC;
begin

 	V_SCRIPT := P_COMMENT;
	
  for s in getSchemas() loop
    V_BUFFER := 'declare' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    V_BUFFER := '  V_SCHEMA_LOCATION_HINT VARCHAR2(700) := ''' || s.SCHEMA_LOCATION_HINT || '''; ' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    V_BUFFER := 'begin' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    V_BUFFER := '  DBMS_XMLSCHEMA.deleteSchema(V_SCHEMA_LOCATION_HINT,4);' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    V_BUFFER := 'end;' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    V_BUFFER := '/' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  end loop;

  if DBMS_XDB.existsResource(P_SCRIPT_FILE) then
    DBMS_XDB.deleteResource(P_SCRIPT_FILE);
  end if;
  V_RESULT := DBMS_XDB.createResource(P_SCRIPT_FILE, V_SCRIPT);
  commit;
  
end;
--
procedure setEvent(P_EVENT VARCHAR2, P_LEVEL VARCHAR2) 
as
begin
	G_EVENT_LIST.extend();
	G_EVENT_LIST(G_EVENT_LIST.last).EVENT := P_EVENT;
	G_EVENT_LIST(G_EVENT_LIST.last).LEVEL := P_LEVEL;
end;
--
procedure printSchemaRegistrationScript(P_SCRIPT_FILE VARCHAR2, P_COMMENT VARCHAR2, P_SCHEMA_ORDERING XMLTYPE, P_XMLSCHEMA_FOLDER VARCHAR2) 
as
  pragma       autonomous_transaction;
  V_BUFFER     VARCHAR2(32000);
  V_SCRIPT     CLOB;
  V_RESULT     BOOLEAN;
   
  cursor getSchemas 
  is
  select * 
    from XMLTable
         (
           xmlNamespaces
           (
              default 'http://xmlns.oracle.com/xdb/pm/registrationConfiguration'
           ),
           '/RegistrationList/Schema'
           passing P_SCHEMA_ORDERING
           columns
           SCHEMA_LOCATION_HINT VARCHAR2(700) PATH 'SchemaLocationHint',
           REPOSITORY_PATH      VARCHAR2(700) PATH 'RepositoryPath',
           FORCE_OPTION         VARCHAR2(5)   PATH 'Force',
           ANNOTATIONS          CLOB          PATH 'Annotations'
         );

  V_EVENTS                 VARCHAR2(32000);

begin
	
 	V_SCRIPT := P_COMMENT;

  V_EVENTS := '--'  || C_NEW_LINE;
  
  if (G_EVENT_LIST.count() > 0) then
    for i in G_EVENT_LIST.first .. G_EVENT_LIST.last loop
      V_EVENTS := V_EVENTS || 'alter session set events ''' || G_EVENT_LIST(i).EVENT || ' trace name context forever, level ' || G_EVENT_LIST(i).LEVEL || '''' || C_NEW_LINE;
      V_EVENTS := V_EVENTS || '/'  || C_NEW_LINE;
      V_EVENTS := V_EVENTS || '--' || C_NEW_LINE;
    end loop;
  end if;

  V_SCRIPT := V_SCRIPT || V_EVENTS;
  
  V_BUFFER := 'begin' || C_NEW_LINE;
  DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
	V_BUFFER := '  XDB_EDIT_XMLSCHEMA.getGroupDefinitions(''' || P_XMLSCHEMA_FOLDER || ''');' || C_NEW_LINE; 
  DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  V_BUFFER := 'end;' || C_NEW_LINE;
  DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  V_BUFFER := '/' || C_NEW_LINE;
  DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

  for s in getSchemas() loop
 	
    V_BUFFER := 'declare' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    
    -- declareExceptions(V_SCRIPT);

    V_BUFFER := '  V_XML_SCHEMA_PATH        VARCHAR2(700) := ''' || s.REPOSITORY_PATH || ''';' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '  V_XML_SCHEMA             XMLType       := xdburitype(V_XML_SCHEMA_PATH).getXML(); ' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);	

    V_BUFFER := '  V_SCHEMA_LOCATION_HINT   VARCHAR2(700) := ''' || s.SCHEMA_LOCATION_HINT || '''; ' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    
    V_BUFFER := 'begin' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    -- V_BUFFER := '  XDB_EDIT_XMLSCHEMA.expandRepeatingGroups(V_XML_SCHEMA);' || C_NEW_LINE;
    V_BUFFER := '  XDB_EDIT_XMLSCHEMA.expandAllGroups(V_XML_SCHEMA);' || C_BLANK_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    -- V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.addXDBNamespace(V_XML_SCHEMA);' || C_NEW_LINE;
    -- DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    if (G_OPTIONS <> DBMS_XMLSCHEMA.REGISTER_BINARYXML) then
      V_BUFFER := '  XDB_EDIT_XMLSCHEMA.mapAnyToClob(V_XML_SCHEMA);' || C_NEW_LINE;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
      V_BUFFER := '  XDB_EDIT_XMLSCHEMA.applySQLTypeMappings(V_XML_SCHEMA);' || C_NEW_LINE;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    end if;

    V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.printWarnings(FALSE);' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    
    if (G_DISABLE_DEFAULT_TABLES) then
      V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.disableDefaultTableCreation(V_XML_SCHEMA);' || C_NEW_LINE;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
     -- addExceptionBlock(V_SCRIPT,V_BUFFER);
    end if;
  
    if (G_DISABLE_DOM_FIDELITY) then
      V_BUFFER := '  DBMS_XMLSCHEMA_ANNOTATE.disableMaintainDom(V_XML_SCHEMA,FALSE);' || C_NEW_LINE;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
      -- addExceptionBlock(V_SCRIPT,V_BUFFER);
    end if;

    V_BUFFER := C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  
    if (G_REMOVE_APPINFO) then
      V_BUFFER := '  XDB_EDIT_XMLSCHEMA.removeAppInfo(V_XML_SCHEMA);' || C_NEW_LINE;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    end if;

    V_BUFFER := '  XDB_EDIT_XMLSCHEMA.fixRelativeURLs(V_XML_SCHEMA,V_SCHEMA_LOCATION_HINT);' || C_BLANK_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    if (s.ANNOTATIONS is not NULL) then
      DBMS_LOB.APPEND(V_SCRIPT,s.ANNOTATIONS);
    end if;

    V_BUFFER := '  XDB_EDIT_XMLSCHEMA.saveAnnotatedSchema(V_XML_SCHEMA_PATH, V_XML_SCHEMA);' || C_BLANK_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := 'end;' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  
    V_BUFFER := '/' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := 'declare' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '  V_XML_SCHEMA_PATH        VARCHAR2(700) := ''' || substr(s.REPOSITORY_PATH,1,instr(s.REPOSITORY_PATH,'.xsd',-1)-1) || '.xdb.xsd'';' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '  V_XML_SCHEMA             XMLType       := xdburitype(V_XML_SCHEMA_PATH).getXML(); ' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);	

    V_BUFFER := '  V_SCHEMA_LOCATION_HINT   VARCHAR2(700) := ''' || s.SCHEMA_LOCATION_HINT || '''; ' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    
    if (G_OPTIONS <> DBMS_XMLSCHEMA.REGISTER_BINARYXML) then
      V_BUFFER := '  V_REGISTRATION_TIMESTAMP TIMESTAMP; ' || C_NEW_LINE;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    end if;

    V_BUFFER := 'begin' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    if (G_OPTIONS <> DBMS_XMLSCHEMA.REGISTER_BINARYXML) then
      V_BUFFER := '  V_REGISTRATION_TIMESTAMP := SYSTIMESTAMP; ' || C_BLANK_LINE;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    end if;
    
    V_BUFFER := '  DBMS_XMLSCHEMA.registerSchema' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '  (' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '    SCHEMAURL       => V_SCHEMA_LOCATION_HINT' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '   ,SCHEMADOC       => V_XML_SCHEMA' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    if (G_LOCAL) then
      V_BUFFER := '   ,LOCAL           => '|| XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(TRUE) || C_NEW_LINE;
    else
      V_BUFFER := '   ,LOCAL           => '|| XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(FALSE) || C_NEW_LINE;
    end if;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '   ,GENTYPES        => '|| XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(G_GENTYPES) || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    V_BUFFER := '   ,GENTABLES       => '|| XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(G_GENTABLES) || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    if (s.FORCE_OPTION = 'TRUE' or G_FORCE) then
      V_BUFFER := '   ,FORCE           => '|| XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(TRUE) || C_NEW_LINE;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    end if;
  
    if (G_OWNER is not null) then
      V_BUFFER := '   ,OWNER           => ''' || G_OWNER || '''' || C_NEW_LINE;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    end if;

    if (G_ENABLE_HIERARCHY is not NULL) then
      V_BUFFER := '    ,ENABLEHIERARCHY => DBMS_XMLSCHEMA.ENABLE_HIERARCHY_INVALID' || C_NEW_LINE;
      if (G_ENABLE_HIERARCHY = DBMS_XMLSCHEMA.ENABLE_HIERARCHY_NONE) then
        V_BUFFER := '   ,ENABLEHIERARCHY => DBMS_XMLSCHEMA.ENABLE_HIERARCHY_NONE' || C_NEW_LINE;
      end if;
      if (G_ENABLE_HIERARCHY = DBMS_XMLSCHEMA.ENABLE_HIERARCHY_CONTENTS) then
        V_BUFFER := '   ,ENABLEHIERARCHY => DBMS_XMLSCHEMA.ENABLE_HIERARCHY_CONTENTS' || C_NEW_LINE;
      end if;
      if (G_ENABLE_HIERARCHY = DBMS_XMLSCHEMA.ENABLE_HIERARCHY_RESMETADATA) then
        V_BUFFER := '   ,ENABLEHIERARCHY => DBMS_XMLSCHEMA.ENABLE_HIERARCHY_RESMETADATA' || C_NEW_LINE;
      end if;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    end if;

    if (G_OPTIONS is not NULL) then
      V_BUFFER := '  ,OPTIONS       => ' || G_OPTIONS ||  C_NEW_LINE;
      if (G_OPTIONS = DBMS_XMLSCHEMA.REGISTER_NODOCID) then
        V_BUFFER := '   ,OPTIONS         => DBMS_XMLSCHEMA.REGISTER_NODOCID' || C_NEW_LINE;
      end if;
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
$ELSE   
      if (G_OPTIONS = DBMS_XMLSCHEMA.REGISTER_BINARYXML) then
        V_BUFFER := '   ,OPTIONS         => DBMS_XMLSCHEMA.REGISTER_BINARYXML' || C_NEW_LINE;
      end if;
      if (G_OPTIONS = DBMS_XMLSCHEMA.REGISTER_NT_AS_IOT) then
        V_BUFFER := '   ,OPTIONS         => DBMS_XMLSCHEMA.REGISTER_NT_AS_IOT' || C_NEW_LINE;
      end if;
$END
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    end if;

    V_BUFFER := '  );' || C_BLANK_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

    if (G_OPTIONS <> DBMS_XMLSCHEMA.REGISTER_BINARYXML) then
      V_BUFFER := '  XDB_ANALYZE_SCHEMA.deleteOrphanTypes(V_REGISTRATION_TIMESTAMP);' || C_NEW_LINE;
      DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
    end if;
    
    V_BUFFER := 'end;' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  
    V_BUFFER := '/' || C_NEW_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);

  end loop;
  
  if DBMS_XDB.existsResource(P_SCRIPT_FILE) then
    DBMS_XDB.deleteResource(P_SCRIPT_FILE);
  end if;
  V_RESULT := DBMS_XDB.createResource(P_SCRIPT_FILE, V_SCRIPT);
  commit;
end;
--
procedure schemaOrderingScript(P_OUTPUT_FOLDER VARCHAR2, P_XMLSCHEMA_FOLDER VARCHAR2, P_SCHEMA_LOCATION_PREFIX VARCHAR2, P_XMLSCHEMA_PATH VARCHAR2 DEFAULT NULL) 
--
-- Generate the Schema Ordering Script for a particular XML Schema. 
-- 
-- P_OUTPUT_FOLDER          : The target folder for all scripts and log files.
--                       
-- P_XMLSCHEMA_FOLDER       : The folder containing all the XML Schemas required to successfully register the specified XML Schema.
--
-- P_XMLSCHEMA_PATH         : The relative path (from P_XMLSCHEMA_FOLDER) to the xsd file to be registered.
--
-- P_SCHEMA_LOCATION_PREFIX : The prefix for the schema location hint to be used when registering the XML Schema. The prefix will be concatenated 
--                            with the value of P_XMLSCHEMA_PATH to create the schema location hint. 
--                            
as
  V_SCHEMA_ORDERING        XMLTYPE;
  V_SCHEMA_FILE            VARCHAR2(700);
  V_SCHEMA_NAME            VARCHAR2(700);
  V_SCRIPT_FILE            VARCHAR2(700);
  V_TRACE_FILE             VARCHAR2(700);
  V_CONFIGURATION_FILE     VARCHAR2(700);
  V_COMMENT                VARCHAR2(4000);
  V_RESULT                 BOOLEAN;
begin

	if (P_XMLSCHEMA_PATH is NULL) then
	  V_SCHEMA_NAME := P_XMLSCHEMA_FOLDER;
  else
    --
    -- Assume Schema Path ends in ".xsd"
    --
    V_SCHEMA_NAME := P_XMLSCHEMA_PATH;
    V_SCHEMA_NAME := substr(V_SCHEMA_NAME,1,instr(V_SCHEMA_NAME,'.',-1)-1);
  end if;

  if instr(V_SCHEMA_NAME,'/',-1) > 1 then
	  V_SCHEMA_NAME := substr(V_SCHEMA_NAME,instr(V_SCHEMA_NAME,'/',-1)+1);
	end if;

  V_TRACE_FILE         := P_OUTPUT_FOLDER || '/' || V_SCHEMA_NAME || '.log';
  V_SCRIPT_FILE        := P_OUTPUT_FOLDER || '/' || V_SCHEMA_NAME || '.sql';
  V_CONFIGURATION_FILE := P_OUTPUT_FOLDER || '/' || V_SCHEMA_NAME || '.xml';
  
	XDB_OUTPUT.createOutputFile(V_TRACE_FILE,true);

  if (P_XMLSCHEMA_PATH is not null) then
    V_SCHEMA_ORDERING := orderSchemas(P_XMLSCHEMA_FOLDER, P_XMLSCHEMA_PATH, P_SCHEMA_LOCATION_PREFIX);
  else
    V_SCHEMA_ORDERING := orderSchemas(P_XMLSCHEMA_FOLDER, P_SCHEMA_LOCATION_PREFIX);
  end if;

  if DBMS_XDB.existsResource(V_CONFIGURATION_FILE) then
    DBMS_XDB.deleteResource(V_CONFIGURATION_FILE);
  end if;
  
  V_RESULT := DBMS_XDB.createResource(V_CONFIGURATION_FILE,V_SCHEMA_ORDERING); 
  commit;
  
  if (P_XMLSCHEMA_PATH is NULL) then
    V_COMMENT :=  '--' ||  C_NEW_LINE || '-- Schema Registration Script for folder "' || P_XMLSCHEMA_FOLDER || C_NEW_LINE || '--' || C_NEW_LINE;
  else
    V_COMMENT :=  '--' ||  C_NEW_LINE || '-- Schema Registration Script for XMLSchema "' || P_XMLSCHEMA_FOLDER || '/' || P_XMLSCHEMA_PATH || C_NEW_LINE || '--' || C_NEW_LINE;
  end if;

  printSchemaRegistrationScript(V_SCRIPT_FILE, V_COMMENT, V_SCHEMA_ORDERING, P_XMLSCHEMA_FOLDER);	

end;
--
procedure schemaRegistrationScript(P_OUTPUT_FOLDER VARCHAR2, P_XMLSCHEMA_FOLDER VARCHAR2, P_CONFIGURATION XMLType, P_SCHEMA_LOCATION_HINT VARCHAR2 DEFAULT NULL, P_OWNER VARCHAR2 DEFAULT USER, P_LIMIT NUMBER DEFAULT 3)
as
  V_SUCCESS                VARCHAR2(10);
  V_TARGET_LOCATION        VARCHAR2(700);
  V_SCHEMA_NAME            VARCHAR2(256);
  V_SCHEMA_ORDERING        XMLTYPE;
  V_DEL_COMMENT            VARCHAR2(4000);
  V_REG_COMMENT            VARCHAR2(4000);
  V_RESULT                 BOOLEAN;

  V_TRACE_FILE             VARCHAR2(700);
  V_SCRIPT_FILE            VARCHAR2(700);
  V_CONFIGURATION_FILE     VARCHAR2(700);
  V_DELETE_SCRIPT_FILE     VARCHAR2(700);
  V_TYPE_ANALYSIS_FILE     VARCHAR2(700);
begin
	
	if (P_SCHEMA_LOCATION_HINT is NULL) then
	  V_SCHEMA_NAME     := P_XMLSCHEMA_FOLDER;
    V_TARGET_LOCATION := P_XMLSCHEMA_FOLDER;
    V_DEL_COMMENT     :=  '--' ||  C_NEW_LINE || '-- Schema Deletion Script for XML Schemas in "' || V_TARGET_LOCATION || '" --' || C_NEW_LINE || '--' || C_NEW_LINE;
    V_REG_COMMENT     :=  '--' ||  C_NEW_LINE || '-- Schema Registration Script for XML Schemas in "' || V_TARGET_LOCATION || '" --' || C_NEW_LINE || '--' || C_NEW_LINE;
  else
    --
    -- Assume Schema Location Hint ends in ".xsd"
    --
    V_SCHEMA_NAME     := substr(P_SCHEMA_LOCATION_HINT,1,instr(P_SCHEMA_LOCATION_HINT,'.',-1)-1);
    V_TARGET_LOCATION := P_SCHEMA_LOCATION_HINT;
    V_DEL_COMMENT     :=  '--' ||  C_NEW_LINE || '-- Schema Deletion Script for XML Schema "' || V_TARGET_LOCATION || '" --' || C_NEW_LINE || '--' || C_NEW_LINE;
    V_REG_COMMENT     :=  '--' ||  C_NEW_LINE || '-- Schmea Registration Script for XML Schema "' || V_TARGET_LOCATION || '" --' || C_NEW_LINE || '--' || C_NEW_LINE;
  end if;

  if instr(V_SCHEMA_NAME,'/',-1) > 1 then
	  V_SCHEMA_NAME := substr(V_SCHEMA_NAME,instr(V_SCHEMA_NAME,'/',-1)+1);
	end if;
  
  V_TRACE_FILE         := P_OUTPUT_FOLDER || '/' || V_SCHEMA_NAME || '.log';
  V_SCRIPT_FILE        := P_OUTPUT_FOLDER || '/' || V_SCHEMA_NAME || '.sql';
  V_CONFIGURATION_FILE := P_OUTPUT_FOLDER || '/' || V_SCHEMA_NAME || '.xml';
  V_DELETE_SCRIPT_FILE := P_OUTPUT_FOLDER || '/deleteSchemas.sql';
  V_TYPE_ANALYSIS_FILE := P_OUTPUT_FOLDER || '/typeAnalysis.log';

	V_SCHEMA_ORDERING := P_CONFIGURATION;

  if DBMS_XDB.existsResource(V_DELETE_SCRIPT_FILE) then
    DBMS_XDB.deleteResource(V_DELETE_SCRIPT_FILE);
    commit;
  end if;

  if DBMS_XDB.existsResource(V_TYPE_ANALYSIS_FILE) then
    DBMS_XDB.deleteResource(V_TYPE_ANALYSIS_FILE);
    commit;
  end if;
	
  if DBMS_XDB.existsResource(V_CONFIGURATION_FILE) then
    DBMS_XDB.deleteResource(V_CONFIGURATION_FILE);
    commit;
  end if;
	
	createDeleteSchemaScript( V_DELETE_SCRIPT_FILE , V_DEL_COMMENT, V_SCHEMA_ORDERING);
  commit;

  V_SUCCESS := doTypeAnalysis(V_TYPE_ANALYSIS_FILE, V_TARGET_LOCATION, V_SCHEMA_ORDERING, P_SCHEMA_LOCATION_HINT, P_OWNER, P_LIMIT);
  commit;

  V_RESULT  := DBMS_XDB.createResource(V_CONFIGURATION_FILE,V_SCHEMA_ORDERING); 
  commit;
  
  printSchemaRegistrationScript(V_SCRIPT_FILE, V_REG_COMMENT, V_SCHEMA_ORDERING, P_XMLSCHEMA_FOLDER);	
  commit;

end;
--
procedure tableCreationScript(P_OUTPUT_FOLDER VARCHAR2, P_TARGET_NAMESPACE VARCHAR2)
as
--
  pragma       autonomous_transaction;

  TYPE T_XML_TABLE_LIST 
       IS TABLE OF VARCHAR2(32) 
       INDEX BY VARCHAR2(32);
       
  V_XML_TABLE_LIST T_XML_TABLE_LIST;

  V_NEW_TABLE_NAME VARCHAR2(32);
  V_COUNTER        NUMBER(2);
  
  V_BUFFER     VARCHAR2(32000);
  V_SCRIPT     CLOB;
  V_RESULT     BOOLEAN;
  
  V_XQUERY     CLOB := 
  
' declare namespace xdbpm = "http://xmlns.oracle.com/xdb/xdbpm"; 
  declare namespace xdb = "http://xmlns.oracle.com/xdb";
             
  declare function xdbpm:qname-to-string ( $qname as xs:string, $context as node() ) 
          as xs:string
  { 
    let $qn := fn:resolve-QName( $qname, $context)
    return concat(fn:local-name-from-QName($qn),":",fn:namespace-uri-from-QName($qn))
  }; 
  
  declare function xdbpm:global-elements ( $schemaList as  node() *,  $complexTypeList as  xs:string*) 
       as xs:string*
  {           
     let $elementList := for $schema in $schemaList/SCHEMA/xs:schema
                           for $element in $schema/xs:element[not(@substitutionGroup) and not(@abstract="true") and not(xs:simpleType)]
                             where (($element/@type and (xdbpm:qname-to-string($element/@type,$element) = $complexTypeList)) or $element/xs:complexType)
                     	     return if ($schema/@targetNamespace) then
  		                         concat($element/@name,":",$schema/@targetNamespace)
  		                       else
  		                         concat($element/@name,":")
     let $elementList := fn:distinct-values($elementList)
     return $elementList
  }; 
                      
  declare function xdbpm:ref-elements ( $schemaList as  node() * ) 
       as xs:string*
  {           
    let $refElementList := for $e in $schemaList/SCHEMA//xs:element[@ref]
                               return xdbpm:qname-to-string($e/@ref,$e)
    let $refElementList := fn:distinct-values($refElementList)
    return $refElementList
  }; 
  
  declare function xdbpm:getSchemaElement( $schemaList as node()*, $e as xs:string) as node()
  {
    if (fn:substring-after($e,":") = "") then 
      for $sch in $schemaList/SCHEMA/xs:schema[not(@targetNamespace) and xs:element[@name=fn:substring-before($e,":")]]
        return <Table>
                 <SCHEMA_URL>{fn:data($sch/@xdb:schemaURL)}</SCHEMA_URL>,
                 <ELEMENT>{fn:substring-before($e,":")}</ELEMENT>
               </Table>
    else
      for $sch in $schemaList/SCHEMA/xs:schema[@targetNamespace=fn:substring-after($e,":") and xs:element[@name=fn:substring-before($e,":")]]
        return <Table>
                 <SCHEMA_URL>{fn:data($sch/@xdb:schemaURL)}</SCHEMA_URL>,
                 <NAMESPACE>{fn:data($sch/@targetNamespace)}</NAMESPACE>
                 <ELEMENT>{fn:substring-before($e,":")}</ELEMENT>
               </Table>
  };

  let $schemaList := fn:collection("oradb:/PUBLIC/USER_XML_SCHEMAS")/ROW                  

  let $complexTypeList := for $schema in $schemaList/SCHEMA/xs:schema
                            for $ct in $schema/xs:complexType                          
                              return if ($schema/@targetNamespace) then
  		                                 concat($ct/@name,":",$schema/@targetNamespace)
  		                               else
  		                                concat($ct/@name,":")
  		                                                              
  let $globalElements := xdbpm:global-elements($schemaList,$complexTypeList)

  let $refs := xdbpm:ref-elements($schemaList)
  for $e in $globalElements
    where not ($e = $refs) 
    return xdbpm:getSchemaElement($schemaList, $e)';
             
  V_SCRIPT_FILE  VARCHAR2(700) := P_OUTPUT_FOLDER || '/doTableCreation.sql';

  cursor getElements
  is
  select /*+ NO_XML_QUERY_REWRITE */
         SCHEMA_URL, ELEMENT
    from XMLTable
         (
           V_XQUERY
           COLUMNS 
           SCHEMA_URL   VARCHAR2(700),
           ELEMENT      VARCHAR2(256),
           NAMESPACE    VARCHAR2(700)
         )
   where (P_TARGET_NAMESPACE is not null and NAMESPACE like P_TARGET_NAMESPACE)
       or
         (P_TARGET_NAMESPACE is null and NAMESPACE is null)
   order by NAMESPACE, SCHEMA_URL, ELEMENT;
           
  V_SQLCODE NUMBER;
  V_SQLERRM VARCHAR2(4000);

begin
	
	for c in 
	(
	  select TABLE_NAME 
	    from USER_XML_TABLES
	) loop 
	  V_XML_TABLE_LIST(c.TABLE_NAME) := c.TABLE_NAME;
  end loop;

  if DBMS_XDB.existsResource(V_SCRIPT_FILE) then
    DBMS_XDB.deleteResource(V_SCRIPT_FILE);
    commit;
  end if;

  V_SCRIPT := '-- Table creation for namespace "' || P_TARGET_NAMESPACE || '"' || C_BLANK_LINE;
    
  for t in getElements loop
    V_NEW_TABLE_NAME := UPPER(SUBSTR(t.ELEMENT,1,24)) || '_TABLE';

    V_COUNTER := 0;    
    while (V_XML_TABLE_LIST.exists(V_NEW_TABLE_NAME)) loop
	    V_COUNTER := V_COUNTER + 1;
	    V_NEW_TABLE_NAME := SUBSTR(UPPER(t.ELEMENT),1,21) || '_' || LPAD(V_COUNTER,2,'0') || '_TABLE';
	  end loop;

    V_XML_TABLE_LIST(V_NEW_TABLE_NAME) := V_NEW_TABLE_NAME;

    V_BUFFER := 'CREATE TABLE "' || V_NEW_TABLE_NAME || '" of XMLTYPE'  || C_NEW_LINE;
    if (G_OPTIONS = DBMS_XMLSCHEMA.REGISTER_BINARYXML) then
      V_BUFFER := V_BUFFER || 'XMLTYPE STORE AS SECUREFILE BINARY XML' || C_NEW_LINE;
    else
      V_BUFFER := V_BUFFER || 'XMLTYPE STORE AS OBJECT RELATIONAL' || C_NEW_LINE;
    end if;
    V_BUFFER := V_BUFFER || 'XMLSCHEMA "' || t.SCHEMA_URL || '" ELEMENT "' || t.ELEMENT || '"' || C_NEW_LINE;
    V_BUFFER := V_BUFFER || '/'||  C_BLANK_LINE;
    DBMS_LOB.WRITEAPPEND(V_SCRIPT,LENGTH(V_BUFFER),V_BUFFER);
  end loop;

  V_RESULT  := DBMS_XDB.createResource(V_SCRIPT_FILE,V_SCRIPT); 
  commit;
end;          
--
procedure deleteOrphanTypes(P_REGISTRATION_DATE TIMESTAMP)
as
  cursor getOrphanTypes 
  is
  select OBJECT_NAME 
    from USER_OBJECTS
   where OBJECT_TYPE = 'TYPE'
     and to_timestamp(TIMESTAMP,'YYYY-MM-DD:HH24:MI:SS') > P_REGISTRATION_DATE
     and not exists
         (
           select 1
             from XDB.XDB$COMPLEX_TYPE ct, XDB.XDB$SCHEMA s
            where ct.XMLDATA.SQLTYPE = OBJECT_NAME
              and ref(s) = ct.XMLDATA.PARENT_SCHEMA 
              and s.XMLDATA.SCHEMA_OWNER = USER           
            union all
           select 1
             from XDB.XDB$ELEMENT e, XDB.XDB$SCHEMA s
            where e.XMLDATA.PROPERTY.SQLCOLLTYPE = OBJECT_NAME
              and ref(s) = e.XMLDATA.PROPERTY.PARENT_SCHEMA 
              and s.XMLDATA.SCHEMA_OWNER = USER     
         );
begin
	for t in getOrphanTypes loop
	  execute immediate 'drop type "' || t.OBJECT_NAME || '" force';
	end loop;
end;
--
function XMLSCHEMA_WIZARD_ORDER_SCHEMAS(
           P_ROOT_XMLSCHEMA VARCHAR2, 
           P_XMLSCHEMA_FOLDER VARCHAR2, 
           P_SCHEMA_LOCATION_PREFIX VARCHAR2
         ) 
return XMLType
as
begin
  return orderSchemas(P_XMLSCHEMA_FOLDER,P_ROOT_XMLSCHEMA,P_SCHEMA_LOCATION_PREFIX);
end;
--
function XMLSCHEMA_WIZARD_TYPE_ANALYSIS(           
           P_CONFIGURATION           IN OUT XMLTYPE, 
           P_LOGFILE_PATH                   VARCHAR2,       
           P_SCHEMA_LOCATION_HINT           VARCHAR2,  
           P_OWNER                          VARCHAR2       DEFAULT USER
         )
return VARCHAR2
as
begin
  return doTypeAnalysis(P_LOGFILE_PATH,P_SCHEMA_LOCATION_HINT,P_CONFIGURATION,P_SCHEMA_LOCATION_HINT,P_OWNER);
end;	
--
begin
	G_EVENT_LIST := EVENT_LIST_T();
end XDBPM_ANALYZE_XMLSCHEMA;
/
show errors
--
grant execute on XDBPM_ANALYZE_XMLSCHEMA to public
/