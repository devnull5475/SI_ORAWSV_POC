--
-- Find the name of the PATH TABLE
--
alter session set current_schema = XDBPM
/
var pathTableName varchar2(34)
--
declare
  V_PATH_TABLE_NAME varchar2(34);
begin
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
  V_PATH_TABLE_NAME := 'XDB.XDB$PATH_ID';
$ELSE
  V_PATH_TABLE_NAME := DBMS_CSX_ADMIN.pathIdtable();
$END
  :pathTableName := V_PATH_TABLE_NAME;
end;
/
undef pathTableName
--
column PATH_TABLE_NAME new_value pathTableName
--
select :pathTableName PATH_TABLE_NAME from dual
/
def pathTableName
--
alter session set current_schema = SYS
/
--
set define on
--
grant all on &pathTableName         to XDBPM
/
alter session set current_schema = SYS
/
--