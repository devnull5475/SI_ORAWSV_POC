--
-- XDBPM_DEBUG should be created under XDBPM
--
alter session set current_schema = XDBPM
/
create or replace package XDBPM_DEBUG
authid CURRENT_USER
as
  function TRACE_FOLDER return VARCHAR2;
  function DEBUG_FILE return VARCHAR2;

  procedure saveTraceFile;
 
  procedure createDebugFile;
  procedure switchDebugOutputFile;
  procedure writeDebug(P_LOG_MESSAGE VARCHAR2);
  procedure writeDebug(P_LOG_MESSAGE CLOB);
  procedure writeDebug(P_XML XMLType);

  function getDebugOutput return CLOB;
  
  function getTraceFileContents return CLOB;
  
  procedure startRewriteTrace(P_COMMENT VARCHAR2);
  function getRewriteTrace return XMLType;  
  
  function getXQueryOptimizationTrace return CLOB;
  
end;
/
show errors
--
create or replace synonym XDB_DEBUG for XDBPM_DEBUG
/
grant execute on XDBPM_DEBUG to public
/
create or replace package body XDBPM_DEBUG
as
--  
  not_current_owner exception;
  PRAGMA EXCEPTION_INIT( not_current_owner , -31003 );

  G_WRITE_TO_TRACE_FILE constant binary_integer := 1;

  G_DEBUG_SEQUENCE_ID NUMBER := 1;
  G_CURRENT_TIMESTAMP TIMESTAMP;

  G_TRACE_FOLDER  VARCHAR2(128) := XDB_CONSTANTS.FOLDER_USER_DEBUG || '/traceFiles';
  G_DEBUG_FILE    VARCHAR2(700) := XDB_CONSTANTS.FOLDER_USER_DEBUG || '/logFiles/' || to_char(systimestamp,'YYYY-MM-DD') || '.' || lpad(XDBPM_HELPER.getSessionID(),6,'0') || '.' || lpad(G_DEBUG_SEQUENCE_ID,6,'0') || '.txt';
--
function DEBUG_FILE
return VARCHAR2
as
begin
  return G_DEBUG_FILE;
end;
--
function TRACE_FOLDER 
return VARCHAR2
as 
begin
  return G_TRACE_FOLDER;
end;
--
function CURRENT_TIMESTAMP
return timestamp
as
begin
  return G_CURRENT_TIMESTAMP;
end;
--
procedure createDebugFolders
as
  pragma autonomous_transaction;
begin
  XDB_HELPER.createDebugFolders(XDB_USERNAME.GET_USERNAME());
  commit;
end;
--
procedure createDebugFile
as 
  pragma autonomous_transaction;
  V_RESULT BOOLEAN;
begin
  if (not dbms_xdb.existsResource(G_DEBUG_FILE)) then
    V_RESULT := dbms_xdb.createResource(G_DEBUG_FILE,to_char(systimestamp,'YYYY-MM-DD"T"HH24:MI:SS.FF') || ' : Trace File Created.');
    G_DEBUG_SEQUENCE_ID := G_DEBUG_SEQUENCE_ID + 1;
    commit;
  end if;  
end;
--
procedure switchDebugOutputFile
as 
  V_RESULT BOOLEAN;
begin
  G_DEBUG_FILE := XDB_CONSTANTS.FOLDER_USER_DEBUG || '/logFiles/' || to_char(systimestamp,'YYYY-MM-DD') || '.' || lpad(XDB_HELPER.getSessionID(),6,'0') || '.' || lpad(G_DEBUG_SEQUENCE_ID,6,'0') || '.txt';
  createDebugFile();
end;
--
procedure writeDebug(P_LOG_MESSAGE VARCHAR2)
as
  V_LOG_MESSAGE CLOB;
  V_TIMESTAMP_INFO VARCHAR2(1024) := chr(13) || chr(10) || to_char(systimestamp,'YYYY-MM-DD"T"HH24:MI:SS.FF') || ' :';
begin
	 
  createDebugFile();

  dbms_lob.createTemporary(V_LOG_MESSAGE,true);
  DBMS_LOB.WRITEAPPEND(V_LOG_MESSAGE,LENGTH(V_TIMESTAMP_INFO),V_TIMESTAMP_INFO);
  DBMS_LOB.WRITEAPPEND(V_LOG_MESSAGE,LENGTH(P_LOG_MESSAGE),P_LOG_MESSAGE);
  XDB_OUTPUT.writeToFile(G_DEBUG_FILE,V_LOG_MESSAGE);

end;
--
procedure writeDebug(P_LOG_MESSAGE CLOB)
as
  V_LOG_MESSAGE CLOB;
  V_TIMESTAMP_INFO VARCHAR2(1024) := chr(13) || chr(10) || to_char(systimestamp,'YYYY-MM-DD"T"HH24:MI:SS.FF') || ' :' || chr(13) || chr(10);
begin
	 
  createDebugFile();

  dbms_lob.createTemporary(V_LOG_MESSAGE,true);
  DBMS_LOB.WRITEAPPEND(V_LOG_MESSAGE,LENGTH(V_TIMESTAMP_INFO),V_TIMESTAMP_INFO);
  dbms_lob.append(V_LOG_MESSAGE,P_LOG_MESSAGE);
  XDB_OUTPUT.writeToFile(G_DEBUG_FILE,V_LOG_MESSAGE);

end;
--
procedure writeDebug(P_XML XMLType)
as
  V_SERIALIZED_XML CLOB;
begin
$IF DBMS_DB_VERSION.VER_LE_10_2 $THEN
  select P_XML.getClobVal()
    into V_SERIALIZED_XML
    from DUAL;
$ELSE
  select XMLSERIALIZE(DOCUMENT P_XML AS CLOB INDENT SIZE = 2)
    into V_SERIALIZED_XML
    from DUAL;
$END 

  writeDebug(V_SERIALIZED_XML);	 
end;
--
function getDebugOutput
return CLOB
as
begin
  return xdburitype(G_DEBUG_FILE).getCLOB();
end;
--
procedure saveTraceFile
as
  pragma autonomous_transaction;
  V_RESULT              BOOLEAN;
  V_TRACE_FILE_PATH     VARCHAR2(255);
  V_TRACE_FILE_CONTENTS CLOB;
begin
  V_TRACE_FILE_CONTENTS := XDBPM_HELPER.getTraceFileContents();
  V_TRACE_FILE_PATH := TRACE_FOLDER || '/' || XDBPM_HELPER.getTraceFileName();
  if (dbms_xdb.existsResource(V_TRACE_FILE_PATH)) then
    dbms_xdb.deleteResource(V_TRACE_FILE_PATH);
  end if;
  V_RESULT := dbms_xdb.createResource(V_TRACE_FILE_PATH,V_TRACE_FILE_CONTENTS);
  dbms_lob.freeTemporary(V_TRACE_FILE_CONTENTS);
  commit;
end;
--
procedure startRewriteTrace(P_COMMENT VARCHAR2) 
as
  pragma autonomous_transaction;
  V_MESSAGE VARCHAR2(4000);
begin
  G_CURRENT_TIMESTAMP := systimestamp;
  V_MESSAGE := '<xdbpm:XQUERY_REWRITE xmlns:xdbpm="http://xmlns.oracle.com/xdbpm" timestamp="' || to_char(G_CURRENT_TIMESTAMP,'YYYY-MM-DD"T"HH24:MI:SS.FF') || '" comment="' || P_COMMENT || '"><![CDATA[';
  sys.dbms_system.KSDWRT(G_WRITE_TO_TRACE_FILE,V_MESSAGE);
  execute immediate 'alter session set events =''19021 trace name context forever, level 0x1000''';
  execute immediate 'alter session set events =''19027 trace name context forever, level 0x2000''';
end;
--
procedure endRewriteTrace
as
  V_MESSAGE VARCHAR2(4000);
begin
  V_MESSAGE := ']]></xdbpm:XQUERY_REWRITE>';
  sys.dbms_system.KSDWRT(G_WRITE_TO_TRACE_FILE,V_MESSAGE);
  sys.dbms_system.KSDFLS();
  execute immediate 'alter session set events =''19021 trace name context off''';
end;
--
function getRewriteTrace(P_STATEMENT_TIMESTAMP TIMESTAMP)
return XMLType
as
  pragma autonomous_transaction;
  V_START_STATEMENT VARCHAR2(4000) := '<xdbpm:XQUERY_REWRITE xmlns:xdbpm="http://xmlns.oracle.com/xdbpm" timestamp="' || to_char(P_STATEMENT_TIMESTAMP,'YYYY-MM-DD"T"HH24:MI:SS.FF') || '"';
  V_END_STATEMENT   VARCHAR2(4000) := '</xdbpm:XQUERY_REWRITE>';
  V_TRACE_FILE      CLOB;
  V_START_OFFSET    NUMBER;
  V_END_OFFSET      NUMBER;
  V_STATEMENT_TEXT  CLOB;
  V_STATEMENT_TRACE XMLTYPE;
begin
  endRewriteTrace();
  dbms_lob.createTemporary(V_STATEMENT_TEXT,TRUE,dbms_lob.session);
  V_TRACE_FILE := XDBPM_HELPER.getTraceFileContents();
  V_START_OFFSET := dbms_lob.instr(V_TRACE_FILE,V_START_STATEMENT);
  V_END_OFFSET := dbms_lob.instr(V_TRACE_FILE,V_END_STATEMENT,V_START_OFFSET) + length(V_END_STATEMENT);
  dbms_lob.copy(V_STATEMENT_TEXT,V_TRACE_FILE,V_END_OFFSET - V_START_OFFSET,1,V_START_OFFSET);
  V_STATEMENT_TRACE := XMLType(V_STATEMENT_TEXT);
  dbms_lob.freeTemporary(V_STATEMENT_TEXT);
  dbms_lob.freeTemporary(V_TRACE_FILE);
  return V_STATEMENT_TRACE;  
end;
--
function getRewriteTrace
return XMLType
as
begin
  return getRewriteTrace(CURRENT_TIMESTAMP);
end;
--
function getTraceFileContents
return CLOB
as
begin
	return XDBPM_HELPER.getTraceFileContents();
end;
--
function getXQueryOptimizationTrace
return CLOB
as
  V_BEGIN_DIAGNOSTIC VARCHAR2(128) := 'XML Performance Diagnosis:';
  V_END_DIAGNOSTIC   VARCHAR2(128) := '===============================================================================';
  
  V_TRACE_FILE       CLOB;
  V_START_OFFSET     NUMBER;
  V_END_OFFSET       NUMBER;
  V_DIAGNOSTIC_TRACE CLOB;
begin
  dbms_lob.createTemporary(V_DIAGNOSTIC_TRACE,TRUE,dbms_lob.session);
  V_TRACE_FILE := XDBPM_HELPER.getTraceFileContents();

  V_START_OFFSET := dbms_lob.instr(V_TRACE_FILE,V_BEGIN_DIAGNOSTIC);
  while (V_START_OFFSET > 0) loop
    V_END_OFFSET := dbms_lob.instr(V_TRACE_FILE,V_END_DIAGNOSTIC,V_START_OFFSET) + length(V_END_DIAGNOSTIC);
    dbms_lob.copy(V_DIAGNOSTIC_TRACE,V_TRACE_FILE,V_END_OFFSET - V_START_OFFSET,1,V_START_OFFSET);
    V_START_OFFSET := dbms_lob.instr(V_TRACE_FILE,V_BEGIN_DIAGNOSTIC,V_END_OFFSET);
  end loop;
  
  dbms_lob.freeTemporary(V_TRACE_FILE);
  return V_DIAGNOSTIC_TRACE;  
end;
--
begin
  createDebugFolders();
end;
/
show errors
--
alter session set current_schema = SYS
/
--