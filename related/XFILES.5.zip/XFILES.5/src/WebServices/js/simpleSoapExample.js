var currentWSDL;
var queryServiceWSDL;

var WebServicesXSL;
var TableFormatterXSL
var SimpleInputFormXSL

function displayWSDL(response) {

  currentWSDL = new xmlDocument(response.responseXML);
	prettyPrintXML(currentWSDL,'d_wsdl');

}
  
function displayRequest(request) {

	prettyPrintXML(request,'d_request');

}

function checkSuccess(soapResponse) {

  var nodeList = soapResponse.selectNodes("/soap:Envelope/soap:Body/soap:Fault",orawsvNamespaces );
  if (nodeList.length > 0 ) {
  	return false;
	}
  
  return true;
 
}

function displayResults(mgr) {

  try {	
  	var soapResponse = mgr.getSoapResponse('simpleSoapExamples.displayResults');
	  prettyPrintXML(soapResponse,'d_response');
	  if (checkSuccess(soapResponse)) {
  	  formatResults(soapResponse,'d_results');
	    showResults();
  	}
	  else {
		  showResponse();
    }
  } 
  catch (e) {
    handleException('simpleSoapExample.displayResults',e,null);
  }

}

function displayResponse(mgr) {
	
	try {	
    var soapResponse = mgr.getSoapResponse('simpleSoapExamples.displayResponse');
	  prettyPrintXML(soapResponse,'d_response');
	  showResponse();
  } 
  catch (e) {
    handleException('simpleSoapExample.displayResults',e,null);
  }

}

function invokeQuery(SQLQUERY) {

  try {
    var mgr = new soapRequestManager("XDB","ORAWSV","SQL",wsManager);
    var ajaxControl = mgr.createPostRequest();
    ajaxControl.onreadystatechange=function() { if( ajaxControl.readyState==4 ) { displayResults(mgr)}};
    mgr.executeSQL(SQLQUERY.value);
    displayRequest(wsManager.getRequestXML());
  } 
  catch (e) {
    handleException('simpleSoapExample.invokeQuery',e,null);
  }
  
}

function callWS(form) {  

  var schema = null;
  var package = null;
  var method = null;
  
  try {
    schema  = document.getElementById("ownerList").value;
    
    if (document.getElementById("procedureList").disabled) {
    	package = document.getElementById("packageList").value;
    	method = document.getElementById("methodList").value;
    }
    else {
    	package = document.getElementById("procedureList").value;
    }
  
    document.getElementById('d_results').innerHTML = "";
	
  
    var mgr = new soapRequestManager(schema,package,method,wsManager);  	
  	var ajaxControl = mgr.createPostRequest();
    ajaxControl.onreadystatechange=function() { if( ajaxControl.readyState==4 ) { displayResponse(mgr)}};

	  parameters = new Object;
	  xparameters = new Object;
	  
    for ( i=4; i<form.elements.length-1; i++)
    {
    	parameters[form.elements[i].name] = form.elements[i].value;
    }

    mgr.sendSoapRequest(parameters,xparameters);   
    displayRequest(wsManager.getRequestXML());
  } 
  catch (e) {
    handleException('simpleSoapExample.callWS',e,null);
  }

}

function generateFormFromWSDL(response) {

   currentWSDL = new xmlDocument(response.responseXML);  
   prettyPrintXML(currentWSDL,'d_wsdl');
   transformXML(document.getElementById('d_inputForm'),currentWSDL,SimpleInputFormXSL);

}

function getTargetWSDL(url) {

  var ajaxControl = httpMgr.createGetRequest(url);
  ajaxControl.onreadystatechange=function() { if( ajaxControl.readyState==4 ) { generateFormFromWSDL(ajaxControl)}};
  ajaxControl.send();
}

function loadWebServicesXSL() {
  WebServicesXSL = loadXSLDocument("/XFILES/WebServices/xsl/webServices.xsl");
}

function loadSimpleInputFormXSL() {
  SimpleInputFormXSL = loadXSLDocument("/XFILES/WebServices/xsl/simpleInputForm.xsl");
}

function loadTableFormatterXSL() {
  TableFormatterXSL = loadXSLDocument("/XFILES/WebDemo/xsl/formatResponse.xsl");
}

function loadQueryServiceWSDL() {
  queryServiceWSDL = loadXMLDocument("/orawsv?wsdl");
}

function onPageLoaded() {

  showQuery();
  
  document.getElementById("ownerList").disabled = true;
  document.getElementById("procedureList").disabled = true;
  document.getElementById("packageList").disabled = true;
  document.getElementById("methodList").disabled = true;


  prettyPrintXML(queryServiceWSDL,'d_wsdl');
  getOwnerList();
  viewXML = doViewXML;
}

function init(target) {

  try { 
    initCommon();
    loadWebServicesXSL();
    loadTableFormatterXSL();
    loadSimpleInputFormXSL();
    loadQueryServiceWSDL();
    loadOracleWebServiceNamespaces();
  
    resourceXML = getResourceXML("/XFILES/WebServices");
    transformXML(target,resourceXML,WebServicesXSL);

	  setPageActive();
  } 
  catch (e) {
    handleException('simpleSoapExample.init',e,null);
  }
 
}

function doViewXML() {
	
	closePopupDialog();
	showSourceCode(currentWSDL);
	
}
