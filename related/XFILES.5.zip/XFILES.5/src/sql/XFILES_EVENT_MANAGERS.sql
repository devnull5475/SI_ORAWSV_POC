--
--  Event manager for XFiles Authentication Events. 
--  Generates a document that indicates whether or not the current HTTP session is authenticated or not
--
create or replace package XFILES_AUTHENTICATION_EVENTS
as
  procedure handleRender(P_EVENT dbms_xevent.XDBRepositoryEvent);
end;
/
show errors
--
create or replace package body XFILES_AUTHENTICATION_EVENTS
as    
-- 
procedure handleRender(P_EVENT dbms_xevent.XDBRepositoryEvent)
as
  V_CHARSET_ID NUMBER(4);
begin
  select NLS_CHARSET_ID(VALUE)
    into V_CHARSET_ID
    from NLS_DATABASE_PARAMETERS
   where PARAMETER = 'NLS_CHARACTERSET';
   
  if (DBMS_XEVENT.GETCURRENTUSER(DBMS_XEVENT.GETXDBEVENT(P_EVENT)) = 'ANONYMOUS') then
    DBMS_XEVENT.setRenderStream(P_EVENT,XMLTYPE('<Authenticated>0</Authenticated>').getBlobVal(V_CHARSET_ID));    
  else
    DBMS_XEVENT.setRenderStream(P_EVENT,XMLTYPE('<Authenticated>1</Authenticated>').getBlobVal(V_CHARSET_ID));    
  end if;
end;   
--
end;
/
show errors
--
grant execute on XFILES_AUTHENTICATION_EVENTS to public
/
--
--  Event manager for XFiles WhoAmI Events. 
--  Generates a document that shows the username for the current HTTP session.
--
create or replace package XFILES_WHOAMI_EVENTS
as
  procedure handleRender(P_EVENT dbms_xevent.XDBRepositoryEvent);
end;
/
show errors
--
create or replace package body XFILES_WHOAMI_EVENTS
as    
-- 
procedure handleRender(P_EVENT dbms_xevent.XDBRepositoryEvent)
as
  V_CHARSET_ID NUMBER(4);
begin
  select NLS_CHARSET_ID(VALUE)
    into V_CHARSET_ID
    from NLS_DATABASE_PARAMETERS
   where PARAMETER = 'NLS_CHARACTERSET';
   
  DBMS_XEVENT.setRenderStream(P_EVENT,XMLTYPE('<CurrentUser>' || DBMS_XEVENT.GETCURRENTUSER(DBMS_XEVENT.GETXDBEVENT(P_EVENT)) ||'</CurrentUser>').getBlobVal(V_CHARSET_ID));    
end;   
--
end;
/
show errors
--
grant execute on XFILES_WHOAMI_EVENTS to public
/
--
create or replace package XFILES_APPLICATION_REDIRECT
as
  procedure handleRender(P_EVENT dbms_xevent.XDBRepositoryEvent);
end;
/
show errors
--
set define off
--
create or replace package body XFILES_APPLICATION_REDIRECT
as    
-- 
  G_HTML_PAGE    VARCHAR2(32000) :=
'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html dir="ltr" lang="en-US">
<head>
  <link rel="stylesheet" charset="UTF-8" type="text/css" href="/XFILES/lite/css/XFiles.css"/>
	<title>Welcome to the Oracle XML DB XFiles Application.</title>
  <script type="text/javascript" language="javascript">
function doRedirect() {
    var target="/XFILES/lite/Folder.html?target=%FOLDER%&stylesheet=/XFILES/lite/xsl/FolderBrowser.xsl&includeContent=false";
    window.location.href = target;
}
  </script>
</head>
<body onload="doRedirect()">
  <table height="100%" align="center" border="0">
		<tr align="center" valign="middle">
			<td class="x14" align="center" valign="middle">
			Welcome to the XFiles application launch page for %FOLDER%. You are current connected as %USER%.
		   <br/>
			Opening this page should automatically launch the Oracle XML DB XFiles Application
		   <br/><br/>
				<a href="#" onclick="doRedirect()">
				   <img src="/XFILES/logo.png" alt="Oracle Files" border="0"/>
				</a>
			<br/><br/>
			If the application does not launch automatically click <span class="xp"><a href="#" onClick="doRedirect();false">here</a></span> to launch the application.
			</td>	
		</tr>
   </table>
</body>
</html>';

procedure handleRender(P_EVENT dbms_xevent.XDBRepositoryEvent)
as
  V_HTML_PAGE VARCHAR2(32000) := G_HTML_PAGE;

  V_TEXT_CONTENT CLOB;
  V_BINARY_CONTENT BLOB;
  V_CHARSET_ID NUMBER(4);

  V_SOURCE_OFFSET      integer := 1;
  V_TARGET_OFFSET      integer := 1;
  V_WARNING            integer;
  V_LANG_CONTEXT       integer := 0;  

  V_PARENT_FOLDER_PATH VARCHAR2(700);
  
begin
  select NLS_CHARSET_ID(VALUE)
    into V_CHARSET_ID
    from NLS_DATABASE_PARAMETERS
   where PARAMETER = 'NLS_CHARACTERSET';

  V_PARENT_FOLDER_PATH := DBMS_XEVENT.getName(DBMS_XEVENT.getParentPath(DBMS_XEVENT.getPath(P_EVENT),1));
  
  if (LENGTH(V_PARENT_FOLDER_PATH) > 1) then
    V_PARENT_FOLDER_PATH := rtrim(V_PARENT_FOLDER_PATH,'/');
  end if;

  V_HTML_PAGE := REPLACE(V_HTML_PAGE,'%OWNER%',DBMS_XDBRESOURCE.getOwner(DBMS_XEVENT.getResource(P_EVENT)));
  V_HTML_PAGE := REPLACE(V_HTML_PAGE,'%USER%',USER);
  V_HTML_PAGE := REPLACE(V_HTML_PAGE,'%FOLDER%',V_PARENT_FOLDER_PATH);
  
  V_TEXT_CONTENT := V_HTML_PAGE;
  dbms_lob.createTemporary(V_BINARY_CONTENT,true);
  dbms_lob.convertToBlob(V_BINARY_CONTENT,V_TEXT_CONTENT,dbms_lob.getLength(V_TEXT_CONTENT),V_SOURCE_OFFSET,V_TARGET_OFFSET,V_CHARSET_ID,V_LANG_CONTEXT,V_WARNING);
  DBMS_XEVENT.setRenderStream(P_EVENT,V_BINARY_CONTENT);    
  DBMS_LOB.FREETEMPORARY(V_BINARY_CONTENT);
  DBMS_LOB.FREETEMPORARY(V_TEXT_CONTENT);  
end;   
--
end;
/
set define on
--
show errors
--
grant execute on XFILES_APPLICATION_REDIRECT to public
/
