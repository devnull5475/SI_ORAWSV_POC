spool XFILES_RELOAD_ICONS.log
set echo on
--
declare 
  
  V_ZIP_FILE      VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/famfamfam_silk_icons_v013.zip';
  V_SOURCE_FOLDER VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/icons/famfamfam'; 
  V_LOG_FILE      VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/famfamfam_silk_icons_v013.log';
  V_ICON_FOLDER   VARCHAR2(700) := V_SOURCE_FOLDER || '/icons';
  V_TARGET_FOLDER VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/lib/icons';
begin                        
	if (DBMS_XDB.existsResource(V_ICON_FOLDER)) then                                                    
    DBMS_XDB.deleteResource(V_ICON_FOLDER,DBMS_XDB.DELETE_RECURSIVE);
    commit;
  end if;
  
	if (DBMS_XDB.existsResource(V_LOG_FILE)) then                                                    
    DBMS_XDB.deleteResource(V_LOG_FILE);
    commit;
  end if;

  delete 
   from resource_view 
  where under_path(res,V_SOURCE_FOLDER) = 1;
  commit; 

  delete 
   from resource_view 
  where under_path(res,V_TARGET_FOLDER) = 1;
  commit; 
  
  XDB_IMPORT_UTILITIES.UNZIP(V_ZIP_FILE,V_SOURCE_FOLDER,V_LOG_FILE,XDB_CONSTANTS.RAISE_ERROR);
end;
/
--
@@PUBLISH_XFILES_ICONS
--
declare
  V_TARGET_FOLDER VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/lib/icons';
  cursor publishIcons is
  select path 
    from path_view
-- where under_path(res,XFILES_CONSTANTS.FOLDER_XFILES_ROOT) = 1;
   where under_path(res,V_TARGET_FOLDER) = 1;
begin
  for res in publishIcons loop
    dbms_xdb.setACL(res.path,'/sys/acls/bootstrap_acl.xml');
  end loop;
end;
/
commit
/
exit
