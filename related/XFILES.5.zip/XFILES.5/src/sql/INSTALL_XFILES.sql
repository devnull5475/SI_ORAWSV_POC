set echo on
spool INSTALL_XFILES.log
--
def XFILES_SCHEMA = &1
--
var XFILES_LOG_TABLE_INDEX  varchar2(120)
--
declare
  V_XFILES_LOG_TABLE_INDEX varchar2(120);
begin
$IF DBMS_DB_VERSION.VER_LE_11_1 $THEN
  V_XFILES_LOG_TABLE_INDEX := 'XFILES_LOG_TABLE_INDEX_11100.sql';
$ELSIF DBMS_DB_VERSION.VER_LE_11_2 $THEN
  V_XFILES_LOG_TABLE_INDEX := 'XFILES_LOG_TABLE_INDEX_11201.sql';
$ELSE
  V_XFILES_LOG_TABLE_INDEX := 'XFILES_LOG_TABLE_INDEX_ERROR.sql';
$END
 :XFILES_LOG_TABLE_INDEX := V_XFILES_LOG_TABLE_INDEX;
end;
/
undef XFILES_LOG_TABLE_INDEX 
--
column XFILES_LOG_TABLE_INDEX new_value XFILES_LOG_TABLE_INDEX 
--
select :XFILES_LOG_TABLE_INDEX XFILES_LOG_TABLE_INDEX  
  from dual
/
def XFILES_LOG_TABLE_INDEX
--
call XDB_UTILITIES.createHomeFolder()
/
commit
/
declare
  text_exception exception;
  PRAGMA EXCEPTION_INIT( text_exception , -20000);
begin
--
  begin
    ctxsys.ctx_ddl.create_policy(policy_name=>'XFILES_HTML_GENERATION', filter=>'ctxsys.auto_filter');
  exception
    when text_exception  then
      null;
  end;
end;
/
@@XFILES_CONSTANTS
--
grant execute on XFILES_CONSTANTS        
              to PUBLIC
/
--
@@XFILES_LOG_TABLE
--
@@XFILES_LOGWRITER
--
grant execute on XFILES_LOGWRITER       
              to PUBLIC
/
@@XFILES_LOGGING
--
grant execute on XFILES_LOGGING         
              to PUBLIC
/
@@XFILES_USER_MANAGEMENT
--
grant execute on XFILES_ADMIN_SERVICES
              to XFILES_ADMINISTRATOR
/              
grant execute on XFILES_USER_SERVICES
              to PUBLIC
/
@@XFILES_RENDERING_SUPPORT
--
@@XFILES_UTILITIES
--
grant execute on XFILES_UTILITIES        
              to PUBLIC
/
@@XFILES_WIKI_SERVICES
--
grant execute on XFILES_WIKI_SERVICES   
              to PUBLIC
/
@@XDB_REPOSITORY_SERVICES
--
grant execute on XDB_REPOSITORY_SERVICES
              to PUBLIC
/
@@XFILES_DOCUMENT_UPLOAD
--
grant execute on XFILES_DOCUMENT_UPLOAD 
              to PUBLIC
/
@@XFILES_SOAP_SERVICES
--
grant execute on XFILES_SOAP_SERVICES   
              to PUBLIC
/
@@XFILES_SEARCH_SERVICES
--
grant execute on XFILES_SEARCH_SERVICES 
              to PUBLIC
/
@@XFILES_REST_SERVICES
--
grant execute on XFILES_REST_SUPPORT 
              to PUBLIC
/
grant execute on XFILES_REST_SERVICES   
              to PUBLIC
/
@@XFILES_APEX_SERVICES
--
--
begin
  dbms_utility.compile_schema('&XFILES_SCHEMA',TRUE);
end;
/
select object_name, object_type, status 
  from all_objects
 where owner= '&XFILES_SCHEMA' 
   and OBJECT_TYPE not in ('LOB')
 order by status, object_type, object_name
/
@@XFILES_XMLINDEX_LIST
--
@@XFILES_XMLSCHEMA_LIST
--
@@XFILES_CREATE_FOLDERS
--
@@XFILES_EVENT_MANAGERS
--
--
call XFILES_LOGWRITER.CREATELOGGINGFOLDERS()
--
-- RESETLOGGINGFOLDERS should be run as a post instal step as it can take a long time...
--
-- call XFILES_LOGWRITER.RESETLOGGINGFOLDERS()
/
commit
/
spool off
exit