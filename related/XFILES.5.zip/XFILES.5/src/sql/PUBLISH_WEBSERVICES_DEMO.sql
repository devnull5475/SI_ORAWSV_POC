--
declare
  V_SOURCE_FOLDER varchar2(700) := XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/WebServices';
  V_TARGET_FOLDER varchar2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/WebServices';
  V_RESULT        boolean;
begin 
  if dbms_xdb.existsResource(V_TARGET_FOLDER) then
    dbms_xdb.deleteResource(V_TARGET_FOLDER,DBMS_XDB.DELETE_RECURSIVE_FORCE);
  end if;

  V_RESULT := dbms_xdb.createFolder(V_TARGET_FOLDER);
  dbms_xdb.link(V_SOURCE_FOLDER || '/webServices.html',V_TARGET_FOLDER,'index.html',DBMS_XDB.LINK_TYPE_WEAK);
  dbms_xdb.link(V_SOURCE_FOLDER || '/js',V_TARGET_FOLDER,'js',DBMS_XDB.LINK_TYPE_WEAK);
  dbms_xdb.link(V_SOURCE_FOLDER || '/xsl',V_TARGET_FOLDER,'xsl',DBMS_XDB.LINK_TYPE_WEAK);
  
end;
/