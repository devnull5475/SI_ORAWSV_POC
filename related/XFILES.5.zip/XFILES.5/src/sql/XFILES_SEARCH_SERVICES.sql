--
create or replace package XFILES_SEARCH_SERVICES
AUTHID CURRENT_USER
as
  function getXMLIndexRootNodeMap(P_PATH_TABLE_NAME VARCHAR2, P_PATH_TABLE_OWNER VARCHAR2) return XMLType;
  function getXMLIndexChildNodeMap(P_PATHID VARCHAR2, P_PATH_TABLE_NAME VARCHAR2, P_PATH_TABLE_OWNER VARCHAR2) return XMLType;

  function getXMLSchemaRootNodeMap(P_SCHEMA_URL varchar2, P_SCHEMA_OWNER varchar2 default USER, P_GLOBAL_ELEMENT varchar2) return XMLType;
  function getXMLSchemaChildNodeMap(P_PROPERTY_NUMBER number) return XMLType;
  function getSubstitutionGroup(P_HEAD_ELEMENT NUMBER)  return XMLType;
  
  function getRepositoryNodeMap return XMLType;

end;
/
show errors
--
create or replace package body XFILES_SEARCH_SERVICES
as
procedure writeLogRecord(P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType)
as
begin
  XFILES_LOGGING.writeLogRecord('/orawsv/XFILES/XFILES_SEARCH_SERVICES/',P_MODULE_NAME, P_INIT_TIME, P_PARAMETERS);
end;
--
procedure writeErrorRecord(P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType, P_STACK_TRACE XMLType)
as
begin
  XFILES_LOGGING.writeErrorRecord('/orawsv/XFILES/XFILES_SEARCH_SERVICES/',P_MODULE_NAME, P_INIT_TIME, P_PARAMETERS, P_STACK_TRACE);
end;
--
procedure handleException(P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE,P_PARAMETERS XMLTYPE)
as
  V_STACK_TRACE XMLType;
  V_RESULT      boolean;
begin
  V_STACK_TRACE := XFILES_LOGGING.captureStackTrace();
  rollback; 
  writeErrorRecord(P_MODULE_NAME,P_INIT_TIME,P_PARAMETERS,V_STACK_TRACE);
end;
--
function GETXMLINDEXROOTNODEMAP(P_PATH_TABLE_NAME VARCHAR2, P_PATH_TABLE_OWNER VARCHAR2) 
return xmlType
as  
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP; 
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("PathTable",P_PATH_TABLE_NAME),
           xmlElement("PathTableOwner",P_PATH_TABLE_OWNER)
         )
    into V_PARAMETERS
    from dual;
  
  V_RESULT := XDB_XMLINDEX_SEARCH.getRootNodeMap(P_PATH_TABLE_NAME,P_PATH_TABLE_OWNER);  
  writeLogRecord('GETXMLINDEXROOTNODEMAP',V_INIT,V_PARAMETERS);
  return V_RESULT;
exception
  when others then
    handleException('GETXMLINDEXROOTNODEMAP',V_INIT,V_PARAMETERS);
    raise;
end;
--
function GETXMLINDEXCHILDNODEMAP(P_PATHID VARCHAR2, P_PATH_TABLE_NAME VARCHAR2, P_PATH_TABLE_OWNER VARCHAR2)
return xmlType
as 
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP; 
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("PathId",P_PATHID),
           xmlElement("PathTable",P_PATH_TABLE_NAME),
           xmlElement("PathTableOwner",P_PATH_TABLE_OWNER)
         )
    into V_PARAMETERS
    from dual;

  V_RESULT := XDB_XMLINDEX_SEARCH.getChildNodeMap(P_PATHID,P_PATH_TABLE_NAME,P_PATH_TABLE_OWNER);  
  writeLogRecord('GETXMLINDEXCHILDNODEMAP',V_INIT,V_PARAMETERS);
  return V_RESULT;
exception
  when others then
    handleException('GETXMLINDEXCHILDNODEMAP',V_INIT,V_PARAMETERS);
    raise;
end;
--
function GETXMLSCHEMAROOTNODEMAP(P_SCHEMA_URL varchar2, P_SCHEMA_OWNER varchar2 default USER, P_GLOBAL_ELEMENT varchar2)
return xmlType
as 
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP; 
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("SchemaURL",P_SCHEMA_URL),
           xmlElement("SchemaOwner",P_SCHEMA_OWNER),
           xmlElement("GlobalElement",P_GLOBAL_ELEMENT)
         )
    into V_PARAMETERS
    from dual;

  V_RESULT := XDB_XMLSCHEMA_SEARCH.getRootNodeMap(P_SCHEMA_URL,P_SCHEMA_OWNER,P_GLOBAL_ELEMENT);
  writeLogRecord('GETXMLSCHEMAROOTNODEMAP',V_INIT,V_PARAMETERS);
  return V_RESULT;
exception
  when others then
    handleException('GETXMLSCHEMAROOTNODEMAP',V_INIT,V_PARAMETERS);
    raise;
end;
--
function GETXMLSCHEMACHILDNODEMAP(P_PROPERTY_NUMBER number)
return xmlType
as 
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP; 
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("P_PROPERTY_NAME",P_PROPERTY_NUMBER)
         )
    into V_PARAMETERS
    from dual;

  V_RESULT := XDB_XMLSCHEMA_SEARCH.getChildNodeMap(P_PROPERTY_NUMBER);
  writeLogRecord('GETXMLSCHEMACHILDNODEMAP',V_INIT,V_PARAMETERS);
  return V_RESULT;
exception
  when others then
    handleException('GETXMLSCHEMACHILDNODEMAP',V_INIT,V_PARAMETERS);
    raise;
end;
--
function GETSUBSTITUTIONGROUP(P_HEAD_ELEMENT number)
return xmlType
as 
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP; 
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("HeadElementId",P_HEAD_ELEMENT)
         )
    into V_PARAMETERS
    from dual;

  V_RESULT := XDB_XMLSCHEMA_SEARCH.getSubstitutionGroup(P_HEAD_ELEMENT);
  writeLogRecord('GETSUBSTITUTIONGROUP',V_INIT,V_PARAMETERS);
  return V_RESULT;
exception
  when others then
    handleException('GETSUBSTITUTIONGROUP',V_INIT,V_PARAMETERS);
    raise;
end;
--
function GETREPOSITORYNODEMAP
return xmlType
as 
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP; 
  V_RESULT            XMLType;
begin
  V_RESULT := XDB_REPOSITORY_SEARCH.getNodeMap();
  writeLogRecord('GETREPOSITORYNODEMAP',V_INIT,NULL);
  return V_RESULT;
exception
  when others then
    handleException('GETREPOSITORYNODEMAP',V_INIT,NULL);
    raise;
end;
--
end;
/
show errors
--
