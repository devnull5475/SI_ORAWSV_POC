def XFILES_SCHEMA = &1
--
select count(*) 
  from &XFILES_SCHEMA..XFILES_LOG_TABLE
/
select count(*) 
  from  &XFILES_SCHEMA..LOG_RECORD_QUEUE_TABLE
/
declare
  po dbms_aqadm.aq$_purge_options_t;
BEGIN
   insert into &XFILES_SCHEMA..XFILES_LOG_TABLE
   select USER_DATA from &XFILES_SCHEMA..LOG_RECORD_QUEUE_TABLE;
   commit;
   po.block := TRUE;
   SYS.DBMS_AQADM.PURGE_QUEUE_TABLE(
     queue_table     => '&XFILES_SCHEMA..LOG_RECORD_QUEUE_TABLE',
     purge_condition => NULL,
     purge_options   => po);
   commit;
end;
/
select count(*) 
  from &XFILES_SCHEMA..XFILES_LOG_TABLE
/
select count(*) 
  from  &XFILES_SCHEMA..LOG_RECORD_QUEUE_TABLE
/
--
