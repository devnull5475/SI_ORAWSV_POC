set echo on
spool XFILES_UNZIP_ARCHIVE.log APPEND
--
def ZIP_FILE_PATH = &1
def TARGET_FOLDER = &2
def LOG_FILE_PATH = &3
--
set timing on
call DBMS_JAVA.SET_OUTPUT(200000)
/
set serveroutput on size 200000
--
call XDB_ZIP_UTILITY.UNZIP('&ZIP_FILE_PATH','&LOG_FILE_PATH','&TARGET_FOLDER',XDB_CONSTANTS.RAISE_ERROR)
/
quit
