set echo on 
spool deinstallTextIndex.log
--
connect sys/&1 as sysdba
--
alter user xdb identified by xdb account unlock
/
connect xdb/xdb
--
drop index xdb$ci force
/
call dbms_xdbt.dropPreferences()
/
connect sys/&1 as sysdba
--
alter user xdb identified by xdb account lock
/
quit
 
