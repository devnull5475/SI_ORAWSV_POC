--
create or replace package XFILES_UTILITIES
authid CURRENT_USER
as  
  function renderAsHTML(P_RESOURCE_PATH VARCHAR2) return CLOB;
  function renderAsText(P_RESOURCE_PATH VARCHAR2) return CLOB;
  function renderAsXHTML(P_RESOURCE_PATH VARCHAR2) return XMLType;
  function generatePreview(P_RESOURCE_PATH VARCHAR2, P_LINES NUMBER DEFAULT 10, P_LINE_SIZE NUMBER DEFAULT 132) return XMLType;
  function transformToHTML(P_XMLDOC XMLType, P_XSL_PATH VARCHAR2) return CLOB;
  function xmlTransform(P_XMLDOC XMLType, P_XSLDOC XMLType) return XMLType;
  function xmlTransform2(P_XMLDOC XMLType, P_XSLDOC XMLType) return XMLType;
  procedure enableRSSFeed(P_FOLDER_PATH VARCHAR2, P_ITEMS_CHANGED_IN VARCHAR2);
  procedure disableRSSFeed(P_FOLDER_PATH VARCHAR2);
end;
/
show errors
--
create or replace package body XFILES_UTILITIES
as
--
function renderAsHTML(P_RESOURCE_PATH VARCHAR2) 
return CLOB
as
begin
  return XFILES_RENDERING.renderAsHTML(xdburitype(P_RESOURCE_PATH).getBLOB());
end;
--
function renderAsText(P_RESOURCE_PATH VARCHAR2) 
return CLOB
as
begin
  return XFILES_RENDERING.renderAsText(xdburitype(P_RESOURCE_PATH).getBLOB());
end;
--
function renderAsXHTML(P_RESOURCE_PATH VARCHAR2) 
return XMLType
as
  V_DOCUMENT CLOB;
  V_CONTENT CLOB;
  V_OFFSET  NUMBER;
begin

  -- xdb_debug.writeDebug(P_RESOURCE_PATH);

  dbms_lob.createTemporary(V_DOCUMENT,true);
  dbms_lob.open(V_DOCUMENT,dbms_lob.lob_readwrite);

  V_CONTENT := '<documentContent><![CDATA[';
  dbms_lob.append(V_DOCUMENT,V_CONTENT);
  dbms_lob.freeTemporary(V_CONTENT);
  
  V_CONTENT := XFILES_RENDERING.renderAsHTML(xdburitype(P_RESOURCE_PATH).getBLOB());
  dbms_lob.append(V_DOCUMENT,V_CONTENT);
  dbms_lob.freeTemporary(V_CONTENT);

  V_CONTENT := ']]></documentContent>';
  dbms_lob.append(V_DOCUMENT,V_CONTENT);
  dbms_lob.freeTemporary(V_CONTENT);

  return xmlType(V_DOCUMENT);
end;
--
function generatePreview(P_RESOURCE_PATH VARCHAR2, P_LINES NUMBER DEFAULT 10, P_LINE_SIZE NUMBER DEFAULT 132) 
return XMLType
as
  V_DOCUMENT  CLOB;
  V_CONTENT   CLOB;
  V_OFFSET    NUMBER := 0;
  V_MAX_CHARS NUMBER := (P_LINES * P_LINE_SIZE);
begin

  -- xdb_debug.writeDebug(P_RESOURCE_PATH);

  dbms_lob.createTemporary(V_DOCUMENT,true);
  dbms_lob.open(V_DOCUMENT,dbms_lob.lob_readwrite);

  V_CONTENT := '<documentContent><![CDATA[';
  dbms_lob.append(V_DOCUMENT,V_CONTENT);
  dbms_lob.freeTemporary(V_CONTENT);
 
  V_CONTENT := XFILES_RENDERING.renderAsText(xdburitype(P_RESOURCE_PATH).getBLOB());
  if (P_LINES > 0) then
    V_OFFSET  := dbms_lob.instr(V_CONTENT,chr(10),1,P_LINES);
    if (V_OFFSET > 0) then
      DBMS_LOB.trim(V_CONTENT,V_OFFSET);
    end if;
  end if;

  if (DBMS_LOB.getLength(V_CONTENT) > V_MAX_CHARS) then
    DBMS_LOB.trim(V_CONTENT,V_MAX_CHARS);
  end if;

  dbms_lob.append(V_DOCUMENT,V_CONTENT);
  dbms_lob.freeTemporary(V_CONTENT);

  V_CONTENT := ']]></documentContent>';
  dbms_lob.append(V_DOCUMENT,V_CONTENT);
  dbms_lob.freeTemporary(V_CONTENT);

  return xmlType(V_DOCUMENT);
end;
--
function transformToHTML(P_XMLDOC XMLType, P_XSL_PATH VARCHAR2) 
return CLOB
as
  V_HTML clob;
begin
  select P_XMLDOC.transform(xdburitype(P_XSL_PATH).getXML()).getClobVal()
    into V_HTML
    from dual;
  return V_HTML;
end;
--
function xmlTransform(P_XMLDOC XMLType, P_XSLDOC XMLType) 
return XMLType
as
begin
  return P_XMLDOC.transform(P_XSLDOC);
end;
--
function xmlTransform2(P_XMLDOC XMLType, P_XSLDOC XMLType) 
return XMLType
as
  V_DOCUMENT CLOB;
  V_CONTENT CLOB;
begin
  dbms_lob.createTemporary(V_DOCUMENT,true);
  dbms_lob.open(V_DOCUMENT,dbms_lob.lob_readwrite);

  V_CONTENT := '<documentContent><![CDATA[';
  dbms_lob.append(V_DOCUMENT,V_CONTENT);
  dbms_lob.freeTemporary(V_CONTENT);

  select P_XMLDOC.transform(P_XSLDOC).getClobVal()
    into V_CONTENT
    from dual;
  dbms_lob.append(V_DOCUMENT,V_CONTENT);
  dbms_lob.freeTemporary(V_CONTENT);

  V_CONTENT := ']]></documentContent>';
  dbms_lob.append(V_DOCUMENT,V_CONTENT);
  dbms_lob.freeTemporary(V_CONTENT);
    
    
  return xmlType(V_DOCUMENT);
end;
--
function transformToHTML(P_XMLDOC XMLType, P_XSLDOC XMLType) 
return XMLType
as
begin
  return P_XMLDOC.transform(P_XSLDOC);
end;
--
procedure enableRSSFeed(P_FOLDER_PATH VARCHAR2, P_ITEMS_CHANGED_IN VARCHAR2)
as 
  V_RSS_METADATA  XMLType;
  V_TEMP           NUMBER(1);
begin

  select xmlElement
         (
           evalname(XFILES_CONSTANTS.ELEMENT_RSS),
           xmlAttributes(XFILES_CONSTANTS.NAMESPACE_XFILES_RSS as "xmlns"),
           xmlElement("ItemsChangedIn", P_ITEMS_CHANGED_IN)
         )
    into V_RSS_METADATA
    from dual;

  begin
    select 1 
      into V_TEMP
      from RESOURCE_VIEW
     where equals_path(RES,P_FOLDER_PATH) = 1
       and existsNode(RES,'/r:Resource/rss:' || XFILES_CONSTANTS.ELEMENT_RSS, DBMS_XDB_CONSTANTS.NSPREFIX_RESOURCE_R || ' ' || XFILES_CONSTANTS.NSPREFIX_XFILES_RSS_RSS) = 1;
     dbms_xdb.updateResourceMetadata(P_FOLDER_PATH, XFILES_CONSTANTS.NAMESPACE_XFILES_RSS, XFILES_CONSTANTS.ELEMENT_RSS, V_RSS_METADATA);
  exception
    when no_data_found then
      dbms_xdb.appendResourceMetadata(P_FOLDER_PATH, V_RSS_METADATA);
    when others then
      raise;
  end;

end;
--
procedure disableRSSFeed(P_FOLDER_PATH VARCHAR2)
as
begin
  dbms_xdb.deleteResourceMetadata(P_FOLDER_PATH, XFILES_CONSTANTS.NAMESPACE_XFILES_RSS, XFILES_CONSTANTS.ELEMENT_RSS);
end;
--
end;
/
show errors
--