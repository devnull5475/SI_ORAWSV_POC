--
create or replace package XFILES_CONSTANTS
authid CURRENT_USER
as
  C_FOLDER_XFILES_ROOT                  constant VARCHAR2(700) := '/XFILES';
  C_FOLDER_XFILES_HOME                  constant VARCHAR2(700) := '/home/&XFILES_SCHEMA';
  C_FOLDER_XFILES_APPS_PRIVATE          constant VARCHAR2(700) := C_FOLDER_XFILES_HOME || '/Applications';
  C_FOLDER_XFILES_APPS_PUBLIC           constant VARCHAR2(700) := C_FOLDER_XFILES_ROOT || '/Applications';
                                       
  C_NAMESPACE_XFILES                    constant VARCHAR2(128) := DBMS_XDB_CONSTANTS.NAMESPACE_ORACLE_XDB || '/xfiles';
  C_NAMESPACE_XFILES_RSS                constant VARCHAR2(128) := C_NAMESPACE_XFILES || '/rss';
                                       
  C_NSPREFIX_XFILES_XFILES              constant VARCHAR2(128) := 'xmlns:xfiles="' || C_NAMESPACE_XFILES || '"';
  C_NSPREFIX_XFILES_RSS_RSS             constant VARCHAR2(128) := 'xmlns:rss="' || C_NAMESPACE_XFILES_RSS || '"';
                                       
  C_ELEMENT_RSS                         constant VARCHAR2(256) := 'enableRSS';
                                       
  C_DOCUMENT_UNAUTHENTICATED            constant VARCHAR2(700) := C_FOLDER_XFILES_ROOT || '/unauthenticated.xml';
                                       
  C_DOCUMENT_WHOAMI                     constant VARCHAR2(700) := C_FOLDER_XFILES_ROOT || '/whoami.xml';
  C_RESCONFIG_WHOAMI                    constant VARCHAR2(700) := C_FOLDER_XFILES_HOME || '/src/xml/whoamiResConfig.xml';
                                       
  C_DOCUMENT_AUTH_STATUS                constant VARCHAR2(700) := C_FOLDER_XFILES_ROOT || '/authenticationStatus.xml';
  C_RESCONFIG_AUTH_STATUS               constant VARCHAR2(700) := C_FOLDER_XFILES_HOME || '/src/xml/authStatusResConfig.xml';
                                       
  C_ACL_XFILES_USERS                    constant VARCHAR2(700) := C_FOLDER_XFILES_HOME || '/src/acls/xfilesUserAcl.xml';
  C_ACL_DENY_XFILES_USERS               constant VARCHAR2(700) := C_FOLDER_XFILES_HOME || '/src/acls/denyXFilesUserAcl.xml';
                                       
  C_DOCUMENT_XMLINDEX_LIST              constant VARCHAR2(700) := C_FOLDER_XFILES_HOME || '/configuration/xmlIndexList.xml';
  C_DOCUMENT_XMLSCHEMA_LIST             constant VARCHAR2(700) := C_FOLDER_XFILES_HOME || '/configuration/xmlSchemaList.xml';
  
  -- Path to the public location, not the private location.
                                       
  C_RESCONFIG_XFILES_REDIRECT           constant VARCHAR2(700) := C_FOLDER_XFILES_ROOT || '/resConfig/xfilesRedirectResConfig.xml';
  
  C_FOLDER_LOGGING                      constant VARCHAR2(700) := C_FOLDER_XFILES_HOME    || '/Logs';
  C_FOLDER_CURRENT_LOGGING              constant VARCHAR2(700) := C_FOLDER_LOGGING        || '/Current';
  C_FOLDER_ERROR_LOGGING                constant VARCHAR2(700) := C_FOLDER_LOGGING        || '/Errors';
  C_FOLDER_CURRENT_ERRORS               constant VARCHAR2(700) := C_FOLDER_ERROR_LOGGING  || '/Current';
  C_FOLDER_CLIENT_LOGGING               constant VARCHAR2(700) := C_FOLDER_LOGGING        || '/Client';
  C_FOLDER_CURRENT_CLIENT               constant VARCHAR2(700) := C_FOLDER_CLIENT_LOGGING || '/Current';

  C_ELEMENT_CUSTOM_VIEWER              constant VARCHAR2(700) := 'CustomViewer';

  function FOLDER_XFILES_ROOT           return VARCHAR2 deterministic;
  function FOLDER_XFILES_HOME           return VARCHAR2 deterministic;
  function FOLDER_XFILES_APPS_PRIVATE   return VARCHAR2 deterministic;
  function FOLDER_XFILES_APPS_PUBLIC    return VARCHAR2 deterministic;
                                       
  function NAMESPACE_XFILES             return VARCHAR2 deterministic;
  function NAMESPACE_XFILES_RSS         return VARCHAR2 deterministic;
  function NSPREFIX_XFILES_XFILES       return VARCHAR2 deterministic;
  function NSPREFIX_XFILES_RSS_RSS      return VARCHAR2 deterministic;
  function ELEMENT_RSS                  return VARCHAR2 deterministic;
                                       
  function ACL_XFILES_USERS             return VARCHAR2 deterministic;
  function ACL_DENY_XFILES_USERS        return VARCHAR2 deterministic;
                                       
  function DOCUMENT_AUTH_STATUS         return VARCHAR2 deterministic;
  function RESCONFIG_AUTH_STATUS        return VARCHAR2 deterministic;
                                       
  function DOCUMENT_WHOAMI              return VARCHAR2 deterministic;
  function RESCONFIG_WHOAMI             return VARCHAR2 deterministic;
  function DOCUMENT_UNAUTHENTICATED     return VARCHAR2 deterministic;        
  
  function RESCONFIG_XFILES_REDIRECT    return VARCHAR2 deterministic;  
  
  function DOCUMENT_XMLINDEX_LIST       return VARCHAR2 deterministic;
  function DOCUMENT_XMLSCHEMA_LIST      return VARCHAR2 deterministic;

  function FOLDER_LOGGING               return VARCHAR2 deterministic;
  function FOLDER_CURRENT_LOGGING       return VARCHAR2 deterministic;
  function FOLDER_ERROR_LOGGING         return VARCHAR2 deterministic;
  function FOLDER_CURRENT_ERRORS        return VARCHAR2 deterministic;
  function FOLDER_CLIENT_LOGGING        return VARCHAR2 deterministic;
  function FOLDER_CURRENT_CLIENT        return VARCHAR2 deterministic;

  function ELEMENT_CUSTOM_VIEWER        return VARCHAR2 deterministic;
end;
/
show errors
--
create or replace package body XFILES_CONSTANTS
as
--
function FOLDER_XFILES_ROOT      
return VARCHAR2 deterministic
as 
begin
  return C_FOLDER_XFILES_ROOT;
end;
--
function FOLDER_XFILES_HOME       
return VARCHAR2 deterministic
as 
begin
  return C_FOLDER_XFILES_HOME;
end;
--
function FOLDER_XFILES_APPS_PRIVATE
return VARCHAR2 deterministic
as 
begin
  return C_FOLDER_XFILES_APPS_PRIVATE;
end;
function FOLDER_XFILES_APPS_PUBLIC
return VARCHAR2 deterministic
as 
begin
  return C_FOLDER_XFILES_APPS_PUBLIC;
end;
function NAMESPACE_XFILES
return VARCHAR2 deterministic
as 
begin
  return C_NAMESPACE_XFILES;
end;
--
function NAMESPACE_XFILES_RSS   
return VARCHAR2 deterministic
as 
begin
  return C_NAMESPACE_XFILES_RSS;
end;
--
function NSPREFIX_XFILES_XFILES   
return VARCHAR2 deterministic
as 
begin
  return C_NSPREFIX_XFILES_XFILES;
end;
--
function NSPREFIX_XFILES_RSS_RSS  
return VARCHAR2 deterministic
as 
begin
  return C_NSPREFIX_XFILES_RSS_RSS;
end;
--
function ELEMENT_RSS
return VARCHAR2 deterministic
as 
begin
  return C_ELEMENT_RSS;
end;
--
function ACL_XFILES_USERS
return VARCHAR2 deterministic
as 
begin
  return C_ACL_XFILES_USERS;
end;
--
function ACL_DENY_XFILES_USERS
return VARCHAR2 deterministic
as 
begin
  return C_ACL_DENY_XFILES_USERS;
end;
--
function DOCUMENT_UNAUTHENTICATED    
return VARCHAR2 deterministic
as 
begin
  return C_DOCUMENT_UNAUTHENTICATED;
end;
--
function DOCUMENT_AUTH_STATUS    
return VARCHAR2 deterministic
as 
begin
  return C_DOCUMENT_AUTH_STATUS;
end;
--
function RESCONFIG_AUTH_STATUS
return VARCHAR2 deterministic
as 
begin
  return C_RESCONFIG_AUTH_STATUS;
end;
--
function DOCUMENT_WHOAMI
return VARCHAR2 deterministic
as 
begin
  return C_DOCUMENT_WHOAMI;
end;
--
function RESCONFIG_WHOAMI       
return VARCHAR2 deterministic
as 
begin
  return C_RESCONFIG_WHOAMI;
end;
--  
function RESCONFIG_XFILES_REDIRECT
return VARCHAR2 deterministic
as 
begin
  return C_RESCONFIG_XFILES_REDIRECT;
end;
--
function DOCUMENT_XMLINDEX_LIST       
return VARCHAR2 deterministic
as 
begin
  return C_DOCUMENT_XMLINDEX_LIST;   
end;
--  
function DOCUMENT_XMLSCHEMA_LIST          
return VARCHAR2 deterministic
as 
begin
  return C_DOCUMENT_XMLSCHEMA_LIST;
end;
--  
function FOLDER_LOGGING
return VARCHAR2 deterministic
as 
begin
  return C_FOLDER_LOGGING;
end;
--  
function FOLDER_CURRENT_LOGGING
return VARCHAR2 deterministic
as 
begin
  return C_FOLDER_CURRENT_LOGGING;
end;
--  
function FOLDER_ERROR_LOGGING
return VARCHAR2 deterministic
as 
begin
  return C_FOLDER_ERROR_LOGGING;
end;
--  
function FOLDER_CURRENT_ERRORS
return VARCHAR2 deterministic
as 
begin
  return C_FOLDER_CURRENT_ERRORS;
end;
--  
function FOLDER_CLIENT_LOGGING
return VARCHAR2 deterministic
as 
begin
  return C_FOLDER_CLIENT_LOGGING;
end;
--  
function FOLDER_CURRENT_CLIENT
return VARCHAR2 deterministic
as 
begin
  return C_FOLDER_CURRENT_CLIENT;
end;
--  
function ELEMENT_CUSTOM_VIEWER
return VARCHAR2 deterministic
as 
begin
  return C_ELEMENT_CUSTOM_VIEWER;
end;
--  
end;
/
show errors
--
