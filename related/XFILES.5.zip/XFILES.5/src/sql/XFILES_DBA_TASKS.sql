set echo on
spool XFILES_DBA_TASKS.log
--
def XFILES_SCHEMA = &1
--
def XFILES_PASSWORD = &2
--
def HTTP_PORT = &3
--
-- Enable Anonymous access to XML DB Repository
--
ALTER SESSION SET XML_DB_EVENTS = DISABLE
/
alter user anonymous account unlock
/
call xdb_configuration.setAnonymousAccess('true')
/
--
-- #BUG 13583446 
--
-- Set the HTTP Port Number
--
-- call dbms_xdb.setHTTPPort(&HTTP_PORT)
-- /
-- alter system register
-- /
--
-- Enable LOB Cache for XMLLob.
--
alter table xdb.xdb$resource modify lob (xmldata.xmllob) (cache)
/
--
-- Enable use of Unified Java API for all users on NT...
--
call dbms_java.grant_permission('PUBLIC','SYS:oracle.aurora.rdbms.security.PolicyTablePermission','0:java.lang.RuntimePermission#loadLibrary.oraxml11',null)
/
call dbms_java.grant_permission('PUBLIC','SYS:java.lang.RuntimePermission','loadLibrary.oraxml11',null)
/
grant select on XDB.XDB$RESOURCE to &XFILES_SCHEMA
/
call dbms_xdb.deleteServletMapping('SelectionProcessor')
/
call dbms_xdb.deleteServletMapping('VersionResources')
/
call dbms_xdb.deleteServletMapping('VersionHistory')
/
call dbms_xdb.deleteServletMapping('UploadFiles')
/
call dbms_xdb.deleteServletMapping('FolderProcessor')
/
call dbms_xdb.deleteServletMapping('NewFolder')
/
call dbms_xdb.deleteServletMapping('XDBReposSearch')
/
call dbms_xdb.deleteServletMapping('XMLRefProcessor')
/
call dbms_xdb.deleteServlet('SelectionProcessor')
/
call dbms_xdb.deleteServlet('VersionResources')
/
call dbms_xdb.deleteServlet('VersionHistory')
/
call dbms_xdb.deleteServlet('UploadFiles')
/
call dbms_xdb.deleteServlet('FolderProcessor')
/
call dbms_xdb.deleteServlet('NewFolder')
/
call dbms_xdb.deleteServlet('XDBReposSearch')
/
call dbms_xdb.deleteServlet('XMLRefProcessor')
/
call dbms_xdb.deleteServlet('XFilesServlet')
/
--
declare
  non_existant_dad exception;
  PRAGMA EXCEPTION_INIT( non_existant_dad , -24231 );
begin
--
  dbms_epg.drop_dad('XFILESUPLOAD');
exception
  when non_existant_dad  then
    null;
end;
/
begin
  dbms_epg.create_dad('XFILESUPLOAD','/sys/servlets/&XFILES_SCHEMA/FileUpload/*');
  dbms_epg.set_dad_attribute('XFILESUPLOAD','document-table-name','&XFILES_SCHEMA..DOCUMENT_UPLOAD_TABLE');
  dbms_epg.set_dad_attribute('XFILESUPLOAD','nls-language','american_america.al32utf8');
end;
/
begin
  dbms_epg.create_dad('XFILESREST','/sys/servlets/&XFILES_SCHEMA/RestService/*');
  dbms_epg.set_dad_attribute('XFILESREST','database-username','ANONYMOUS');
end;
/
begin
  dbms_epg.create_dad('XFILESAUTH','/sys/servlets/&XFILES_SCHEMA/Protected/*');
end;
/
call DBMS_XDB.DELETESERVLET(NAME => 'orawsv')
/
call DBMS_XDB.DELETESERVLETMAPPING(NAME => 'orawsv')
/
call DBMS_XDB.DELETESERVLETSECROLE(SERVNAME  => 'orawsv', ROLENAME  => 'XDB_WEBSERVICES' ) 
/    
call DBMS_XDB.ADDSERVLETMAPPING(PATTERN => '/orawsv/*', NAME    => 'orawsv')
/
call DBMS_XDB.ADDSERVLET
     (
        NAME     => 'orawsv',
        LANGUAGE => 'C',
        DISPNAME => 'Oracle Database Native Web Services',
        DESCRIPT => 'Servlet for issuing queries as a Web Service'
     )
/
call DBMS_XDB.ADDSERVLETSECROLE
(
   SERVNAME  => 'orawsv',               
   ROLENAME  => 'XDB_WEBSERVICES',
   ROLELINK  => 'XDB_WEBSERVICES'
)     
/
call DBMS_XDB.addMimeMapping('sql','text/plain')
/
call DBMS_XDB.addMimeMapping('log','text/plain')
/
call DBMS_XDB.addMimeMapping('ctl','text/plain')
/
commit
/
@@XFILES_DROP_OLD_OBJECTS
--
declare 
  XFILES_ROOT                  VARCHAR2(700) := '/XFILES';
  XFILES_HOME                  VARCHAR2(700) := '/home/&XFILES_SCHEMA';
                             
  UNAUTHENTICATED_DOCUMENT     VARCHAR2(700) := XFILES_ROOT || '/unauthenticated.xml';
                             
  WHOAMI_DOCUMENT              VARCHAR2(700) := XFILES_ROOT || '/whoami.xml';
  WHOAMI_RESCONFIG             VARCHAR2(700) := XFILES_HOME || '/src/xml/whoamiResConfig.xml';
                             
  AUTH_STATUS_DOCUMENT         VARCHAR2(700) := XFILES_ROOT || '/authenticationStatus.xml';
  AUTH_STATUS_RESCONFIG        VARCHAR2(700) := XFILES_HOME || '/src/xml/authStatusResConfig.xml';
                             
  PUBLISHED_CONTENT_RESCONFIG  VARCHAR2(700) := XFILES_HOME || '/src/resConfig/xfilesRedirectResConfig.xml';
  RESCONFIG_ARCHIVE            VARCHAR2(700) := '/sys/resConfig/XFILES/xfilesRedirect';

  AUTH_USERS_ACL               VARCHAR2(700) := XFILES_HOME || '/acls/xfilesUserAcl.xml';
                             
  XMLINDEX_LIST                VARCHAR2(700) := XFILES_HOME || '/configuration/xmlIndex/xmlIndexList.xml';
  XMLSCHEMA_LIST               VARCHAR2(700) := XFILES_HOME || '/configuration/xmlSchema/xmlSchemaList.xml';
                             
  V_RESULT                     BOOLEAN;
  
begin
	if DBMS_XDB.existsResource(XMLINDEX_LIST) then
    dbms_xdb.deleteResource(XMLINDEX_LIST,DBMS_XDB.DELETE_FORCE);
  end if;
  commit;

	if DBMS_XDB.existsResource(XMLSCHEMA_LIST) then
    dbms_xdb.deleteResource(XMLSCHEMA_LIST,DBMS_XDB.DELETE_FORCE);
  end if ;
  commit;

  if (DBMS_XDB.existsResource(UNAUTHENTICATED_DOCUMENT)) then
    DBMS_XDB.deleteResource(UNAUTHENTICATED_DOCUMENT);
  end if;  

  if (DBMS_XDB.existsResource(WHOAMI_DOCUMENT)) then
    DBMS_XDB.deleteResource(WHOAMI_DOCUMENT);
  end if;  

  if (DBMS_XDB.existsResource(WHOAMI_RESCONFIG)) then
    DBMS_XDB.deleteResource(WHOAMI_RESCONFIG);
  end if;

  if (DBMS_XDB.existsResource(AUTH_STATUS_DOCUMENT)) then
    DBMS_XDB.deleteResource(AUTH_STATUS_DOCUMENT);
  end if;  

  if (DBMS_XDB.existsResource(AUTH_STATUS_RESCONFIG)) then
    DBMS_XDB.deleteResource(AUTH_STATUS_RESCONFIG);
  end if;  

  if (DBMS_XDB.existsResource(PUBLISHED_CONTENT_RESCONFIG)) then
    XDB_UTILITIES.mkdir(RESCONFIG_ARCHIVE,TRUE);
    DBMS_XDB.link(PUBLISHED_CONTENT_RESCONFIG, RESCONFIG_ARCHIVE, 'resConfig-' || to_char(systimestamp,'SYYYY-MM-DD"T"HH24MISS.FFTZHTZM') || '.xml');
    DBMS_XDB.deleteResource(PUBLISHED_CONTENT_RESCONFIG);
  end if;  

  commit;

  -- Workaround for bug 9866493.

  if (DBMS_XDB.existsResource('/home/XFILES/plugins/Xinha')) then
    DBMS_XDB.deleteResource('/home/XFILES/plugins/Xinha');
  end if;
  
  -- End Workaround

  if (DBMS_XDB.existsResource(XFILES_ROOT)) then
    DBMS_XDB.deleteResource(XFILES_ROOT,DBMS_XDB.DELETE_RECURSIVE_FORCE);
  end if;
  
	if DBMS_XDB.existsResource(XFILES_HOME) then
    DBMS_XDB.deleteResource(XFILES_HOME,DBMS_XDB.DELETE_RECURSIVE_FORCE);
  end if ;
  commit;
  
  V_RESULT := DBMS_XDB.createFolder(XFILES_ROOT);
  DBMS_XDB.setAcl(XFILES_ROOT,'/sys/acls/bootstrap_acl.xml');
  DBMS_XDB.changeOwner(XFILES_ROOT,'&XFILES_SCHEMA');
  commit;

end;
/
grant connect, 
      resource, 
      alter session, 
      create table, 
      create view, 
      create synonym 
   to &XFILES_SCHEMA
/
grant create any directory, 
      drop any directory 
   to &XFILES_SCHEMA
/
--
--  Create Roles
--
create role XFILES_USER
/
grant XDB_WEBSERVICES 
   to XFILES_USER 
/
grant XDB_WEBSERVICES_OVER_HTTP 
   to XFILES_USER
/
grant XDB_WEBSERVICES_WITH_PUBLIC 
   to XFILES_USER
/
create role XFILES_ADMINISTRATOR
/
grant XDB_WEBSERVICES 
   to XFILES_ADMINISTRATOR 
 with admin option
/
grant XDB_WEBSERVICES_OVER_HTTP 
   to XFILES_ADMINISTRATOR 
 with admin option
/
grant XDB_WEBSERVICES_WITH_PUBLIC 
   to XFILES_ADMINISTRATOR 
 with admin option
/
grant XFILES_USER 
   to XFILES_ADMINISTRATOR 
 with admin option
/
grant XFILES_USER
   to &XFILES_SCHEMA
/
grant execute 
   on DBMS_AQ 
   to &XFILES_SCHEMA
/
grant ctxapp 
   to &XFILES_SCHEMA
/
ALTER SESSION SET XML_DB_EVENTS = ENABLE
/
alter session set CURRENT_SCHEMA = &XFILES_SCHEMA
/
@@XFILES_LOG_QUEUE
--
@@XFILES_REGISTER_WIKI
--
quit
