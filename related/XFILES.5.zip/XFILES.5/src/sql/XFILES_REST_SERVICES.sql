--
create or replace package XFILES_REST_SUPPORT
as
  procedure writeLogRecord(P_SERVLET_URL VARCHAR2, P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType);
  procedure writeErrorRecord(P_SERVLET_URL VARCHAR2, P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType, P_STACK_TRACE XMLType);
  procedure handleException(P_SERVLET_URL VARCHAR2, P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE,P_PARAMETERS XMLTYPE);
  procedure WRITESERVLETOUTPUTSTREAM(P_CONTENT VARCHAR2,P_CONTENT_TYPE VARCHAR2);
  procedure WRITESERVLETOUTPUTSTREAM(P_CONTENT IN OUT CLOB,P_CONTENT_TYPE VARCHAR2);
  procedure WRITESERVLETOUTPUTSTREAM(P_XML XMLTYPE, P_CONTENT_TYPE BOOLEAN DEFAULT TRUE);
end;
/
show errors
--
create or replace package body XFILES_REST_SUPPORT
as
--
procedure writeLogRecord(P_SERVLET_URL VARCHAR2, P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType)
as
begin
  XFILES_LOGGING.writeLogRecord(P_SERVLET_URL, P_MODULE_NAME, P_INIT_TIME, P_PARAMETERS);
end;
--
procedure writeErrorRecord(P_SERVLET_URL VARCHAR2, P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType, P_STACK_TRACE XMLType)
as
begin
  XFILES_LOGGING.writeErrorRecord(P_SERVLET_URL ,P_MODULE_NAME, P_INIT_TIME, P_PARAMETERS, P_STACK_TRACE);
end;
--
procedure handleException(P_SERVLET_URL VARCHAR2, P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE,P_PARAMETERS XMLTYPE)
as
  V_STACK_TRACE XMLType;
  V_RESULT      boolean;
begin
  V_STACK_TRACE := XFILES_LOGGING.captureStackTrace();
  writeErrorRecord(P_SERVLET_URL, P_MODULE_NAME,P_INIT_TIME,P_PARAMETERS,V_STACK_TRACE);
  rollback; 
end;
--
procedure WRITESERVLETOUTPUTSTREAM(P_CONTENT VARCHAR2,P_CONTENT_TYPE VARCHAR2)
as
  V_CONTENT_SIZE   BINARY_INTEGER := 0;
begin
	OWA_UTIL.MIME_HEADER(P_CONTENT_TYPE,FALSE);
	V_CONTENT_SIZE := LENGTH(P_CONTENT);
  htp.p('Content-Length: ' || V_CONTENT_SIZE);
  owa_util.http_header_close;
  htp.prn(P_CONTENT);
  htp.flush();
end;
--	
procedure WRITESERVLETOUTPUTSTREAM(P_CONTENT IN OUT CLOB,P_CONTENT_TYPE VARCHAR2)
as
  V_BUFFER         VARCHAR2(8000) ;
  V_OFFSET         BINARY_INTEGER := 1;
  V_AMOUNT         BINARY_INTEGER := 4196;
  V_BYTES_COPIED   BINARY_INTEGER := 0;
  V_CONTENT_SIZE   BINARY_INTEGER := 0;
begin
	OWA_UTIL.MIME_HEADER(P_CONTENT_TYPE,FALSE);
	V_CONTENT_SIZE := DBMS_LOB.getLength(P_CONTENT);
  htp.p('Content-Length: ' || V_CONTENT_SIZE);
  owa_util.http_header_close;
	while (V_OFFSET < V_CONTENT_SIZE) loop
	  V_BUFFER := DBMS_LOB.SUBSTR(P_CONTENT,V_AMOUNT,V_OFFSET);
    V_BYTES_COPIED := LENGTHB(V_BUFFER);
    IF (V_OFFSET + V_BYTES_COPIED) > V_CONTENT_SIZE THEN
      V_BUFFER := SUBSTR(V_BUFFER,1,(V_CONTENT_SIZE - V_OFFSET)+1);
      V_BYTES_COPIED := LENGTH(V_BUFFER);
    end if;
    htp.prn(V_BUFFER);
    V_OFFSET := V_OFFSET + V_BYTES_COPIED;
  end loop;
  htp.flush();
  DBMS_LOB.FREETEMPORARY(P_CONTENT);
end;
--	
procedure WRITESERVLETOUTPUTSTREAM(P_XML XMLTYPE, P_CONTENT_TYPE BOOLEAN DEFAULT TRUE)
as
  V_SERIALIZED_XML CLOB;
begin
	if (P_CONTENT_TYPE) THEN
	  select XMLSERIALIZE(DOCUMENT P_XML AS CLOB INDENT SIZE = 2)
	    into V_SERIALIZED_XML 
	    from dual;
	else
	  select XMLSERIALIZE(DOCUMENT P_XML AS CLOB)
	    into V_SERIALIZED_XML 
	    from dual;
	end if;
	writeServletOutputStream(V_SERIALIZED_XML,'text/xml');
end;
--
end;
/
create or replace package XFILES_REST_SERVICES
AUTHID CURRENT_USER
as
  C_DEFAULT_TEMPLATE_PATH   constant VARCHAR2(700) := '/XFILES/lite/Folder.html';
  C_DEFAULT_STYLESHEET_PATH constant VARCHAR2(700) := '/XFILES/lite/xsl/FolderBrowser.xsl';
  
  function DEFAULT_TEMPLATE_PATH   return VARCHAR2 deterministic;
  function DEFAULT_STYLESHEET_PATH return VARCHAR2 deterministic;
  
  function getResource(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0) return XMLType;
  function getResourceWithContent(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0) return XMLType;
  function getFolderListing(P_FOLDER_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0) return XMLType;

  procedure getResource(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0);
  procedure getResourceWithContent(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0);
  procedure getFolderListing(P_FOLDER_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0);

  procedure enableRSSIcon(P_FOLDER_PATH VARCHAR2);
  procedure enableRSSIcon(P_RESOURCE_PATH VARCHAR2,P_TEMPLATE_PATH VARCHAR2,P_STYLESHEET_PATH VARCHAR2,P_FORCE_AUTHENTICATION VARCHAR2);
  procedure generateRSSFeed(P_RESOURCE_PATH VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0);
  procedure RENDERDOCUMENT(P_RESOURCE_PATH VARCHAR2, P_CONTENT_TYPE VARCHAR2);

  procedure whoami;
  procedure doAuthentication;
  procedure showSourceCode(SOURCECODE VARCHAR2);

  procedure WRITELOGRECORD(LOG_RECORD VARCHAR2);

end;
/
show errors
--
create or replace package body XFILES_REST_SERVICES
as
--
  JAVA_SERVLET_URL VARCHAR2(1024) := '/sys/servlets/XFILES/XFilesSupport/dbRestServices/&XFILES_SCHEMA/XFILES_REST_SERVICES/';
  EPG_SERVLET_URL VARCHAR2(1024)  := '/sys/servlets/XFILES/RestService/&XFILES_SCHEMA..XFILES_REST_SERVICES.';
--	
--
function DEFAULT_TEMPLATE_PATH 
return VARCHAR2 deterministic
as
begin
	return C_DEFAULT_TEMPLATE_PATH;
end;
--
function DEFAULT_STYLESHEET_PATH 
return VARCHAR2 deterministic
as
begin
	return C_DEFAULT_STYLESHEET_PATH;
end;
--
function getResource(P_SERVLET_URL VARCHAR2, P_RESOURCE_PATH in VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;

  V_RESOURCE XMLType;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET)
         )
    into V_PARAMETERS
    from dual;
  
  XDB_REPOSITORY_SERVICES.getResource(P_RESOURCE_PATH, FALSE, P_TIMEZONE_OFFSET, V_RESOURCE);
  XFILES_REST_SUPPORT.writeLogRecord(P_SERVLET_URL,'GETRESOURCE',V_INIT,V_PARAMETERS);
  return V_RESOURCE;
exception
  when others then
    XFILES_REST_SUPPORT.handleException(P_SERVLET_URL,'GETRESOURCE',V_INIT,V_PARAMETERS);
    raise;
end;
--
function getResource(P_RESOURCE_PATH in VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
return XMLType
as
begin
  return getResource(P_SERVLET_URL => JAVA_SERVLET_URL, P_RESOURCE_PATH => P_RESOURCE_PATH, P_TIMEZONE_OFFSET => P_TIMEZONE_OFFSET);
end;
-- 
procedure getResource(P_RESOURCE_PATH in VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
as
  V_RESOURCE XMLType;
begin
	V_RESOURCE := getResource(P_SERVLET_URL => EPG_SERVLET_URL, P_RESOURCE_PATH => P_RESOURCE_PATH, P_TIMEZONE_OFFSET => P_TIMEZONE_OFFSET);
	XFILES_REST_SUPPORT.writeServletOutputStream(V_RESOURCE, FALSE);
end;
--
function getResourceWithContent(P_SERVLET_URL VARCHAR2, P_RESOURCE_PATH in VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;

  V_RESOURCE XMLType;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.getResource(P_RESOURCE_PATH, TRUE, P_TIMEZONE_OFFSET, V_RESOURCE);
  XFILES_REST_SUPPORT.writeLogRecord(P_SERVLET_URL,'GETRESOURCEWITHCONTENT',V_INIT,V_PARAMETERS);
  return V_RESOURCE;
exception
  when others then
    XFILES_REST_SUPPORT.handleException(P_SERVLET_URL,'GETRESOURCEWITHCONTENT',V_INIT,V_PARAMETERS);
    raise;
end;
--
function getResourceWithContent(P_RESOURCE_PATH in VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
return XMLType
as
begin
  return getResourceWithContent(P_SERVLET_URL => JAVA_SERVLET_URL, P_RESOURCE_PATH => P_RESOURCE_PATH, P_TIMEZONE_OFFSET => P_TIMEZONE_OFFSET);
end;
--
procedure getResourceWithContent(P_RESOURCE_PATH in VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
as
  V_RESOURCE XMLType;
begin
	V_RESOURCE := getResourceWithContent(P_SERVLET_URL => EPG_SERVLET_URL, P_RESOURCE_PATH => P_RESOURCE_PATH, P_TIMEZONE_OFFSET => P_TIMEZONE_OFFSET);
	XFILES_REST_SUPPORT.writeServletOutputStream(V_RESOURCE, FALSE);
end;
--
function getFolderListing(P_SERVLET_URL VARCHAR2, P_FOLDER_PATH in VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;

  V_RESOURCE XMLType;
  V_CHILDREN XMLType;
begin
  select xmlConcat
         (
           xmlElement("FolderPath",P_FOLDER_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.getFolderListing(P_FOLDER_PATH, P_TIMEZONE_OFFSET, V_RESOURCE, V_CHILDREN);
  V_RESOURCE := V_RESOURCE.appendChildXML('/Resource',V_CHILDREN,'xmlns="http://xmlns.oracle.com/xdb/XDBResource.xsd"');
  XFILES_REST_SUPPORT.writeLogRecord(P_SERVLET_URL,'GETFOLDERLISTING',V_INIT,V_PARAMETERS);
  return V_RESOURCE;
exception
  when others then
    XFILES_REST_SUPPORT.handleException(P_SERVLET_URL,'GETFOLDERLISTING',V_INIT,V_PARAMETERS);
    raise;
end;
--
function getFolderListing(P_FOLDER_PATH in VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
return XMLType
as
begin
  return getFolderListing(P_SERVLET_URL => JAVA_SERVLET_URL, P_FOLDER_PATH => P_FOLDER_PATH, P_TIMEZONE_OFFSET => P_TIMEZONE_OFFSET);
end;
--

procedure getFolderListing(P_FOLDER_PATH in VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
as
  V_RESOURCE XMLType;
begin
	V_RESOURCE := getFolderListing(P_SERVLET_URL => EPG_SERVLET_URL, P_FOLDER_PATH => P_FOLDER_PATH, P_TIMEZONE_OFFSET => P_TIMEZONE_OFFSET);
	XFILES_REST_SUPPORT.writeServletOutputStream(V_RESOURCE, FALSE);
end;
--
function generateRSSFeed(P_SERVLET_URL VARCHAR2, P_RESOURCE_PATH VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0) 
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;

  V_RSS_DOCUMENT      DBMS_XMLDOM.DOMDocument;
  V_NODE              DBMS_XMLDOM.DOMNode;
  V_ITEM	            DBMS_XMLDOM.DOMNode;
  V_RSS_CHANNEL       DBMS_XMLDOM.DOMNode;
  V_RSS_ROOT          DBMS_XMLDOM.DOMElement;
  
  cursor getResource
  is
  select DISPLAY_NAME, DESCRIPTION
    from RESOURCE_VIEW rv,
         XMLTable
         (
           xmlNamespaces
           (
             default 'http://xmlns.oracle.com/xdb/XDBResource.xsd'
           ),
           '/Resource' passing rv.RES
           columns
           DISPLAY_NAME varchar2(128)                 path 'DisplayName',
           DESCRIPTION  varchar2(4000)                path 'Comment'
         ) r     
   where equals_path(res,P_RESOURCE_PATH) = 1;

  cursor getChildren
  is
  select ANY_PATH, DISPLAY_NAME, DESCRIPTION, AUTHOR, MODIFICATION_DATE
    from RESOURCE_VIEW rv,
         XMLTable
         (
           xmlNamespaces
           (
             default 'http://xmlns.oracle.com/xdb/XDBResource.xsd'
           ),
           '/Resource' passing rv.RES
           columns
           DISPLAY_NAME varchar2(128)                 path 'DisplayName',
           DESCRIPTION  varchar2(4000)                path 'Comment',
           AUTHOR       varchar2(128)                 path 'Author',
           MODIFICATION_DATE TIMESTAMP with TIME ZONE path 'ModificationDate'
         ) r     
   where under_path(res,1,P_RESOURCE_PATH) = 1;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET)
         )
    into V_PARAMETERS
    from dual;

  V_RSS_DOCUMENT := DBMS_XMLDOM.newDOMDocument();
  V_RSS_ROOT := DBMS_XMLDOM.createElement(V_RSS_DOCUMENT,'rss');
  V_RSS_ROOT := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(DBMS_XMLDOM.makeNode(V_RSS_DOCUMENT),DBMS_XMLDOM.makeNode(V_RSS_ROOT)));
  DBMS_XMLDOM.setAttribute(V_RSS_ROOT,'version','2.0');
  
  V_RSS_CHANNEL := DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createElement(V_RSS_DOCUMENT,'channel'));
  V_RSS_CHANNEL := DBMS_XMLDOM.appendChild(DBMS_XMLDOM.makeNode(V_RSS_ROOT),V_RSS_CHANNEL);

  for r in getResource() loop
    V_NODE := DBMS_XMLDOM.appendChild(V_RSS_CHANNEL,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createElement(V_RSS_DOCUMENT,'title')));
    V_NODE := DBMS_XMLDOM.appendChild(V_NODE,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createTextNode(V_RSS_DOCUMENT,r.DISPLAY_NAME)));
    V_NODE := DBMS_XMLDOM.appendChild(V_RSS_CHANNEL,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createElement(V_RSS_DOCUMENT,'description')));
    V_NODE := DBMS_XMLDOM.appendChild(V_NODE,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createTextNode(V_RSS_DOCUMENT,r.DESCRIPTION)));
  end loop;
  
  for c in getChildren() loop
    V_ITEM := DBMS_XMLDOM.appendChild(V_RSS_CHANNEL,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createElement(V_RSS_DOCUMENT,'item')));
    V_NODE := DBMS_XMLDOM.appendChild(V_ITEM,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createElement(V_RSS_DOCUMENT,'title')));
    V_NODE := DBMS_XMLDOM.appendChild(V_NODE,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createTextNode(V_RSS_DOCUMENT,c.DISPLAY_NAME)));
    V_NODE := DBMS_XMLDOM.appendChild(V_ITEM,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createElement(V_RSS_DOCUMENT,'description')));
    V_NODE := DBMS_XMLDOM.appendChild(V_NODE,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createTextNode(V_RSS_DOCUMENT,c.DESCRIPTION)));
    V_NODE := DBMS_XMLDOM.appendChild(V_ITEM,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createElement(V_RSS_DOCUMENT,'link')));
    V_NODE := DBMS_XMLDOM.appendChild(V_NODE,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createTextNode(V_RSS_DOCUMENT,c.ANY_PATH)));
    V_NODE := DBMS_XMLDOM.appendChild(V_ITEM,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createElement(V_RSS_DOCUMENT,'author')));
    V_NODE := DBMS_XMLDOM.appendChild(V_NODE,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createTextNode(V_RSS_DOCUMENT,c.AUTHOR)));
    V_NODE := DBMS_XMLDOM.appendChild(V_ITEM,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createElement(V_RSS_DOCUMENT,'pubdata')));
    V_NODE := DBMS_XMLDOM.appendChild(V_NODE,DBMS_XMLDOM.makeNode(DBMS_XMLDOM.createTextNode(V_RSS_DOCUMENT,c.MODIFICATION_DATE)));
  end loop;
  
  XFILES_REST_SUPPORT.writeLogRecord(P_SERVLET_URL,'GENERATERSSFEED',V_INIT,V_PARAMETERS);
  return DBMS_XMLDOM.getXMLType(V_RSS_DOCUMENT);
exception
  when others then
    XFILES_REST_SUPPORT.handleException(P_SERVLET_URL,'GENERATERSSFEED',V_INIT,V_PARAMETERS);
    raise;
end;
--
function generateRSSFeed(P_RESOURCE_PATH VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0) 
return XMLType
as
begin
	return generateRSSFeed(P_SERVLET_URL => JAVA_SERVLET_URL, P_RESOURCE_PATH => P_RESOURCE_PATH, P_TIMEZONE_OFFSET => P_TIMEZONE_OFFSET);
end;
--
procedure generateRSSFeed(P_RESOURCE_PATH VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0) 
as
  V_FOLDER_RSS XMLType;
begin
	V_FOLDER_RSS := generateRSSFeed(P_SERVLET_URL => EPG_SERVLET_URL, P_RESOURCE_PATH => P_RESOURCE_PATH, P_TIMEZONE_OFFSET => P_TIMEZONE_OFFSET);
	XFILES_REST_SUPPORT.writeServletOutputStream(V_FOLDER_RSS, FALSE);
end;
--
function WHOAMI(P_SERVLET_URL VARCHAR2) 
return XMLType  
as
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_WHOAMI            XMLType;
begin
  select xmlElement("User",USER) into V_WHOAMI from DUAL;
  XFILES_REST_SUPPORT.writeLogRecord(P_SERVLET_URL,'WHOAMI',V_INIT,NULL);
  return V_WHOAMI;
exception
  when others then
    XFILES_REST_SUPPORT.handleException(P_SERVLET_URL,'WHOAMI',V_INIT,null);
    raise;
end;
--
function WHOAMI
return XMLType
as
begin
	 return WHOAMI(P_SERVLET_URL => JAVA_SERVLET_URL);
end;
--
procedure WHOAMI
as
  V_RESULT XMLType;
begin
	V_RESULT := WHOAMI(P_SERVLET_URL => EPG_SERVLET_URL);
	XFILES_REST_SUPPORT.writeServletOutputStream(V_RESULT, FALSE);
end;
--
procedure ENABLERSSICON(P_RESOURCE_PATH VARCHAR2,P_TEMPLATE_PATH VARCHAR2,P_STYLESHEET_PATH VARCHAR2,P_FORCE_AUTHENTICATION VARCHAR2)
--
-- Generates a HTML Page which will enable the Browser's RSS Icon. To enable the ICON the pages HEAD element has to contain a 
-- <link rel="alternate" type="application/rss+xml".. element that provides the link to RSS feed for the page
--
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;

  V_HTML_PAGE VARCHAR2(32000);
begin
	  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TemplatePath",P_TEMPLATE_PATH),
           xmlElement("StylesheetPath",P_STYLESHEET_PATH),
           xmlElement("forceAuthentication",P_FORCE_AUTHENTICATION)
         )
    into V_PARAMETERS
    from dual;

  V_HTML_PAGE := xdburitype(P_TEMPLATE_PATH).getClob();
	V_HTML_PAGE := REPLACE(V_HTML_PAGE,'<link id="enableRSSIcon"/>','<link id="rssEnabled" rel="alternate" type="application/rss+xml" title="RSS Feed for %P_RESOURCE_PATH%" href="/sys/servlets/XFILES/RestService/XFILES.XFILES_REST_SERVICES.GENERATERSSFEED?P_RESOURCE_PATH=%P_RESOURCE_PATH%"/>');
  V_HTML_PAGE := REPLACE(V_HTML_PAGE,'%P_RESOURCE_PATH%',P_RESOURCE_PATH);
  V_HTML_PAGE := REPLACE(V_HTML_PAGE,'%INIT%','initRSS(document.getElementById(''pageContent''),''' || P_RESOURCE_PATH || ''',''' || P_STYLESHEET_PATH || ''',''' || P_FORCE_AUTHENTICATION || ''');');

 	XFILES_REST_SUPPORT.writeServletOutputStream(V_HTML_PAGE, 'text/html');
	XFILES_REST_SUPPORT.writeLogRecord(EPG_SERVLET_URL,'ENABLERSSICON',V_INIT,V_PARAMETERS);
exception
  when others then
    XFILES_REST_SUPPORT.handleException(EPG_SERVLET_URL,'ENABLERSSICON',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure ENABLERSSICON(P_FOLDER_PATH VARCHAR2)
--
-- Generates a HTML Page which will enable the Browser's RSS Icon. To enable the ICON the pages HEAD element has to contain a 
-- <link rel="alternate" type="application/rss+xml".. element that provides the link to RSS feed for the page
--
as
begin
	ENABLERSSICON(P_FOLDER_PATH,XFILES_REST_SERVICES.DEFAULT_TEMPLATE_PATH,XFILES_REST_SERVICES.DEFAULT_STYLESHEET_PATH,'false');
end;
--
procedure DOAUTHENTICATION 
as
  V_PARAMETERS        XMLType;
  
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_WHOAMI            XMLType := NULL;
begin
	select xmlElement("currentUser",USER)
	  into V_PARAMETERS
	  from DUAL;
         
	if (USER = 'ANONYMOUS') then
	  -- htp.p('WWW-Authenticate: Basic realm="XDB"');
		owa_util.status_line(401,'Authorization Required',TRUE);
  else	
    select xmlElement("User",USER) into V_WHOAMI from DUAL;
   	XFILES_REST_SUPPORT.writeServletOutputStream(V_WHOAMI, FALSE);
  end if;

  XFILES_REST_SUPPORT.writeLogRecord(EPG_SERVLET_URL,'DOAUTHENTICATION',V_INIT,V_PARAMETERS);
exception
  when others then
    XFILES_REST_SUPPORT.handleException(EPG_SERVLET_URL,'DOAUTHENTICATION',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure SHOWSOURCECODE(SOURCECODE VARCHAR2)
as
begin
	OWA_UTIL.MIME_HEADER('text/xml',FALSE);
  htp.p('Content-Length: ' || length(SOURCECODE));
  owa_util.http_header_close;
  htp.print(SOURCECODE);
  htp.flush();
end;
--	
procedure RENDERDOCUMENT(P_RESOURCE_PATH VARCHAR2, P_CONTENT_TYPE VARCHAR2)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RENDERING         CLOB;

begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("ContentType",P_CONTENT_TYPE)
         )
    into V_PARAMETERS
    from dual;
    
  if (P_CONTENT_TYPE = 'text/plain') THEN  
    V_RENDERING := XFILES_UTILITIES.RENDERASTEXT(P_RESOURCE_PATH);
  else
    V_RENDERING := XFILES_UTILITIES.RENDERASHTML(P_RESOURCE_PATH);
  end if;  
  
  XFILES_REST_SUPPORT.WRITESERVLETOUTPUTSTREAM(V_RENDERING,P_CONTENT_TYPE);
  -- DBMS_LOB.freeTemporary(V_RENDERING);

  XFILES_REST_SUPPORT.writeLogRecord(EPG_SERVLET_URL,'RENDERDOCUMENT',V_INIT,V_PARAMETERS);
exception
  when others then
    XFILES_REST_SUPPORT.handleException(EPG_SERVLET_URL,'RENDERDOCUMENT',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure WRITELOGRECORD(LOG_RECORD VARCHAR2)
as
begin
  &XFILES_SCHEMA..XFILES_LOGWRITER.ENQUEUE_LOG_RECORD(XMLTYPE(LOG_RECORD));
  XFILES_REST_SUPPORT.WRITESERVLETOUTPUTSTREAM('Success','text/plain');
end;
--
end;
/
show errors
--