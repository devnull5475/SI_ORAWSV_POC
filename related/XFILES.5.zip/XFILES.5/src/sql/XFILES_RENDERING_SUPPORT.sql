--
create or replace package XFILES_RENDERING
authid DEFINER
as
  function renderAsHTML(P_SOURCE_DOC BLOB) return CLOB;
  function renderAsText(P_SOURCE_DOC BLOB) return CLOB;
end;
/
show errors
--
create or replace package body XFILES_RENDERING
as
--
function renderAsHTML(P_SOURCE_DOC BLOB) 
return CLOB
as
  V_HTML_CONTENT CLOB;
begin
  dbms_lob.createTemporary(V_HTML_CONTENT,true,DBMS_LOB.SESSION);
  ctx_doc.policy_filter(policy_name => 'XFILES_HTML_GENERATION',
                        document => P_SOURCE_DOC,
                        restab => V_HTML_CONTENT,
                        plaintext => false);
  return V_HTML_CONTENT;
end;
--
function renderAsText(P_SOURCE_DOC BLOB) 
return CLOB
as
  V_CONTENT CLOB;
begin
  dbms_lob.createTemporary(V_CONTENT,true,DBMS_LOB.SESSION);
  ctx_doc.policy_filter(policy_name => 'XFILES_HTML_GENERATION',
                        document => P_SOURCE_DOC,
                        restab => V_CONTENT,
                        plaintext => true);
  return V_CONTENT;
end;
--
end;
/
show errors
--