--
call xdb_utilities.createHomeFolder()
/
declare
  V_RESULT boolean;
begin
  if dbms_xdb.existsResource('/home/&XFILES_SCHEMA/configuration') then 
    dbms_xdb.deleteResource('/home/&XFILES_SCHEMA/configuration',DBMS_XDB.DELETE_RECURSIVE);
  end if;

  V_RESULT := dbms_xdb.createFolder('/home/&XFILES_SCHEMA/configuration');

  commit;

  --
  -- Icons : FAMFAMFAM
  -- 

  if dbms_xdb.existsResource('/home/&XFILES_SCHEMA/icons') then 
    dbms_xdb.deleteResource('/home/&XFILES_SCHEMA/icons',DBMS_XDB.DELETE_RECURSIVE);
  end if;

  V_RESULT := dbms_xdb.createFolder('/home/&XFILES_SCHEMA/icons');
  V_RESULT := dbms_xdb.createFolder('/home/&XFILES_SCHEMA/icons/famfamfam');

  commit;
  
  --
  -- Plugins : XINHA
  -- 

  if dbms_xdb.existsResource('/home/&XFILES_SCHEMA/plugins') then 
    dbms_xdb.deleteResource('/home/&XFILES_SCHEMA/plugins',DBMS_XDB.DELETE_RECURSIVE);
  end if;

  V_RESULT := dbms_xdb.createFolder('/home/&XFILES_SCHEMA/plugins');

  commit;
  
end;
/
--
