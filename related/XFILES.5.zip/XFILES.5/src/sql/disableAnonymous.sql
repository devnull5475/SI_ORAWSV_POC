set echo on
spool disableAnonymous.log
--
connect sys/&1 as sysdba
--
alter user anonymous account lock
/
declare
  xdbconfig xmltype; 
begin
  xdbconfig := dbms_xdb.cfg_get();
  if (xdbConfig.existsNode('/xdbconfig/sysconfig/protocolconfig/httpconfig/allow-repository-anonymous-access')) = 1 then
    select deleteXML
           (
             xdbconfig,
             '/xdbconfig/sysconfig/protocolconfig/httpconfig/allow-repository-anonymous-access',
             'xmlns="http://xmlns.oracle.com/xdb/xdbconfig.xsd"'
           )
      into xdbconfig
      from dual;
    
    dbms_xdb.cfg_update(xdbconfig);
  end if;
end;
/
quit
