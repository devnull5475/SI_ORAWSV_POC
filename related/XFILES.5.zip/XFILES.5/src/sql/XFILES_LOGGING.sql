--
create or replace package XFILES_LOGGING
as
  procedure writeLogRecord(P_PACKAGE_URL VARCHAR2, P_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType);
  procedure writeErrorRecord(P_PACKAGE_URL VARCHAR2, P_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType, V_STACK_TRACE XMLType);
  function captureStackTrace return XMLType;
end;  
/
show errors
--
create or replace package body XFILES_LOGGING
as
procedure writeLogRecord(P_PACKAGE_URL VARCHAR2, P_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType)
as
  PRAGMA AUTONOMOUS_TRANSACTION;
  V_LOG_RECORD XMLType;
begin

  select XMLElement
         (
           "XFilesLogRecord",
           xmlElement("RequestURL", P_PACKAGE_URL || P_NAME || + '()'),
           xmlElement("User",USER),
           xmlElement
           (
             "Timestamps",
             xmlElement("Init",P_INIT_TIME),
             xmlElement("Complete",SYSTIMESTAMP)
           ),
           xmlElement
           (
             "Parameters",
             P_PARAMETERS
           )
         )
    into V_LOG_RECORD
    from dual;

  XFILES_LOGWRITER.ENQUEUE_LOG_RECORD(V_LOG_RECORD);
  commit;

end;
--
procedure writeErrorRecord(P_PACKAGE_URL VARCHAR2, P_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType, V_STACK_TRACE XMLType)
as
  PRAGMA AUTONOMOUS_TRANSACTION;
  V_LOG_RECORD XMLType;
begin

  select XMLElement
         (
           "XFilesErrorRecord",
           xmlElement("RequestURL",P_PACKAGE_URL || P_NAME || + '()'),
           xmlElement("User",USER),
           xmlElement
           (
             "Timestamps",
             xmlElement("Init",P_INIT_TIME),
             xmlElement("Complete",SYSTIMESTAMP)
           ),
           xmlElement
           (
             "Parameters",
             P_PARAMETERS
           ),
           V_STACK_TRACE
         )
    into V_LOG_RECORD
    from dual;
    
  XFILES_LOGWRITER.ENQUEUE_LOG_RECORD(V_LOG_RECORD);
  commit;

end;
--
function captureStackTrace
return XMLType
as
  V_STACK_TRACE XMLType;
begin
  select xmlElement
         (
           "Error",
           xmlElement
           (
             "Stack",
             xmlCDATA(DBMS_UTILITY.FORMAT_ERROR_STACK())
           ),
           xmlElement
           (
             "BackTrace",
             xmlCDATA(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE())
           )
         )
    into V_STACK_TRACE
    from DUAL;
   
    return V_STACK_TRACE;
end;
--
end;
/
show errors
--
