set echo on
spool clearLogging.log
--
DEF DBA=&1
--
DEF DBAPASSWORD = &2
--
DEF TNSALIAS = &3
--
DEF XFILES_SCHEMA = &4
--
connect &DBA/&DBAPASSWORD@&TNSALIAS
--
select count(*) from &XFILES_SCHEMA..XFILES_LOG_RECORDS
/
select count(*) from &XFILES_SCHEMA..LOG_RECORD_QUEUE_TABLE
/
declare 
  pending          number(32);  
  i                number(32);
  deq_ct           dbms_aq.dequeue_options_t;
  msg_prop         dbms_aq.message_properties_t;
  enq_msgid        raw(16);
  V_LOG_RECORD      XMLType;
  V_LOG_RECORD_REF  REF XMLType;
  V_USER            VARCHAR2(32);
  V_TIMESTAMP       TIMESTAMP(6) WITH TIME ZONE;
  V_LOG_RECORD_TYPE VARCHAR2(256);  
begin
   select count(*)
     into PENDING
     from &XFILES_SCHEMA..LOG_RECORD_QUEUE_TABLE;
     
   if (PENDING > 0) then
     for i in 1..PENDING loop
       DBMS_AQ.DEQUEUE('&XFILES_SCHEMA..LOG_RECORD_Q', deq_ct, msg_prop, V_LOG_RECORD, enq_msgid);
      
       insert into &XFILES_SCHEMA..XFILES_LOG_TABLE x 
         values(V_LOG_RECORD)
         returning ref(x) INTO V_LOG_RECORD_REF;

  -- Generate the Filename from the Log Record.

      select LOG_USER, LOG_TIMESTAMP, LOG_RECORD_TYPE
        INTO V_USER,   V_TIMESTAMP, V_LOG_RECORD_TYPE
        from XMLTABLE(
               '/*'
               passing V_LOG_RECORD
               COLUMNS
               LOG_USER         VARCHAR2(32)                path 'User',
               LOG_TIMESTAMP    TIMESTAMP(6) WITH TIME ZONE path 'Timestamps/Init',
               LOG_RECORD_TYPE  VARCHAR2(32)                path 'fn:local-name(.)'
             );

	     XFILES_LOGWRITER.PROCESSLOGRECORD(V_LOG_RECORD_REF, V_USER, V_TIMESTAMP, V_LOG_RECORD_TYPE);
     end loop;
   end if;
end;
/
select count(*) from &XFILES_SCHEMA..XFILES_LOG_RECORDS
/
select count(*) from &XFILES_SCHEMA..LOG_RECORD_QUEUE_TABLE
/
DECLARE
  po dbms_aqadm.aq$_purge_options_t;
BEGIN
   commit;
   po.block := TRUE;
   DBMS_AQADM.PURGE_QUEUE_TABLE(
     queue_table     => '&XFILES_SCHEMA..LOG_RECORD_QUEUE_TABLE',
     purge_condition => NULL,
     purge_options   => po);
   commit;
END;
/
