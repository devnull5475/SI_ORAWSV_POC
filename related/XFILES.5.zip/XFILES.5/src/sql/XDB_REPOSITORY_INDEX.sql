set echo on 
spool XDB_REPOSITORY_INDEX.log
--
def DBA = &1
--
def DBAPASSWORD = &2
---
DEF TNSALIAS = &3
--
alter user xdb identified by xdb account unlock
/
connect xdb/xdb@&TNSALIAS
--
call dbms_xdbt.dropPreferences()	
/
call dbms_xdbt.createPreferences()	
/
call dbms_xdbt.createIndex()
/
call dbms_xdbt.configureautosync()
/
connect &DBA/&DBAPASSWORD@&TNSALIAS
--
alter user xdb identified by xdb account lock
/
quit
 
