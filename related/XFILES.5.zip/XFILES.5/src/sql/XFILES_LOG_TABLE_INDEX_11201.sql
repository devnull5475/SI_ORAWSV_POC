create index LOG_RECORD_INDEX on XFILES_LOG_TABLE(OBJECT_VALUE)
indextype is XDB.xmlIndex
parameters (
            '    PATH TABLE LOG_RECORD_PATH_TABLE
                PIKEY INDEX LOG_RECORD_PI_IDX
                VALUE INDEX LOG_RECORD_VALUE_IDX
              PATH ID INDEX LOG_RECORD_PATH_IDX
            ORDER KEY INDEX LOG_RECORD_ORDER_IDX'
           )
/
