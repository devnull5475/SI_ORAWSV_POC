--
create or replace package XFILES_SOAP_SERVICES
AUTHID CURRENT_USER
as
  procedure CHANGEOWNER(P_RESOURCE_PATH VARCHAR2, P_NEW_OWNER VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure CHANGEOWNERLIST(P_RESOURCE_LIST XMLTYPE, P_NEW_OWNER VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure CHECKIN(P_RESOURCE_PATH VARCHAR2,P_COMMENT VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure CHECKINLIST(P_RESOURCE_LIST XMLTYPE,P_COMMENT VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure CHECKOUT(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure CHECKOUTLIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure COPYRESOURCE(P_RESOURCE_PATH VARCHAR2, P_TARGET_FOLDER VARCHAR2,P_DEEP BOOLEAN DEFAULT FALSE);
  procedure COPYRESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_TARGET_FOLDER VARCHAR2,P_DEEP BOOLEAN DEFAULT FALSE);
  procedure CREATENEWFOLDER(P_FOLDER_PATH VARCHAR2, P_DESCRIPTION VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_UPDATED_RESOURCE IN OUT XMLType, P_UPDATED_CHILDREN  IN OUT XMLType);
  procedure CREATENEWWIKIPAGE(P_RESOURCE_PATH VARCHAR2, P_DESCRIPTION VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_UPDATED_RESOURCE IN OUT XMLType, P_UPDATED_CHILDREN  IN OUT XMLType);
  procedure CREATEZIPFILE(P_RESOURCE_PATH VARCHAR2, P_DESCRIPTION VARCHAR2, P_RESOURCE_LIST XMLType,  P_TIMEZONE_OFFSET NUMBER DEFAULT 0,P_UPDATED_RESOURCE IN OUT XMLType, P_UPDATED_CHILDREN  IN OUT XMLType);
  procedure DELETERESOURCE(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE, P_FORCE BOOLEAN DEFAULT FALSE);  
  procedure DELETERESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN DEFAULT FALSE, P_FORCE BOOLEAN DEFAULT FALSE);  
  procedure LINKRESOURCE(P_RESOURCE_PATH VARCHAR2, P_TARGET_FOLDER VARCHAR2, P_LINK_TYPE NUMBER DEFAULT DBMS_XDB.LINK_TYPE_WEAK);  
  procedure LINKRESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_TARGET_FOLDER VARCHAR2, P_LINK_TYPE NUMBER DEFAULT DBMS_XDB.LINK_TYPE_WEAK);  
  procedure LOCKRESOURCE(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure LOCKRESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure MAKEVERSIONED(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure MAKEVERSIONEDLIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure MOVERESOURCE(P_RESOURCE_PATH VARCHAR2, P_TARGET_FOLDER VARCHAR2);
  procedure MOVERESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_TARGET_FOLDER VARCHAR2);
  procedure PUBLISHRESOURCE(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure PUBLISHRESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure RENAMERESOURCE(P_RESOURCE_PATH VARCHAR2, P_NEW_NAME VARCHAR2);
  procedure SETACL(P_RESOURCE_PATH VARCHAR2, P_ACL_PATH VARCHAR2,P_DEEP BOOLEAN DEFAULT FALSE);
  procedure SETACLLIST(P_RESOURCE_LIST XMLTYPE, P_ACL_PATH VARCHAR2,P_DEEP BOOLEAN DEFAULT FALSE);
  procedure SETRSSFEED(P_FOLDER_PATH VARCHAR2, P_ENABLE BOOLEAN, P_ITEMS_CHANGED_IN VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure SETCUSTOMVIEWER(P_RESOURCE_PATH VARCHAR2, P_VIEWER_PATH VARCHAR2);
  procedure SETCUSTOMVIEWERLIST(P_RESOURCE_LIST XMLTYPE, P_VIEWER_PATH VARCHAR2);
  procedure UNLOCKRESOURCE(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure UNLOCKRESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN DEFAULT FALSE);
  procedure UNZIP(P_FOLDER_PATH VARCHAR2, P_RESOURCE_PATH VARCHAR2, P_DUPLICATE_ACTION VARCHAR2);
  procedure UNZIPLIST(P_FOLDER_PATH VARCHAR2, P_RESOURCE_LIST XMLTYPE, P_DUPLICATE_ACTION VARCHAR2);
  procedure UPLOADRESOURCE(P_RESOURCE_PATH VARCHAR2, P_CONTENT BLOB, P_CONTENT_TYPE VARCHAR2, P_DESCRIPTION VARCHAR2, P_LANGUAGE VARCHAR2, P_CHARACTER_SET VARCHAR2, P_DUPLICATE_POLICY VARCHAR2);
  procedure UPDATEPROPERTIES(P_RESOURCE_PATH VARCHAR2, P_NEW_VALUES XMLType, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_UPDATED_RESOURCE IN OUT XMLType);

  procedure getResourceWithContent(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_RESOURCE IN OUT XMLType);
  procedure getResource(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_RESOURCE IN OUT XMLType);
  procedure getFolderListing(P_FOLDER_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_FOLDER IN OUT XMLType, P_CHILDREN IN OUT XMLType);
  procedure getVersionHistory(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_RESOURCE IN OUT XMLType, P_VERSION_HISTORY IN OUT XMLType);
 
  function GENERATEPREVIEW(P_RESOURCE_PATH VARCHAR2, P_LINES number) return XMLType;
  function renderAsXHTML(P_RESOURCE_PATH VARCHAR2) return XMLType;

  procedure getTargetFolderTree(P_TREE IN OUT XMLType);

  procedure SETPASSWORD(P_PASSWORD VARCHAR2);  
  
  function doTransform(P_RESOURCE_PATH VARCHAR2, P_XSL VARCHAR2) return XMLType;
  function doTransform(P_SOURCE VARCHAR2, P_XSL VARCHAR2) return XMLType;
  function doTransform(P_SOURCE XMLTYPE,  P_XSL VARCHAR2) return XMLType;
  function doTransform(P_SOURCE VARCHAR2, P_XSL XMLTYPE)  return XMLType;
  function doTransform(P_SOURCE XMLTYPE,  P_XSL XMLTYPE)  return XMLType;  

  function testResource(P_RESOURCE_PATH IN VARCHAR2,P_TIMEZONE_OFFSET NUMBER DEFAULT 0) return XMLType;
  function testResourceWithContent(P_RESOURCE_PATH IN VARCHAR2,P_TIMEZONE_OFFSET NUMBER DEFAULT 0) return XMLType;
  function testFolderListing(P_FOLDER_PATH IN VARCHAR2,P_TIMEZONE_OFFSET NUMBER DEFAULT 0) return XMLType;
  function testVersionHistory(P_RESOURCE_PATH IN VARCHAR2,P_TIMEZONE_OFFSET NUMBER DEFAULT 0) return XMLType;

  function xmlSchemaWizardUpload(P_SCHEMA_CONTAINER VARCHAR2) return XMLType;
  function xmlSchemaWizardOrder(P_ROOT_XMLSCHEMA VARCHAR2, P_XMLSCHEMA_FOLDER VARCHAR2, P_SCHEMA_LOCATION_PREFIX VARCHAR2) return XMLType;
  procedure xmlschemaWizardRegister(
              P_SCHEMA_LOCATION_HINT   VARCHAR2, 
              P_SCHEMA_PATH            VARCHAR2, 
              P_LOCAL                  BOOLEAN        DEFAULT TRUE, 
              P_GENTYPES               BOOLEAN        DEFAULT TRUE, 
              P_GENTABLES              BOOLEAN        DEFAULT TRUE,
              P_FORCE                  BOOLEAN        DEFAULT FALSE,
              P_OWNER                  VARCHAR2       DEFAULT USER,
              P_ENABLE_HEIRARCHY       BINARY_INTEGER DEFAULT DBMS_XMLSCHEMA.ENABLE_HIERARCHY_CONTENTS,
              P_OPTIONS                BINARY_INTEGER DEFAULT 0,
              P_DISABLE_DOM_FIDELITY   BOOLEAN        DEFAULT TRUE,
              P_DISABLE_DEFAULT_TABLES BOOLEAN        DEFAULT TRUE,
              P_USE_TIMESTAMP_WITH_TZ  BOOLEAN        DEFAULT TRUE,
              P_SCHEMA_ANNOTATIONS     VARCHAR2       DEFAULT NULL
          );
          
  function xmlschemaWizardAnalyze(
           P_CONFIGURATION           IN OUT XMLTYPE, 
           P_LOGFILE_PATH                   VARCHAR2,       
           P_SCHEMA_LOCATION_HINT           VARCHAR2, 
           P_OWNER                          VARCHAR2       DEFAULT USER
         )
  return VARCHAR2;
  
end;
/
show errors
--
create or replace package body XFILES_SOAP_SERVICES
as
  G_NODE_COUNT number(38) := 1;
--
procedure writeLogRecord(P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType)
as
begin
  XFILES_LOGGING.writeLogRecord('/orawsv/XFILES/XFILES_SOAP_SERVICES/',P_MODULE_NAME, P_INIT_TIME, P_PARAMETERS);
end;
--
procedure writeErrorRecord(P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE, P_PARAMETERS XMLType, P_STACK_TRACE XMLType)
as
begin
  XFILES_LOGGING.writeErrorRecord('/orawsv/XFILES/XFILES_SOAP_SERVICES/',P_MODULE_NAME, P_INIT_TIME, P_PARAMETERS, P_STACK_TRACE);
end;
--
procedure handleException(P_MODULE_NAME VARCHAR2, P_INIT_TIME TIMESTAMP WITH TIME ZONE,P_PARAMETERS XMLTYPE)
as
  V_STACK_TRACE XMLType;
  V_RESULT      boolean;
begin
  V_STACK_TRACE := XFILES_LOGGING.captureStackTrace();
  rollback; 
  writeErrorRecord(P_MODULE_NAME,P_INIT_TIME,P_PARAMETERS,V_STACK_TRACE);
end;
--
procedure GETRESOURCE(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_RESOURCE IN OUT XMLType)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.getResource(P_RESOURCE_PATH, FALSE, P_TIMEZONE_OFFSET, P_RESOURCE);  
  writeLogRecord('GETRESOURCE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('GETRESOURCE',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure GETRESOURCEWITHCONTENT(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_RESOURCE IN OUT XMLType)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.getResource(P_RESOURCE_PATH, TRUE, P_TIMEZONE_OFFSET, P_RESOURCE);
  writeLogRecord('GETRESOURCEWITHCONTENT',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('GETRESOURCEWITHCONTENT',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure GETFOLDERLISTING(P_FOLDER_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_FOLDER IN OUT XMLType, P_CHILDREN IN OUT XMLType)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("FolderPath",P_FOLDER_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.getFolderListing(P_FOLDER_PATH, P_TIMEZONE_OFFSET, P_FOLDER, P_CHILDREN);
  writeLogRecord('GETFOLDERLISTING',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('GETFOLDERLISTING',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure GETVERSIONHISTORY(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_RESOURCE IN OUT XMLType, P_VERSION_HISTORY IN OUT XMLType)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.getVersionHistory(P_RESOURCE_PATH, P_TIMEZONE_OFFSET, P_RESOURCE, P_VERSION_HISTORY);
  writeLogRecord('GETVERSIONHISTORY',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('GETVERSIONHISTORY',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure UPDATEPROPERTIES(P_RESOURCE_PATH  VARCHAR2, P_NEW_VALUES XMLType, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_UPDATED_RESOURCE IN OUT XMLType)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RESOURCE_PATH     VARCHAR2(1024);
begin  
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET),
           P_NEW_VALUES          
         )
    into V_PARAMETERS
    from dual;

  V_RESOURCE_PATH := XDB_REPOSITORY_SERVICES.UPDATEPROPERTIES(P_RESOURCE_PATH,P_NEW_VALUES,P_TIMEZONE_OFFSET);      
  XDB_REPOSITORY_SERVICES.getResource(V_RESOURCE_PATH, FALSE, P_TIMEZONE_OFFSET, P_UPDATED_RESOURCE);
  writeLogRecord('UPDATEPROPERTIES',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('UPDATEPROPERTIES',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure CREATENEWWIKIPAGE(P_RESOURCE_PATH VARCHAR2, P_DESCRIPTION VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_UPDATED_RESOURCE IN OUT XMLType, P_UPDATED_CHILDREN  IN OUT XMLType)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_PARENT_FOLDER     VARCHAR2(1024) := SUBSTR(P_RESOURCE_PATH,1,INSTR(P_RESOURCE_PATH,'/',-1) -1);
begin
  select XMLConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET),
           xmlElement("Description",P_DESCRIPTION)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.CREATEWIKIPAGE(P_RESOURCE_PATH, P_DESCRIPTION, P_TIMEZONE_OFFSET);
  XDB_REPOSITORY_SERVICES.getFolderListing(V_PARENT_FOLDER, P_TIMEZONE_OFFSET, P_UPDATED_RESOURCE, P_UPDATED_CHILDREN);
  writeLogRecord('CREATENEWWIKIPAGE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('CREATENEWWIKIPAGE',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure CREATENEWFOLDER(P_FOLDER_PATH VARCHAR2, P_DESCRIPTION VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_UPDATED_RESOURCE IN OUT XMLType, P_UPDATED_CHILDREN IN OUT XMLType)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_PARENT_FOLDER     VARCHAR2(1024) := SUBSTR(P_FOLDER_PATH,1,INSTR(P_FOLDER_PATH,'/',-1) -1);
begin
  -- execute immediate 'alter session set TIME_ZONE=''-08:00''';
  -- V_INIT := SYSTIMESTAMP;
  select XMLConcat
         (
           xmlElement("FolderPath",P_FOLDER_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET),
           xmlElement("Description",P_DESCRIPTION)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.CREATEFOLDER(P_FOLDER_PATH, P_DESCRIPTION, P_TIMEZONE_OFFSET);
  XDB_REPOSITORY_SERVICES.getFolderListing(P_FOLDER_PATH, P_TIMEZONE_OFFSET, P_UPDATED_RESOURCE, P_UPDATED_CHILDREN);
  writeLogRecord('CREATENEWFOLDER',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('CREATENEWFOLDER',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure SETACL(P_RESOURCE_PATH VARCHAR2, P_ACL_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);

begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("ACL",P_ACL_PATH),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.SETACL(P_RESOURCE_PATH, P_ACL_PATH, P_DEEP);
  
  writeLogRecord('SETACL',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('SETACL',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure SETACLLIST(P_RESOURCE_LIST XMLTYPE, P_ACL_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("ACL",P_ACL_PATH),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;

  for r in getResources loop
    XDB_REPOSITORY_SERVICES.SETACL(r.RESOURCE_PATH, P_ACL_PATH, P_DEEP);
  end loop;
  
  writeLogRecord('SETACLLIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('SETACLLIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure CHANGEOWNER(P_RESOURCE_PATH VARCHAR2, P_NEW_OWNER VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("NewOwner",P_NEW_OWNER),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.CHANGEOWNER(P_RESOURCE_PATH,P_NEW_OWNER,P_DEEP);
  
  writeLogRecord('CHANGEOWNER',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('CHANGEOWNER',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure CHANGEOWNERLIST(P_RESOURCE_LIST XMLTYPE, P_NEW_OWNER VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("NewOwner",P_NEW_OWNER),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;

    for r in getResources loop
      XDB_REPOSITORY_SERVICES.CHANGEOWNER(r.RESOURCE_PATH,P_NEW_OWNER,P_DEEP);
    end loop;
  
  writeLogRecord('CHANGEOWNERLIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('CHANGEOWNERLIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure SETCUSTOMVIEWER(P_RESOURCE_PATH VARCHAR2, P_VIEWER_PATH VARCHAR2)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("ViewerPath",P_VIEWER_PATH)
         )
    into V_PARAMETERS
    from dual;
    
  XDB_REPOSITORY_SERVICES.setCustomViewer(P_RESOURCE_PATH,P_VIEWER_PATH); 
  writeLogRecord('SETCUSTOMVIEWER',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('SETCUSTOMVIEWER',V_INIT,V_PARAMETERS);
    raise;  
end;
--
procedure SETCUSTOMVIEWERLIST(P_RESOURCE_LIST XMLTYPE, P_VIEWER_PATH VARCHAR2)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("Viewer",P_VIEWER_PATH)
         )
    into V_PARAMETERS
    from dual;

  for r in getResources loop
    XDB_REPOSITORY_SERVICES.setCustomViewer(r.RESOURCE_PATH, P_VIEWER_PATH);
  end loop;
  
  writeLogRecord('SETCUSTOMVIEWERLIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('SETCUSTOMVIEWERLIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure MAKEVERSIONED(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.MAKEVERSIONED(P_RESOURCE_PATH, P_DEEP);

  writeLogRecord('MAKEVERSIONED',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('MAKEVERSIONED',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure MAKEVERSIONEDLIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;

  for r in getResources loop
    XDB_REPOSITORY_SERVICES.MAKEVERSIONED(r.RESOURCE_PATH, P_DEEP);
  end loop;

  writeLogRecord('MAKEVERSIONEDLIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('MAKEVERSIONEDLIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure CHECKOUT(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;
 
  XDB_REPOSITORY_SERVICES.CHECKOUT(P_RESOURCE_PATH, P_DEEP);

  writeLogRecord('CHECKOUT',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('CHECKOUT',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure CHECKOUTLIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;
 
    for r in getResources loop
      XDB_REPOSITORY_SERVICES.CHECKOUT(r.RESOURCE_PATH, P_DEEP);
    end loop;

  writeLogRecord('CHECKOUTLIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('CHECKOUTLIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure CHECKIN(P_RESOURCE_PATH VARCHAR2, P_COMMENT VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("Deep",V_DEEP),
           xmlElement("Comment",P_COMMENT)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.CHECKIN(P_RESOURCE_PATH, P_COMMENT, P_DEEP);
  writeLogRecord('CHECKIN',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('CHECKIN',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure CHECKINLIST(P_RESOURCE_LIST XMLTYPE, P_COMMENT VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("Deep",V_DEEP),
           xmlElement("Comment",P_COMMENT)
         )
    into V_PARAMETERS
    from dual;

    for r in getResources loop
      XDB_REPOSITORY_SERVICES.CHECKIN(r.RESOURCE_PATH, P_COMMENT, P_DEEP);
    end loop;
    
  writeLogRecord('CHECKINLIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('CHECKINLIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure LOCKRESOURCE(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;
    
  XDB_REPOSITORY_SERVICES.LOCKRESOURCE(P_RESOURCE_PATH, P_DEEP);

  writeLogRecord('LOCKRESOURCE',V_INIT,V_PARAMETERS);

exception
  when others then
    handleException('LOCKRESOURCE',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure LOCKRESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;
    
  for r in getResources loop
    XDB_REPOSITORY_SERVICES.LOCKRESOURCE(r.RESOURCE_PATH, P_DEEP);
  end loop;

  writeLogRecord('LOCKRESOURCELIST',V_INIT,V_PARAMETERS);

exception
  when others then
    handleException('LOCKRESOURCELIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure UNLOCKRESOURCE(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;
  
  XDB_REPOSITORY_SERVICES.UNLOCKRESOURCE(P_RESOURCE_PATH, P_DEEP);

  writeLogRecord('UNLOCKRESOURCE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('UNLOCKRESOURCE',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure UNLOCKRESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;
  
  for r in getResources loop
   XDB_REPOSITORY_SERVICES.UNLOCKRESOURCE(r.RESOURCE_PATH, P_DEEP);
  end loop;
  
  writeLogRecord('UNLOCKRESOURCELIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('UNLOCKRESOURCELIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure DELETERESOURCE(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN, P_FORCE BOOLEAN)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
  V_FORCE             VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_FORCE);
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("Deep",V_DEEP),
           xmlElement("Force",V_FORCE)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.DELETERESOURCE(P_RESOURCE_PATH, P_DEEP, P_FORCE);  
  writeLogRecord('DELETERESOURCE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('DELETERESOURCE',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure DELETERESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN, P_FORCE BOOLEAN)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
  V_FORCE             VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_FORCE);

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("Deep",V_DEEP),
           xmlElement("Force",V_FORCE)
         )
    into V_PARAMETERS
    from dual;

  for r in getResources loop
    XDB_REPOSITORY_SERVICES.DELETERESOURCE(r.RESOURCE_PATH, P_DEEP, P_FORCE);  
  end loop;
  
  writeLogRecord('DELETERESOURCELIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('DELETERESOURCELIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure SETRSSFEED(P_FOLDER_PATH VARCHAR2, P_ENABLE BOOLEAN, P_ITEMS_CHANGED_IN VARCHAR2, P_DEEP BOOLEAN)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
  V_ENABLE            VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_ENABLE);
begin
  select xmlConcat
         (
           xmlElement("FolderPath",P_FOLDER_PATH),
           xmlElement("Deep",V_DEEP),
           xmlElement("Enable",V_ENABLE),
           xmlElement("ItemsChanged",P_ITEMS_CHANGED_IN)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.SETRSSFEED(P_FOLDER_PATH, P_ENABLE, P_ITEMS_CHANGED_IN, P_DEEP);

  writeLogRecord('SETRSSFEED',V_INIT,V_PARAMETERS);

exception
  when others then
    handleException('SETRSSFEED',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure LINKRESOURCE(P_RESOURCE_PATH VARCHAR2, P_TARGET_FOLDER VARCHAR2,P_LINK_TYPE NUMBER DEFAULT DBMS_XDB.LINK_TYPE_WEAK)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TargetFolder",P_TARGET_FOLDER),
           xmlElement("LinkType",P_LINK_TYPE)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.LINKRESOURCE(P_RESOURCE_PATH, P_TARGET_FOLDER,P_LINK_TYPE);
  
  writeLogRecord('LINKRESOURCE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('LINKRESOURCE',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure LINKRESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_TARGET_FOLDER VARCHAR2,P_LINK_TYPE NUMBER DEFAULT DBMS_XDB.LINK_TYPE_WEAK)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("TargetFolder",P_TARGET_FOLDER),
           xmlElement("LinkType",P_LINK_TYPE)
         )
    into V_PARAMETERS
    from dual;

  for r in getResources loop
    XDB_REPOSITORY_SERVICES.LINKRESOURCE(r.RESOURCE_PATH, P_TARGET_FOLDER,P_LINK_TYPE);
  end loop;
  
  writeLogRecord('LINKRESOURCELIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('LINKRESOURCELIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure MOVERESOURCE(P_RESOURCE_PATH VARCHAR2, P_TARGET_FOLDER VARCHAR2)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TargetFolder",P_TARGET_FOLDER)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.MOVERESOURCE(P_RESOURCE_PATH, P_TARGET_FOLDER);

  writeLogRecord('MOVERESOURCE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('MOVERESOURCE',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure MOVERESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_TARGET_FOLDER VARCHAR2)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("TargetFolder",P_TARGET_FOLDER)
         )
    into V_PARAMETERS
    from dual;

  for r in getResources loop
    XDB_REPOSITORY_SERVICES.MOVERESOURCE(r.RESOURCE_PATH, P_TARGET_FOLDER);
  end loop;

  writeLogRecord('MOVERESOURCELIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('MOVERESOURCELIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure RENAMERESOURCE(P_RESOURCE_PATH VARCHAR2, P_NEW_NAME VARCHAR2)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("New Name",P_NEW_NAME)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.RENAMERESOURCE(P_RESOURCE_PATH, P_NEW_NAME);

  writeLogRecord('RENAMERESOURCE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('RENAMERESOURCE',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure COPYRESOURCE(P_RESOURCE_PATH VARCHAR2, P_TARGET_FOLDER VARCHAR2,P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TargetFolder",P_TARGET_FOLDER),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;
   
  XDB_REPOSITORY_SERVICES.COPYRESOURCE(P_RESOURCE_PATH, P_TARGET_FOLDER);

  writeLogRecord('COPYRESOURCE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('COPYRESOURCE',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure COPYRESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_TARGET_FOLDER VARCHAR2,P_DEEP BOOLEAN DEFAULT FALSE)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);
  
  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("TargetFolder",P_TARGET_FOLDER),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;
   
   for r in getResources loop
     XDB_REPOSITORY_SERVICES.COPYRESOURCE(r.RESOURCE_PATH, P_TARGET_FOLDER);
   end loop;
  
  writeLogRecord('COPYRESOURCELIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('COPYRESOURCELIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure PUBLISHRESOURCE(P_RESOURCE_PATH VARCHAR2, P_DEEP BOOLEAN DEFAULT FALSE)
as

  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);  
begin

  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;

   XDB_REPOSITORY_SERVICES.PUBLISHRESOURCE(P_RESOURCE_PATH, P_DEEP);

  writeLogRecord('PUBLISHESOURCE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('PUBLISHESOURCE',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure PUBLISHRESOURCELIST(P_RESOURCE_LIST XMLTYPE, P_DEEP BOOLEAN DEFAULT FALSE)
as

  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_DEEP              VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DEEP);  

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin

  select xmlConcat
         (
           P_RESOURCE_LIST,
           xmlElement("Deep",V_DEEP)
         )
    into V_PARAMETERS
    from dual;

   for r in getResources loop
     XDB_REPOSITORY_SERVICES.PUBLISHRESOURCE(r.RESOURCE_PATH, P_DEEP);
   end loop;
   
  writeLogRecord('PUBLISHESOURCELIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('PUBLISHESOURCELIST',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure UPLOADRESOURCE(P_RESOURCE_PATH VARCHAR2, P_CONTENT BLOB, P_CONTENT_TYPE VARCHAR2, P_DESCRIPTION VARCHAR2, P_LANGUAGE VARCHAR2, P_CHARACTER_SET VARCHAR2, P_DUPLICATE_POLICY VARCHAR2)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("ContentLength",DBMS_LOB.GETLENGTH(P_CONTENT)),
           xmlElement("ContentType",P_CONTENT_TYPE),
           xmlElement("Description",P_DESCRIPTION),
           xmlElement("Language",P_LANGUAGE),
           xmlElement("CharacterSet",P_CHARACTER_SET),
           xmlElement("DuplicatePolicy",P_DUPLICATE_POLICY)
         )
    into V_PARAMETERS
    from dual;
      
  XDB_REPOSITORY_SERVICES.UPLOADRESOURCE(P_RESOURCE_PATH, P_CONTENT, P_CONTENT_TYPE, P_DESCRIPTION, P_LANGUAGE, P_CHARACTER_SET, P_DUPLICATE_POLICY);
        
  writeLogRecord('UPLOADRESOURCE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('UPLOADRESOURCE',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure CREATEZIPFILE(P_RESOURCE_PATH VARCHAR2, P_DESCRIPTION VARCHAR2, P_RESOURCE_LIST XMLType,  P_TIMEZONE_OFFSET NUMBER DEFAULT 0, P_UPDATED_RESOURCE IN OUT XMLType, P_UPDATED_CHILDREN  IN OUT XMLType)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_PARENT_FOLDER     VARCHAR2(1024) := SUBSTR(P_RESOURCE_PATH,1,INSTR(P_RESOURCE_PATH,'/',-1) -1);
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("TimezoneOffset",P_TIMEZONE_OFFSET),
           xmlElement("Description",P_DESCRIPTION),
           P_RESOURCE_LIST
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.CREATEZIPFILE(P_RESOURCE_PATH, P_DESCRIPTION, P_RESOURCE_LIST,  P_TIMEZONE_OFFSET);    
  XDB_REPOSITORY_SERVICES.getFolderListing(V_PARENT_FOLDER, P_TIMEZONE_OFFSET, P_UPDATED_RESOURCE, P_UPDATED_CHILDREN);

  writeLogRecord('CREATEZIPFILE',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('CREATEZIPFILE',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure UNZIP(P_FOLDER_PATH VARCHAR2, P_RESOURCE_PATH VARCHAR2, P_DUPLICATE_ACTION VARCHAR2)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("FolderPath",P_FOLDER_PATH),
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("DuplicateAction",P_DUPLICATE_ACTION)
         )
    into V_PARAMETERS
    from dual;

  XDB_REPOSITORY_SERVICES.unzip(P_FOLDER_PATH, P_RESOURCE_PATH, P_DUPLICATE_ACTION);
  writeLogRecord('UNZIP',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('UNZIP',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure UNZIPLIST(P_FOLDER_PATH VARCHAR2, P_RESOURCE_LIST XMLTYPE, P_DUPLICATE_ACTION VARCHAR2)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;

  cursor getResources 
  is
  select RESOURCE_PATH 
    from XMLTABLE
         (
            'ResourceList/Resource'
            passing P_RESOURCE_LIST
            columns
            RESOURCE_PATH VARCHAR2(700) PATH '.'
         );
begin
  select xmlConcat
         (
           xmlElement("FolderPath",P_FOLDER_PATH),
           P_RESOURCE_LIST,
           xmlElement("DuplicateAction",P_DUPLICATE_ACTION)
         )
    into V_PARAMETERS
    from dual;

  for r in getResources loop
   XDB_REPOSITORY_SERVICES.unzip(P_FOLDER_PATH, r.RESOURCE_PATH, P_DUPLICATE_ACTION);
  end loop;
  
  writeLogRecord('UNZIPLIST',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('UNZIPLIST',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure addChildToTree(P_PATH VARCHAR2, P_PARENT_FOLDER DBMS_XMLDOM.DOMElement)
as
  V_CHILD_FOLDER_NAME VARCHAR2(256);
  V_DESCENDANT_PATH   VARCHAR2(700);
  
  V_NODE_LIST         DBMS_XMLDOM.DOMNodeList;
  V_CHILD_FOLDER      DBMS_XMLDOM.DOMElement;

  V_CHILD_FOLDER_XML  XMLType;

begin
       
  if (INSTR(P_PATH,'/',2) > 0) then
    V_CHILD_FOLDER_NAME := SUBSTR(P_PATH,2,INSTR(P_PATH,'/',2)-2);
    V_DESCENDANT_PATH   := SUBSTR(P_PATH,INSTR(P_PATH,'/',2));
  else
    V_CHILD_FOLDER_NAME := SUBSTR(P_PATH,2);
    V_DESCENDANT_PATH   := NULL;
  end if;
  
  V_NODE_LIST         := DBMS_XSLPROCESSOR.selectNodes(DBMS_XMLDOM.makeNode(P_PARENT_FOLDER),'folder[@name="' || V_CHILD_FOLDER_NAME || '"]');

  if (DBMS_XMLDOM.getLength(V_NODE_LIST) = 0) then

    -- Target is not already in the tree - add it..

    G_NODE_COUNT := G_NODE_COUNT + 1;

    if (V_DESCENDANT_PATH is not NULL) then
      -- We are not at the bottom of the path so assume this is a read-only folder for now
      select xmlElement
             (
               "folder",
               xmlAttributes
               (
                 V_CHILD_FOLDER_NAME as "name",
                 G_NODE_COUNT as "id",
                 'null' as "isSelected",
                 'closed' as "isOpen",
                 '/XFILES/lib/icons/readOnlyFolderOpen.png' as "openIcon",
                 '/XFILES/lib/icons/readOnlyFolderClosed.png' as "closedIcon",
                 'hidden' as "children",
                 '/XFILES/lib/icons/hideChildren.png' as "hideChildren",
                 '/XFILES/lib/icons/showChildren.png' as "showChildren"
               )
             )
        into V_CHILD_FOLDER_XML
        from dual;
    else
      -- We are at the bottom of the path so we can link items into this folder.
      select xmlElement
             (
               "folder",
               xmlAttributes
               (
                 V_CHILD_FOLDER_NAME as "name",
                 G_NODE_COUNT as "id",
                 'null' as  "isSelected",
                 'closed' as "isOpen",
                 '/XFILES/lib/icons/writeFolderOpen.png' as "openIcon",
                 '/XFILES/lib/icons/writeFolderClosed.png' as "closedIcon",
                 'hidden' as "children",
                 '/XFILES/lib/icons/hideChildren.png' as "hideChildren",
                 '/XFILES/lib/icons/showChildren.png' as "showChildren"
               )
             )
        into V_CHILD_FOLDER_XML
        from dual;
    end if;
    
    V_CHILD_FOLDER := DBMS_XMLDOM.getDocumentElement(DBMS_XMLDOM.newDOMDocument(V_CHILD_FOLDER_XML));
    V_CHILD_FOLDER := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.importNode(DBMS_XMLDOM.getOwnerDocument(DBMS_XMLDOM.makeNode(P_PARENT_FOLDER)), DBMS_XMLDOM.makeNode(V_CHILD_FOLDER), true));    
    V_CHILD_FOLDER := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.appendChild(DBMS_XMLDOM.makeNode(P_PARENT_FOLDER),DBMS_XMLDOM.makeNode(V_CHILD_FOLDER)));

  else
    --  Target is already in the tree. 
    
    V_CHILD_FOLDER := DBMS_XMLDOM.makeElement(DBMS_XMLDOM.item(V_NODE_LIST,0));

    if (V_DESCENDANT_PATH is NULL) then      
       -- We are at the bottom of the path, Make sure folder is shown as writeable
       DBMS_XMLDOM.setAttribute(V_CHILD_FOLDER,'openIcon','/XFILES/lib/icons/writeFolderOpen.png');
       DBMS_XMLDOM.setAttribute(V_CHILD_FOLDER,'closedIcon','/XFILES/lib/icons/writeFolderClosed.png');
     end if;
  end if;
  
  -- Process remainder of path

  if (V_DESCENDANT_PATH is not null) then
    addChildToTree(V_DESCENDANT_PATH, V_CHILD_FOLDER);
  end if;
  
end;
--
procedure addPathToTree(P_TREE XMLType, P_PATH VARCHAR2)
as
  V_PARENT_FOLDER DBMS_XMLDOM.DOMElement;
begin
  dbms_output.put_line(P_PATH);
  V_PARENT_FOLDER := DBMS_XMLDOM.getDocumentElement(DBMS_XMLDOM.NewDOMDocument(P_TREE));
  addChildToTree(P_PATH, V_PARENT_FOLDER);
end;
--
function addWriteableFolders(P_TREE XMLType)
return XMLType
as
  cursor getFolderList
  is
  select path
    from PATH_VIEW
$IF DBMS_DB_VERSION.VER_LE_11_1 $THEN
   where existsNode(res,'/Resource[@Container="true"]','xmlns="http://xmlns.oracle.com/xdb/XDBResource.xsd"') = 1
$ELSE
   where XMLExists
         (
           'declare default element namespace "http://xmlns.oracle.com/xdb/XDBResource.xsd"; (: :)
            $R/Resource[@Container=xs:boolean("true")]'
           passing RES as "R"
         )
$END
     and sys_checkacl
         (
           extractValue(res,'/Resource/ACLOID/text()'),
           extractValue(res,'/Resource/OwnerID/text()'),
           XMLTYPE
           (
             '<privilege xmlns="http://xmlns.oracle.com/xdb/acl.xsd" 
                         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                         xsi:schemaLocation="http://xmlns.oracle.com/xdb/acl.xsd http://xmlns.oracle.com/xdb/acl.xsd">
              <link/>
             </privilege>'
           )
         ) = 1;     
begin
  for f in getFolderList() loop  
    addPathToTree(P_TREE,F.PATH);   
  end loop;
  return P_TREE;
end;
--
function initTree
return XMLType
as
  V_TREE XMLType;
begin
  
  select xmlElement
           (
             "root",
             xmlAttributes
             (
               'targetFolderTree' as "controlName",
               '/' as "name",
               G_NODE_COUNT as "id",
               '/' as "currentPath",
               'null' as "isSelected",
               'open' as "isOpen",
               '/XFILES/lib/icons/readOnlyFolderOpen.png' as "openIcon",
               '/XFILES/lib/icons/readOnlyFolderClosed.png' as "closedIcon",
               'visible' as "children",
               '/XFILES/lib/icons/hideChildren.png' as "hideChildren",
               '/XFILES/lib/icons/showChildren.png' as "showChildren"
             )
           )
    into V_TREE
    from DUAL;

  return V_TREE;
end;
--
procedure getTargetFolderTree(P_TREE IN OUT XMLType)
as
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
   P_TREE := initTree();
   P_TREE := addWriteableFolders(P_TREE);
   writeLogRecord('GETTARGETFOLDERTREE',V_INIT,NULL);
exception
  when others then
    handleException('GETTARGETFOLDERTREE',V_INIT,NULL);
    raise;
  
end;
--
function GENERATEPREVIEW(P_RESOURCE_PATH VARCHAR2, P_LINES number) 
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("Lines",P_LINES)
         )
    into V_PARAMETERS
    from dual;
    
   V_RESULT := XFILES_UTILITIES.generatePreview(P_RESOURCE_PATH,P_LINES);
   
   writeLogRecord('PREVIEW',V_INIT,V_PARAMETERS);
   return V_RESULT;
exception
  when others then
    handleException('PREVIEW',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
function RENDERASXHTML(P_RESOURCE_PATH VARCHAR2) 
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH)
         )
    into V_PARAMETERS
    from dual;
    
   V_RESULT := XFILES_UTILITIES.renderAsXHTML(P_RESOURCE_PATH);
   
   writeLogRecord('RENDERASXHTML',V_INIT,V_PARAMETERS);
   return V_RESULT;  
exception
  when others then
    handleException('RENDERASXHTML',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
procedure SETPASSWORD(P_PASSWORD VARCHAR2)
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_STATEMENT         VARCHAR2(4000) :=null;
begin
  V_STATEMENT := 'alter user "' || USER || '" identified by "' || P_PASSWORD || '"';
  select xmlConcat
         (
           xmlElement("User",USER),
           xmlElement("Password",V_STATEMENT)
         )
    into V_PARAMETERS
    from dual;
    
  -- Add Code to check P_PASSWORD for '"' characters to prevent SQL Injection...  
 
  writeLogRecord('SETPASSWORD',V_INIT,V_PARAMETERS);
  execute immediate V_STATEMENT;

exception
  when others then
    handleException('SETPASSWORD',V_INIT,V_PARAMETERS);
    raise;
  
end;
--
function doTransform(P_RESOURCE_PATH VARCHAR2, P_XSL VARCHAR2)
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RESULT            XMLType;
  V_RESOURCE          XMLType;
  V_TIMEZONE_OFFSET   NUMBER;
begin
  select xmlConcat
         (
           xmlElement("ResourcePath",P_RESOURCE_PATH),
           xmlElement("xslPath",P_XSL)
         )
    into V_PARAMETERS
    from dual;
    
   XDB_REPOSITORY_SERVICES.getResource(P_RESOURCE_PATH, FALSE, V_TIMEZONE_OFFSET, V_RESOURCE);
   V_RESULT := XDB_REPOSITORY_SERVICES.doTransform(V_RESOURCE,P_XSL);
   writeLogRecord('DOTRANSFORM',V_INIT,V_PARAMETERS);
   return V_RESULT;  
exception
  when others then
    handleException('DOTRANSFORM',V_INIT,V_PARAMETERS);
    raise;
end;
--
function doTransform(P_SOURCE VARCHAR2, P_XSL VARCHAR2)
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("sourcePath",P_SOURCE),
           xmlElement("xslPath",P_XSL)
         )
    into V_PARAMETERS
    from dual;
    
   V_RESULT := XDB_REPOSITORY_SERVICES.doTransform(P_SOURCE,P_XSL);
   writeLogRecord('DOTRANSFORM',V_INIT,V_PARAMETERS);
   return V_RESULT;  
exception
  when others then
    handleException('DOTRANSFORM',V_INIT,V_PARAMETERS);
    raise;
end;
--
function doTransform(P_SOURCE XMLTYPE, P_XSL VARCHAR2)
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("sourceDocument",P_SOURCE),
           xmlElement("xslPath",P_XSL)
         )
    into V_PARAMETERS
    from dual;
    
   V_RESULT := XDB_REPOSITORY_SERVICES.doTransform(P_SOURCE,P_XSL);
   writeLogRecord('DOTRANSFORM',V_INIT,V_PARAMETERS);
   return V_RESULT;  
exception
  when others then
    handleException('DOTRANSFORM',V_INIT,V_PARAMETERS);
    raise;
end;
--
function doTransform(P_SOURCE VARCHAR2, P_XSL XMLTYPE)
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("sourcePath",P_SOURCE),
           xmlElement("xslDocument",P_XSL)
         )
    into V_PARAMETERS
    from dual;
    
   V_RESULT := XDB_REPOSITORY_SERVICES.doTransform(P_SOURCE,P_XSL);
   writeLogRecord('DOTRANSFORM',V_INIT,V_PARAMETERS);
   return V_RESULT;  
exception
  when others then
    handleException('DOTRANSFORM',V_INIT,V_PARAMETERS);
    raise;
end;
--
function doTransform(P_SOURCE XMLTYPE, P_XSL XMLTYPE)
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("sourceDocument",P_SOURCE),
           xmlElement("xslDocument",P_XSL)
         )
    into V_PARAMETERS
    from dual;
    
   V_RESULT := XDB_REPOSITORY_SERVICES.doTransform(P_SOURCE,P_XSL);
   writeLogRecord('DOTRANSFORM',V_INIT,V_PARAMETERS);
   return V_RESULT;  
exception
  when others then
    handleException('DOTRANSFORM',V_INIT,V_PARAMETERS);
    raise;
end;
--
function xmlSchemaWizardUpload(P_SCHEMA_CONTAINER VARCHAR2) 
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RESULT            XMLType;
begin
  select xmlElement("schemaContainer",P_SCHEMA_CONTAINER)
    into V_PARAMETERS
    from dual;

  V_RESULT := XDB_ANALYZE_XMLSCHEMA.XMLSCHEMA_WIZARD_UPLOAD(P_SCHEMA_CONTAINER);
  writeLogRecord('XMLSCHEMAWIZARDUPLOAD',V_INIT,V_PARAMETERS);
  return V_RESULT;  
exception
  when others then
    handleException('XMLSCHEMAWIZARDUPLOAD',V_INIT,V_PARAMETERS);
    raise;
end;
--
function xmlSchemaWizardOrder(P_ROOT_XMLSCHEMA VARCHAR2, P_XMLSCHEMA_FOLDER VARCHAR2, P_SCHEMA_LOCATION_PREFIX VARCHAR2) 
return XMLType
as
  V_PARAMETERS        XMLType;
  V_INIT              TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_RESULT            XMLType;
begin
  select xmlConcat
         (
           xmlElement("xmlSchema",P_ROOT_XMLSCHEMA),
           xmlElement("folderPath",P_XMLSCHEMA_FOLDER),
           xmlElement("schemaLocationHint",P_SCHEMA_LOCATION_PREFIX)
         )
    into V_PARAMETERS
    from dual;

  V_RESULT := XDB_ANALYZE_XMLSCHEMA.XMLSCHEMA_WIZARD_ORDER_SCHEMAS(P_ROOT_XMLSCHEMA ,P_XMLSCHEMA_FOLDER, P_SCHEMA_LOCATION_PREFIX);
  writeLogRecord('XMLSCHEMAWIZARDORDER',V_INIT,V_PARAMETERS);
  return V_RESULT;  
exception
  when others then
    handleException('XMLSCHEMAWIZARDORDER',V_INIT,V_PARAMETERS);
    raise;
end;
--
procedure xmlschemaWizardRegister(
            P_SCHEMA_LOCATION_HINT   VARCHAR2, 
            P_SCHEMA_PATH            VARCHAR2, 
            P_LOCAL                  BOOLEAN        DEFAULT TRUE, 
            P_GENTYPES               BOOLEAN        DEFAULT TRUE, 
            P_GENTABLES              BOOLEAN        DEFAULT TRUE,
            P_FORCE                  BOOLEAN        DEFAULT FALSE,
            P_OWNER                  VARCHAR2       DEFAULT USER,
            P_ENABLE_HEIRARCHY       BINARY_INTEGER DEFAULT DBMS_XMLSCHEMA.ENABLE_HIERARCHY_CONTENTS,
            P_OPTIONS                BINARY_INTEGER DEFAULT 0,
            P_DISABLE_DOM_FIDELITY   BOOLEAN        DEFAULT TRUE,
            P_DISABLE_DEFAULT_TABLES BOOLEAN        DEFAULT TRUE,
            P_USE_TIMESTAMP_WITH_TZ  BOOLEAN        DEFAULT TRUE,
            P_SCHEMA_ANNOTATIONS     VARCHAR2       DEFAULT NULL
        )
as
  NO_MATCHING_NODE exception;
  PRAGMA EXCEPTION_INIT( NO_MATCHING_NODE , -31061 );

  V_PARAMETERS                   XMLType;
  V_INIT                         TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
  V_XMLSCHEMA                    XMLType;
  V_SCHEMA_ANNOTATIONS           VARCHAR2(32000);

  V_LOCAL                        VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_LOCAL);
  V_GENTYPES                     VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_GENTYPES);
  V_GENTABLES                    VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_GENTABLES);
  V_FORCE                        VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_FORCE);
  V_DISABLE_DOM_FIDELITY         VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DISABLE_DOM_FIDELITY);
  V_DISABLE_DEFAULT_TABLES       VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_DISABLE_DEFAULT_TABLES);
  V_USE_TIMESTAMP_WITH_TZ        VARCHAR2(5) := XDB_DOM_UTILITIES.BOOLEAN_TO_VARCHAR(P_USE_TIMESTAMP_WITH_TZ);
begin
  select xmlConcat
         (
           xmlElement("schemaLocationHint",P_SCHEMA_LOCATION_HINT),
           xmlElement("schemaPath",P_SCHEMA_PATH),
           xmlElement("local",V_LOCAL),
           xmlElement("generateTypes",V_GENTYPES),
           xmlElement("generateTables",V_GENTABLES),
           xmlElement("force",V_FORCE),
           xmlElement("owner",P_OWNER),
           xmlElement("enableHierarchy",P_ENABLE_HEIRARCHY),
           xmlElement("options",P_OPTIONS),
           xmlElement("domFidelityDisabled",V_DISABLE_DOM_FIDELITY),
           xmlElement("defaultTablesDisabled",V_DISABLE_DEFAULT_TABLES),
           xmlElement("timestampWithTimeZone",V_USE_TIMESTAMP_WITH_TZ),
           xmlElement("annotactons",P_SCHEMA_ANNOTATIONS)
         )
    into V_PARAMETERS
    from dual;

  V_XMLSCHEMA := xdburitype(P_SCHEMA_PATH).getXML();
  XDB_EDIT_XMLSCHEMA.fixRelativeURLs(V_XMLSCHEMA,P_SCHEMA_LOCATION_HINT);
  
  if (P_SCHEMA_ANNOTATIONS is not null) then
    V_SCHEMA_ANNOTATIONS := 'declare V_XMLSCHEMA XMLType := :1; begin ' || P_SCHEMA_ANNOTATIONS || ' end';
    execute immediate V_SCHEMA_ANNOTATIONS using in out V_XMLSCHEMA;
  end if;
  
  if ((P_DISABLE_DOM_FIDELITY) and (V_XMLSCHEMA.existsNode('//xsd:complexType','xmlns:xsd="http://www.w3.org/2001/XMLSchema"') = 1)) then
    DBMS_XMLSCHEMA_ANNOTATE.disableMaintainDOM(V_XMLSCHEMA);
  end if;
  
  if ((P_DISABLE_DEFAULT_TABLES) and (V_XMLSCHEMA.existsNode('/xsd:schema/xsd:element','xmlns:xsd="http://www.w3.org/2001/XMLSchema"') = 1)) then
      DBMS_XMLSCHEMA_ANNOTATE.disableDefaultTableCreation(V_XMLSCHEMA);
  end if;

  if (P_USE_TIMESTAMP_WITH_TZ) then
    begin
      DBMS_XMLSCHEMA_ANNOTATE.setTimestampWithTimeZone(V_XMLSCHEMA);
    exception
      when NO_MATCHING_NODE then
        NULL;
      when others then
        RAISE;
    end;
  end if;

  DBMS_XMLSCHEMA.registerSchema
  (
    SCHEMAURL        => P_SCHEMA_LOCATION_HINT,
    SCHEMADOC        => V_XMLSCHEMA,
    LOCAL            => P_LOCAL,
    GENBEAN          => FALSE,
    GENTYPES         => P_GENTYPES,
    GENTABLES        => P_GENTABLES,
    FORCE            => P_FORCE,
    OWNER            => P_OWNER,
    ENABLEHIERARCHY  => P_ENABLE_HEIRARCHY,
    OPTIONS          => P_OPTIONS
  );

  writeLogRecord('XMLSCHEMAWIZARREGISTER',V_INIT,V_PARAMETERS);
exception
  when others then
    handleException('XMLSCHEMAWIZARREGISTER',V_INIT,V_PARAMETERS);
    raise;
end;
--	
function xmlschemaWizardAnalyze(
           P_CONFIGURATION           IN OUT XMLTYPE, 
           P_LOGFILE_PATH                   VARCHAR2,       
           P_SCHEMA_LOCATION_HINT           VARCHAR2, 
           P_OWNER                          VARCHAR2       DEFAULT USER
         )
return VARCHAR2
as
  V_RESULT                       VARCHAR2(5);
  V_PARAMETERS                   XMLType;
  V_INIT                         TIMESTAMP WITH TIME ZONE := SYSTIMESTAMP;
begin
  select xmlConcat
         (
           xmlElement("Configuration",P_CONFIGURATION),
           xmlElement("LogFile",P_LOGFILE_PATH),
           xmlElement("SchemaLocationHint",P_SCHEMA_LOCATION_HINT),
           xmlElement("Owner",P_OWNER)
         )
    into V_PARAMETERS
    from dual;

  V_RESULT := XDB_ANALYZE_XMLSCHEMA.XMLSCHEMA_WIZARD_TYPE_ANALYSIS(P_CONFIGURATION, P_LOGFILE_PATH, P_SCHEMA_LOCATION_HINT, P_OWNER);
  writeLogRecord('XMLSCHEMAWIZARDANALYZE',V_INIT,V_PARAMETERS);
  return V_RESULT;
exception
  when others then
    handleException('XMLSCHEMAWIZARDANALYZE',V_INIT,V_PARAMETERS);
    raise;
end;
--	
function testResource(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0) 
return XMLType
as
  V_RESOURCE XMLTYPE;
begin
  getResource(P_RESOURCE_PATH, P_TIMEZONE_OFFSET, V_RESOURCE);
  return V_RESOURCE;
end;
--
function testResourceWithContent(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0) 
return XMLType
as
  V_RESOURCE XMLTYPE;
begin
  getResourceWithContent(P_RESOURCE_PATH, P_TIMEZONE_OFFSET, V_RESOURCE);
  return V_RESOURCE;
end;
--
function testFolderListing(P_FOLDER_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
return XMLType
as
  V_RESOURCE XMLTYPE;
  V_CHILDREN XMLTYPE;
begin
  getFolderListing(P_FOLDER_PATH, P_TIMEZONE_OFFSET, V_RESOURCE, V_CHILDREN);
  return V_CHILDREN;
end;
--
function testVersionHistory(P_RESOURCE_PATH IN VARCHAR2, P_TIMEZONE_OFFSET NUMBER DEFAULT 0)
return XMLType
as
  V_RESOURCE XMLTYPE;
  V_VERSION_SERIES XMLTYPE;
begin
  getVersionHistory(P_RESOURCE_PATH, P_TIMEZONE_OFFSET, V_RESOURCE, V_VERSION_SERIES);
  return V_VERSION_SERIES;
end;
--
end;
/
show errors
--
