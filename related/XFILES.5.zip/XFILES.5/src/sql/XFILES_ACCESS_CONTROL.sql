--
-- Create the documents that provide access control. 
-- One document makes it possbile to detect whether or not the current user is authenticated. 
-- The other returns the name of the current user and can only be accessed by authenticated user.
--
declare
  V_RESULT BOOLEAN;
begin

  if (DBMS_XDB.existsResource(XFILES_CONSTANTS.DOCUMENT_AUTH_STATUS)) then
    DBMS_XDB.deleteResource(XFILES_CONSTANTS.DOCUMENT_AUTH_STATUS);
  end if;

  if (DBMS_XDB.existsResource(XFILES_CONSTANTS.DOCUMENT_WHOAMI)) then
    DBMS_XDB.deleteResource(XFILES_CONSTANTS.DOCUMENT_WHOAMI);
  end if;
  
  commit;
  
  V_RESULT := DBMS_XDB.createResource(XFILES_CONSTANTS.DOCUMENT_WHOAMI,XMLType('<CurrentUser/>'));
  V_RESULT := DBMS_XDB.createResource(XFILES_CONSTANTS.DOCUMENT_AUTH_STATUS,XMLType('<Authenticated/>'));
  V_RESULT := DBMS_XDB.createResource(XFILES_CONSTANTS.DOCUMENT_UNAUTHENTICATED,XMLType('<Unauthenticated/>'));
  commit;
   
  DBMS_RESCONFIG.addResConfig(XFILES_CONSTANTS.DOCUMENT_WHOAMI,XFILES_CONSTANTS.RESCONFIG_WHOAMI,null);
  DBMS_RESCONFIG.addResConfig(XFILES_CONSTANTS.DOCUMENT_AUTH_STATUS,XFILES_CONSTANTS.RESCONFIG_AUTH_STATUS,null);
  commit;
 
  DBMS_XDB.setACL(XFILES_CONSTANTS.DOCUMENT_UNAUTHENTICATED,XFILES_CONSTANTS.ACL_DENY_XFILES_USERS);
  DBMS_XDB.setACL(XFILES_CONSTANTS.DOCUMENT_WHOAMI,XFILES_CONSTANTS.ACL_XFILES_USERS);

  DBMS_XDB.setACL(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/WebServices',XFILES_CONSTANTS.ACL_XFILES_USERS);
  DBMS_XDB.setACL(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/XMLSearch',XFILES_CONSTANTS.ACL_XFILES_USERS);
  commit;
end;
/
--
