set echo on
spool PUBLISH_XFILES.log
--
def COLOR_SCHEME = &1
--
def LOGO = &2
--
undef XFILES_ROOT
--
column XFILES_ROOT new_value XFILES_ROOT
--
select XFILES_CONSTANTS.FOLDER_XFILES_ROOT XFILES_ROOT
  from dual
/
def XFILES_ROOT
--
-- Set XFilesLaunchPad.html as the index.html page for /XFILES
--
declare 
  V_LINK_TARGET  VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/index.html';
begin
	if DBMS_XDB.existsResource(V_LINK_TARGET) then
	  DBMS_XDB.deleteResource(V_LINK_TARGET);
	end if;
  DBMS_XDB.link(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/lite/XFilesLaunchPad.html',XFILES_CONSTANTS.FOLDER_XFILES_ROOT,'index.html');
end;
/  
--
-- Set aboutXFiles.html as the aboutXFiles.html page for /XFILES
--
declare 
  V_LINK_TARGET  VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/aboutXFiles.html';
begin
	if DBMS_XDB.existsResource(V_LINK_TARGET) then
	  DBMS_XDB.deleteResource(V_LINK_TARGET);
	end if;
  DBMS_XDB.link(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/lite/aboutXFiles.html',XFILES_CONSTANTS.FOLDER_XFILES_ROOT,'aboutXFiles.html');
end;
/  
--
-- Create the 'lib' folder tree
--
declare
  cursor deleteFolders 
  is 
  select PATH
    from PATH_VIEW
   where under_path(RES,1,XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/lib') = 1;
begin 
	for f in deleteFolders loop
	  DBMS_XDB.deleteResource(f.PATH,DBMS_XDB.DELETE_RECURSIVE_FORCE);
  end loop;
  XDB_UTILITIES.mkdir(XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/lib/icons',TRUE);
end;
/
--
-- Publish Common components under /XFILES
-- 
declare 
  V_LINK_TARGET  VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/common';
begin
	if DBMS_XDB.existsResource(V_LINK_TARGET) then
	  DBMS_XDB.deleteResource(V_LINK_TARGET);
	end if;
  dbms_xdb.link(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/common/',XFILES_CONSTANTS.FOLDER_XFILES_ROOT,'common',DBMS_XDB.LINK_TYPE_WEAK);
end;
/
--
-- Publish Image Library components under /XFILES/lib
-- 
declare 
  V_LINK_TARGET  VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/images';
begin
	if DBMS_XDB.existsResource(V_LINK_TARGET) then
	  DBMS_XDB.deleteResource(V_LINK_TARGET);
	end if;
  dbms_xdb.link(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/images/',XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/lib' ,'images',DBMS_XDB.LINK_TYPE_WEAK);
end;
/
-- 
-- Publish XFILES 'lite' under /XFILES
--
declare 
  V_LINK_TARGET  VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/lite';
begin
	if DBMS_XDB.existsResource(V_LINK_TARGET) then
	  DBMS_XDB.deleteResource(V_LINK_TARGET);
	end if;
	DBMS_XDB.link(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/lite',XFILES_CONSTANTS.FOLDER_XFILES_ROOT,'lite',DBMS_XDB.LINK_TYPE_WEAK);
end;
/ 
-- 
-- Publish XFILES 'Applications' under /XFILES
--
declare 
  V_LINK_TARGET  VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/Applications';
begin
	if DBMS_XDB.existsResource(V_LINK_TARGET) then
	  DBMS_XDB.deleteResource(V_LINK_TARGET);
	end if;
	DBMS_XDB.link(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/Applications',XFILES_CONSTANTS.FOLDER_XFILES_ROOT,'Applications',DBMS_XDB.LINK_TYPE_WEAK);
end;
/ 
--
-- Publish resConfig documents
--
declare 
  V_LINK_TARGET  VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/resConfig';
begin
	if DBMS_XDB.existsResource(V_LINK_TARGET) then
	  DBMS_XDB.deleteResource(V_LINK_TARGET);
	end if;
  dbms_xdb.link(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/resConfig',XFILES_CONSTANTS.FOLDER_XFILES_ROOT,'resConfig',DBMS_XDB.LINK_TYPE_WEAK);
end;
/
-- 
-- Publish Assets
--
declare 
  V_TARGET_FOLDER VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT;
begin                                                                                     
  dbms_xdb.link(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/images/&LOGO',                                     V_TARGET_FOLDER,             'logo.png',DBMS_XDB.LINK_TYPE_WEAK);
  dbms_xdb.link(XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/src/images/Barber_Pole_Red.gif',                       V_TARGET_FOLDER,             'loading.gif',DBMS_XDB.LINK_TYPE_WEAK);
end;
/
-- 
-- Publish Xinha under /XFILES/Xinha
--
declare 
  V_XINHA_VERSION VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/plugins/Xinha-0.96.1/tmp/Xinha-0.96.1';
  V_XINHA_ROOT    VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/plugins/Xinha';
  V_LINK_TARGET   VARCHAR2(700) := XFILES_CONSTANTS.FOLDER_XFILES_ROOT || '/Xinha';
begin
	if DBMS_XDB.existsResource(V_XINHA_ROOT) then
	  DBMS_XDB.deleteResource(V_XINHA_ROOT);
	end if;

	if DBMS_XDB.existsResource(V_LINK_TARGET) then
	  DBMS_XDB.deleteResource(V_LINK_TARGET);
	end if;
	
	dbms_xdb.link(V_XINHA_VERSION,XFILES_CONSTANTS.FOLDER_XFILES_HOME || '/plugins','Xinha');
	
  DBMS_XDB.link(V_XINHA_ROOT,XFILES_CONSTANTS.FOLDER_XFILES_ROOT,'Xinha',DBMS_XDB.LINK_TYPE_WEAK);
end;
/
@@PUBLISH_XFILES_ICONS
--
@@PUBLISH_WEBSERVICES_DEMO
--
@@PUBLISH_WEBDEMO_FRAMEWORK
--
@@PUBLISH_XMLSEARCH
--
-- Ensure all items in /XFILES are readable by the world
--
declare
  cursor publishResources is
  select path 
    from path_view
-- where under_path(res,XFILES_CONSTANTS.FOLDER_XFILES_ROOT) = 1;
   where under_path(res,'&XFILES_ROOT') = 1;
begin
  dbms_xdb.setACL(XFILES_CONSTANTS.FOLDER_XFILES_ROOT,XDB_CONSTANTS.ACL_BOOTSTRAP);
  for res in publishResources loop
    dbms_xdb.setACL(res.path,XDB_CONSTANTS.ACL_BOOTSTRAP);
  end loop;
end;
/
commit
/
declare
  cursor findSoftLinks 
  is
  select RESID
    from PATH_VIEW
-- where under_path(res,XFILES_CONSTANTS.FOLDER_XFILES_ROOT) = 1
   where under_path(res,'&XFILES_ROOT') = 1
     and XMLExists
         (
           'declare default element namespace "http://xmlns.oracle.com/xdb/XDBStandard"; (: :)
            $L/LINK[LinkType="Weak"]'
            passing LINK as "L"
         )
$IF DBMS_DB_VERSION.VER_LE_11_1 $THEN
     and existsNode(res,'/Resource[@Container="true"]','xmlns="http://xmlns.oracle.com/xdb/XDBResource.xsd"') = 1;
$ELSE
     and XMLExists
         (
           'declare default element namespace "http://xmlns.oracle.com/xdb/XDBResource.xsd"; (: :)
            $R/Resource[@Container=xs:boolean("true")]'
           passing RES as "R"
         );
$END
  cursor findHardLink(C_RESID RAW)
  is
  select path 
    from PATH_VIEW
   where RESID = C_RESID
     and XMLExists
         (
           'declare default element namespace "http://xmlns.oracle.com/xdb/XDBStandard"; (: :)
            $L/LINK[LinkType="Hard"]'
            passing LINK as "L"
         );

  cursor publishResources(C_PATH VARCHAR2) is
  select path 
    from path_view
   where under_path(res,C_PATH) = 1;

begin
  for r in findSoftLinks loop
    for hl in findHardLink(r.RESID) loop
      dbms_xdb.setACL(hl.PATH,XDB_CONSTANTS.ACL_BOOTSTRAP);
      for p in publishResources(hl.PATH) loop  
        dbms_xdb.setACL(p.PATH,XDB_CONSTANTS.ACL_BOOTSTRAP);
      end loop;
    end loop;
  end loop;
end;
/        
commit
/
-- 
-- Reset the ACL on /XFILES/whoami.xml to prevent access by anonymous...
--
@@XFILES_ACCESS_CONTROL
--
column RES_PATH FORMAT A100
column ACL_PATH FORMAT A100
--
set lines 256 pages 100 trimspool on
--
select r.any_path RES_PATH,
       (
         select r.ANY_PATH
           from RESOURCE_VIEW r
          where extractValue(r.res,'/Resource/XMLRef') = ref(a)
       ) ACL_PATH
  from xdb.xdb$acl a, resource_view r
 where extractValue(r.res,'/Resource/ACLOID') = a.object_id
-- and under_path(r.res,XFILES_CONSTANTS.FOLDER_XFILES_HOME) = 1
   and under_path(r.res,'/home/XFILES') = 1
 order by 2
/
--
quit
