spool XFILES_PUBLIC_SYNONYMS.log
set echo on
--
define XFILES_SCHEMA = &1
--
alter session set current_schema = &XFILES_SCHEMA
/
alter session set CURRENT_SCHEMA = &XFILES_SCHEMA
/
create or replace public synonym XFILES_CONSTANTS       
                             for XFILES_CONSTANTS
/
create or replace public synonym XFILES_UTILITIES        
                             for XFILES_UTILITIES
/
create or replace public synonym XFILES_LOGWRITER        
                             for XFILES_LOGWRITER
/
create or replace public synonym XFILES_LOGGING          
                             for XFILES_LOGGING
/
create or replace public synonym XDB_REPOSITORY_SERVICES 
                             for XDB_REPOSITORY_SERVICES
/
create or replace public synonym XFILES_DOCUMENT_UPLOAD  
                             for XFILES_DOCUMENT_UPLOAD
/
create or replace public synonym XFILES_WIKI_SERVICES    
                             for XFILES_WIKI_SERVICES
/
create or replace public synonym XFILES_SOAP_SERVICES    
                             for XFILES_SOAP_SERVICES
/
create or replace public synonym XFILES_SEARCH_SERVICES  
                             for XFILES_SEARCH_SERVICES
/
create or replace public synonym XFILES_REST_SERVICES    
                             for XFILES_REST_SERVICES
/
create or replace public synonym XFILES_WEBDEMO_SERVICES 
                             for XFILES_WEBDEMO_SERVICES
/
quit