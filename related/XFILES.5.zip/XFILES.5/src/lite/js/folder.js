function init() {

  try {
  	var target = document.getElementById('pageContent');
    initXFilesCommon(target);
    validateUser(getParameter('forceAuthentication'));

    stylesheetURL = unescape(getParameter("stylesheet"));
    if ((typeof stylesheetURL == "undefined") || (stylesheetURL == "")) {
      stylesheetURL = '/XFILES/lite/xsl/FolderBrowser.xsl';
    }
    
    resourceURL = unescape(getParameter("target"));
    if ((typeof resourceURL == "undefined") || (resourceURL == "")) {
      resourceURL = '/';
    }
    showFolder(resourceURL,target,stylesheetURL,true);
  }
  catch (e) {
    handleException('folder.init',e,null);
  }
}

function initRSS(target,p_resourceURL,p_stylesheetURL,forceAuthentication) {

  try {
  	resourceURL = p_resourceURL;
  	stylesheetURL = p_stylesheetURL;
    initXFilesCommon(target);
    validateUser(forceAuthentication);
    showFolder(resourceURL,target,stylesheetURL);
  }
  catch (e) {
    handleException('folder.init',e,null);
  }
}
