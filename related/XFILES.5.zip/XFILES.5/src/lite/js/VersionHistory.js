var max
var first
var last 

function onPageLoaded() {
  loadPreviews();
}

function loadPreviews() {
  
  var residList = resource.selectNodes('//res:Resource/xfiles:ResourceStatus/xfiles:Resid',xfilesNamespaces);
  var contentTypeList = resource.selectNodes('//res:Resource/res:ContentType',xfilesNamespaces)
  var contentType;
  	
  for (i=0; i < residList.length; i++){
    var  contentType = contentTypeList.item(i).firstChild.nodeValue;
    var RESID        = residList.item(i).firstChild.nodeValue;
    var previewArea = document.getElementById(RESID);

    var primaryContentType = contentType;
    if (contentType.indexOf('/') > 0) {
      primaryContentType = contentType.substring(0,contentType.indexOf('/'));
    }

    if (primaryContentType != "image") {
      previewContent(previewArea,RESID);
    }	  
  }
}

function processPreview(mgr, target) {

  try {
    var soapResponse = mgr.getSoapResponse('VersionHistory.processPreview');
   
   	var namespaces = xfilesNamespaces
	  namespaces.redefinePrefix("tns",mgr.getNamespace());
	  
    var nodeList = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:RETURN",namespaces);
    target.innerHTML = extractText(nodeList.item(0));
    return;
  }
  catch (e) {
    handleException('VersionHistory.processPreview',e,null);
  }
}


function previewContent(target,RESID) {
  
  var path = '/sys/oid/' + RESID;

	var schema  = "XFILES";
  var package = "XFILES_SOAP_SERVICES";
  var method =  "GENERATEPREVIEW";

	var mgr = new soapRequestManager(schema,package,method,wsManager);	
	var ajaxControl = mgr.createPostRequest();
  ajaxControl.onreadystatechange=function() { if( ajaxControl.readyState==4 ) { processPreview(mgr, target)}};
  
	var parameters = new Object;
	parameters["P_RESOURCE_PATH-VARCHAR2-IN"] = path
	parameters["P_LINES-NUMBER-IN"] = 10
	
  mgr.sendSoapRequest(parameters);
  
}

function renderContentSOAP(RESID) {
 
  var path = '/sys/oid/' + RESID;

	var schema  = "XFILES";
  var package = "XFILES_SOAP_SERVICES";
  var method =  "RENDERASXHTML";

	var mgr = new soapRequestManager(schema,package,method,wsManager);
	var ajaxControl = mgr.createPostRequest();
  ajaxControl.onreadystatechange=function() { if( ajaxControl.readyState==4 ) { processXHTML(mgr)}};
  
	var parameters = new Object;
	parameters["P_RESOURCE_PATH-VARCHAR2-IN"] = path		
  mgr.sendSoapRequest(parameters);

}

function processXHTML(mgr) {

  try {
    var soapResponse = mgr.getSoapResponse('VersionHistory.processXHTML');
   
   	var namespaces = xfilesNamespaces
	  namespaces.redefinePrefix("tns",mgr.getNamespace());
	  
    var nodeList = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:RETURN",namespaces);
    contentArea = document.getElementById("previewContent")     
    contentArea.innerHTML = extractText(nodeList.item(0));
  }
  catch (e) {
    handleException('VersionHistory.processXHTML',e,null);
  }
}

function renderContent(path) {
 

	var schema  = "XFILES";
  var package = "XFILES_SOAP_SERVICES";
  var method =  "RENDERASXHTML";

	var mgr = new soapRequestManager(schema,package,method,wsManager);
	var ajaxControl = mgr.createPostRequest();
  ajaxControl.onreadystatechange=function() { if( ajaxControl.readyState==4 ) { processXHTML(mgr)}};
  
	var parameters = new Object;
	parameters["P_RESOURCE_PATH-VARCHAR2-IN"] = path		
  mgr.sendSoapRequest(parameters);

}


function renderDocument(evt, RESID) {

  var path = '/sys/oid/' + RESID;
  var previewArea = document.getElementById("documentPreviewDialog");
  // renderContent(path);
  var iframe = document.getElementById("documentPreview");
  iframe.src = '/sys/servlets/XFILES/Protected/XFILES.XFILES_REST_SERVICES.RENDERDOCUMENT?P_RESOURCE_PATH=' + escape(path) + '&P_CONTENT_TYPE=text/html';
  openPopupDialog(evt,previewArea);
}

function closePreview() {
	closePopupDialog();
}

function showNext() {	  
	if (last < max) {
    document.getElementById(first).style.display="none";
	  first++;
		last++;
		document.getElementById(last).style.display="inline-block";
	}
}

function showPrev() {	  
  if (first > 1) {
 	  document.getElementById(last).style.display="none";
		first--;
		last--;
		document.getElementById(first).style.display="inline-block"
	}
}
	 