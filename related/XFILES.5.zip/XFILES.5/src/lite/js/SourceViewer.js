function onPageLoaded() {
  viewSource();
}

function viewSource() {

  var contentType = resource.selectNodes('/res:Resource/res:ContentType',xfilesNamespaces).item(0).firstChild.nodeValue;
  var displayName = resource.selectNodes('/res:Resource/res:DisplayName',xfilesNamespaces).item(0).firstChild.nodeValue;
  if (( contentType == "text/xml") || ( contentType ==  "application/vnd.oracle-csx")) {
    try {
      contentXML = loadXMLDocument(resourceURL);
      prettyPrintXML(contentXML,document.getElementById('sourcearea'));
    }
    catch (e) {
      if (e.status == "AccessDenied") {
        showUserErrorMessage("Unable to access : " + e.target + ". Access Denied.");
      }
      else {
				error = new xfilesException('SourceViewer.viewSource',12, resourceURL, e);
    		throw error;
      } 
    }
  }
  else {
    try {
      resourceContent = getDocumentContent(resourceURL);
      document.getElementById("sourcearea").value = resourceContent;
      if (displayName.substring(displayName.lastIndexOf(".")+1).toUpperCase() == "SQL") {
      	document.getElementById("executeQuery").style.display="block";
      }
    }
    catch (e) {
      if (e.status == "AccessDenied") {
        showUserErrorMessage("Unable to access : " + e.target + ". Access Denied.");
      }
      else {
				error = new xfilesException('SourceViewer.viewSource',12, resourceURL, e);
    		throw error;
      } 
    }
  }
}                                                                                                                 

 