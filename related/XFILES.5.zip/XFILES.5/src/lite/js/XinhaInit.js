var xinha_init    = null;
                                                                              
var xinha_editors = null;
var xinha_config  = null;
var xinha_plugins = null;

_editor_url = "/XFILES/Xinha/";  // (preferably absolute) URL (including trailing slash) where Xinha is installed 
_editor_lang = "en";             // And the language we need to use in the editor.


