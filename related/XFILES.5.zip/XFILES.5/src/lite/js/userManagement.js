function getHttpUsername() {

  /* 
  **
  ** Find the user name for the current session...
  **
  */

  if (window.ActiveXObject) {

	  /*
	  **
	  ** Use xml.load() to access the WHO AM I Service. The IE Implementation of DOM LOAD will fail with "Access is Denied"
	  ** when accessing a protected resource as the ANONYMOUS user. Cannot use the FF solution since it appears that IE 
	  ** always makes an inital unauthenticated request when requesting a resource. It only provides authentication headers 
	  ** once the browser has rejected the unauthenticated request.
	  **
	  */

    var httpUserName = "ANONYMOUS";

    try {  	
      var usernameXML = new xmlDocument().load('/XFILES/whoami.xml');
      httpUsername = usernameXML.getDocumentElement().firstChild.nodeValue;
    }  
    catch (e) {
  	  if (e.number == -2147024891) {
  	  	// Access Denied : User is ANONYMOUS
	 		}
	    else {
	    	throw e;
	    }
    }
  }  
  else {
  	
  	/*
  	**
  	** Firefox : Cannot use xml.load since FF will automatically prompt for credentials when a request to access a protected resource 
  	** is challanged. However, FF will always provide an authenication header if one is available so we can differentiate between
  	** authenticated and unauthenticated users.
  	**
  	*/
  	
    var httpRequest = httpMgr.createGetRequest('/XFILES/authenticationStatus.xml',false);
    httpRequest.send(null);
    
    var isAuthenticatedXML = new xmlDocument().parse(httpRequest.responseText);
  
    if (isAuthenticatedXML.getDocumentElement().firstChild.nodeValue == 1) {
      var usernameXML = new xmlDocument().load('/XFILES/whoami.xml');
      httpUsername = usernameXML.getDocumentElement().firstChild.nodeValue;
    }
    else {
    	// isAuthenticatedXML returned 0 : User is Anonymous
    }
    
    return httpUsername;
  }  
}  

function isAuthenticatedUser() {

	return httpUsername != 'ANONYMOUS';

}
 
function processAuthentication(httpRequest) {

	/*
	**
	** Note that since the document is not recognized as xml we have to parse the responseText rather than create a new instance from responseXML
	**
	*/

  httpRequest.send(null);
 
  if (httpRequest.status == 200) {
    var usernameXML = new xmlDocument().parse(httpRequest.responseText);
    httpUsername = usernameXML.getDocumentElement().firstChild.nodeValue;
    try { 
      xfilesSoapManager = new soapServiceManager();
    } catch (e) {
    	try {
    		var test = loadXMLDocument('/XFILES/whoami.xml');
      } catch (e1) {
 	      if (e1.number == -2147024891) {
  	  	  // Access Denied : User Login in inconsistant state...
          error = new xfilesException('userManagement.processAuthentication',15,null, e);
          error.setDescription("Inconsistant authentication state detected for user " + httpUsername + " : Close all XFILES sessions and try again.");
          throw error;
	 		  }
	      else {
	    	  throw e;
	      }      
      }
    }
  }
  else {
  	httpUsername = 'ANONYMOUS';
  	window.location.href = '/XFILES'
  }
}

function doLogon(evt) {
	
	/*
	**
	** Force Login / Verify Authenticated Used by accessing a protected resource. 
	** This will force the browser to prompt for username and password if the session is not authenticated
	** If the Authentication succeeds set httpUsername to value specified in the whoami.xml document
	** If login succeeds reload the current page. Pages that cannot use reload() must override the reloadPage method
	** If login fails redirect to /XFILES home page...
  **
  */

  try {
  
    evt = (evt) ? evt : ((window.event) ? window.event : "")
    var httpRequest = httpMgr.createGetRequest('/XFILES/whoami.xml', false);
    processAuthentication(httpRequest);
	  reloadForm();
  }
  catch (e) {
    handleException('userManagement.doLogon',e,null);
  }
  
}

function logoffRedirect() {

  xfilesSoapManager = null;
  getHttpUsername();
  window.location = '/XFILES';

}

function firefoxClearAuthenticationCache() {
 
  /*
  **
  ** Cannot do graceful HTTP Session logoff with Firebox Browser.
  **
  ** The solution below is proposed on many Web Sites. It appears to only apply to XMLHTTPRequest objects, and 
  ** not to the Browsers HTTP Session, so use with care.
  **
  ** Access a protected resource so at to force an Authentication Challange which will display the Browser's HTTP login dialog.
  ** Clicking cancel on the HTTP Login Dialog will flush the current Authentication information for this website.
  ** Must use Synchronous mode.
  **
  ** At that point the HTTP session will be effectively be logged out.  
  **
  ** Previous implementations have tried setting target as follows :
  **
  ** var target = window.location.protocol + "//" + "ANONYMOUS:ANONYMOUS@" + window.location.hostname + target;
  ** var target = '/XFILES/index.html?reAuthenticate=true';
  **  
  **
  */

	var target = '/XFILES/unauthorized.xml';

  try {
    httpRequest = httpMgr.createGetRequest(target, false, 'ANONYMOUS', 'ANONYMOUS');
    httpRequest.send("");
    httpRequest.abort();
  }
  catch(e) {
  	throw new XFileException('userManagement.firefoxClearAuthenticationCache',e,target);
  }
 
}

function doLogoff(evt)
{
	try {
		
    evt = (evt) ? evt : ((window.event) ? window.event : "")
    var target = '/XFILES/index.html';
    if (window.ActiveXObject) {
      self.document.execCommand("ClearAuthenticationCache");
      logoffRedirect();
    }
    else {
    	
      /*
      **
      ** Cannot do graceful HTTP Session logoff with Firebox Browser.
      **
      ** The solution below is proposed on many Web Sites. It appears to only apply to XMLHTTPRequest objects, and 
      ** not to the Browsers HTTP Session, so use with care.
      **
      ** Access a protected resource so at to force an Authentication Challange which will display the Browser's HTTP login dialog.
      ** Clicking cancel on the HTTP Login Dialog will flush the current Authentication information for this website.
      ** Must use Synchronous mode.
      ** At that point the HTTP session will be effectively be logged out.  
      **
      */
    
      showInfoMessage('Click cancel at the HTTP Authentication prompt to complete Firefox logoff.');
      firefoxClearAuthenticationCache();
	    logoffRedirect();
    }
  }
  catch (e) {
    handleException('userManagement.doLogoff',e,null);
  }
  
}

function forceAuthentication() {

  /*
  **
  ** Use protected EPG configuration to invoke WHOAMI Service. 
  ** Use a AJAX GET rather than a DOM load so that an so an unauthenticated session is forced to login in both IE and Firefox.
  ** Reset the value of httpUsername.
  **
  */

  var httpRequest = createGetRequest('/XFILES/whoami.xml',false);
  procesAuthentication(httpRequest);

}

function validateUser(restrictedAccessForm) {

  var restrictedAccess = (restrictedAccessForm == "true");

  if (restrictedAccess) {

    if (!isAuthenticatedUser()) {

      /*
      **
      ** Force authentication and reload page.
      **
      */

  	  forceAuthentication()
      reloadPage();
      return false;
    }
  }
   
  return true;

}

function validCredentials(username,password) {

  if (window.ActiveXObject) {
    self.document.execCommand("ClearAuthenticationCache");
  }
  else {
    firefoxClearAuthenticationCache();
  }

  xfilesSoapManager = null;
  getHttpUsername();

  try {

    var httpRequest; 
    var targetURL = "/XFILES/whoami.xml"
    var attemptCount = 0;
    
    do {
      attemptCount++;
      httpRequest = httpMgr.createGetRequest(targetURL , false, username, password);
      processAuthentication(httpRequest);

      if (httpRequest.status == 401) {
        return false;
      }

    }
    while ((httpRequest.status == 12152) && (attemptCount < 2));
 
    if (attemptCount > 2) {
      error = new xfilesException('userManagement.validCredentials',15,targetURL, null);
      error.setDescription(httpRequest.statusText);
      error.setNumber(httpRequest.status);
      throw error;
    }

  }
  catch (e) {
    error = new xfilesException('userManagement.validCredentials',15, resourceURL, e);
    throw error;
  }
  
  return true;
  
}

function validateDBA() {

  try {

    resourceURL = "/xdbconfig.xml"
    var httpRequest = createGetRequest(resourceURL , false);
    httpRequest.send(null);

    // alert('httpRequest(' +targetURL + ' = ') : Status = httpRequest.status);

    if (httpRequest.status == 200) {
      window.location.reload(true);
      return true;
    }

    if (httpRequest.status == 401) {
      showUserErrorMessage("This user is not a DBA. This step cannot be executed.");
      enableCloseButton();
      return false;
    }
  }
  catch (e) {
    error = new xfilesException('userManagement.validCredentials',15, resourceURL, e);
    throw error;
  }

}

function processsPasswordReset(mgr, message) {

  var successMessage = 'Operation Successful';
  if (typeof message != "undefined") {
    successMessage = message;
  }

  try {
    var soapResponse = mgr.getSoapResponse('userManagement.processsPasswordReset');
    showInfoMessage(successMessage);
    closePopupDialog();

  }
  catch (e) {
    handleException('userManagement.processsPasswordReset',e,null);
  }

}

function openSetPasswordDialog(evt) {
  document.getElementById('newPassword1').value = "";
  document.getElementById('newPassword2').value = "";
  openPopupDialog(evt, document.getElementById('setPasswordDialog'))
}

function doSetPassword(evt) {
  openSetPasswordDialog(evt);
}

function setUserOptions() {

  var pwd1 = document.getElementById('newPassword1').value;
  var pwd2 = document.getElementById('newPassword2').value;

  if ((pwd1) || (pwd2)) {
    if (pwd1 != pwd2) {
      showUserErrorMessage('Password must match');
      document.getElementById('newPassword1').focus;
      return false;
    }
  }

  var resetHomeFolder    = booleanToNumber(document.getElementById('resetHomeFolder').checked)
  var recreateHomePage   = booleanToNumber(document.getElementById('recreateHomePage').checked)
  var resetPublicFolder  = booleanToNumber(document.getElementById('resetPublicFolder').checked)
  var recreatePublicPage = booleanToNumber(document.getElementById('recreatePublicPage').checked)

  try {
    var schema  = "XFILES";
    var package = "XFILES_USER_SERVICES";
    var method =  "RESETUSEROPTIONS";
  
  	var mgr = new soapRequestManager(schema,package,method,wsManager);
  	var httpRequest = mgr.createPostRequest();
    httpRequest.onreadystatechange=function() { if( httpRequest.readyState==4 ) { processsPasswordReset(mgr, 'User Updated')}};
  	  	
  	var parameters = new Object;
  	parameters["P_NEW_PASSWORD-VARCHAR2-IN"]   = pwd1
  	parameters["P_RESET_PUBLIC_FOLDER-BOOLEAN-IN"]   = resetPublicFolder
  	parameters["P_RESET_HOME_FOLDER-BOOLEAN-IN"]   = resetHomeFolder
  	parameters["P_RECREATE_PUBLIC_PAGE-BOOLEAN-IN"]   = recreatePublicPage
  	parameters["P_RECREATE_HOME_PAGE-BOOLEAN-IN"]   = recreateHomePage

    mgr.sendSoapRequest(parameters)
  } 
  catch (e) {
    handleException('userManagement.setUserOptions',e,null);
  }
  
}

function addUsersToUserList(optionList) {

	var selectList = document.getElementById('userList');
	selectList.innerHTML = "";
	var width = 0;
	for (var i=0; i< optionList.length; i++) {
	  var user = optionList.item(i);
	  var value = user.firstChild.nodeValue;
	  var option = document.createElement("option");
	  selectList.appendChild(option);
	  option.id = value;
	  option.value = value;
    var text = document.createTextNode(value);
    option.appendChild(text);
    if (width < value.length) {
      width = value.length
    }
 }

 selectList.width = width;

}

function processAdminPrivileges(mgr,evt) {

	var soapResponse = mgr.getSoapResponse('userManagement.processAdminPrivileges');

  var namespaces = xfilesNamespaces; 
  namespaces.redefinePrefix("tns",mgr.getNamespace());

  document.getElementById('newUserPassword1').value = "";
  document.getElementById('newUserPassword2').value = "";
  document.getElementById('username').value = "";
  openPopupDialog(evt,document.getElementById('manageUsersDialog'))

  var div
 	div = document.getElementById('dbaOnly');
 	div.style.display="none";
 	div = document.getElementById('xfilesAdmin');
  div.style.display="none";
  div = document.getElementById('noAdminRights');
  div.style.display="block";

  var userList = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:RETURN/tns:UserPrivileges/tns:userList/tns:user",namespaces);
  addUsersToUserList(userList);

  var nodeList = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:RETURN/tns:UserPrivileges[tns:dba=1]",namespaces);
  if (nodeList.length == 1) {
  	div = document.getElementById('dbaOnly');
  	div.style.display="block";
  	div = document.getElementById('xfilesAdmin');
   	div.style.display="block";
  	div = document.getElementById('noAdminRights');
   	div.style.display="none";
   	return;
  }

  var nodeList = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:RETURN/tns:UserPrivileges[tns:xfilesAdmin=1]",xfilesNamespaces);
  if (nodeList.length == 1) {
  	div = document.getElementById('dbaOnly');
  	div.style.display="none";
	  div = document.getElementById('xfilesAdmin');
  	div.style.display="block";
  	div = document.getElementById('noAdminRights');
   	div.style.display="none";
  	div = document.getElementById('adminOptionButton');
    var nodeList = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:RETURN/tns:UserPrivileges/tns:xfilesAdmin[text()=1 and @withGrant=1]",xfilesNamespaces);
    if (nodeList.length == 1) {
     	div.style.display="block";
    }
    else {
     	div.style.display="none";
    }
   	return;
  }

}

function checkAdminPrivileges(evt) {

  var schema  = "XFILES";
  var package = "XFILES_USER_SERVICES";
  var method =  "GETUSERPRIVILEGES";

	var mgr = new soapRequestManager(schema,package,method,wsManager);
 	var httpRequest  = mgr.createPostRequest();
  httpRequest.onreadystatechange=function() { if( httpRequest.readyState==4 ) { processAdminPrivileges(mgr,evt)}};

	var parameters = new Object;
  mgr.sendSoapRequest(parameters);
	
}


function openManageUsersDialog(evt) {
	checkAdminPrivileges(evt);
}

function doManageUsers(evt) {
  openManageUsersDialog(evt);
}

function manageUser(userName, pwd1, pwd2) {

  if (pwd1 != pwd2) {
    showUserErrorMessage('Password must match');
    document.getElementById('newPassword1').focus;
    return false;
  }
  
  try {

    var schema  = "XFILES";
    var package = "XFILES_ADMIN_SERVICES";
    var method =  "CREATEXFILESUSER";
  
  	var mgr = new soapRequestManager(schema,package,method,wsManager);    	
  	var httpRequest = mgr.createPostRequest();
    httpRequest.onreadystatechange=function() { if( httpRequest.readyState==4 ) { reportSuccess(mgr, 'User Created')}};
  	
  	var parameters = new Object;
  	parameters["P_PRINCIPLE_NAME-VARCHAR2-IN"]   = userName
  	parameters["P_PASSWORD-VARCHAR2-IN"]   = pwd1
  	
    mgr.sendSoapRequest(parameters)
  } 
  catch (e) {
    handleException('userManagement.manageUser',e,null);
  }
  
}

function updateRole(user,role) {

  var schema  = "XFILES";
  var package = "XFILES_ADMIN_SERVICES ";
  var method;
  var message;
  
  if (role == 'disabled') {
  	method =  "REVOKEXFILES";
   	message =  'XFiles access revoked from "' + user + '"';
  }
 
  if (role == 'user') {
    method =  "GRANTXFILESUSER";
    message =   'XFiles access emabled for "' + user + '"';
  }
 
  if (role == 'administrator') {
    method =  "GRANTXFILESADMINISTRATOR";
    message =  'XFiles adminstration enabled for "' + user + '"';
  }
 
  var mgr = new soapRequestManager(schema,package,method,wsManager);
  var httpRequest = mgr.createPostRequest();
  httpRequest.onreadystatechange=function() { if( httpRequest.readyState==4 ) { reportSuccess(mgr,message)}};
  
  var parameters = new Object;
  parameters["P_PRINCIPLE_NAME-VARCHAR2-IN"]   = user

  mgr.sendSoapRequest(parameters);
 
}

function setUserRole() {

  try {
		var selectList = document.getElementById('userList');
    var roleList = document.getElementsByName('roleSelector');
    var newRole;

    for (var i = 0; i < roleList.length; i++) {
      if (roleList[i].checked) {
      	newRole = roleList[i].value;
      }
    }

    for (var i = 0; i < selectList.options.length; i++) {
      if (selectList.options[i].selected) {
      	updateRole(selectList.options[i].value, newRole);
      }
    }
  } 
  catch (e) {
    handleException('userManagement.setUserRole',e,null);
  }
}

