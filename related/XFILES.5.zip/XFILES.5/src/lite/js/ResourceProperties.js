var dummy // Declaring a variable seems to help IE load the script correctly

function onPageLoaded() {
  updatePickLists();
}

function updatePickLists() {

  if (resource.selectNodes('/res:Resource[@Container="false"]',xfilesNamespaces).length > 0) {
    target = resource.selectNodes('/res:Resource/res:CharacterSet',xfilesNamespaces).item(0).firstChild.nodeValue;
    if (document.getElementById(target)) {
      document.getElementById(target).selected='selected';
    }
    target = resource.selectNodes('/res:Resource/res:Language',xfilesNamespaces).item(0).firstChild.nodeValue
    if (document.getElementById(target)) {
      document.getElementById(target).selected='selected';
    }
  }

}

function processUpdate(mgr, outputWindow, closeFormWhenFinished) {

  try {
    soapResponse = mgr.getSoapResponse('ResourceProperties.processProperties');

   	var namespaces = xfilesNamespaces
	  namespaces.redefinePrefix("tns",mgr.getNamespace());
    nodeList = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:P_UPDATED_RESOURCE/res:Resource",namespaces);
    if (nodeList.length == 1) {
      showInfoMessage('Resource Updated');
      if (closeFormWhenFinished) {
        closeCurrentWindow();
      }
      resource = importResource(nodeList.item(0));
      displayResource(resource,outputWindow,stylesheetURL);
      return;
    }
    
    error = new xfilesException('ResourceProperties.processUpdate',12, resourceURL, null);
    error.setDescription("Invalid Update Properties Document Receieved :  " + soapResponse.serialize());
    throw error;
  }
  catch (e) {
    handleException('ResourceProperties.processUpdate',e,null);
  }

}

function doSave() {
  saveChanges(false);
}

function doSaveAndClose() {
  saveChanges(true);
}

function updateProperties(resourceURL, closeFormWhenFinished, newValues, outputWindow) {

  var schema  = "XFILES";
  var package = "XFILES_SOAP_SERVICES";
  var method =  "UPDATEPROPERTIES";

	var mgr = new soapRequestManager(schema,package,method,wsManager);
	var httpRequest = mgr.createPostRequest();
  httpRequest.onreadystatechange=function() { if( httpRequest.readyState==4 ) { processUpdate(mgr, outputWindow, closeFormWhenFinished)}};

	var parameters = new Object;
	parameters["P_RESOURCE_PATH-VARCHAR2-IN"] = resourceURL
	parameters["P_TIMEZONE_OFFSET-NUMBER-IN"] = timezoneOffset 

	var xparameters = new Object;
	xparameters["P_NEW_VALUES-XMLTYPE-IN"] = newValues
		
  mgr.sendSoapRequest(parameters,xparameters); 
    
}

function saveChanges(closeFormWhenFinished) {

  var modification = new xmlDocument();
  var root = modification.createElement("ResourceUpdate");
  modification.appendChild(root);
  
  isContainer = resource.selectNodes('/res:Resource[@Container="true"]',xfilesNamespaces).length > 0;
  
  var newDisplayName   = document.getElementById('DisplayName').value;
  
  if (!isContainer) {
    var newAuthor        = document.getElementById('Author').value;
  }
  
  var newComment       = document.getElementById('Comment').value;

  var newCharacterSet;
  var newLanguage;     
  
  if (!isContainer) {
    newCharacterSet  = document.getElementById('CharacterSet').value;
     newLanguage      = document.getElementById('Language').value;
  }
  
  var oldDisplayName   = resource.selectNodes('/res:Resource/res:DisplayName',xfilesNamespaces).item(0).firstChild.nodeValue;

  var oldAuthor;
  var oldAuthorList  = resource.selectNodes('/res:Resource/res:Author',xfilesNamespaces);
  if (oldAuthorList.length > 0) {
    oldAuthor = oldAuthorList.item(0).firstChild.nodeValue;
  }

  var oldComment
  var oldCommentList = resource.selectNodes('/res:Resource/res:Comment',xfilesNamespaces);
  if (oldCommentList.length > 0) {
    oldCommennt = oldCommentList.item(0).firstChild.nodeValue;
  }
 
  var oldCharacterSet  = resource.selectNodes('/res:Resource/res:CharacterSet',xfilesNamespaces).item(0).firstChild.nodeValue;
  var oldLanguage      = resource.selectNodes('/res:Resource/res:Language',xfilesNamespaces).item(0).firstChild.nodeValue;

  if (oldDisplayName != newDisplayName) {
    var displayName = modification.createElement("DisplayName");
    var text        = modification.createTextNode(newDisplayName);
    displayName.appendChild(text);
    root.appendChild(displayName);
    var updateLinkName   = document.getElementById('RenameLink').checked;
    if (updateLinkName) {
      displayName.setAttribute('renameLinks','true');
    }
  }  
  
  if ((newAuthor) && (oldAuthor != newAuthor )) {
    var author = modification.createElement("Author");
    var text   = modification.createTextNode(newAuthor);
    author.appendChild(text);
    root.appendChild(author);
  }  

  if ((newComment) && (oldComment != newComment)) {
    var comment = modification.createElement("Comment");
    var text   = modification.createTextNode(newComment);
    comment.appendChild(text);
    root.appendChild(comment);
  }  

  if (oldCharacterSet != newCharacterSet) {
    var characterSet = modification.createElement("CharacterSet");
    var text   = modification.createTextNode(newCharacterSet);
    characterSet.appendChild(text);
    root.appendChild(characterSet);
  }  

  if (oldLanguage != newLanguage) {
    var language = modification.createElement("Language");
    var text   = modification.createTextNode(newLanguage);
    language.appendChild(text);
    root.appendChild(language);
  }  
 
  updateProperties(resourceURL, closeFormWhenFinished, modification, document.getElementById('pageContent'));

}

function doPreviewDocument(event) {
	openPopupDialog(event,"documentPreviewDialog");
}