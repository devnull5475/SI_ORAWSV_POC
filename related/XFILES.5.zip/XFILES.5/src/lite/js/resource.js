function init(target) {

  try {
    initXFilesCommon(target);

    stylesheetURL   =   unescape(getParameter("stylesheet"));  
    if ((typeof stylesheetURL == "undefined") || (stylesheetURL == "")) {
      stylesheetURL = '/XFILES/lite/xsl/ResourceProperties.xsl';
    }
    
    includeContent   = (getParameter("includeContent") == "true");

    resourceURL = unescape(getParameter("target"));
    if ((typeof resourceURL == "undefined") || (resourceURL == "")) {
      resourceURL = '/';
    }
    getResource(resourceURL,target,stylesheetURL,includeContent);
  }
  catch (e) {
    handleException('resource.init',e,null);
  }
}
