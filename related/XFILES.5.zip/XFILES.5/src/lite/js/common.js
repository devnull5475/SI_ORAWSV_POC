var resource;
var resourceURL;
var stylesheetURL;

// Cache the current XSL to allow local sorting without refetching the XSL.

var folderXSL;
                  
var xfilesNamespaces ;
var xfilesPrefixList = orawsvPrefixList;
    xfilesPrefixList['xfiles'] = 'http://xmlns.oracle.com/xdb/xfiles';
    xfilesPrefixList['rss']    = 'http://xmlns.oracle.com/xdb/xfiles/rss';
    xfilesPrefixList['res']    = 'http://xmlns.oracle.com/xdb/XDBResource.xsd';
    xfilesPrefixList['wiki']   = 'http://xmlns.oracle.com/xdb/xfiles/wiki';
    xfilesPrefixList['img']    = "http://xmlns.oracle.com/xdb/metadata/ImageMetadata";
    xfilesPrefixList['exif']   = "http://xmlns.oracle.com/ord/meta/exif";
    xfilesPrefixList['xhtml']  = "http://www.w3.org/1999/xhtml";

function loadXFilesNamespaces() {
  xfilesNamespaces = new namespaceManager(xfilesPrefixList);
}

function initXFilesCommon(target) {

  initCommon();
  loadXFilesNamespaces();
  
}
     
function doTransform(target,document,stylesheetURL) {
	 
	 var stylesheet = loadXSLDocument(stylesheetURL);
   transformXML(target,document,stylesheet);

}
   
function xmlTreeControl(name,tree,namespaces,XSL,target) {

   var treeName;
   var treeState; 
   var treeStateXSL;
   var targetWindow;
   var treeNamespaces;
   
   this.treeName = name;
   this.treeState = tree;
   this.treeStateXSL = XSL;
   this.targetWindow = target
   this.treeNamespaces = namespaces;
   
   var self = this;

   transformXML(this.targetWindow,this.treeState,this.treeStateXSL);
   
   function toggleChildren(parent,state) {
     for (i=0 ; i < parent.childNodes.length; i++) {
       child = parent.childNodes[i];
       if (child.nodeName == 'DIV') {
         if (state == 'visible') {
           child.style.display="block";
         }
         else {
           child.style.display="none";
         }
       }
     }
   }
   
   this.showChildren = function ( id ) { 
     node = self.treeState.selectNodes('//*[@id="' + id + '"]/@children',self.treeNamespaces).item(0);
     node.value = 'visible';
     transformXML(self.targetWindow,self.treeState,self.treeStateXSL);
     raiseEvent(target,"click");
   }

   this.hideChildren = function ( id ) { 
     node = self.treeState.selectNodes('//*[@id="' + id + '"]/@children',self.treeNamespaces).item(0);
     node.value = 'hidden';
     transformXML(self.targetWindow,self.treeState,self.treeStateXSL);
     raiseEvent(target,"click");
   }
   
   this.getOpenFolder = function() {
     node = self.treeState.selectNodes('//*[@isOpen="open"]',self.treeNamespaces).item(0);
     if (!node) {
       return null
     }

     var currentPath = "";
          
     if (node) {
       currentPath = "";
       while (node.parentNode.ownerDocument) {
         currentPath = '/' + node.getAttribute('name')  + currentPath;
         node = node.parentNode;
       }
     }

     if (currentPath == "") {
       currentPath = "/";
     }     
     return currentPath;
     
   }

   this.selectBranch = function ( id ) { 
     unimplementedFunction('selectBranch ' + id);
   }
   
   this.unselectBranch = function ( id ) { 
     unimplementedFunction('unselectBranch ' + id);
   }
   
   this.makeOpen = function ( id ) { 
     node = self.treeState.selectNodes('//*[@isOpen="open"]',self.treeNamespaces).item(0);
     if (node) {
       node.setAttribute('children','hidden');
       node.setAttribute('isOpen','closed');
     }

     node = self.treeState.selectNodes('//*[@id="' + id + '"]',self.treeNamespaces).item(0);
     node.setAttribute('isOpen','open');
     while (node.ownerDocument) {
       node.setAttribute('children','visible');
       node = node.parentNode;
     }
     transformXML(self.targetWindow,self.treeState,self.treeStateXSL);
     raiseEvent(target,"click");

   }

   this.makeClosed = function ( id ) { 
     node = self.treeState.selectNodes('//*[@isOpen="open"]',self.treeNamespaces).item(0);
     node.setAttribute('isOpen','closed');
     transformXML(self.targetWindow,self.treeState,self.treeStateXSL);
     raiseEvent(target,"click");
   }
}

function doSearch(searchType,searchTerms) {

  var action = searchType.value;
  var criteria = searchTerms.value;
   
  if (!isAuthenticatedUser()) {
  	showUserErrorMessage("Search restricted to authenticated users - please log in.");
  	return;
  }
  
  if ((action == 'FOLDER') || (action == 'TREE') || (action == 'ROOT')) {
  	 if (isEmptyString(criteria)) {
  	 	 showErrorMessage('Enter Search Criteria');
  	 	 return;
  	 }
     window.location='/XFILES/XMLSearch/reposSearch.html?target=' + escape(resourceURL) + '&searchType=' + action + '&searchTerms=' + escape(criteria);   
  }
 
  if (action == 'ADV') {
     window.location='/XFILES/XMLSearch/resourceSearch.html?target=' + escape(resourceURL) + '&searchTerms=' + escape(criteria);   
  }
  
  if (action == 'XSD') {
     window.location='/XFILES/lite/Resource.html?target=' + ('/XFILES/XMLSearch/xmlSchema/xmlSchemaList.xml') + '&stylesheet=' + escape('/XFILES/lite/xsl/XMLSchemaList.xsl') + '&includeContent=true';   
  }
  
  if (action == 'XIDX') {
     window.location='/XFILES/lite/Resource.html?target=' + ('/XFILES/XMLSearch/xmlIndex/xmlIndexList.xml') + '&stylesheet=' + escape('/XFILES/lite/xsl/XMLIndexList.xsl')  + '&includeContent=true';   
  }

}

function toggleSearchTerms(searchType,searchTerms) {

  var action = searchType.value;

  if ((action == 'FOLDER') || (action == 'TREE') || (action == 'ROOT') ||  (action == 'ADV')) {
   	searchTerms.disabled = false;
  }
  else {
   	searchTerms.disabled = true;
  }	
}

function displayResource(resource, outputWindow, stylesheetURL) {

  resourceURL = resource.selectNodes("/res:Resource/xfiles:ResourceStatus/xfiles:CurrentPath/@xfiles:EncodedPath",xfilesNamespaces).item(0).nodeValue;
  doTransform(outputWindow,resource,stylesheetURL);
  loadScripts();

}

function importResource(resource) {

  var newResource = new xmlDocument();
  var node = newResource.appendChild(newResource.importNode(resource,true));
  return newResource;

}

function processResourceREST(newResource, outputWindow, stylesheetURL) {

  try {
  	newResource.checkParsing();
	  resource = newResource;
  	displayResource(resource,outputWindow,stylesheetURL);
  }
  catch (e) {
    handleException('common.processResourceREST',e,resourceURL);
  }
  
}

function processResourceSOAP(mgr, outputWindow, stylesheetURL) {

  try {
    var soapResponse = mgr.getSoapResponse("common.processResourceSOAP");
    
    var namespaces = xfilesNamespaces;
    namespaces.redefinePrefix("tns",mgr.getNamespace());
  
    var newResource = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:P_RESOURCE/res:Resource",namespaces).item(0);
    resource = importResource(newResource);
    displayResource(resource,outputWindow,stylesheetURL);
  }
  catch (e) {
    handleException('common.processResourceSOAP',e,resourceURL);
  }

}

function getResourceREST(resourceURL, outputWindow, stylesheetURL, includeContent) {

  var restURL;
  var resource = new xmlDocument();
   
  if (includeContent) {
    restURL = '/sys/servlets/XFILES/RestService/XFILES.XFILES_REST_SERVICES.GETRESOURCEWITHCONTENT?P_RESOURCE_PATH=' + resourceURL;
  }
  else {
    restURL = '/sys/servlets/XFILES/RestService/XFILES.XFILES_REST_SERVICES.GETRESOURCE?P_RESOURCE_PATH=' + resourceURL;
  }
    
  resource.setOnLoad( function() {processResourceREST(resource, outputWindow, stylesheetURL)} );
  resource.load(restURL,true);

}


function getResourceSOAP(resourceURL, outputWindow, stylesheetURL, includeContent) {

  var schema  = "XFILES";
  var package = "XFILES_SOAP_SERVICES";
  var method;

  if (includeContent) {
	  method =  "GETRESOURCEWITHCONTENT";
	}
  else {
	  method =  "GETRESOURCE";
	}
	
	var mgr = new soapRequestManager(schema,package,method,wsManager);
  	
	var namespaces = xfilesNamespaces
	namespaces.redefinePrefix("lite",mgr.getNamespace());
	
	var httpRequest = mgr.createPostRequest();
  httpRequest.onreadystatechange=function() { if( httpRequest.readyState==4 ) { processResourceSOAP(mgr, outputWindow, stylesheetURL) } };

	var parameters = new Object;
	parameters["P_RESOURCE_PATH-VARCHAR2-IN"]   = resourceURL
  parameters["P_TIMEZONE_OFFSET-NUMBER-IN"] = timezoneOffset
  mgr.sendSoapRequest(parameters);    
     
}

function getResource(resourceURL, outputWindow, stylesheetURL, includeContent) {

  if (!isAuthenticatedUser()) {
    getResourceREST(resourceURL,outputWindow,stylesheetURL,includeContent);
  }
  else {
    getResourceSOAP(resourceURL,outputWindow,stylesheetURL,includeContent);
  }
}

function displayFolder(resource, outputWindow, stylesheetURL) {

  // showSourceCode(resource);
  resourceURL = resource.selectNodes("/res:Resource/xfiles:ResourceStatus/xfiles:CurrentPath/@xfiles:EncodedPath",xfilesNamespaces).item(0).nodeValue;

  var rssEnabled = (resource.selectNodes("/res:Resource/rss:enableRSS",xfilesNamespaces).length > 0);
  if (rssEnabled) {
  	// RSS Feed is enabled for this folder. Check if the HTML Page contains the rss Link
    var rssLinkPresent = document.getElementById('rssEnabled');
    if (! rssLinkPresent) {
    	// Redirect to the ENABLERSSICON servlet. Servlet regenerates the HTML Page with the RSS Link and sends it back to browser. <HEAD> element must contain an element as follows : <link id="enableRSSIcon"/>
    	var doAuthentication = getParameter("forceAuthentication");
    	if ((!doAuthentication) || (doAuthentication.toLowerCase != "true")) {
    		doAuthentication = "false";
      }
      if (isAuthenticatedUser()) {
        window.location.href = "/sys/servlets/XFILES/Protected/XFILES.XFILES_REST_SERVICES.ENABLERSSICON?P_RESOURCE_PATH=" + escape(resourceURL) + "&P_TEMPLATE_PATH=" + escape("/XFILES/lite/FolderRSS.html") + "&P_STYLESHEET_PATH=" + escape(stylesheetURL) + "&P_FORCE_AUTHENTICATION=" + doAuthentication;
      }
      else {
        window.location.href = "/sys/servlets/XFILES/RestService/XFILES.XFILES_REST_SERVICES.ENABLERSSICON?P_RESOURCE_PATH=" + escape(resourceURL) + "&P_TEMPLATE_PATH=" + escape("/XFILES/lite/FolderRSS.html") + "&P_STYLESHEET_PATH=" + escape(stylesheetURL) + "&P_FORCE_AUTHENTICATION=" + doAuthentication;
      }
      return;
    }
  }

  // Cache folderXSL to enable local sorting.

	folderXSL = loadXSLDocument(stylesheetURL);
  transformXML(outputWindow,resource,folderXSL);
  loadScripts();
  
}

function importFolder(resource,children) {

  var newResource = new xmlDocument();
  var node = newResource.appendChild(newResource.importNode(resource,true));
  node = newResource.getDocumentElement().appendChild(newResource.importNode(children,true));
  return newResource;

}

function processFolderREST(newResource, outputWindow, stylesheetURL) {

  try {
  	newResource.checkParsing();
    resource = newResource;
    displayFolder(resource,outputWindow,stylesheetURL);
  }
  catch (e) {
    handleException('common.processFolderREST',e,resourceURL);
  }

}

function processFolderSOAP(mgr, outputWindow, stylesheetURL) {

  try {
    var soapResponse = mgr.getSoapResponse("common.processFolderSOAP");
    
    var namespaces = xfilesNamespaces;
    namespaces.redefinePrefix("tns",mgr.getNamespace());
  
    var folder = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:P_FOLDER/res:Resource",namespaces).item(0);
    var children  = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:P_CHILDREN/xfiles:DirectoryContents",namespaces).item(0)     
    resource = importFolder(folder,children);
    displayFolder(resource,outputWindow,stylesheetURL);
  }    
  catch (e) {
   handleException('common.processFolderSOAP',e,resourceURL);
  }
}

function showFolderREST(folderURL, outputWindow, stylesheetURL) {

  // alert('getFolderRest(' + folderURL + ')');
  
  var resource = new xmlDocument();
  resource.setOnLoad( function() {processFolderREST(resource, outputWindow, stylesheetURL)} );
  resource.load('/sys/servlets/XFILES/RestService/XFILES.XFILES_REST_SERVICES.GETFOLDERLISTING?P_FOLDER_PATH=' + folderURL,true);
  
}

function showFolderSOAP(folderURL, outputWindow, stylesheetURL) {


  var schema  = "XFILES";
  var package = "XFILES_SOAP_SERVICES";
  var method =  "GETFOLDERLISTING";

	var mgr = new soapRequestManager(schema,package,method,wsManager);
	var httpRequest = mgr.createPostRequest();
  httpRequest.onreadystatechange=function() { if( httpRequest.readyState==4 ) { processFolderSOAP(mgr, outputWindow, stylesheetURL) } };

	var parameters = new Object;
	parameters["P_FOLDER_PATH-VARCHAR2-IN"]   = folderURL
	parameters["P_TIMEZONE_OFFSET-NUMBER-IN"] = timezoneOffset 
	mgr.sendSoapRequest(parameters);

}

function showFolder(folderURL, outputWindow, stylesheetURL) {

  if (!isAuthenticatedUser()) {
    showFolderREST(folderURL,outputWindow,stylesheetURL);
  }
  else {
    showFolderSOAP(folderURL,outputWindow,stylesheetURL);
  }
}
    
function doFolderJump(newFolderPath,newStylesheetURL) {

  stylesheetURL = '/XFILES/lite/xsl/FolderBrowser.xsl';
  
  if ((typeof newStylesheetURL == "string") && ( newStylesheetURL != "")) {
    stylesheetURL = newStylesheetURL
  }

  // If the current Page is RSS enabled we must do the jump via a reload to ensure the Browser's RSS Icon registers the change of location / RSS status

  var rssEnabled = (resource.selectNodes("/res:Resource/rss:enableRSS",xfilesNamespaces).length > 0);
  if (rssEnabled)	{
  	window.location.href = "/XFILES/lite/Folder.html?target=" + escape(newFolderPath) + "&stylesheet="+ escape(stylesheetURL);
  }
  else {
	  resourceURL = newFolderPath
	  showFolder(resourceURL,document.getElementById('pageContent'),stylesheetURL,false);
	}
}

function displayVersionHistory(resource, outputWindow, stylesheetURL) {

  resourceURL = resource.selectNodes("/res:Resource/xfiles:ResourceStatus/xfiles:CurrentPath/@xfiles:EncodedPath",xfilesNamespaces).item(0).nodeValue;
  doTransform(outputWindow,resource,stylesheetURL);
  loadScripts();
  
}

function importVersionHistory(resource,versionHistory) {

  newResource = new xmlDocument();
  var node = newResource.appendChild(newResource.importNode(resource,true));
  node = newResource.getDocumentElement().appendChild(newResource.importNode(versionHistory,true));
  return newResource;

}

function processVersionHistoryREST(newResource, outputWindow, stylesheetURL) {
	
  try {
  	newResource.checkParsing();
    resource = newResource;
    displayVersionHistory(resource,outputWindow,stylesheetURL);
  }
  catch (e) {
    handleException('common.processVersionHistoryREST',e,resourceURL);
  }
  
}

function processVersionHistorySOAP(mgr, outputWindow, stylesheetURL) {

  try {
    var soapResponse = mgr.getSoapResponse("common.processVersionHistorySOAP");
    
    var namespaces = xfilesNamespaces;
    namespaces.redefinePrefix("tns",mgr.getNamespace());
  
    var newResource = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:P_RESOURCE/res:Resource",namespaces).item(0);
    var versionHistory  = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:P_VERSION_HISTORY/xfiles:VersionHistory",namespaces).item(0);
    resource = importVersionHistory(newResource,versionHistory);
    displayVersionHistory(resource,outputWindow,stylesheetURL);
  }
  catch (e) {
    handleException('common.processVersionHistorySOAP',e,resourceURL);
  }

}

function getVersionHistorySOAP(resourceURL, outputWindow, stylesheetURL) {

  var schema  = "XFILES";
  var package = "XFILES_SOAP_SERVICES";
  var method =  "GETVERSIONHISTORY";

	var mgr = new soapRequestManager(schema,package,method,wsManager);
	var httpRequest = mgr.createPostRequest();
  httpRequest.onreadystatechange=function() { if( httpRequest.readyState==4 ) { processVersionHistorySOAP(mgr, outputWindow, stylesheetURL) } };

  var parameters = new Object;
	parameters["P_RESOURCE_PATH-VARCHAR2-IN"] = resourceURL
	parameters["P_TIMEZONE_OFFSET-NUMBER-IN"] = timezoneOffset 
  mgr.sendSoapRequest(parameters);

}

function getVersionHistoryREST(resourceURL, outputWindow, stylesheetURL) {

  var resource = new xmlDocument();
  resource.setOnload( function() {processVersionHistoryREST(resource, outputWindow, stylesheetURL)} );
  resource.load('/sys/servlets/XFILES/RestService/XFILES.XFILES_REST_SERVICES.GETVERSIONHISTORY?P_FOLDER_PATH=' + resourceURL,true);
  
}

function getVersionHistory(resourceURL, outputWindow, stylesheetURL) {

  if (!isAuthenticatedUser()) {
    getVersionHistoryREST(resourceURL,outputWindow,stylesheetURL);
  }
  else {
    getVersionHistorySOAP(resourceURL,outputWindow,stylesheetURL);
  }
}

function showAboutXFiles(evt) {
	
	openPopupDialog(evt,"aboutXFilesDialog");
	
}

function doShowHomeFolder(evt,user) {
	
  if (document.getElementById("folderListing")) {
    doFolderJump('/home/' + user);
  }
  else {
    window.location = "/XFILES/lite/Folder.html?target=" + escape("/home/" + user);
  }
}

function xfilesHelpMenu(evt) {
	var dialog = document.getElementById("xfilesHelpMenu");
  openPopupDialog(evt, dialog)

}
     	
function closeCurrentWindow(currentURL) {
	showParentFolder(currentURL);
}

function showParentFolder(currentURL) {
  
  var targetURL 
 
  if (typeof currentURL == "undefined") {
    targetURL = resourceURL;
  } 
  else {
   targetURL = currentURL;
  }
 
  if (resourceURL.lastIndexOf("/") == 0) {
    targetURL = "/";
  }
  else {
    targetURL = targetURL.substring(0,targetURL.lastIndexOf("/"));
  }
 
  window.location = "/XFILES/lite/Folder.html?target=" + escape(targetURL);
}

function isErrorDialogOpen() {
	
	errorDialog = document.getElementById("genericErrorDialog");
	if (errorDialog) {
		return errorDialog.style.display != "none";
	}
	
	return false;

}
