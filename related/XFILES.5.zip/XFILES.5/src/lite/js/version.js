function init(target) {

  try {
    initXFilesCommon(target);
    validateUser(getParameter('forceAuthentication'));

    stylesheetURL = unescape(getParameter("stylesheet"));
    if ((typeof stylesheetURL == "undefined") || (stylesheetURL == "")) {
      stylesheetURL = '/XFILES/lite/xsl/VersionHistory.xsl';
    } 
 
    resourceURL = unescape(getParameter("target"));
    if ((typeof resourceURL == "undefined") || (resourceURL == "")) {
      resourceURL = '/';
    }
    getVersionHistory(resourceURL,target,stylesheetURL);
  }
  catch (e) {		
    handleException('version.init',e,null);
  }
}

