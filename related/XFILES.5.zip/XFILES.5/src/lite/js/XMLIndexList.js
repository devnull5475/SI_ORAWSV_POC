function onPageLoaded() {
}

function processResponse(mgr) {

  try {
    var soapResponse = mgr.getSoapResponse('XMLIndexList.processResponse');
    window.location.reload( true );
  }    
  catch (e) {
    handleException('XMLIndexList.processResponse',e,null);
  }
}
  
function setDefaultValues(owner, tableName, indexName, uploadFolderPath)
{
  if (tableName.value == "") {
    uploadFolderPath.value = "";
    indexName.value = "";
  }
  else {
    if (uploadFolderPath.value == "" ) {
      uploadFolderPath.value = '/home/' + owner.value + '/upload';
    }
    if (indexName.value == "" ) {
      indexName.value = tableName.value + "_IDX";
    }
  }
}

function createXMLIndexedTable(tableName,indexName,uploadFolderPath) {

  try {
    if (isEmptyString(tableName)) {
      showUserErrorMessage('Please enter a name for the new table.');
     return;
    }

    if (isEmptyString(indexName)) {
      showUserErrorMessage('Please enter a name for the index.');
      return;
    }

    if (isEmptyString(uploadFolderPath)) {
      showUserErrorMessage('Please enter a location for the upload folder.');
      return;
    }
 
    var schema  = "XDBPM";
    var package = "XDBPM_TABLE_UPLOAD";
    var method =  "CREATEXMLINDEXEDTABLE";
  
  	var mgr = new soapRequestManager(schema,package,method,wsManager);
   	var httpRequest = mgr.createPostRequest();
  	httpRequest.onreadystatechange = function() { if( httpRequest.readyState==4 ) { processResponse(mgr) } };
    
  	var parameters = new Object;
  	parameters["P_UPLOAD_FOLDER-VARCHAR2-IN"]   = uploadFolderPath
  	parameters["P_TABLE_NAME-VARCHAR2-IN"]   = tableName
  	parameters["P_INDEX_NAME-VARCHAR2-IN"]   = indexName
    mgr.sendSoapRequest(parameters);
  }    
  catch (e) {
    handleException('XMLIndexList.createXMLIndexedTable',e,null);
  }
 
}