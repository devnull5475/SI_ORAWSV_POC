var dummy // Declaring a variable seems to help IE load the script correctly

function onPageLoaded() {
}

function xmlSchemaSearch(xmlSchemaOwner,xmlSchemaURL,dbSchemaName,dbTableName,xmlSchemaElement) {
    
  target = window.location.protocol + '//' + window.location.hostname + '/XFILES/XMLSearch/xmlSchema.html';
  target = target + '?xmlSchemaOwner=' + xmlSchemaOwner.value;
  target = target + '&xmlSchema=' + xmlSchemaURL.value;
  target = target + '&globalElement=' + xmlSchemaElement.value;
  target = target + '&defaultTable=' + dbTableName.value;
  target = target + '&defaultTableSchema=' + dbSchemaName.value;
  
  window.location.href = target

}
