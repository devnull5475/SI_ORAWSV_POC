// Generic dummy node map required to allow common fetchDocument function()

var nodeMap

function loadReposSearchXSL() {
	stylesheetURL = '/XFILES/XMLSearch/xsl/reposSearch.xsl';
}

function repositorySearch(searchType, searchTerms) {

  var targetFolder;
  
  if (searchType == "ROOT") {
    targetFolder = "/"
  }
  else {
    targetFolder = resourceURL;
  }
 
  sqlQuery = 'select ANY_PATH "resourcePath", score(1) RANK, r.*' + "\n" + 
             '  from "PUBLIC"."RESOURCE_VIEW",' + "\n" +
             getResourceProperties() +   
             '  where under_path (RES,';

  if (searchType == 'FOLDER') {
    sqlQuery = sqlQuery + "1,";
  }
    
  sqlQuery = sqlQuery + "'" + targetFolder + "') = 1 " + "\n" +
             "    and contains(RES,'" + searchTerms + "',1) > 0 " + "\n" +
             "  order by score(1) desc";
             
  var resultWindow = document.getElementById('resultWindow');             
  invokeExecuteSQLStatement(documentNodeMap, sqlQuery, resultWindow);   
  showSQLQuery(sqlQuery,document.getElementById('queryWindow'));

}

function init(target) {

  try {
    initXFilesCommon(target);
    loadReposSearchXSL();
    loadSearchTreeViewXSL();
    loadResourceListXSL();
    xfilesNamespaces = new namespaceManager(xfilesPrefixList);
  
    resourceURL  =   unescape(getParameter("target"));
    searchType   = getParameter("searchType");
    searchTerms  =  unescape(getParameter("searchTerms"));

    getResource(resourceURL,target,stylesheetURL);
  }
  catch (e) {
    handleException('reposSearch.init',e,null);
  }
}

function populateFormFields() {

  documentNodeMap = new NodeMap( "nodeMap" ,  loadXMLDocument('/XFILES/XMLSearch/xsl/resourceList.xsl'), 'resultWindow' );;
  document.getElementById("searchType").selectedValue=searchType;  
  document.getElementById("btnShowNodeMap").style.display = "none";
  repositorySearch(searchType,searchTerms);
  
}

function doViewXSL() {
	
	closePopupDialog();
  showSourceCode(documentNodeMap.getStylesheet());

}

function onPageLoaded() {
  populateFormFields();
  viewXSL = doViewXSL;
  document.getElementById("xmlIndexOptions").style.display = "none";
  document.getElementById("btnShowNodeMap").style.display = "none";
}
