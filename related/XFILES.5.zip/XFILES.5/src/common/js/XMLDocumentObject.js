function namespaceManager(namespaces) {

  var ns = namespaces
  var nsList = rebuildNamespaceList();
  
  function rebuildNamespaceList() {
    var nsList = ""
    for (x in ns) {
     nsList += "xmlns:" + x + "=\"" + ns[x] + "\" ";       
    }
    return nsList;
  }  
  
  this.resolveNamespace = function (prefix) { return ns[prefix] || null };
  this.getNamespaces = function () { return nsList };
  this.redefinePrefix = function (prefix, namespace) { ns[prefix] = namespace; nsList = rebuildNamespaceList(); }
}

function xsltProcessor( xsl, target) {

  var processor;
  var engine;
  var target;
  var self = this;
  
  try {
     this.target = target;
     if (window.ActiveXObject) {
      this.processor = new ActiveXObject(xslImplementation);
      this.processor.stylesheet = xsl.baseDocument;
      this.engine = this.processor.createProcessor();
    }
    else {
      if (document.implementation  && document.implementation.createDocument)  {
        this.processor = new XSLTProcessor();
        this.processor.importStylesheet(xsl.baseDocument); 
      }
      else {
        error = new xfilesException('xmlDocumentObject.xsltProcessor',9, null, null);
        error.setDescription('Browser does not support an XSLT Processor');
        throw error;
      }
    }
  }
  catch (e) {  
    error = new xfilesException('xmlDocumentObject.xsltProcessor',9, null, e);
    error.setDescription('Error Instantiating XSLT Processor');
    throw error;
  }
  

  function remoteTransform(xml,xsl) {

    // Server-Side XSL Transformation
    // Result is returned as a CDATA section

    var schema  = "XFILES";
    var package = "XFILES_UTILITIES";
    var method =  "XMLTRANSFORM2";
  
  	var mgr = new soapRequestManager(schema,package,method,wsManager);
   	var ajaxControl = mgr.createPostRequest(false);

  	var parameters = new Object
  
  	var xparameters = new Object;
  	xparameters["P_XSLDOC-XMLTYPE-IN"]   = xsl
  	xparameters["P_xmlDOC-XMLTYPE-IN"]   = xml
  		
    mgr.sendSoapRequest(parameters,xparameters);     // alert("Processing Server Side Transformation");
 
    var soapResponse = mgr.getSoapResponse('xmlDocumentObject.xsltProcessor.remoteTransform');

   	var namespaces = xfilesNamespaces
  	namespaces.redefinePrefix("tns",mgr.getNamespace());
  	
    nodeList = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:RETURN/tns:documentContent",namespaces);
    return new xmlDocument().parse(nodeList.item(0).firstChild.nodeValue);
  
  }
  
  function gecko2xml(node) {
    try {
      return self.processor.transformToFragment(node,self.target);
    }
    catch (e) {  
      // return remoteTransform(xml,xsl)
      error = new xfilesException('xmlDocumentObject.xsltProcessor.gecko2xml',9, null, e);
      error.setDescription('[GECKO]Error in processor.transformToFragment().');
      throw error;
    }
  }
  
  function gecko2document(node) {
    try {
      return self.processor.transformToDocument(node);
    }
    catch (e) {  
      error = new xfilesException('xmlDocumentObject.xsltProcessor.gecko2document',9, null, e);
      error.setDescription('[GECKO]Error in processor.transformToDocument().');
      throw error;
    }
  }

  function gecko2text(node,xsl) {
    return new XMLSerializer().serializeToString(gecko2xml(node));
  }
  
  function microsoft2xml(node) {
      var docFragment = target.createDocumentFragment();
      node.transformNodeToObject(xsl.baseDocument, docFragment);
      return docFragment;
  }
  
  function microsoft2text(node) {
    self.engine.input = node;
    self.engine.transform();
    return self.engine.output;
  }
  
  this.nodeToXML = function(node) {
    if (window.ActiveXObject) {
      return microsoft2xml(node) 
    }
    else {
      return gecko2xml(node);
    }
  }
  
  this.toXML = function(xml) {
  	return this.nodeToXML(xml.baseDocument);
  }
   
  this.nodeToText = function(node) {
    if (window.ActiveXObject) {
      return microsoft2text(node);
    }
    else {
      return gecko2text(node);
    }
  }
  
  this.toText = function(xml) {
  	return this.nodeToText(xml.baseDocument);
  }

  this.nodeToDocument = function(node) {
    if (window.ActiveXObject) {
  		return new xmlDocument().parse(microsoft2text(node));
  	}
  	else {
  		return new xmlDocument(gecko2document(node))
    }
  }

  this.toDocument = function(xml) {
  	return this.nodeToDocument(xml.baseDocument);
  }
}

function xmlNodeList(nl) {

  var innerNodeList;
  var length;
  
  if (window.ActiveXObject) {
  	innerNodeList = nl
  }
  else {
    innerNodeList = new Array();
    var node = nl.iterateNext(); 
    while (node) {
       innerNodeList.push(node);
       node = nl.iterateNext();
    }
  }

  this.length = innerNodeList.length;
  this.item = function (index) { return innerNodeList[index]};

}

function xmlElement(element) {

  var baseElement;
  var self;
  
  this.baseElement = element;
  this.self = this;
  
  this.selectNodes = function(xpath, nsResolver) {
    if (window.ActiveXObject) {
      this.baseElement.ownerDocument.setProperty("SelectionNamespaces", nsResolver.getNamespaces());
      return new xmlNodeList(this.baseElement.selectNodes(xpath));
    }
    else {
      return new xmlNodeList(this.baseElement.ownerDocument.evaluate(xpath ,this.baseElement, nsResolver.resolveNamespace ,XPathResult.ORDERED_NODE_ITERATOR_TYPE , null));
    }
  }

  this.serialize = function () {
     
    if (window.ActiveXObject) {
        return this.baseElement.xml;
    }
    else {
      return new XMLSerializer().serializeToString(this.baseElement);
    }
  }
  
  this.getAttribute = function(attrName) {
    return this.baseElement.getAttribute(attrName);
  }


  this.getElementsByTagName = function (elementName) {
  	return this.baseElement.getElementsByTagName(elementName);
  } 

}

function xmlDocument(baseDocument,baseDocumentType,namespaceManager) {

  function createNewDocument() {

    try {
      //code for Internet Explorer
      if (window.ActiveXObject) {
        self.baseDocument = new ActiveXObject(domImplementation); 
        self.implementation = MicrosoftDOM;
      }
      // code for gecko, Firefox, etc.
      else {
        if (document.implementation && document.implementation.createDocument) {
          self.baseDocument  = document.implementation.createDocument("","",null); 
          self.baseDocument.preserveWhiteSpace=false;
          self.implementation = NativeDOM;
        }
        else {
          error = new xfilesException('xmlDocumentObject.newxmlDocument.createNewDocument',8, null, null);
          error.setDescription('Browser cannot instantiate an XML Document object');
          throw error;
        }  
      }
    }
    catch (e) {  
      error = new xfilesException('xmlDocumentObject.xmlDocument.createNewDocument',9, null, e);
      error.setDescription('Error Instantiating XML Document');
      throw error;
    }
  }
  
  function checkParsing(module, xml) {

    if (window.ActiveXObject) {
      if (xml.parseError.errorCode != 0) {
        error = new xfilesException(module,2,self.loadedFromURL, null);
        error.setDescription("[MSXML]XML Parsing error : " + xml.parseError.reason);
        error.setNumber(xml.parseError.errorCode);
        throw error;
      }
    }
    else {
      if (xml.documentElement) {
        root = xml.documentElement; 
        if (root.nodeName == 'parsererror')  {
          error = new xfilesException('xmlDocumentObject.xmlDocument.checkParsing',2,self.loadedFromURL, null);
	        error.setDescription("[GECKO]XML Parsing Error");
          error.setXML(xml);
          throw error;
        }
      }
      else {
        error = new xfilesException('xmlDocumentObject.xmlDocument.checkParsing',4, this.loadedFromURL, null);
        error.setDescription('Unable to load Document');
        throw error;
      }
    }   
  }
  

  function msftConvertImplementation(incorrectVersion) {
     try {
       correctedVersion = new ActiveXObject(domImplementation); 
       correctedVersion.loadXML(incorrectVersion.xml);
       checkParsing('xmlDocument.msftConvertImplementation',correctedVersion);
       return correctedVersion.documentElement;
     }
     catch (e) {
       error = new xfilesException('xmlDocumentObject.xmlDocument.msftConvertImplementation',8, self.loadedFromURL, e);
       throw error;
     }
  }
  
  function stripInsignificantWhitespace(element) {
  	
  	if ((typeof element == "undefined") || (element == null)) {
  		if ((typeof self.baseDocument.documentElement == "undefined") || (self.baseDocument.documentElement == null)) {
  			return
  		}
  		else {
  		  element = baseDocument.documentElement;
  		}
    }
  
    // If XML:SPACE is preserve assume we are doing whitespace preservation for the entire branch.
  
    if (element.getAttribute("http://www.w3.org/XML/1998/namespace","space") == "preserve") {
  	  return;
    }
  
    var nl = element.childNodes;
    
    // Check to see if the current node has a text node containng significant text (eg not just whitespace).
    // If it does we assume mixed text or simple content and we're done with this branch.
    
    for (var i=0; i<nl.length;i++) {
  	  var node = nl.item(i);
    	if ((node.nodeType == nodeTypeText) && (!node.isElementContentWhitespace)) {
    		return
      }
    }

    // Strip all insignificant whitespace from the node and check any child elements.

    var node = element.firstChild;
    while (node) {
    	if ((node.nodeType == nodeTypeText) && (node.isElementContentWhitespace)) {
    		var nextNode = node.nextSibling
  	 		element.removeChild(node);
  	 		node = nextNode;
   			continue;
  	 	}
    	if (node.nodeType == nodeTypeElement) {
    		stripInsignificantWhitespace(node);
    		node = node.nextSibling;
        continue;
      }
      node = node.nextSibling;
    }

  }
   
  
  var innerNode;
  var implementation;
  var namespaceManager;
  var loadedFromURL;
  var onReadyStateChange;

  var self = this;
    
  var MicrosoftDOM  = 1; // Microsoft FreeThreadedDOM ActiveX object
  var NativeDOM     = 2; // Firefox Native DOM
  var ResponseXML   = 3; // responseXML from XMLHTTP object
  
  if (baseDocument) {
    if (!window.ActiveXObject) {
    	stripInsignificantWhitespace(baseDocument.documentElement);
    }
    this.baseDocument      = baseDocument;
    this.implementation    = baseDocumentType;
    this.namespaceManager  = namespaceManager;
  }
  else {
    createNewDocument();
  }

  this.setNamespaceManager = function ( namespaceManager ) {
    this.namespaceManager = namespaceManager;
  }
    
  this.serialize = function (node) {
     
    if (node) {
      if (window.ActiveXObject) {
        return node.xml;
      }
      else {
        return new XMLSerializer().serializeToString(node);
      }
    }
    else {
      if (this.baseDocument) {
        return this.serialize(this.baseDocument)
      }
      else {
        error = new xfilesException('xmlDocumentObject.xmlDocument.serialize',8, this.loadedFromURL, null);
        error.setDescription('Cannont Serialize emtpy Document');
        throw error;
      }
    }
  }

  this.checkParsing = function () {
  	checkParsing("xmlDocumentObject.xmlDocument.load",self.baseDocument);
  }

  this.load = function(url, mode) {

    try {
      self.loadedFromURL = url;
      
      asynchronousMode = false;
      if (typeof mode != "undefined") {
        asynchronousMode = mode;
      }

      self.baseDocument.async = mode;
      self.baseDocument.resolveExternals = resolveExternals;   
      self.baseDocument.validateOnParse = false;
      
      if (window.ActiveXObject) {
        self.baseDocument.setProperty("AllowDocumentFunction",true);
      }
      
      // Beware Mozilla load() implementation will prompt for user/passord if unauthorized.
      
      var result = self.baseDocument.load(url);
	    if (!window.ActiveXObject) {
        stripInsignificantWhitespace(this.baseDocument.documentElement);
      }

      if (!asynchronousMode) {
      	checkParsing('xmlDocumentObject.xmlDocument.load[SYNC]',self.baseDocument);
        return self;
      }

      if (!result) {
	      error = new xfilesException('xmlDocumentObject.xmlDocument.load',8, url, e);
  	    error.setDescription('Error Loading Document');
    	  throw error;
      }
      
    }
    catch (e) {
      error = new xfilesException('xmlDocumentObject.xmlDocument.load',8, url, e);
      error.setDescription('Error Loading Document');
      throw error;
    }

  }

  this.setOnLoad = function ( onLoadFunction ) {
  
    if (window.ActiveXObject) {
      this.baseDocument.onreadystatechange = function () { if (self.baseDocument.readyState==4) { onLoadFunction() }} ;
    }
    else {
      this.baseDocument.onload = function () { onLoadFunction(); };
    }
  }
  
  this.setOnReadyStateChange = function ( onReadyStateChangeFunction ) {
  
    if (window.ActiveXObject) {
      this.baseDocument.onreadystatechange = onReadyStateChangeFunction;
    }
    else {
      error = new xfilesException('xmlDocumentObject.xmlDocument.setOnReadyStateChange',8, this.loadedFromURL, null);
      error.setDescription("[GECKO]onReadyStateFunction not implemented. Use onLoad() instead");
      throw error
    }
  }

  this.getReadyState = function () {

    if (window.ActiveXObject) {
      return self.baseDocument.readyState;
    }
    else {
      return 4;
    }
  }
  
  this.parse = function(xmlContent) {

    this.loadedFromURL = 'text';
    try {
      if (window.ActiveXObject) {
        this.baseDocument.async = false;
        this.baseDocument.loadXML(xmlContent);
        this.implementation = this.MicrosoftDOM
      }
      else {
        var oParser = new DOMParser();
        this.baseDocument = oParser.parseFromString(xmlContent,"text/xml");
        this.implementation = this.NativeDOM;
        stripInsignificantWhitespace(this.baseDocument.documentElement);
      }
      checkParsing('xmlDocumentObject.xmlDocument.parse',this.baseDocument);
    }
    catch (e) {  
      error = new xfilesException('xmlDocumentObject.xmlDocument.parse',8, self.loadedFromURL, e);
      error.setDescription("Parsing Error");
      error.setContent(xmlContent);
      throw error
    }
    return this;
  }
  
  this.getStatus = function () {
    return self.baseDocument.parseError.errorCode;
  }

  this.save = function (URL) {
    xmlHTTP = getXMLHTTPRequest();
    targetURL = URL.replace(/\\/g,"/");
    // alert(URL)
    xmlHTTP.open ("PUT", URL, false);                                 
    xmlHTTP.send(this.baseDocument);
    showInfoMessage('Content saved to ' + URL);
  }

  this.importNode = function ( node, deep ) {
    try {
      return this.baseDocument.importNode(node,deep);
    }
    catch (e) {
      var error;
      if (window.ActiveXObject) {
        if (e.number == -2147467259) {
          // Print and Parse to avoid MSFT incompatible MSXML implementations
          return this.baseDocument.importNode(msftConvertImplementation(node),deep);
        }
        else {
          error = new xfilesException('xmlDocumentObject.xmlDocument.importNode',8, this.loadedFromURL, e);
          error.setDescription("[MSXML]Import Node Error");
          error.setXML(node);
          throw error;
        }
      } 
      else {
        error = new xfilesException('xmlDocumentObject.xmlDocument.importNode',8, this.loadedFromURL, e);
        error.setDescription("[GECKO]Import Node Error");
        error.setXML(node);
        throw error;
      }
    }
  }
  
  this.appendChild = function ( node ) {
    try {
      return this.baseDocument.appendChild ( node );
    }
    catch (e) {
      var error;
      if (window.ActiveXObject) {
        error = new xfilesException('xmlDocumentObject.xmlDocument.appendChild',8, this.loadedFromURL, e);
        error.setDescription("[MSXML]Append Child Error");
        error.setXML(node);
      }
      else {
        error = new xfilesException('xmlDocumentObject.xmlDocument.appendNode',8, this.loadedFromURL, e);
        if (e.name == 'NS_ERROR_DOM_HIERARCHY_REQUEST_ERR') {
          error.setDescription("[GECKO]NS_ERROR_DOM_HIERARCHY_REQUEST_ERR : Cannot append instance of " + node + "[" + node.nodeName + "] to " + this.baseDocument + "[" + this.baseDocument.nodeName + "].");
        }
        else {
	        error.setDescription("[MSXML]Append Child Error");
	      }
      }
      throw error;   
    }
  }

  this.setAttribute = function (name, value, namespace ) {
    if (typeof namespace == "undefined") {
      this.baseDocument.setAttribute(name, value) ;
    }
  }

  this.getAttribute = function (name, namespace ) {
    if (typeof namespace == "undefined") {
      return this.baseDocument.getAttribute(value) ;
    }
  }
  
  this.createNode = function ( nodeType, name, namespace) {
    if (window.ActiveXObject) {
      return this.baseDocument.createNode( nodeType, name, namespace);
    }
    else {
      if (nodeType == nodeTypeElement) { // Element 
        if (namespace) {
          return this.baseDocument.createElementNS(namespace,name);
        }
        else {
          return this.baseDocument.createElement(name);
        }
      }
 if (nodeType == nodeTypeAttribute) { // Attribute 
        if (namespace) {
          return this.baseDocument.createAttributeNS(namespace,name);
        }
        else {
          return this.baseDocument.createAttribute(name);
        }
      }

    if (nodeType == nodeTypeText) { // Text 
        return this.baseDocument.createTextNode(name);
      }

    if (nodeType == nodeTypeAttribute) { // Attribute 
        if (namespace) {
          return this.baseDocument.createAttributeNS(namespace,name);
        }
        else {
          return this.baseDocument.createAttribute(name);
        }
      }
      error = new xfilesException('xmlDocumentObject.xmlDocument.createNode',8, this.loadedFromURL, null);
      error.setDescription("[GECKO]CreateNode for nodeType " + nodeType + " not (yet) implemented.");
      throw error;
    }
  }

  this.createElement = function (name, namespace) {
    return this.createNode(nodeTypeElement, name, namespace);
  }
  
  this.createAttribute = function (name, namespace) {
    return this.createNode(nodeTypeAttribute, name, namespace);
  }

  this.createTextNode = function (data) {
    return this.baseDocument.createTextNode(data) ;
  }

  this.createCDATASection = function (data) {
    return this.baseDocument.createCDATASection(data) ;
  }

  this.createDocumentFragment = function() {
  	return this.baseDocument.createDocumentFragment();
  }
 
  this.selectNodes = function (xpath, namespaces, node) {

    var nsResolver = namespaces;
    if (!nsResolver) {
      nsResolver = this.namespaceManager;
    }

    if (!node) {
      node = this.baseDocument;
    }
    
    // alert(this.serialize(node));
    // alert(this.namespaceManager.getNamespaces());
    // alert(xpath);

    if (window.ActiveXObject) {
      if (node.ownerDocument) {
        node.ownerDocument.setProperty("SelectionNamespaces", nsResolver.getNamespaces());
      }
      else {
        node.setProperty("SelectionNamespaces", nsResolver.getNamespaces());
      }
      // alert(node.selectNodes(xpath).length);
      return node.selectNodes(xpath);
    }
    else {
      if (node.ownerDocument) {
        xpathResult = node.ownerDocument.evaluate(xpath ,node, nsResolver.resolveNamespace ,XPathResult.ORDERED_NODE_ITERATOR_TYPE , null);
      }
      else {
        xpathResult = node.evaluate(xpath ,node, nsResolver.resolveNamespace ,XPathResult.ORDERED_NODE_ITERATOR_TYPE , null);
      }    
      return new xmlNodeList(xpathResult);
    }
  }     
  
  this.getDocumentElement = function () {
    return this.baseDocument.documentElement;
  }

  this.getFirstChild = function () {
  	return this.baseDocument.firstChild;
  }
  
  this.transformToNode = function ( xsl, target ) { 
  	if (typeof target == "undefined") {
  	  target = this;
    }
    var processor = new xsltProcessor(xsl,target);
    return processor.toXML(this);    
  }
  
  this.transformToDocument = function ( xsl ) {
    // Create a new XML document, avoiding transformNodeToObject raising "It is an error to mix objects from different versions of msxml"
  	// by using a print and parse approach
    var processor = new xsltProcessor(xsl);
    return processor.toDocument(this);    
  }  	
  
  this.transformToText = function ( xsl ) {
    var processor = new xsltProcessor(xsl);
    return processor.toText(this);    
  }
  
  
}

function extractText(node) {

    if (window.ActiveXObject) {
      return node.firstChild.text
    }
    else {
      // alert(node.textContent);
      return node.textContent;
    }
}
