var domImplementation 
var httpImplementation 
var xslImplementation 
var resolveExternals

var wsManager;
var xfilesSoapManager;

var dialogCloser;

var Printer = new PrettyPrinter();

var timezoneOffset;
var httpUsername = "ANONYMOUS";

// Configurable Functions

var handleException;
var showSourceCode;
var openDialog
var closeDialog
var openPopupDialog
var closePopupDialog
var closeCurrentForm
var reloadForm
var viewXML
var viewXSL
var viewSOAPRequest
var viewSOAPResponse

var orawsvNamespaces;

var orawsvPrefixList = {
      'soap'   : 'http://schemas.xmlsoap.org/soap/envelope/',
      'oraerr' : 'http://xmlns.oracle.com/orawsv/faults',
      'orawsv' : 'http://xmlns.oracle.com/orawsv'
    };

var errStackXSLSource = 
'  <xsl:stylesheet version="1.0" xmlns:orawsv="http://xmlns.oracle.com/orawsv" xmlns:oraerr="http://xmlns.oracle.com/orawsv/faults" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xdbpm="http://xmlns.oracle.com/orawsv/XFILES/XFILES_WEBDEMO_HELPER">' + '\n' +
'  	<xsl:output indent="yes" method="html"/>' + '\n' +
'  	<xsl:template match="/">' + '\n' +
'  		<xsl:for-each select="//oraerr:OracleErrors[oraerr:OracleError]">' + '\n' +
'  			<xsl:for-each select="oraerr:OracleError">' + '\n' +
'  				<B>' + '\n' +
'  					<xsl:value-of select="oraerr:ErrorNumber"/>' + '\n' +
'  					<xsl:text>:</xsl:text>' + '\n' +
'  					<xsl:value-of select="oraerr:Message"/>' + '\n' +
'  				</B>' + '\n' +
'  				<xsl:if test="position() != last()">' + '\n' +
'  					<BR/>' + '\n' +
'  				</xsl:if>' + '\n' +
'  			</xsl:for-each>' + '\n' +
'  		</xsl:for-each>' + '\n' +
'  	</xsl:template>' + '\n' +
'  </xsl:stylesheet>';

var errStackXSL

var contentToHTMLSource  = 
'<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fo="http://www.w3.org/1999/XSL/Format" xmlns:xhtml="http://www.w3.org/1999/xhtml">' + '\n' +
'	<xsl:template match="/">' + '\n' +
'		<xsl:for-each select="xhtml:*/node()">' + '\n' +
'			<xsl:copy-of select="."/>' + '\n' +
'		</xsl:for-each>' + '\n' +
'</xsl:template></xsl:stylesheet>';

var contentToHTML;

function loadOracleWebServiceNamespaces() {
  orawsvNamespaces = new namespaceManager(orawsvPrefixList);
}

function initCommon() {

  handleException  = xfilesHandleException;
  showSourceCode   = xfilesShowSourceCode;
  openDialog       = xfilesOpenDialog;
  closeDialog      = xfilesCloseDialog;
  openPopupDialog  = xfilesOpenPopupDialog;
  closePopupDialog = xfilesClosePopupDialog;
  closeCurrentForm = xfilesCloseCurrentForm;
  reloadForm       = xfilesReloadForm;
  viewXML          = xfilesViewXML;
  viewXSL          = xfilesViewXSL;
  viewSOAPRequest  = xfilesViewSOAPRequest;
  viewSOAPResponse = xfilesViewSOAPResponse;
    
  tzBase = new Date().getTimezoneOffset();
  timezoneOffset = (tzBase / 60) * -1;
    
  setDomVersion();
  loadOracleWebServiceNamespaces();
  errStackXSL   = new xmlDocument().parse(errStackXSLSource);
  contentToHTML = new xsltProcessor(new xmlDocument().parse(contentToHTMLSource),document);
  wsManager     = new dbnwsManager();
  httpMgr       = new httpManager()  

  // Check if the current session is authenticated to allow for REST/SOAP descisions when loading pages
  getHttpUsername();
  if (isAuthenticatedUser()) {
    xfilesSoapManager = new soapServiceManager();
  }
  
}
   
function setDomVersion(domVersionId) {

  // No support for earlier versions of MSXML : document.importNode() not available
  
  domImplementation  = "Msxml2.FreeThreadedDOMDocument.6.0"; 
  httpImplementation = "Msxml2.XMLHTTP.6.0";
  xslImplementation  = "Msxml2.XSLTemplate.6.0";
  resolveExternals   = true;

  //  domImplementation  = "Msxml2.FreeThreadedDOMDocument"; 
  //  httpImplementation = "Msxml2.XMLHTTP";
  //  xslImplementation  = "Msxml2.XSLTemplate";
  //  resolveExternals   = true;

  //  domImplementation  = "Msxml2.FreeThreadedDOMDocument.4.0";
  //  httpImplementation = "Msxml2.XMLHTTP.4.0";
  //  xslImplementation  = "Msxml2.XSLTemplate.4.0";
  //  resolveExternals   = false;
}

function dbnwsManager() {

  var requestXML = null;
  var responseXML = null;
  var queryText = null;
  
  this.setQuery        = function ( query )    { this.queryText = query; this.requestXML = null; this.responseXML = null; };
  this.setRequestXML   = function ( request )  { this.requestXML  = request; this.responseXML = null; };
  this.setResponseXML  = function ( response ) { this.responseXML = response };

  this.getRequestXML   = function ( )  { return this.requestXML };
  this.getResponseXML  = function ( )  { return this.responseXML };
  this.getQuery        = function ( )  { return this.queryText };
  
}

function xfilesException(module,id,target,exception) {

	this.xfilesErrorCodes = {
     '1' : 'ACCESS-DENIED',
     '2' : 'XML-PARSE',
     '3' : 'AJAX',
     '4' : 'NOT-FOUND',
     '5' : 'XMLHTTP',
     '6' : 'SERVER',
     '7' : 'XML-LOAD',
     '8' : 'XML-IMPL',
     '9' : 'XSL-IMPL',
    '10' : 'XSL-GECKO',
    '11' : 'WEB-DEMO',
    '12' : 'XFILES-APP',
    '13' : 'TIMEOUT',
    '14' : 'HTTP',
    '15' : 'SOAP-SVC-MGR'
    
  };
  
  var module;
  var id;
  var target;
  var exception;

  var description;
  
  var name;
  var number;
  var fileName;
  var lineNumber;

  var xml;
  var text;
  var element;
  var content;
    
  this.module = module;
  this.id = id;
  this.target = unescape(target);
  this.exception = exception;
  
  this.description = null;
  this.name        = null;
  this.number      = null;
  this.fileName    = null;
  this.lineNumber  = null;
  this.xml         = null;
  this.content     = null;
  
  this.setDescription = function ( description )   { this.description = description };
  this.setNumber      = function ( number )        { this.number = number };
  this.setXML         = function ( xml )           { this.xml = xml };
  this.setContent     = function ( content )       { this.xml = content };
  	
  if (exception) {
    if (window.ActiveXObject) {
      if ((exception.description) && (exception.description != null)) { this.description = exception.description };
      if ((exception.name)        && (exception.name != null))        { this.name = exception.name };
      if ((exception.number)      && (exception.number != null))      { this.number = exception.number };
    }
    else {
      if ((exception.message)  && (exception.message != null))  { this.description = exception.message };
      if ((exception.fileName) && (exception.filename != null)) { this.fileName = exception.fileName };
      if ((exception.message)  && (exception.message != null))  { this.lineNumber = exception.lineNumber };
    }
  }
  
  this.getErrorType = function() { return this.xfilesErrorCodes[this.id] };
  this.getErrorCode = function() { return this.id};

  this.getBaseException = function () {
  	
  	var e = this;
	  while (e.exception) {
		  e = e.exception;
  	}
	  return e;
  }

  this.serialize = function (exception) {
 
 	  var xml;
  	
  	if (typeof exception == "undefined") {
  	  xml = new xmlDocument();
    	exception = xml.createElement("XFilesException")
    	xml.appendChild(exception);
  	}
  	else {
  		xml = exception.ownerDocument;
    }
    
  	for (var i in this) {
  		if (typeof this[i] == "object") {
  			if ((i == "exception") && (this[i] != null)) {
  				if (this[i].id) {
    		    var innerException = this[i].serialize(exception);
    		    // exception.appendChild(innerException);
    		  }
    		  else {
    		  	e = this[i];
    		  	var innerException = xml.createElement("Exception");
    		    exception.appendChild(innerException);
          	for (var i in e) {
          		if (i != "location") { // Avoid Firefox Error with location attribute of native exception.
    	          element = xml.createElement(i);
    	          text = xml.createTextNode(e[i]);
    	          element.appendChild(text);
     	          innerException.appendChild(element);
     	        }
          	}
    		  }
    		}
    		else {
    			if (i != "xfilesErrorCodes") {
    				// Generic Javascript object to XML serialization code..
    		  }
        }    			
      } 
      else{
      	if (typeof this[i] != "function") {
    	    element = xml.createElement(i);
    	    text = xml.createTextNode(this[i]);
    	    element.appendChild(text);
    	    exception.appendChild(element);
    	  }
    	}
    }
    return exception;
  }
}

function appendException(e,parent) {

  var wrapper = document.createElement("span");
  wrapper.style.padding="10px";
  wrapper.style.display="block";
  parent.appendChild(wrapper);

  if (e.module) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "Module      : " + e.module;
  	wrapper.appendChild(span);
  }  

  if (e.id) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "Error Type  : " + e.id  + " [" +  e.getErrorType() + "]";
  	wrapper.appendChild(span);
  }  

  if (e.description) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "Description : " + e.description;
  	wrapper.appendChild(span);
  }

  if (e.target) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "Target URL  : " + e.target;
  	wrapper.appendChild(span);
  }

  if (e.message) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "Error       : " + e.message;
  	wrapper.appendChild(span);
  }

  if (e.number) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "Number      : " + e.number;
  	wrapper.appendChild(span);
  }

  if (e.id == 13) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "Information : " + "Possible Server Crash. Please check database Alert Log for more information.";
  	wrapper.appendChild(span);  	
  }

  if (e.id == 3 && e.number == 502) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "Information : " + "Possible Server Crash. Please check database Alert Log for more information.";
  	wrapper.appendChild(span);  	
  }

  if (e.name) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "Name        : " + e.name;
  	wrapper.appendChild(span);
  }

  if (e.fileName) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "File       : " + e.fileName;
  	wrapper.appendChild(span);
  }
     
  if (e.lineNumber) {
  	span = document.createElement("span");
  	span.style.display="block";
  	span.innerHTML = "Line Number : " + e.lineNumber;
  	wrapper.appendChild(span);
  }
  
  if (e.exception) {
    appendException(e.exception,wrapper);
  }

  if (e.id == 6) {
  	if (e.xml) {
     	pre = document.createElement("pre");
    	wrapper.appendChild(pre);
     	transformXML(pre,e.xml,errStackXSL);
    }
  }
  else {
  	if (e.xml) {
     	pre = document.createElement("pre");
    	wrapper.appendChild(pre);
    	prettyPrintXML(e.xml, pre) 
  	}
  }
 
  if (e.content) {
   	pre = document.createElement("pre");
  	wrapper.appendChild(pre);
  	pre.innerHTML = e.content;
  }
  
}

function showErrorMessage(message) {
	alert("Error :- " + message);
}

function showUserErrorMessage(message) {
	alert("Error (user) :- " + message);
}

function showInfoMessage(message) {
	alert("Info :- " + message);
}

function showWarningMessage(message) {
	alert("Warning :- " + message);
}

function unsupportedFeature(message) {
  showWarningMessage("Unsupported Feature : " + message);
}

function unimplementedFunction(message) {
	showWarningMessage("Unimplemted Function : " + message);
}

function setPageActive() {

  // var pageStatusIcon = document.getElementById('pageStatusIcon');
  // pageStatusIcon.src = '/XFILES/lib/icons/pageReady.png';
  var pageLoading = document.getElementById('pageLoading');
  pageLoading.style.display="none";
  var greyLoading = document.getElementById('greyLoading');
  greyLoading.style.display="none";

  var pageContent = document.getElementById('pageContent');
  pageContent.style.display="block";
  onPageLoaded();

}
   
function loadScripts() {

  var head = document.getElementsByTagName('head').item(0);
  var scriptList = document.getElementById('localScriptList');
  if (scriptList) {
    var scriptEntry = scriptList.firstChild;

    while (scriptEntry) {
      var scriptLocation = scriptEntry.firstChild.nodeValue;
      script = document.createElement("script");
      script.type= 'text/javascript'; 
      var scriptContent = getDocumentContent(scriptLocation);
      script.text = scriptContent;

      // script.src == scriptLocation;

      head.appendChild(script);
  	  scriptEntry = scriptEntry.nextSibling;
  	}

  }

  setPageActive();

}

function loadXSLDocument(targetURL) {
	
  try {
   	return loadXMLDocument(targetURL);
  }
  catch (e) { 
    error = new xfilesException('common.loadXSLDocument',7, targetURL, e);
    throw error;
  }

}

function loadXMLDocument(targetURL) {

  // doc.load directly from the repository.
    
  try {
    return new xmlDocument().load(targetURL);
  }
  catch (e) { 
    error = new xfilesException('common.loadXMLDocument',7, targetURL, e);
    throw error;
  }
 
}

function getXMLDocument(targetURL) {

  try {
    targetURL = targetURL.replace(/\\/g,"/");
    var httpRequest = httpMgr.createGetRequest(targetURL);
    httpRequest.send(null);
    if (httpRequest.status != 200) {
      error = new xfilesException('common.getXMLDocument',3, targetURL, null);
      error.setDescription(httpRequest.statusText);
      error.setNumber(httpRequest.status);
      throw error;
    }
    return new xmlDocument(httpRequest.responseXML,xmlDocument.ResponseXML);
  }
  catch (e) {  
    error = new xfilesException('common.getXMLDocument',7, targetURL, e);
    throw error;
  }
}

function deleteXMLDocument(targetURL) {
  try {
    targetURL = targetURL.replace(/\\/g,"/");
    var httpRequest = httpMgr.createDeleteRequest(targetURL,false);
    httpRequest.send(null);
    if ((httpRequest.status != 201) && (httpRequest.status != 204) && (httpRequest.status != 207) && (httpRequest.status != 404)) {
      error = new xfilesException('common.getXMLDocument',3,targetURL, null);
      error.setDescription(httpRequest.statusText);
      error.setNumber(httpRequest.status);
      throw error;
    }
    return;
  }
  catch (e)  {  
    error = new xfilesException('common.deleteXMLDocument',7, targetURL, e);
    throw error;
  }
}

function getResourceXML(resourceURL, includeContent) {

  try {
  	var schema  = "XFILES";
    var package = "XFILES_SOAP_SERVICES";
    var method;

    if (includeContent) {
	    method =  "GETRESOURCEWITHCONTENT";
	  }
    else {
	    method =  "GETRESOURCE";
  	}
	
  	var mgr = new soapRequestManager(schema,package,method,wsManager);
   	var httpRequest = mgr.createPostRequest(false);

	  var parameters = new Object;
  	parameters["P_RESOURCE_PATH-VARCHAR2-IN"]   = resourceURL
		parameters["P_TIMEZONE_OFFSET-NUMBER-IN"] = timezoneOffset 
		
    mgr.sendSoapRequest(parameters);    

    var soapResponse = mgr.getSoapResponse('common.getResourceXML()');

	  var namespaces = orawsvNamespaces
	  namespaces.redefinePrefix("tns",mgr.getNamespace());

    var nodeList = soapResponse.selectNodes(mgr.getOutputXPath() + "/tns:P_RESOURCE/res:Resource",namespaces);
    if (nodeList.length == 1) {
      var resource = new xmlDocument();
      var node = resource.appendChild(resource.importNode(nodeList.item(0),true))
      return resource;
    }
     
    error = new xfilesException('common.getResourceXML',12,resourceURL,null);
    error.setDescription("Invalid Resource Document."); 
    error.setXML(soapResponse);
    throw error;
  }
  catch (e) {
    error = new xfilesException('common.getResourceXML',7,resourceURL,e);
    error.setDescription("Unable to load Document");
    throw error;
  }
}

function getDocumentContentImpl ( targetURL ) {

  targetURL = targetURL.replace(/\\/g,"/");
  var httpRequest = httpMgr.createGetRequest(targetURL,false);
  httpRequest.send(null);
  if (httpRequest.status != 200) {
    error = new xfilesException('common.getDocumentContentImpl',3,targetURL,null);
    error.setDescription(httpRequest.statusText);
    error.setNumber(httpRequest.status);
    throw error;
  }
  return httpRequest.responseText;
}


function getDocumentContent ( targetURL ) {
  try {
    return getDocumentContentImpl(targetURL);
  }
  catch (e) {
    error = new xfilesException('common.getDocumentContent',7, targetURL, e);
    throw error;
  }
}

function concatentateTextNodes(result) {
	
	// FF appears to chop the result up into 4K chunks
	// Cannot use an XMLSerializer() : Formatting is lost
	
	var text = "";
  var textNode = result.firstChild;
  while (textNode) {
    text += textNode.nodeValue;
    textNode = textNode.nextSibling
  }
  return text;
  
}

function loadOption(optionList, optionDefinition, initialValue) {
	
	
	// The select clause should return a rowset consisting of either a a single column which will act as name, value and id, or a triple consisting of columns called NAME, VALUE, ID
	
	if (optionDefinition.firstChild) {
		
		var value
		var id
		var name
	
    child = optionDefinition.firstChild;
 
    if (optionDefinition.childNodes.length == 1) {
			value    = child.firstChild.nodeValue
			id       = child.firstChild.nodeValue
			name     = child.firstChild.nodeValue
    }
    else {
    	while (child) {
    		if (child.nodeType == nodeTypeElement) {
      		if (child.nodeName=="NAME") {
      			name = child.firstChild.nodeValue;
          }
    	  	if (child.nodeName=="VALUE") {
    		  	value = child.firstChild.nodeValue;
          }
    		  if (child.nodeName=="ID") {
    		  	id = child.firstChild.nodeValue;
          }
        }
			  child = child.nextSibling;
			}
			if (!value) {
				value = name;
		  }
		  if (!id) {
		  	id = value;
		  }
		}

    option = document.createElement("option");
    optionList.appendChild(option);       

    var text = document.createTextNode(name);
    option.appendChild(text);
    width = name.length
    
    option.value = value;
    option.id    = id;
    
    if (option.value == initialValue) {
    	option.selected = "selected";
    }
    
    return width
  }
  else {
  	return 0
  }
}

function loadOptions(selectControl,optionList,resultSet,initialValue,addEmptyOption) {

   selectControl.disabled = true;
   optionList.innerHTML = "";
   var width = 0;
   
	 if (addEmptyOption) {
     var option = document.createElement("option");
     option.value     = "";
     option.id        = "";
     if (initialValue == null) {
       option.selected  = "selected";
     }
     optionList.appendChild(option);      
   }
   
 	 if (resultSet.length > 0) {
 		
     
     for (i = 0; i < resultSet.length; i++) {
       var optionDefinition = resultSet.item(i);
       optionWidth = loadOption(optionList,optionDefinition,initialValue);
       if (width < optionWidth) {
         width = optionWidth;
       }
     }
     
     selectControl.width = width;
     selectControl.disabled = false;
     
   }
}

function loadOptionList(mgr,selectControl,optionList,initialValue,addEmptyOption,allowEmptyList) {
	
	if (typeof addEmptyOption != "boolean") {
		addEmptyOption = true;
	}
	
	if (typeof allowEmptyList != "boolean") {
		allowEmptyList = true;
  }
	
	if (typeof initialValue == "undefiend") {
		initialValue = null;
  }
  	
	try {
    var soapResponse = mgr.getSoapResponse('common.loadOptionList()');  
    var namespaces = orawsvNamespaces;
    namespaces.redefinePrefix("tns",mgr.getNamespace());
    var resultSet = soapResponse.selectNodes(mgr.getOutputXPath() + "/orawsv:ROWSET/orawsv:ROW",namespaces );
    
    if ((resultSet.length == 0) && (!allowEmptyList)) {
      error = new xfilesException("common.loadOptionList",12,null, null);
      error.setDescription("Invalid Option List Document Receieved");
      error.setXML(soapResponse);
      throw error;
    }
    
    loadOptions(selectControl, optionList, resultSet,initialValue,addEmptyOption);

  } 
  catch (e) {
    handleException('common.loadOptionList',e,null);
  }
   
}

function convertSQLToHTML(statement) {

  statementHTML = statement;
  statementHTML = statementHTML.replace(/&/g,'&amp;');
  statementHTML = statementHTML.replace(/</g,"&lt;");
  statementHTML = statementHTML.replace(/>/g,"&gt;");
  // statementHTML = statementHTML.replace(/"/g,"&quot;");
  statementHTML = statementHTML.replace(/(\r\n|\r|\n)/g, "<br/>");
  statementHTML = statementHTML.replace(/\s/g,"&nbsp;");
  statementHTML = statementHTML + "<BR/>";
  return statementHTML;
}



function prettyPrintXML(xml, target) {
   
   if (typeof target == "string") {
     Printer.print(xml, document.getElementById(target));
   }
   else {
   	 Printer.print(xml,target);
   }

}

function prettyPrintXMLElement(xml, target) {
	
  if (typeof target == "string") {
    Printer.printXMLElement(xml, document.getElementById(target));
  }
  else {
    Printer.printXMLElement(xml,target);
  }

}

function prettyPrintXMLColumn(xml, target) {
	
	// Use when printing an XML column in a result set.
	// Swallows the tag that generated from the column name
	
  if (typeof target == "string") {
    Printer.printXMLColumn(xml, document.getElementById(target));
  }
  else {
    Printer.printXMLColumn(xml,target);
  }

}	
function prettyPrintXMLFragment(xml, target) {
   
   if (typeof target == "string") {
     Printer.printFragment(xml, document.getElementById(target));
   }
   else {
   	 Printer.printFragment(xml,target);
   }

}

function prettyPrintRootFragment(xml, target) {
   
   if (typeof target == "string") {
     Printer.printRootFragment(xml, document.getElementById(target));
   }
   else {
   	 Printer.printRootFragment(xml,target);
   }

}

function transformXML(target,xml,xsl,appendMode) {

  if ((!appendMode) || (appendMode == false)) {
    target.innerHTML = "";
  }
   
  if (window.ActiveXObject) {
    // var childNode = document.createElement("DIV");
    // childNode.innerHTML = xml.transformToText(xsl);
    // target.appendChild(childNode)
    target.innerHTML = target.innerHTML +  xml.transformToText(xsl);
  }
  else {
    // Manage errors related to appending invalid HTML with FireFox
  
    try {
      var childNode = xml.transformToNode(xsl,document);
    }
    catch (e) {
        error = new xfilesException('common.transformXML',10,null,e);
        throw error;
    }
   
    try {
      target.appendChild(childNode);
    }
    catch (e) {
      error = new xfilesException('common.transformXML',10,null,e);
      if (e.name == 'NS_ERROR_DOM_HIERARCHY_REQUEST_ERR') {
        error.setDescription("NS_ERROR_DOM_HIERARCHY_REQUEST_ERR : Cannot append instance of " + childNode + "[" + childNode.nodeName + "] to " + target + "[" + target.nodeName + "].");
      }
      else {
        error.setDescription("Generic Error while appending instance of " + childNode + "[" + childNode.nodeName + "] to " + target + "[" + target.nodeName + "].");
      }
      throw error;   
    }
  }
}
  
function getParameter( name )
{
  var regexS = "[\\?&]"+name+"=([^&#]*)";
  var regex = new RegExp( regexS );
  var tmpURL = window.location.href;
  var results = regex.exec( tmpURL );
  if( results == null )
    return "";
  else
    return results[1];
}

document.getElementsByClassName = function(clsName){
    var retVal = new Array();
    var elements = document.getElementsByTagName("*");
    for(var i = 0;i < elements.length;i++){
        if(elements[i].className.indexOf(" ") >= 0){
            var classes = elements[i].className.split(" ");
            for(var j = 0;j < classes.length;j++){
                if(classes[j] == clsName)
                    retVal.push(elements[i]);
            }
        }
        else if(elements[i].className == clsName)
            retVal.push(elements[i]);
    }
    return retVal;
}

// This code was written by Tyler Akins and has been placed in the
// public domain.  It would be nice if you left this header intact.
// Base64 code from Tyler Akins -- http://rumkin.com

var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

function encode64(input) {
   var output = "";
   var chr1, chr2, chr3;
   var enc1, enc2, enc3, enc4;
   var i = 0;

   do {
      chr1 = input.charCodeAt(i++);
      chr2 = input.charCodeAt(i++);
      chr3 = input.charCodeAt(i++);

      enc1 = chr1 >> 2;
      enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
      enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
      enc4 = chr3 & 63;

      if (isNaN(chr2)) {
         enc3 = enc4 = 64;
      } else if (isNaN(chr3)) {
         enc4 = 64;
      }

      output = output + keyStr.charAt(enc1) + keyStr.charAt(enc2) + 
         keyStr.charAt(enc3) + keyStr.charAt(enc4);
   } while (i < input.length);
   
   return output;
}

function decode64(input) {
   var output = "";
   var chr1, chr2, chr3;
   var enc1, enc2, enc3, enc4;
   var i = 0;

   // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
   input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

   do {
      enc1 = keyStr.indexOf(input.charAt(i++));
      enc2 = keyStr.indexOf(input.charAt(i++));
      enc3 = keyStr.indexOf(input.charAt(i++));
      enc4 = keyStr.indexOf(input.charAt(i++));

      chr1 = (enc1 << 2) | (enc2 >> 4);
      chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
      chr3 = ((enc3 & 3) << 6) | enc4;

      output = output + String.fromCharCode(chr1);

      if (enc3 != 64) {
         output = output + String.fromCharCode(chr2);
      }
      if (enc4 != 64) {
         output = output + String.fromCharCode(chr3);
      }
   } while (i < input.length);

   return output;
}
    
function closeWindow() {
  window.open('','_parent','');
  window.close();
}

function sendRestRequest(httpRequest) {
   httpRequest.send(null);
}

function xmlTransform(xmlPath, xslPath, target, dbnwsManager) {
	
  // Server Side Transform


  var schema  = "XFILES";
  var package = "XFILES_SOAP_SERVICES";
  var method =  "DOTRANSFORM";

	var mgr = new soapRequestManager(schema,package,method,wsManager);
	var httpRequest = mgr.createPostRequest();
	var xpathExpression = mgr.getOutputXPath() + "/tns:RETURN/tns:XMLTRANSFORM";
  httpRequest.onreadystatechange=function() { if( soapRequest.readyState==4 ) { xmlPrettyPrint(mgr,target,xpathExpression)}};

	var parameters = new Object; 
	parameters["P_XSL-VARCHAR2-IN"]             = xslPath
	parameters["P_RESOURCE_PATH-VARCHAR2-IN"]   = xmlPath
	  
  mgr.sendSoapRequest(parameters);	 
     
}
  
function stopBubble(evt) {
  evt = (evt) ? evt : ((window.event) ? window.event : "")
  evt.cancelBubble=true;
}


function doOnClick() {
  closePopupDialog();
}

function reportSuccess(mgr, message) {

  var successMessage = 'Operation Successful';
  if (typeof message != "undefined") {
    successMessage = message;
  }

  try {
    var soapResponse = mgr.getSoapResponse('common.reportSuccess()');
    showInfoMessage(successMessage);
    closePopupDialog();
  }
  catch (e) {
    error = new xfilesException('common.reportSuccess',12, null, e);
    throw error;
  }

} 
function renderHTML(mgr,target,xpathExpression) {

   var soapResponse = mgr.getSoapResponse('common.renderHTML()');
   var nodeList = soapResponse.selectNodes(mgr.getOutputXPath() + xpathExpression,namespaces);
   target.innerHTML = nodelist.item(0).firstChild.nodeValue;
      
}

function htmlTransform(xmlPath, xslPath, target, dbnwsManager) {
	
  // Server Side Transformation via AJAX

	
  var schema  = "XFILES";
  var package = "XFILES_SOAP_SERVICES";
  var method =  "DOTRANSFORM";

	var mgr = new soapRequestManager(schema,package,method);
	var httpRequest = mgr.createPostRequest();
	var xpathExpression = mgr.getOutputXPath() + "/tns:RETURN/tns:XMLTRANSFORM";
  httpRequest.onreadystatechange=function() { if( httpRequest.readyState==4 ) { renderHTML(mgr,target,xpathExpression)}};

	var parameters = new Object; 
	parameters["P_XSL-VARCHAR2-IN"]             = xslPath
	parameters["P_RESOURCE_PATH-VARCHAR2-IN"]   = xmlPath
  
  mgr.sendSoapRequest(parameters);	 
   
}

function generatePage(xmlPath, xslPath, target) {
	
// Most of XFiles HTML pages consists of a simple HTML document with a HEAD that contains the required CSS and Script imports and a 
// a body DIV which will contain the page content. The content of the DIV is generated by applying the XSL to tje XML. 
// The result of the transform is rendered into the target DIV, generating the page seen by the user.
// Most of the time the XML document will be the XML representation of a Resource's metadata without it's content.
	
// Transformation can be done in the Browser or on the Server via AJAX

   htmlTransform(xmlPath, xslPath, target, null);
 
}

function raiseEvent(target,eventName) {
  
  if(document.dispatchEvent) { // W3C
      var oEvent = document.createEvent( "MouseEvents" );
      oEvent.initMouseEvent(eventName, true, true,window, 1, 1, 1, 1, 1, false, false, false, false, 0, target);
      target.dispatchEvent( oEvent );
    }
  else if(document.fireEvent) { // IE
    target.fireEvent("on" + eventName);
  }    
}

var resizeImage = function(img, maxh, maxw) {
  var ratio = maxh/maxw;
  if (img.height/img.width > ratio){
     // height is the problem
    if (img.height > maxh){
      img.width = Math.round(img.width*(maxh/img.height));
      img.height = maxh;
    }
  } else {
    // width is the problem
    if (img.width > maxh){
      img.height = Math.round(img.height*(maxw/img.width));
      img.width = maxw;
    }
  } 
}

function findPos(obj) {
	var curleft = curtop = 0;
	if (obj.offsetParent) {
  	do {
	 		curleft += obj.offsetLeft;
			curtop += obj.offsetTop;
    } while (obj = obj.offsetParent);

	  return [curleft,curtop];
	}
}

function getEventTarget(event) {
	
	var target;

	if (event.target) {
		target = event.target;
	}
	else {
		if (event.srcElement) {
			target = event.srcElement;
     	if (target.nodeType == 3) {
		    target = target.parentNode;
      }
    }
  }
  
  return target;
}

function setActiveTab(tab) {
	var tabset = tab.parentNode.getElementsByTagName("SPAN");
	for (i=0; i < tabset.length; i++) {
		if (tabset[i].className == "activeTab") {
			tabset[i].className = "inactiveTab";
	  }
	}
	 tab.className = "activeTab";
}

function setDialogCloser(newDialogCloser) {

  closePopupDialog();
  dialogCloser = newDialogCloser;

}

function lpadZeros(Num, Zs) {
return(("00000000000000000000" + Num).slice(-Zs));
}

function rpadZeros(Num, Zs) {
  return((Num + "00000000000000000000").slice(0,Zs));
}

function getTimestampXML() {

  var now = new Date();
  return lpadZeros(now.getUTCFullYear(),4) + "-" + lpadZeros(now.getUTCMonth()+ 1,2) + "-" + lpadZeros(now.getUTCDate(),2) + "T" + lpadZeros(now.getUTCHours(),2) + ":" +  lpadZeros(now.getUTCMinutes(),2) + ":" + lpadZeros(now.getUTCSeconds(),2) + "." + rpadZeros(now.getUTCMilliseconds(),6) + "Z"
	
}

function getRadioButtonValue(radioName) {
	
	var buttons = document.getElementsByName(radioName);
	for (var i=0; i < buttons.length; i++) {
		if (buttons.item(i).checked) {
			return buttons.item(i).value;
		}
  }
   return "";

}


var xfilesHandleException = function(module, e, target) {
	
  try {
  	var xml = new xmlDocument();
  	var clientError = xml.createElement("XFilesClientException");
  	xml.appendChild(clientError);

  	var timestampElement = xml.createElement("Timestamps");
  	clientError.appendChild(timestampElement);
  	var initElement = xml.createElement("Init");
    timestampElement.appendChild(initElement);
    var text = xml.createTextNode(getTimestampXML());
    initElement.appendChild(text);
      
    var navigatorElement = xml.createElement("Browser");
  	clientError.appendChild(navigatorElement);

  	var nameElement = xml.createElement("Name");
  	navigatorElement.appendChild(nameElement);
    var text = xml.createTextNode(navigator.appName);
    nameElement.appendChild(text);

  	var versionElement = xml.createElement("Version");
  	navigatorElement.appendChild(versionElement);
    var text = xml.createTextNode(navigator.appVersion);
    versionElement.appendChild(text);
 
  	var versionElement = xml.createElement("CookieEnabled");
  	navigatorElement.appendChild(versionElement);
    var text = xml.createTextNode(navigator.cookieEnabled);
    versionElement.appendChild(text);

  	var versionElement = xml.createElement("Platform");
  	navigatorElement.appendChild(versionElement);
    var text = xml.createTextNode(navigator.platform);
    versionElement.appendChild(text);

  	var versionElement = xml.createElement("UserAgent");
  	navigatorElement.appendChild(versionElement);
    var text = xml.createTextNode(navigator.userAgent);
    versionElement.appendChild(text);

  	var userElement = xml.createElement("User");
  	clientError.appendChild(userElement);
  	text = xml.createTextNode(httpUsername);
  	userElement.appendChild(text);

  	var moduleElement = xml.createElement("Module");
  	clientError.appendChild(moduleElement);
  	text = xml.createTextNode(module);
  	moduleElement.appendChild(text);

  	if ((typeof target != "undefined") && (target != null)) {
  		var targetElement = xml.createElement("TargetURL");
  		text = xml.createTextNode(target);
  		targetElement.appendChild(text);
  		clientError.appendChild(targetElement);
    }
  	var exception = xml.createElement("XFilesException")
  	clientError.appendChild(exception);
  	if (e.id) {
  	  e.serialize(exception);
  	}
  	else {
     	for (var i in e) {
    	  element = xml.createElement(i);
    	  text = xml.createTextNode(e[i]);
    	  element.appendChild(text);
     	  exception.appendChild(element);
    	}
    }
  
  	if ((isAuthenticatedUser())  && (xfilesSoapManager != null)) {
  	
      var schema  = "XFILES";
      var package = "XFILES_LOGWRITER";
      var method =  "ENQUEUE_LOG_RECORD";
  
  	  var mgr = new soapRequestManager(schema,package,method,wsManager);
  	  var httpRequest = mgr.createPostRequest(false);
  
  	  var parameters = new Object;
  	  var xparameters = new Object;
  	  xparameters["LOG_RECORD-XMLTYPE-IN"] = xml
  	
      mgr.sendSoapRequest(parameters,xparameters);
      
    }
    else {
    	var targetURL = restURL = '/sys/servlets/XFILES/RestService/XFILES.XFILES_REST_SERVICES.WRITELOGRECORD?LOG_RECORD=' + escape(xml.serialize());
      var httpRequest = httpMgr.createGetRequest(targetURL,false);
      httpRequest.send(null);
      if (httpRequest.status != 200) {
        error = new xfilesException('common.handleException',3, targetURL, e);
        error.setDescription(httpRequest.statusText);
        error.setNumber(httpRequest.status);
        throw error;
      }
    }
  
    if (window.ActiveXObject) {

      if (e.number == -2147024891 ) { 
        // Access Denied : (e.description.indexOf("Access is denied.") == 0
        e = new xfilesException(module,1,target,e);
      }  

      if (e.number == 12152) {
        e = new xfilesException(module,13,target,e);
      }

    }
 
    if (!document.getElementById('genericErrorDialog')) {
    	var errorDialog = getDocumentContentImpl('/XFILES/lite/css/ErrorDialog.html');
      var body = document.getElementsByTagName('body').item(0);
      var errorDiv = document.createElement('div');
      errorDiv.innerHTML = errorDialog;
      errorDiv.style.height = "256px";
      errorDiv.style.width = "512px";
      body.appendChild(errorDiv);
    }
 
    document.getElementById('errorType').style.display = "none";
    document.getElementById('errorTarget').style.display = "none";
    document.getElementById('errorTraceClient').style.display = "none";
    document.getElementById('errorTraceServer').style.display = "none";

  	document.getElementById('errorModule').style.display = "block";
	  document.getElementById('errorModuleText').innerHTML = module;
	
    openDialog('genericErrorDialog')

    if (e.id) {
  	  
    	// WebService error - Message is a SQL Stack Trace in XML
  
    	document.getElementById('errorType').style.display = "block";
    	document.getElementById('errorTypeText').innerHTML = e.id  + ' [' +  e.getErrorType() + ']';
   
      if ((e.target) && (e.target != null)) {
    	  document.getElementById('errorTarget').style.display = "block";
      	document.getElementById('errorTargetText').innerHTML = e.target;
      }
    
    	if (e.id == 6) {
        if (e.xml) {
        	document.getElementById('errorTraceServer').style.display = "block";
        	transformXML(document.getElementById('errorTraceServerText'),e.xml,errStackXSL);
      	}
      }
      else {
	  		document.getElementById('errorTraceClient').style.display = "block";
	  		traceArea = document.getElementById('errorTraceClientText');
	  		traceArea.innerHTML = "";
	  		appendException(e,traceArea);
      }
    }
    else {
      if ((e.URL) && (e.target != URL)) {
       	document.getElementById('errorTarget').style.display = "block";
    	  document.getElementById('errorTargetText').innerHTML = e.URL;
      }
  		document.getElementById('errorTraceClient').style.display = "block";
  		traceArea = document.getElementById('errorTraceClientText');
	 		traceArea.innerHTML = "";
			appendException(e,traceArea);
    }
  }
  catch (ie) {
    appendException(e,document.getElementById('pageContent'));
    appendException(ie,document.getElementById('pageContent'));
    return;
  }
  
}

var xfilesCloseCurrentForm = function() {
	history.back();
}

function hideSiblings(me,display){
	
	if (typeof display != "string") {
		display = "block";
	}
	
	for (i=0; i < me.parentNode.childNodes.length; i++) {
		if (me.parentNode.childNodes[i].nodeName == me.nodeName) {
		  me.parentNode.childNodes[i].style.display = "none";
		}
	}
  me.style.display = display;
}

var xfilesViewXML = function () {
	closePopupDialog();
  showSourceCode(resource);
}

var xfilesViewXSL = function () {
	closePopupDialog();
  showSourceCode(loadXMLDocument(stylesheetURL));
}

var xfilesViewSOAPRequest = function (wsHelper) {

	closePopupDialog();
	if ((typeof wsHelper == "unknown") || (!wsHelper) || (!wsHelper == null)) {
		showWarningMessage("Web Services logging not active");
  }
  else { 
  	if (wsHelper.getRequestXML() == null) {
  		showWarningMessage("Request object not available");		
    }
  	else {
	    showSourceCode(wsHelper.getRequestXML());
	  }
  }

}

var xfilesViewSOAPResponse = function (wsHelper) {

	closePopupDialog();
	if ((typeof wsHelper == "unknown") || (!wsHelper) || (!wsHelper == null)) {
		showWarningMessage("Web Services logging not active");
  }
  else { 
  	if (wsHelper.getResponseXML() == null) {
  		showWarningMessage("Response object not yet available");		
    }
  	else {
  	  showSourceCode(wsHelper.getResponseXML());
	  }
  }
}

var xfilesShowSourceCode = function (xml) {
	
	var xmlOutputArea = document.getElementById('xmlWindow');
	xmlOutputArea.innerHTML = "";
	Printer.print(xml,xmlOutputArea);
	openDialog('currentXML');
    	
}	

var xfilesOpenDialog = function (dialog) {
	
	if (typeof dialog == "string") {
		dialog = document.getElementById(dialog)
	}
		
	dialog.style.display = "block";

}


var xfilesCloseDialog = function (dialog) {
	
	if (typeof dialog == "string") {
		dialog = document.getElementById(dialog)
	} 
	
	dialog.style.display = "none";

}

var xfilesOpenPopupDialog = function (evt, dialog, dialogCloser) {
	
	if (typeof dialog == "string") {
		dialog = document.getElementById(dialog)
	}

  if ((!dialogCloser) || (typeof dialogCloser != "function")) {
    dialogCloser = function() {dialog.style.display="none";}
  }

	setDialogCloser(dialogCloser);
  dialog.style.display = "block";

  stopBubble(evt);
	
}

var xfilesClosePopupDialog = function() {
   
  if (typeof dialogCloser == "function") {
    var dialog = dialogCloser();
    dialogCloser = null;
  }

}

var xfilesReloadForm = function() {

  if (window.ActiveXObject) {
  	 window.location.reload(false);
  }
  else {
  	window.location.reload();
  }
}

function xinhaToDiv(editor) {

  // Assume the content of a xinhaDescriptionEditor.getHTML()is always valid XHTML Fragment can that be manageded as the child of an XHTML Body Element..
  // ? Need to replace &nbsp in XHTML ? then 
  var xinhaContent = editor.outwardHtml(editor.getHTML());
  xinhaContent = xinhaContent.replace( /\&nbsp/gi, "&#160" )
  xinhaContent = xinhaContent.replace( /class=" htmtableborders" style=" htmtableborders"/gi, "class=\" htmtableborders\" " )
  var xhtmlBody = new xmlDocument().parse("<div xmlns=\"http://www.w3.org/1999/xhtml\">" +  xinhaContent + "</div>");
  return xhtmlBody;
  
}

function textAreaToDiv(textArea) {

  // Assume the content of a xinhaDescriptionEditor.getHTML()is always valid XHTML Fragment can that be manageded as the child of an XHTML Body Element..
  // ? Need to replace &nbsp in XHTML ? then 
  
  var xhtmlBody = new xmlDocument().parse("<div xmlns=\"http://www.w3.org/1999/xhtml\">" + textArea.innerHTML.replace( /\&nbsp/gi, "&#160" ) + "</div>");
  return xhtmlBody;
  
}
 
function httpManager() {
	
  function newRequest () {
    try {
      if (window.XMLHttpRequest) {
         // If IE7, Mozilla, Safari, and so on: Use native object.
         return new XMLHttpRequest();
      }
      else {
        if (window.ActiveXObject) {
          return new ActiveXObject(httpImplementation);  
        }
        else {
          error = new xfilesException(module,5, null, null);
          error.setDescription("Browser cannot instantiate an XMLHTTPRequest object");
          throw error;
        }      
      }
    }
    catch (e)  {  
      error = new xfilesException('common.httpManager.newHTTPRequest',3, null, e);
      throw error;
    }
  }
  
	function createRequest(method,targetURL,mode, user, pwd) {

  	asynchronousMode = true;
  	if (typeof mode != "undefined") {
    	asynchronousMode = mode;
 		}
    
    var httpRequest = newRequest();
    
    if ((typeof user == "undefined") || (typeof pwd == "undefined")) {
      httpRequest.open (method, targetURL, asynchronousMode);
    }
    else {
      httpRequest.open (method, targetURL, asynchronousMode, user, pwd);
    }
    return httpRequest;
  }
  
  this.newRequest = function () {
  	return newRequest();
  }
  
  this.createPostRequest = function (url, async, user, pwd) {
    var httpRequest = createRequest("POST", url, async, user, pwd);
    return httpRequest;
	} 

  this.createPutRequest = function (url, async, user, pwd) {
    var httpRequest = createRequest("PUT", url, async, user, pwd);
    return httpRequest;
	} 
	 
  this.createHeadRequest = function (url, async, user, pwd) {
    var httpRequest = createRequest("HEAD", url, async, user, pwd);
    return httpRequest;
	} 

  this.createDeleteRequest = function (url, async, user, pwd) {
    var httpRequest = createRequest("DELETE", url ,async, user, pwd);
    return httpRequest;
	} 

  this.createGetRequest = function (url, async, user, pwd) {
    var httpRequest = createRequest("GET",url, async, user, pwd);
    return httpRequest;
	}

}

function soapServiceManager() {
   
  var requestCache = new Object
  
  var prefixList = {
      "soap"   : "http://schemas.xmlsoap.org/wsdl/soap/",
      "env"    : "http://schemas.xmlsoap.org/soap/envelope/",
      "wsdl"   : "http://schemas.xmlsoap.org/wsdl/",
      'xsd'    : "http://www.w3.org/2001/XMLSchema",
      'orawsv' : "http://xmlns.oracle.com/orawsv"
  }
  
  var namespaces = new namespaceManager(prefixList);

  var requestXSL = loadXSLDocument('/XFILES/common/xsl/wsdl2request.xsl'); 
  loadSQLService();
  
  function loadSQLService() {

    var target = "XDB.ORAWSV.SQL";
    var wsdlURL = '/orawsv?wsdl';
    
    try {
      var wsdl = loadXMLDocument(wsdlURL);
    }
    catch (e) {
    	cause = e.getBaseException();
    	if (cause.number = -2147024891) {
        error = new xfilesException('common.soapServiceManager.loadSQLService',15, wsdlURL, null);
        error.setDescription('Error instantiating SOAP SERVICE MANAGER : Ensure user has been granted XFILES_USER or XFILES_ADMINISTRATOR');
        throw error;    	
      }
      else {
        error = new xfilesException('common.soapServiceManager.loadSQLService',15, wsdlURL, null);
        error.setDescription('Unexpected Error ecnountered instantiating SOAP SERVICE MANAGER');
        throw error;    	
      }
    }

    var soapErrors = wsdl.selectNodes('/env:Envelope/env:Body/env:Fault',namespaces);
    if (soapErrors.length > 0) {
        error = new xfilesException('common.soapServiceManager.loadQueryService',15, wsdlURL, null);
        error.setDescription('Error Fetching WSDL : Ensure user has been granted XFILES_USER or XFILES_ADMINISTRATOR');
        error.setXML(wsdl);
        throw error;    	
    }
    var requestDocument = wsdl.transformToDocument(requestXSL);     
    var namespace = wsdl.selectNodes("/wsdl:definitions/wsdl:types/xsd:schema/@targetNamespace",namespaces).item(0).nodeValue; 
    var url = wsdl.selectNodes("/wsdl:definitions/wsdl:service/wsdl:port/soap:address/@location",namespaces).item(0).nodeValue;
    var messageName = wsdl.selectNodes("/wsdl:definitions/wsdl:portType/wsdl:operation/wsdl:output/@message",namespaces).item(0).nodeValue;
    var elementName = wsdl.selectNodes("/wsdl:definitions/wsdl:message[@name=substring-after(\"" + messageName +"\",\":\")]/wsdl:part/@element",namespaces).item(0).nodeValue;
    requestCache[target] = new Array(url,namespace,requestDocument,elementName);    

    target = "XDB.ORAWSV.XQUERY";
    requestDocument = wsdl.transformToDocument(requestXSL);     
    requestDocument.selectNodes("/env:Envelope/env:Body/orawsv:query/orawsv:query_text",namespaces).item(0).setAttribute("type","XQUERY");
    requestCache[target] = new Array(url,namespace,requestDocument,elementName);    
  }
 
  function loadRequestCache(schema, package, method) {

    var target;
    var wsdlURL; 
    
    if (method == null) {
  	  target = (schema + "." + package);
      wsdlURL = "/orawsv/" + schema + "/" + package + "?wsdl";
    }
    else {
  	  target = (schema + "." + package + "." + method);
      var wsdlURL = "/orawsv/" + schema + "/" + package + "/" + method + "?wsdl";
  	}
  	
    var wsdl = loadXMLDocument(wsdlURL);    

    var soapErrors = wsdl.selectNodes('/env:Envelope/env:Body/env:Fault',namespaces);
    if (soapErrors.length > 0) {
        error = new xfilesException('common.soapServiceManager.loadRequestCache',15, wsdlURL, null);
        error.setDescription('Error Fetching WSDL');
        error.setXML(wsdl);
        throw error;    	
    }

    var requestDocument = wsdl.transformToDocument(requestXSL);    
    var namespace = wsdl.selectNodes("/wsdl:definitions/wsdl:types/xsd:schema/@targetNamespace",namespaces).item(0).nodeValue; 
    var url = wsdl.selectNodes("/wsdl:definitions/wsdl:service/wsdl:port/soap:address/@location",namespaces).item(0).nodeValue;
    var messageName = wsdl.selectNodes("/wsdl:definitions/wsdl:portType/wsdl:operation/wsdl:output/@message",namespaces).item(0).nodeValue;
    var elementName = wsdl.selectNodes("/wsdl:definitions/wsdl:message[@name=substring-after(\"" + messageName +"\",\":\")]/wsdl:part/@element",namespaces).item(0).nodeValue;
    requestCache[target] = new Array(url,namespace,requestDocument,elementName);    
  }
  
  this.getSoapRequestEntry = function (schema, package, method) {
	  
		if (method == null) {
    	target = schema + "." + package;
	  }
    else {
    	target = schema + "." + package + "." + method;
    }

  	if (!requestCache[target]) {
  		loadRequestCache(schema, package, method);
  	}
  	return requestCache[target];
  }
}  

function soapRequestManager(schema, package, method, manager) {

  var soapRequestEntry = xfilesSoapManager.getSoapRequestEntry(schema, package, method);
  
  var wsManager
  var httpRequest;
  var soapServiceManager;
  var soapRequest;
      
  if (typeof manager != "object") {
    wsManager = new dbnwsManager();
  }
  else {
  	wsManager = manager
  }

  this.getWsManager = function () {
 	  return wsManager;
  }
 
  function getRequestDocument () {
    var requestDocument = soapRequestEntry[2];
    requestClone = new xmlDocument();
    requestClone.appendChild(requestClone.importNode(requestDocument.getDocumentElement().cloneNode(true),true));
    return requestClone;
  }

  function getServiceNamespace () {
	  return soapRequestEntry[1];
  }
  
  function getServiceLocation () {
	  return soapRequestEntry[0];
  }
  
  this.createPostRequest = function(mode) {
  	httpRequest = httpMgr.createPostRequest(getServiceLocation(),mode);
  	return httpRequest;
  }
      
  this.sendSoapRequest = function (args, xargs, queryType) {
  	
	  var soapRequest = getRequestDocument();
	  var namespace = getServiceNamespace();
	  
	  var serviceNamespaceList = { "tns" : getServiceNamespace() }
	  var serviceNamespaces = new namespaceManager(serviceNamespaceList);
	 
	  if (typeof args == "object") { 
	    for (var i in args) {
	  	  var arg = soapRequest.selectNodes('//tns:' + i, serviceNamespaces).item(0);
	  	  if (arg == null) {
          error = new xfilesException("common.soapRequestManager.sendSoapRequest",15,getServiceLocation(),null);
          error.setDescription("Invalid Parameter : " + i);
          error.setXML(soapRequestEntry[2]);
          throw error;
	  	  }
	  	  if (args[i] != null) {
	  	  	var text;
	  	    if ((typeof(args[i]) == "string") && (args[i].indexOf('<') > -1)) {
  	  	    text = soapRequest.createCDATASection(args[i]);
  	  	  }
  	  	  else {
	    	    text = soapRequest.createTextNode(args[i]);
	  	    }  	    
	  	    arg.appendChild(text);
	  	  }
	    }
    }
    
    if (typeof xargs == "object") {
	    for (var i in xargs) {
	  	  var arg = soapRequest.selectNodes('//tns:' + i, serviceNamespaces).item(0);
	  	  if (arg == null) {
          error = new xfilesException("common.soapRequestManager.sendSoapRequest",15,getServiceLocation(),null);
          error.setDescription("Invalid Parameter : " + i);
          error.setXML(soapRequestEntry[2]);
          throw error;
	  	  }
	  	  while (arg.hasChildNodes()) {
	  	  	arg.removeChild(arg.firstChild); 
	  	  }
	  	  arg.appendChild(soapRequest.importNode(xargs[i].getDocumentElement(),true));
	    }
    }
    
    // Check for executing an XQuery via ORAWSV query service
    
    if (namespace == orawsvPrefixList["orawsv"]) {
      if (queryType == "XQUERY") {
      	var arg = soapRequest.selectNodes("//tns:query_text", serviceNamespaces).item(0);
      	arg.setAttribute("type","XQUERY");
      }
    }
    
    wsManager.setRequestXML(soapRequest);
    httpRequest.setRequestHeader ('SOAPAction',getServiceLocation());
    httpRequest.setRequestHeader ('Content-Type', 'text/xml; charset=utf-8');
    httpRequest.send(soapRequest.baseDocument);

  }

  this.getSoapResponse = function(callingModule) {
  
    var module = 'common.soapRequestManager.getSoapResponse';
    var error;
  
    if (callingModule) {
      module = callingModule;
    }
 
    if (httpRequest.status != 200) {
      error = new xfilesException(module,3, null, null);
      error.setDescription(httpRequest.statusText);
      error.setNumber(httpRequest.status);
      throw error;
    }
  
  	var tnsNamespaces = orawsvNamespaces
  	tnsNamespaces.redefinePrefix("tns",this.getNamespace());

    var soapResponse = new xmlDocument(httpRequest.responseXML,xmlDocument.ResponseXML,tnsNamespaces);
    wsManager.setResponseXML(soapResponse);

    var nodeList = soapResponse.selectNodes("/soap:Envelope/soap:Body/soap:Fault/detail/oraerr:OracleErrors");
    if (nodeList.length > 0) {
      // Add code to check for incorrect URL : User may not be authorized for Web Services
      error = new xfilesException(module,6,getServiceLocation(),null);
      error.setDescription("Soap Fault");
      error.setXML(soapResponse);
      throw error;
    }
    
    var nodeList = soapResponse.selectNodes(this.getOutputXPath());
    if (nodeList.length == 1) {
      return soapResponse;
    }

    error = new xfilesException(module,15,getServiceLocation(),null);
    error.setDescription("Unexpected Soap Response");
    error.setXML(soapResponse);
    throw error;

  }

  this.executeSQL =  function (query) {
  	
    wsManager.setQuery(query);

	  var parameters = new Object;
	  parameters["query_text"]  = query;
	  parameters["null_handling"]   = "EMPTY_TAG"
	  parameters["pretty_print"] = "true" 
	
    this.sendSoapRequest(parameters,null,"SQL");

  }

  this.executeXQuery =  function (query) {
  	
    wsManager.setQuery(query);

	  var parameters = new Object;
	  parameters["query_text"]  = query;
	  parameters["null_handling"]   = "EMPTY_TAG"
	  parameters["pretty_print"] = "true" 
	
    this.sendSoapRequest(parameters,null,"XQUERY");

  }

  
  this.getNamespace = function() {
  	return getServiceNamespace()
  }
  
  this.getOutputXPath = function() {
    return "/soap:Envelope/soap:Body/" + soapRequestEntry[3];
  }
  
}

function booleanToNumber(booleanValue) {
	if (booleanValue) {
		return 1
  }
  else {
  	return 0
  }
}


function isEmptyString(value) {

  var emptyStringRegExp = /^[\s]*$/;	
  
  if (typeof value != "undefined") {
  	if (value != null) {
  		if (value != "") {
  			return emptyStringRegExp.test(value)
  		}
    }
  }
  
  return true;
  
}