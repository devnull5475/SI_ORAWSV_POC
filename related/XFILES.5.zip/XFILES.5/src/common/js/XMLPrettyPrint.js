var nodeTypeElement   =  1;
var nodeTypeAttribute =  2;
var nodeTypeText      =  3;
var nodeTypeCData     =  4;
var nodeTypeEntityRef =  5;
var nodeTypeEntity    =  6;
var nodeTypePI        =  7;
var nodeTypeComment   =  8;
var nodeTypeDocument  =  9;
var nodeTypeDTD       = 10;
var nodeTypeDocFrag   = 11;
var nodeTypeNotation  = 12;

function PrettyPrinter() {

  var innerHTML

  this.unimplementedCopy = function (targetNode) {

    var node;
    var text;
    var unimplemented =  document.createElement("UnimplementedNode");
 
    node = document.createElement("nodeType");
    unimplemented.appendChild(node);
    text = document.createTextNode(targetNode.nodeType);
    node.appendChild(text);

    node = document.createElement("nodeName");
    unimplemented.appendChild(node);
    text = document.createTextNode(targetNode.nodeName);
    node.appendChild(text);

    node = document.createElement("nodeValue");
    unimplemented.appendChild(node);
    text = document.createTextNode(targetNode.nodeValue);
    node.appendChild(text);
 
    return unimplemented;
  }

  this.hasChildElements = function (elementNode) {
  
    var childNode;
 
    childNode = elementNode.firstChild;
    while (childNode) {
    	if (childNode.nodeType == 1) {
    		return true;
      }
      childNode = childNode.nextSibling;
    }
    return false;	
  }

  this.hasTextNodes = function (elementNode) {
  
    var childNode;
 
    childNode = elementNode.firstChild;
    while (childNode) {
    	if ((childNode.nodeType == 3) && (!childNode.isElementContentWhitespace)) {
    		return true;
      }
      childNode = childNode.nextSibling;
    }
    return false;	
  }

  this.copyAttributes = function (elementNode,openTagContainer) {
 
    var  attr;
    var  span;
    var  text;
    var  nameClass;
    var  valueClass;
       
    var	nodeMap = elementNode.attributes;
    
    for (i=0; i < nodeMap.length; i++ ) {

      attr = nodeMap.item(i);
   
      if (((attr.namespaceURI == 'http://www.w3.org/2000/xmlns/') || (attr.prefix == 'xmlns')) && ((attr.localName == 'xmlns') || (attr.prefix == 'xmlns'))) {
    	  nameClass = 'nmspcName';
    	}
    	else {
    		 nameClass = 'attrName';
    	}
    	
      text = document.createTextNode(' ');
      openTagContainer.appendChild(text);
          
      span = document.createElement('span');
      openTagContainer.appendChild(span);
      span.className = nameClass;
      text = document.createTextNode(attr.nodeName);
      span.appendChild(text);
      
      span = document.createElement('span');
      openTagContainer.appendChild(span);
      span.className = 'attrFixed';
      text = document.createTextNode('="');
      span.appendChild(text);
      
 	    span = document.createElement('span');
      openTagContainer.appendChild(span);
      span.className = 'attrValue';
      text = document.createTextNode(attr.value);
      span.appendChild(text);
     
 	    span = document.createElement('span');
      openTagContainer.appendChild(span);
      span.className = 'attrFixed';
      text = document.createTextNode('"');
      span.appendChild(text);
    }
  }

  this.copyPi = function(piNode) {
  	
  	var span;
  	var text;
  	var piDefinitiont;

    piDefinition = document.createElement('div');
    piDefinition.className = "simpleContent";
  	
    span = document.createElement('span');
    piDefinition.appendChild(span);
    span.className = 'piFixed';
    text = document.createTextNode('<?');
    span.appendChild(text)
      
    span = document.createElement('span');
    piDefinition.appendChild(span);
    span.className = 'piName';
    text = document.createTextNode(piNode.nodeName);
    span.appendChild(text)
  
    text = document.createTextNode(' ');
    piDefinition.appendChild(text);
  
    span = document.createElement('span');
    piDefinition.appendChild(span);
    span.className = 'piValue';
    text = document.createTextNode(piNode.nodeValue);
    span.appendChild(text);
    
    span = document.createElement('span');
    piDefinition.appendChild(span);
    span.className = 'piFixed';
    text = document.createTextNode('?>');
    span.appendChild(text)
    
    return piDefinition;
  }
  
  this.copyComment = function(commentNode) {
  	
  	var span;
  	var text;
  	var commentDefinition;

    commentDefinition = document.createElement('div');
    commentDefinition.className = "simpleContent";

    span = document.createElement('span');
    commentDefinition.appendChild(span);
    span.className = 'commentFixed';
    text = document.createTextNode('<!--');
    span.appendChild(text)
        
    span = document.createElement('span');
    commentDefinition.appendChild(span);
    span.className = 'commentValue';
    text = document.createTextNode(commentNode.nodeValue);
    span.appendChild(text);
    
    span = document.createElement('span');
    commentDefinition.appendChild(span);
    span.className = 'commentFixed';
    text = document.createTextNode('-->');
    span.appendChild(text)
    
    return commentDefinition;
  }
  
  this.copyCData = function(cdataNode) {
  	
  	var span;
  	var text;
  	var cdataDefinition;
  	var spanName;
  	var spanContent;
  	var lineContainer;
  	var cdataContent;

    var cdataDefinition = document.createElement('div');
    var spanName = document.createElement('span');
    cdataDefinition.appendChild(spanName);
  	
    childrenToggle = document.createElement('a');
    spanName.appendChild(childrenToggle);
    childrenToggle.className = 'openClose';
    childrenToggle.href = '#';
    
    // childrenToggle.onlick = function(){toggleShowChildren(event); return false;};
    
    if (childrenToggle.addEventListener) {
	    childrenToggle.addEventListener("click", this.toggleShowChildren, false);
	  }
    else {
 	    childrenToggle.attachEvent("onclick", this.toggleShowChildren);
    }
     
    text = document.createTextNode('-');
    childrenToggle.appendChild(text);
    // text = document.createTextNode(' ');
    // childrenToggle.appendChild(text);

    span = document.createElement('span');
    spanName.appendChild(span);
    span.className = 'cdataFixed';
    text = document.createTextNode('<![CDATA[');
    span.appendChild(text)
   
    childNodeContainer = document.createElement('div');
    cdataDefinition.appendChild(childNodeContainer);

    childNodeIndent = document.createElement('div');
    childNodeContainer.appendChild(childNodeIndent);
    childNodeIndent.className="indentChildren";
    
    pre = document.createElement('pre');
    childNodeIndent.appendChild(pre);
    pre.className = "cdata";
        
    var lines = cdataNode.data.split('\n');
    for ( i=0; i<lines.length; i++) {
    	textContent = lines[i];
    	text = document.createTextNode(textContent);
      pre.appendChild(text);
      br = document.createElement('br');
      pre.appendChild(br);;
    }
 
    span = document.createElement('span');
    cdataDefinition.appendChild(span);
    span.className = 'cdataFixed  complexContent';
    text = document.createTextNode(']]>');
    span.appendChild(text)
    
    return cdataDefinition;
  }
  
  this.copyTextNode = function(textNode) {
  	
    var span = document.createElement('span');
    span.className = 'textValue';
    var text = document.createTextNode(textNode.data);
    span.appendChild(text);
    return span;
  }
  
  this.openElement = function (elementNode, target) {
  
    span = document.createElement('span');
    target.appendChild(span);
    span.className = 'elmntFixed';
    text = document.createTextNode('<');
    span.appendChild(text)
      
    span = document.createElement('span');
    target.appendChild(span);
    span.className = 'elmntName';
    text = document.createTextNode(elementNode.nodeName);
    span.appendChild(text)
  
    this.copyAttributes(elementNode,target);
    
    span = document.createElement('span');
    target.appendChild(span);
    span.className = 'elmntFixed';

    if (elementNode.hasChildNodes()) {
      text = document.createTextNode('>');
    }
    else {
      text = document.createTextNode('/>');
    }
    span.appendChild(text)          
  }

  this.closeElement = function (elementNode, target) {
  	
    span = document.createElement('span');
    target.appendChild(span);
    span.className = 'elmntFixed';
    text = document.createTextNode('</');
    span.appendChild(text)
      
    span = document.createElement('span');
    target.appendChild(span);
    span.className = 'elmntName';
    text = document.createTextNode(elementNode.nodeName);
    span.appendChild(text)
 
    span = document.createElement('span');
    target.appendChild(span);
    span.className = 'elmntFixed';
    text = document.createTextNode('>');
    span.appendChild(text);
    
  }
  
  this.copyElement = function (elementNode, isMixedContent) {

    var elementDefinition;
    var openTagContainer;
    var childNodeContainer;
    var collapsingArea;
    var childNodeIndent;
    var childrenToggle;
    var span;
    var text;
    var childNode;
    var containerType;
     	
    var mixedContent   = this.hasTextNodes(elementNode) && this.hasChildElements(elementNode) || isMixedContent;
    var simpleContent  = !this.hasChildElements(elementNode);
 
    if (mixedContent) {
      containerType     = 'span';
    }
    else {
    	containerType     = 'div';
    }
       
    elementDefinition = document.createElement(containerType);
    elementDefinition.className = "simpleContent";
    openTagContainer = elementDefinition;
    
    if(!simpleContent && !mixedContent) {
    	
    	// Add a +/- Control 
    	
      openTagContainer = document.createElement(containerType);
      elementDefinition.appendChild(openTagContainer);
      elementDefinition.className = "complexContent";
      childrenToggle = document.createElement('a');
      openTagContainer.appendChild(childrenToggle);
      childrenToggle.className = 'openClose';
      childrenToggle.href = '#';
      
      // childrenToggle.onlick = function(){this.Printer.toggleShowChildren(event); return false;};

      if (childrenToggle.addEventListener) {
  	    childrenToggle.addEventListener("click", this.toggleShowChildren, false);
	    }
      else {
 	      childrenToggle.attachEvent("onclick", this.toggleShowChildren);
      }

      text = document.createTextNode('-');
      childrenToggle.appendChild(text);
      // text = document.createTextNode(' ');
      // childrenToggle.appendChild(text);
    }

    this.openElement(elementNode, openTagContainer);

    if (elementNode.hasChildNodes()) {
    
      childNodeContainer = elementDefinition;
      openTagContainer   = elementDefinition;
      cloeTagContainer   = elementDefinition;
    
      if (!simpleContent) {
      	// Add Collapseable Section to contain content and close Tag.
      	collapsingArea = document.createElement(containerType);
      	elementDefinition.appendChild(collapsingArea);
      	childNodeContainer = collapsingArea;
      }
      	    
      if (!simpleContent && !mixedContent) {
      	// Add Div to Indent Content
      	childNodeIndent = document.createElement('div');	
      	childNodeContainer.appendChild(childNodeIndent);
        childNodeIndent.className = 'indentChildren';
      	childNodeContainer = childNodeIndent;
      }
    
      // ProcessContent 
    
      childNode = elementNode.firstChild;
      while (childNode) {
      	if ((childNode.nodeType != 3) || (simpleContent) || (mixedContent)) {
      		// Skip text nodes unless processing simple or mixed content
      	  this.copyNode(childNode,childNodeContainer,mixedContent);
      	}
      	childNode = childNode.nextSibling;
      }

      if (!simpleContent) {
      	// Force the Close Tag to Ident
      	cloeTagContainer = document.createElement(containerType);
      	collapsingArea.appendChild(cloeTagContainer);
      	cloeTagContainer.className = "complexContent";
      }
        
      this.closeElement(elementNode,cloeTagContainer);
    }
          	
    return elementDefinition;

  }
  
  this.copyDocument  = function (doc) {
  	
  	var documentDefinition = document.createElement("div");

	  childNode = doc.firstChild;
    while (childNode) {
  	  this.copyNode(childNode,documentDefinition,false);
    	childNode = childNode.nextSibling;
  	}
  	return documentDefinition;
  }

  this.copyNode = function (node, target, isMixedContent) {

    switch (node.nodeType) {
      case nodeTypeElement : // Element
        var element = this.copyElement(node, isMixedContent)
        target.appendChild(element);
        return element;
      case nodeTypeAttribute : // Attribute - Illegal document structure...
        break;
      case nodeTypeText : // Text
        var text = this.copyTextNode(node);
        target.appendChild(text);
        return text;
      case nodeTypeCData : // CDATA
        var cdata = this.copyCData(node)
        target.appendChild(cdata);
        return cdata;
      case  nodeTypeEntityRef : // EntityRef
        break;
      case  nodeTypeEntity : // Entity
        break;
      case  nodeTypePI : // PI
        var pi = this.copyPi(node);
        target.appendChild(pi);
        return pi;
      case  nodeTypeComment : // Comment
        var comment = this.copyComment(node);
        target.appendChild(comment);
        return comment;
      case  nodeTypeDocument : // Document 
        var doc = this.copyDocument(node)
        target.appendChild(doc);
        return doc;
      case nodeTypeDTD : // Document Type DTD
        break;
      case nodeTypeDocFrag : // DocumentFragment
        break;
      case nodeTypeNotation : // Notation
        break;
    }
    
    // Copy and print the unsupported node type to the output document.
  
    var nodeDefinition;
    var childNode;
   
    nodeDefinition = this.unimplementedCopy(node);
    target.appendChild(nodeDefinition);
  
    childNode = node.firstChild;
    while (childNode) {
      copyNode(childNode,nodeDefinition)
      childNode = childNode.nextSibling;
    }

  }

  this.addToggleChildrenScript = function () {
  	
  	
  	var script = 'function toggleShowChildren(target) {                                          ' + "\n" +
  	             '                                                                               ' + "\n" +
  	             '  var collapsingDiv;                                                           ' + "\n" +
  	             '  if (target.parentElement) {                                                  ' + "\n" +
  	             '    collapsingDiv = target.parentElement.parentElement.firstChild.nextSibling; ' + "\n" +
  	             '  }                                                                            ' + "\n" +
  	             '  else {                                                                       ' + "\n" +
  	             '    collapsingDiv = target.parentNode.parentNode.firstChild.nextSibling;       ' + "\n" +
  	             '  }                                                                            ' + "\n" +
  	             '                                                                               ' + "\n" +
  	             '  while (collapsingDiv.nodeType != 1) {                                        ' + "\n" +
  	             '    collapsingDiv = collapsingDiv.nextSibling;                                 ' + "\n" +
  	             '  }                                                                            ' + "\n" +
  	             '                                                                               ' + "\n" +
  	             '  if (target.innerHTML == "-") {                                               ' + "\n" +
  	             '  	target.innerHTML = "+";                                                    ' + "\n" +
  	             '  	collapsingDiv.style.display = "none";                                      ' + "\n" +
  	             '  }                                                                            ' + "\n" + 
  	             '  else {                                                                       ' + "\n" + 
  	             '  	target.innerHTML = "-";                                                    ' + "\n" + 
  	             '  	collapsingDiv.style.display = "block";                                     ' + "\n" + 
  	             '  }                                                                            ' + "\n" + 
  	             '                                                                               ' + "\n" + 
  	             '  return false;                                                                ' + "\n" + 
  	             '                                                                               ' + "\n" + 
  	             '}';
  	
  	
  	scriptElement = document.createElement("script");
    script.type= 'text/javascript'; 
  	scriptElement.text = script;
  	return scriptElement;
  	
  }
  
  this.toggleShowChildren = function (event) {
 
    var anchorElement;
    var collapsingDiv;
    
    if (window.event) { 
    	event = window.event; 
    }
    
    if  (event.srcElement) {
    	anchorElement = event.srcElement;
      collapsingDiv = anchorElement.parentElement.parentElement.firstChild.nextSibling;
    }
    else {
    	anchorElement = event.target;
    	collapsingDiv = anchorElement.parentNode.parentNode.firstChild.nextSibling;
    }
     	
  	if (anchorElement.innerHTML == '-') {
  		anchorElement.innerHTML = '+';
  		collapsingDiv.style.display = "none";
  	}
  	else {
  		anchorElement.innerHTML = '-';
  		collapsingDiv.style.display = "block";
  	}
  	
  	if (event.preventDefault) {
  		event.preventDefault();
  		event.stopPropagation();
  	}
		else {
			event.returnResult = false;
			event.cancelBubble = true;
		}
		
		anchorElement.focus();
		return false;
  }
       
  this.processSiblings = function (node,target) {

    while (node) {
      this.copyNode(node, target, false);
      node = node.nextSibling;
    }

  }
  
  this.print = function (xml, target) {
  		
    this.innerHTML = false;
    target.innerHTML = "";

    var node = xml.baseDocument;
    this.processSiblings(node,target);

  }

  this.printXMLColumn = function (xml, target, expand) {
  	
  	// Used when the document to be printed has been returned as the child of another element.
  	// Typically required when the document to be printed is embedded in a SOAP response

    var node = xml.baseElement;
  	node = node.firstChild;
    this.processSiblings(node,target);

  }

  this.printXMLElement = function (xml, target, expand) {
  	
    var node = xml.baseElement;
    this.processSiblings(node,target);

  }


  this.printToHTML = function (xml, target) {
  	
    // Used when the content will be written to a popup via innerHTML
    // Add Explicit Java Script for OpenClose and use onlick attribute 

    this.innerHTML = true;
    target.innerHTML = "";

    var div = document.createElement('div');
    target.appendChild(div);
    div.appendChild(this.addToggleChildrenScript());
    
    var node = xml.baseDocument;
    if (node.nodeType == 9) {
    	node = node.firstChild;
    }
    this.processSiblings(node,div);

  }

  this.expandXML = function (node,target,div) {
    var element =  this.copyElement(node, false) 
    target.replaceChild(element,div);
  }
  
  this.rootElementOnly = function (elementNode,target) {

    var elementDefinition;
    var openTagContainer;
    var childrenToggle;
    var containerType     = 'div';
     	     
    elementDefinition = document.createElement(containerType);
    openTagContainer = elementDefinition;
     	
  	// Add a +/- Control 
    	
    openTagContainer = document.createElement(containerType);
    elementDefinition.appendChild(openTagContainer);
    childrenToggle = document.createElement('a');
    openTagContainer.appendChild(childrenToggle);
    childrenToggle.className = 'openClose';
    childrenToggle.href = '#';
    // childrenToggle.onlick = function(){expandXML(); return false;};
    if (childrenToggle.addEventListener) {
	    childrenToggle.addEventListener("click", function() { Printer.expandXML(elementNode,target,elementDefinition)}, false);
	  }
    else {
 	    childrenToggle.attachEvent("onclick",  function() { Printer.expandXML(elementNode,target,elementDefinition) });
    }
    
    text = document.createTextNode('+');
    childrenToggle.appendChild(text);
    // text = document.createTextNode(' ');
    // childrenToggle.appendChild(text);

    span = document.createElement('span');
    openTagContainer.appendChild(span);
    span.className = 'elmntFixed';
    text = document.createTextNode('<');
    span.appendChild(text)
      
    span = document.createElement('span');
    openTagContainer.appendChild(span);
    span.className = 'elmntName';
    text = document.createTextNode(elementNode.nodeName);
    span.appendChild(text)
  
    span = document.createElement('span');
    openTagContainer.appendChild(span);
    span.className = 'elmntFixed';

    text = document.createTextNode('/>');
    span.appendChild(text)          
    return elementDefinition;

  }


  this.processRootElement = function (node,target) {
  	
  // Prints the Root Element(s), along with any root level comments or processing instructions
  
    var temp = node;
    var isComplexContent = false;
    
    while (temp) {
    	if ((temp.nodeType == 1) && hasChildElements(temp)) {
    		isComplexType = true;
    		break;
      }
      temp = temp.nextSibling;
    }	
  
    while (node) {
   
      switch (node.nodeType) {
        case nodeTypeElement : // Element
          element = this.rootElementOnly(node,target)
          target.appendChild(element);
          break;
        case nodeTypePI : // PI
          var pi = this.copyPi(node);
          if (isComplexContent) {
            pi.className = "simpleContent";
          }
          target.appendChild(pi);
          break;
        case nodeTypeComment : // Comment
          var comment = this.copyComment(node)
          if (isComplexContent) {
            comment.className = "simpleContent";
          }
          target.appendChild(comment);
          break;
      }
      node = node.nextSibling;
    }

  }

  this.printRootFragment = function (xml, target) {
  	
  	// Used when the document to be printed has been returned as the child of another element.
  	// Typically required when the document to be printed is embedded in a SOAP response
  		
    this.innerHTML = false;
    target.innerHTML = "";

    var div = document.createElement('div');
    target.appendChild(div);

    var node = xml.baseDocument;
  	node = node.firstChild;
    this.processRootElement(node,div);
  }

  this.printRoot = function(xml, target) {
  		
    this.innerHTML = false;
    target.innerHTML = "";

    var div = document.createElement('div');
    target.appendChild(div);

    var node = xml.baseDocument;
    if (node.nodeType == 9) {
    	node = node.firstChild;
    }
    this.processRootElement(node,div);
  }
  
}